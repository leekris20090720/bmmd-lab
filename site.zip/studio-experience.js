/* Read-only visual orchestration. The catalog, teaching controller and shared
 * mechanics core remain the only owners of actions, parameters and results. */
(function(global){
  'use strict';
  const node=typeof module==='object'&&module.exports,B=global.BM||{},M=node?require('./mechanics-core.js'):B.Mechanics;
  function curveData(model,params,baseline,progress,mode='arm'){
    const current=M.evaluate(model,params,progress);if(!current.valid)return {valid:false,reasons:current.reasons};
    const before=M.atCoordinate(model,baseline,model==='cam'?current.angleRad:current.displacementM);
    const cam=model==='cam',motion=cam&&mode==='motion',project=r=>({x:motion?r.angleRad:cam?r.effectiveArmM:r.displacementM,y:cam?r.torqueNm:r.forceN});
    const samples=motion?M.sample(model,params,61).map(project):cam?Array.from({length:61},(_,i)=>{const arm=M.bounds.cam.baseArmM[0]+(M.bounds.cam.baseArmM[1]-M.bounds.cam.baseArmM[0])*i/60;return project(M.evaluate('cam',{...params,baseArmM:arm},progress));}):M.sample(model,params,61).map(project);
    const reference=cam&&!motion?[]:M.sample(model,baseline,61).map(project);
    return {valid:true,model,kind:motion?'physical-angle':cam?'effective-arm-family':'physical-travel',xUnit:motion?'rad':'m',yUnit:cam?'N·m':'N',samples,reference,current:project(current),baseline:before.valid?project(before):null,result:current};
  }
  if(node){module.exports={curveData};return;}
  if(!M||!B.Didactics)return;
  const en=()=>B.i18n?.getLanguage()==='en',t=(zh,english)=>en()?english:zh;
  const $=s=>document.querySelector(s),NS='http://www.w3.org/2000/svg';
  let deck=null,cue=null,queued=0,focusKey='',lastCurveKey='',lastGraph=null;
  const setText=(el,text)=>{if(el&&el.textContent!==String(text))el.textContent=String(text);};
  function create(viewport){
    cue=document.createElement('aside');cue.className='studio-observation-cue';cue.setAttribute('aria-live','polite');cue.innerHTML='<span></span><strong></strong><p></p>';viewport.append(cue);
    deck=document.createElement('section');deck.className='studio-analysis';deck.hidden=true;deck.setAttribute('data-i18n-skip','');
    deck.innerHTML='<header class="studio-analysis-head"><div><small></small><h2></h2></div><span class="studio-model-badge"></span></header><div class="studio-analysis-figure"></div><p class="studio-analysis-caption"></p><div class="studio-linked-readouts"><div data-value="force"><small></small><strong></strong></div><div data-value="distance"><small></small><strong></strong></div><div data-value="result"><small></small><strong></strong></div></div><section class="studio-linked-chart"><header><h3></h3><span></span></header><svg id="studio-linked-curve" role="group" viewBox="0 0 640 192"></svg></section><footer class="studio-analysis-legend"></footer>';
    viewport.append(deck);
  }
  function clear(){if(deck){deck.hidden=true;deck.querySelector('.studio-analysis-figure').replaceChildren();}if(cue)cue.hidden=true;const viewport=$('.twin-pane');viewport?.removeAttribute('data-studio-principle');viewport?.removeAttribute('data-studio-observation');delete document.body.dataset.studioAction;focusKey='';}
  function spatialGraph(s){
    const current=s.spatial,project=v=>({x:v.params.angleDeg*Math.PI/180,y:v.result.torqueNm});
    const override=s.spatialBaseline?{pulley:s.spatialBaseline.pulley,ratio:s.spatialBaseline.ratio,massKg:s.spatialBaseline.massKg}:{};
    const samples=Array.from({length:61},(_,i)=>project(B.physics.readScene('arm',i/60*100))),reference=Array.from({length:61},(_,i)=>project(B.physics.readScene('arm',i/60*100,override)));
    return {valid:true,samples,reference,current:project(current),baseline:project(B.physics.readScene('arm',current.step,override)),xUnit:'rad',yUnit:'N·m'};
  }
  function graph(s){return s.spatial?spatialGraph(s):curveData(s.model,s.params,s.baseline,s.progress,s.curve);}
  function armFigure(s){
    const r=s.spatial.result,p=s.spatial.params,O={x:215,y:160},xy=v=>({x:O.x+v.x*105,y:O.y-v.y*105}),H=xy(p.handle),P=xy(p.pulley),u=r.uDir,h=p.handle,projection=h.x*u.x+h.y*u.y,foot={x:h.x-projection*u.x,y:h.y-projection*u.y},D=xy(foot),A=xy({x:h.x-u.x*1.2,y:h.y-u.y*1.2}),Z=xy({x:h.x+u.x*1.2,y:h.y+u.y*1.2}),force={x:H.x+u.x*57,y:H.y-u.y*57},phi=r.phiRad*180/Math.PI;
    return `<svg class="did-force-figure" viewBox="0 0 400 300" role="img" aria-label="${t('位置向量、钢索拉力与垂直力臂','Position vector, cable force and perpendicular arm')}"><defs><marker id="arm-force-tip" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#d97440"/></marker></defs><path d="M${O.x} ${O.y}v53" stroke="currentColor" opacity=".3" stroke-dasharray="3 3"/><path d="M${A.x} ${A.y}L${Z.x} ${Z.y}" stroke="#d97440" stroke-dasharray="5 4"/><path d="M${H.x} ${H.y}L${P.x} ${P.y}" stroke="currentColor" opacity=".2"/><path d="M${O.x} ${O.y}L${H.x} ${H.y}" stroke="#718293" stroke-width="7"/><path d="M${O.x} ${O.y}L${D.x} ${D.y}" stroke="#22a79b" stroke-width="3"/><path d="M${D.x+u.x*7} ${D.y-u.y*7}l${-u.y*7} ${-u.x*7}l${-u.x*7} ${u.y*7}" fill="none" stroke="#22a79b"/><path d="M${H.x} ${H.y}L${force.x} ${force.y}" stroke="#d97440" stroke-width="3" marker-end="url(#arm-force-tip)"/><circle cx="${O.x}" cy="${O.y}" r="7" fill="#8771d5"/><circle cx="${P.x}" cy="${P.y}" r="9" fill="none" stroke="currentColor"/><text x="12" y="26">θ ${p.angleDeg.toFixed(1)}° · φ ${phi.toFixed(1)}°</text><text x="12" y="51">T ${r.forceN.toFixed(2)} N</text><text x="12" y="76">d ${r.momentArmM.toFixed(3)} m</text><text x="${O.x-21}" y="${O.y-14}">O</text><text x="${H.x+9}" y="${H.y+20}">r</text><text x="${force.x+8}" y="${force.y}">F</text><text x="12" y="288">${t('理想支点与点负载；箭头固定长度示方向','Fixed arrow length shows direction')}</text></svg>`;
  }
  function armBoard(s,viewport){
    cue.hidden=true;deck.hidden=false;viewport.setAttribute('data-studio-principle','');viewport.removeAttribute('data-studio-observation');
    setText(deck.querySelector('.studio-analysis-head small'),s.name+' · '+t('方向改变，大小不变','DIRECTION CHANGES, TENSION FIXED'));
    setText(deck.querySelector('.studio-analysis-head h2'),t('分清 θ、φ 与垂直力臂','Distinguish θ, φ and the moment arm'));
    setText(deck.querySelector('.studio-model-badge'),t('模型几何 · 非人体检测','MODEL GEOMETRY · NO BODY TRACKING'));
    deck.querySelector('.studio-analysis-figure').innerHTML=armFigure(s);
    const r=s.spatial.result;
    for(const [id,label,value] of [['force','T · '+t('手柄拉力','handle tension'),r.forceN.toFixed(2)+' N'],['distance','d · '+t('垂直力臂','perpendicular arm'),r.momentArmM.toFixed(3)+' m'],['result','τ · '+t('理想支点力矩','ideal-pivot moment'),r.torqueNm.toFixed(3)+' N·m']]){const v=deck.querySelector('[data-value="'+id+'"]');setText(v.querySelector('small'),label);setText(v.querySelector('strong'),value);}
    setText(deck.querySelector('.studio-analysis-caption'),t('同一位置 r，不同拉力方向会改变 φ 和 d。这里计算 |r × F|，不是肌肉力或实测关节负荷。','At the same r, changing force direction changes φ and d. This is |r × F|, not muscle force or measured joint loading.'));
    deck.querySelector('.studio-linked-chart').hidden=false;setText(deck.querySelector('.studio-linked-chart h3'),t('沿抬臂角观察理想力矩','Ideal moment along arm elevation'));setText(deck.querySelector('.studio-linked-chart header span'),t('● 当前   ┄ 初始滑轮位置','● Current   ┄ Initial pulley position'));
    setText(deck.querySelector('.studio-analysis-legend'),t('灰 r：位置向量 · 橙 F：拉力 · 橙虚线：作用线 · 青 d：垂距 · 紫 O：理想支点。θ 从竖直向下量起，φ 为 r 与 F 的夹角。','Gray r: position · orange F: tension · orange dashes: force line · teal d: perpendicular arm · purple O: ideal pivot. θ is measured from downward vertical; φ is between r and F.'));
    deck.dataset.model='cable-angle';deck.dataset.result=JSON.stringify({forceN:r.forceN,momentArmM:r.momentArmM,torqueNm:r.torqueNm,theta:s.spatial.params.angleDeg,phi:r.phiRad});plot(s);
  }
  function pointData(s){
    if(s.spatial){const r=s.spatial,override=s.spatialBaseline?{pulley:s.spatialBaseline.pulley,ratio:s.spatialBaseline.ratio,massKg:s.spatialBaseline.massKg}:{},before=B.physics.readScene('arm',r.step,override);return {valid:true,current:{x:r.params.angleDeg*Math.PI/180,y:r.result.torqueNm},baseline:{x:before.params.angleDeg*Math.PI/180,y:before.result.torqueNm},xUnit:'rad',yUnit:'N·m'};}
    const r=s.result;if(!r?.valid)return {valid:false};const cam=s.model==='cam',motion=cam&&s.curve==='motion',project=v=>({x:motion?v.angleRad:cam?v.effectiveArmM:v.displacementM,y:cam?v.torqueNm:v.forceN}),before=M.atCoordinate(s.model,s.baseline,cam?r.angleRad:r.displacementM);
    return {valid:true,current:project(r),baseline:before.valid?project(before):null,xUnit:motion?'rad':'m',yUnit:cam?'N·m':'N'};
  }
  function plot(s){
    const svg=deck.querySelector('svg#studio-linked-curve'),compact=matchMedia('(max-width:760px)').matches,curveParams=s.model==='cam'&&s.curve!=='motion'?{...s.params,baseArmM:0}:s.params,key=JSON.stringify([s.model,s.spatial?[s.spatial.params.pulley,s.spatial.params.massKg,s.spatial.params.ratio]:curveParams,s.spatialBaseline||s.baseline,s.curve,en(),compact]);
    if(key!==lastCurveKey||!svg.firstChild){
      lastCurveKey=key;lastGraph=graph(s);if(!lastGraph.valid){svg.replaceChildren();return;}
      const g=lastGraph,points=[...g.samples,...g.reference],xmin=Math.min(0,...points.map(p=>p.x)),xmax=Math.max(.01,...points.map(p=>p.x)),lo=Math.min(0,...points.map(p=>p.y)),hi=Math.max(1,...points.map(p=>p.y)),pad=(hi-lo)*.12;
      const bottom=compact?134:146,sx=x=>54+(x-xmin)/Math.max(.001,xmax-xmin)*550,sy=y=>bottom-(y-lo)/(hi+pad-lo)*106;lastGraph.scale={sx,sy,bottom};svg.setAttribute('viewBox',compact?'0 0 640 230':'0 0 640 192');
      const path=rows=>rows.map((p,i)=>`${i?'L':'M'}${sx(p.x).toFixed(2)} ${sy(p.y).toFixed(2)}`).join(' ');
      let html='';const yt=B.Education.ticks(lo,hi,compact?3:5),angle=g.xUnit==='rad',xt=B.Education.ticks(angle?xmin*180/Math.PI:xmin,angle?xmax*180/Math.PI:xmax,compact?3:5);
      yt.values.forEach((y,i)=>{html+=`<path d="M54 ${sy(y)}H604" class="studio-plot-grid"/><text x="44" y="${sy(y)+4}" text-anchor="end">${yt.labels[i]}</text>`;});
      xt.values.forEach((x,i)=>{html+=`<text x="${sx(angle?x*Math.PI/180:x)}" y="${compact?176:166}" text-anchor="middle">${xt.labels[i]}${angle?'°':''}</text>`;});
      html+=`<text x="54" y="20">${s.model==='cam'||s.spatial?'τ (N·m)':'F (N)'}</text><text x="604" y="${compact?220:188}" text-anchor="end">${angle?t('角度 θ（显示°，内部rad）','Angle θ (°; rad internally)'):s.model==='cam'?t('垂直力臂 d (m)','Perpendicular arm d (m)'):t('实际行程 x (m)','Physical travel x (m)')}</text>`;
      if(g.reference.length)html+=`<path d="${path(g.reference)}" class="studio-plot-baseline"/>`;
      html+=`<path d="${path(g.samples)}" class="studio-plot-current"/><path data-baseline-cross class="studio-plot-baseline"/><path data-current-cross class="studio-plot-guide"/><circle data-baseline-point r="4" class="studio-baseline-point"/><circle data-current-point r="6" class="studio-current-point"/>`;
      html+=`<rect data-studio-seek x="54" y="35" width="550" height="110" fill="transparent" tabindex="0" role="slider" aria-label="${t('曲线位置：左右方向键移动','Curve position: use left/right arrows')}" aria-valuemin="0" aria-valuemax="100"/>`;svg.innerHTML=html;svg.setAttribute('aria-label',t('当前条件的曲线；灰色虚线为比较基准','Current condition curve; gray dashes mark the reference'));
      svg.dataset.quantity=s.model==='cam'||s.spatial?'torqueNm':'forceN';svg.dataset.xQuantity=angle?'angleRad':s.model==='cam'?'effectiveArmM':'displacementM';
    }
    const g=pointData(s);if(!g.valid||!lastGraph?.scale)return;
    const {sx,sy,bottom}=lastGraph.scale,current=svg.querySelector('[data-current-point]'),cross=svg.querySelector('[data-current-cross]'),base=svg.querySelector('[data-baseline-point]'),baseCross=svg.querySelector('[data-baseline-cross]');
    current.setAttribute('cx',sx(g.current.x));current.setAttribute('cy',sy(g.current.y));cross.setAttribute('d',`M${sx(g.current.x)} 40V${bottom}M54 ${sy(g.current.y)}H${sx(g.current.x)}`);
    base.setAttribute('visibility',g.baseline?'visible':'hidden');baseCross.setAttribute('visibility',g.baseline?'visible':'hidden');
    if(g.baseline){base.setAttribute('cx',sx(g.baseline.x));base.setAttribute('cy',sy(g.baseline.y));baseCross.setAttribute('d',`M${sx(g.baseline.x)} 40V${bottom}M54 ${sy(g.baseline.y)}H${sx(g.baseline.x)}`);}
    svg.querySelector('[data-studio-seek]').setAttribute('aria-valuenow',String(Math.round((s.spatial?s.spatial.step/100:s.model==='cam'&&s.curve!=='motion'?s.result.effectiveArmM/.4:s.progress)*100)));svg.dataset.current=JSON.stringify({...g.current,xUnit:g.xUnit,yUnit:g.yUnit});svg.dataset.baseline=JSON.stringify(g.baseline);
  }
  function update(){
    queued=0;const s=B.Didactics.presentation(),route=document.body.dataset.bmRoute||'',viewport=$('.twin-pane');
    if(!s||!viewport||route!=='action/'+s.id||s.model==='qualitative'){clear();return;}
    if(!deck)create(viewport);
    document.body.dataset.studioAction=s.id;
    if(s.mode==='physics'&&s.id==='arm'){armBoard(s,viewport);return;}
    if(s.mode==='physics'){
      cue.hidden=true;deck.hidden=false;viewport.setAttribute('data-studio-principle','');viewport.removeAttribute('data-studio-observation');
      const fresh=$('#bm-learning-panel #did-inline-diagram,#bm-learning-panel #did-other-diagram'),figure=deck.querySelector('.studio-analysis-figure');
      if(fresh&&fresh.parentNode!==figure)figure.replaceChildren(fresh);
      const head=deck.querySelector('.studio-analysis-head'),cam=s.model==='cam';
      setText(head.querySelector('small'),s.name+(cam?' · '+(s.intro+1)+' / 7':'')+' · '+t('分析对象 / 理想模型','ANALYSIS OBJECT / IDEAL MODEL'));
      setText(head.querySelector('h2'),matchMedia('(max-width:760px)').matches?(cam?t('这个力怎样让轴转动？','How does this force turn the shaft?'):s.model==='pulley'?t('少用力，需要拉多远？','Less force: how far must you pull?'):t('上推与下放，力为何不同？','Why do ascent and descent need different forces?')):cam?t('传动轴与刚性支臂','Shaft and rigid arm'):s.model==='pulley'?t('手柄与等效滑轮','Handle and equivalent pulley'):t('沿斜面运动的滑车','Sled on an incline'));
      setText(head.querySelector('.studio-model-badge'),t('模型示例 · 非实测','MODEL EXAMPLE · NOT MEASURED'));
      const tasks=['object','force','line','distance','vary','compare','meaning'];
      setText(deck.querySelector('.studio-analysis-caption'),cam?(s.curve==='motion'?t('彩色理想机构与曲线共享 θ；角度对应教学外壳范围，有效力臂函数仍是假设，不是实物标定。','The ideal mechanism and curve share θ in the teaching shell range. The effective-arm function remains assumed, not calibrated.'):B.Didactics.txt(tasks[s.intro])):s.model==='pulley'?t('同一配重与总抬升高度，比较拉力和手柄行程。','Keep load and total lift fixed; compare force and handle travel.'):t('上坡为外力正向；下放时保留功的符号。','Uphill force is positive; keep the sign of work on descent.'));
      const r=s.result,force=cam?r.forces.find(q=>q.id==='cable')?.magnitudeN:r.forceN;
      const values=[['force',cam?'F · '+t('指定拉力','specified force'):'F · '+t('外力','external force'),force.toFixed(1)+' N'],['distance',cam?'d · '+t('垂直力臂','perpendicular arm'):'x · '+t('当前位置','current position'),(cam?r.effectiveArmM:r.displacementM).toFixed(3)+' m'],['result',cam?'τ · '+t('轴上力矩','shaft torque'):'W · '+t('当前外力功','current input work'),(cam?r.torqueNm:r.energy.inputWorkJ).toFixed(2)+(cam?' N·m':' J')]];
      for(const [key,title,value] of values){const host=deck.querySelector(`[data-value="${key}"]`);setText(host.querySelector('small'),title);setText(host.querySelector('strong'),cam&&((key==='force'&&s.intro<1)||(key==='distance'&&s.intro<3)||(key==='result'&&s.intro<4))?'—':value);}
      const chart=deck.querySelector('.studio-linked-chart');chart.hidden=cam&&s.intro<4;
      setText(chart.querySelector('h3'),cam?(s.curve==='motion'?t('沿理想角度 θ，观察阻力矩','Follow ideal angle θ; observe torque'):t('保持 F，改变垂直力臂 d','Hold F; vary perpendicular arm d')):t('同一条件，曲线与读数同步','One condition, one synchronized curve'));
      setText(chart.querySelector('header span'),t('● 当前   ┄ 基准','● Current   ┄ Reference'));
      if(!chart.hidden)plot(s);
      setText(deck.querySelector('.studio-analysis-legend'),cam?t('橙色实箭头 F：力向量  ·  橙色虚线：作用线  ·  青色 └ d：垂直力臂  ·  紫色 O：转轴。箭头固定示方向，大小见 N。','Orange F: force vector · dashed orange: action line · teal └ d: perpendicular arm · purple O: pivot. Arrow indicates direction; read N for magnitude.'):t('蓝 F：外力  ·  橙 T / mg：钢索或重力  ·  紫 N：支承力  ·  金 f：摩擦。箭头共用当前帧线性比例；大小以 N 为准。','Blue F: external · orange T / mg: cable or gravity · purple N: support · gold f: friction. One linear arrow scale per frame; read N for magnitude.'));
      deck.dataset.step=String(s.intro);deck.dataset.model=s.model;deck.dataset.result=JSON.stringify({forceN:force,effectiveArmM:r.effectiveArmM,torqueNm:r.torqueNm,workJ:r.energy.inputWorkJ});
      return;
    }
    deck.hidden=true;deck.querySelector('.studio-analysis-figure').replaceChildren();viewport.removeAttribute('data-studio-principle');viewport.setAttribute('data-studio-observation','');cue.hidden=false;
    const step=s.mode==='setup'?1:s.step;setText(cue.querySelector('span'),s.name+' · '+String(step+1).padStart(2,'0')+' / 04 · '+t('观察任务','OBSERVATION'));
    setText(cue.querySelector('strong'),step===0?t('先辨认整体与关键部件','Locate the key parts'):step===1?t('先核对这一处位置','Check this setup position'):step===2?t('跟随当前运动部件','Follow the moving part'):t('对照一处情况，再做调整','Review one situation, then adjust'));
    setText(cue.querySelector('p'),s.partLabel||(t('点名称，模型中的对应位置会提亮。','Choose a label to highlight its actual model part.')));
    const key=[s.id,s.mode,s.step,s.part,step===2?s.phase:''].join('/');
    if(key!==focusKey){focusKey=key;if(s.part){if(step===2)B.equipmentInspection?.highlight(s.part,{contextual:true});else if(step===1)B.equipmentInspection?.select(s.part);document.querySelectorAll('.did-parts [data-part]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.part===s.part)));}}
  }
  function seekGraph(fraction){const s=B.Didactics.presentation();if(!s)return;if(s.spatial){const input=$('#arm-angle');input.value=String(fraction*90);input.dispatchEvent(new Event('input',{bubbles:true}));return;}if(s.model==='cam'&&s.curve!=='motion'){const input=$('[data-did-arm]');if(input){input.value=String(fraction*.4);input.dispatchEvent(new Event('input',{bubbles:true}));}return;}B.Didactics.seek(fraction);}
  document.addEventListener('pointerdown',event=>{if(!event.target.closest('[data-studio-seek]'))return;const svg=event.target.closest('svg'),point=new DOMPoint(event.clientX,event.clientY).matrixTransform(svg.getScreenCTM().inverse());seekGraph(Math.max(0,Math.min(1,(point.x-54)/550)));});
  document.addEventListener('keydown',event=>{if(!event.target.matches('[data-studio-seek]')||!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();const s=B.Didactics.presentation(),p=s.spatial?s.spatial.step/100:s.model==='cam'&&s.curve!=='motion'?s.result.effectiveArmM/.4:s.progress;seekGraph(event.key==='Home'?0:event.key==='End'?1:Math.max(0,Math.min(1,p+(event.key==='ArrowRight'?.05:-.05))));});
  document.addEventListener('input',event=>{if(event.target.matches('#arm-angle,[data-machine-key]'))schedule();});
  function schedule(){if(!queued)queued=requestAnimationFrame(update);}
  document.addEventListener('bm:didactics-view',schedule);
  document.addEventListener('bm:language-change',()=>{lastCurveKey='';schedule();});
  window.addEventListener('hashchange',schedule);
  window.addEventListener('resize',schedule);
  const observer=new MutationObserver(records=>{if(records.some(r=>r.type==='attributes'||r.target.id==='bm-learning-panel'||r.target.closest?.('#bm-learning-panel')))schedule();});
  observer.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['data-bm-route','data-learning-mode']});
  const pausePresentation=()=>{B.Didactics.pause();B.learningTeaching?.stop();};
  const viewport=$('.twin-pane');if(viewport)new IntersectionObserver(([entry])=>{if(!entry.isIntersecting)pausePresentation();}).observe(viewport);
  const dialog=$('#bm-dialog');if(dialog)new MutationObserver(()=>{if(dialog.open)pausePresentation();}).observe(dialog,{attributes:true,attributeFilter:['open']});
  new MutationObserver(()=>{if(document.body.hasAttribute('data-explore-open'))pausePresentation();}).observe(document.body,{attributes:true,attributeFilter:['data-explore-open']});
  schedule();
})(typeof window==='object'?window:globalThis);
