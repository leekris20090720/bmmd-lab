/* Site-integrated ports of React Bits SpotlightCard, TiltedCard, Magnet,
 * ClickSpark and ScrollReveal, plus Magic UI Border Beam. The source formulas
 * are retained; existing semantic nodes, routes and form handlers stay owned
 * by the product. Full credits: assets/vendor/reference-effects/*.md. */
(() => {
  'use strict';
  const B=window.BM=window.BM||{};
  const media=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
  const cardsSelector='.pd-home-directions>section,.pd-learn-tools>a,.pd-learn-tools>button,.pd-learn-feature,.pd-learn-shelf>a,.pd-course-directory>a,.pd-doors>a,.pd-learn-questions li>a,.pd-ex-theme li>a';
  const magnetsSelector='.pd-home-directions .pd-button,.pd-learn-feature .pd-button,#pd-header>div button';
  const clickSelector='#pd-header a,#pd-header button,.pd-home-directions a,.pd-home-directions button,.pd-learn-tools>a,.pd-learn-tools>button,.pd-learn-shelf>a,.pd-course-directory>a,.pd-doors>a,.pd-learn-questions a,.pd-main .pd-button';
  const beamSelector='.pd-home-directions>section,.pd-learn-discover,.pd-learn-feature,.pd-live-lab';
  const textSelector='.pd-learn-intro .pd-lead,.pd-learn-question-note,.pd-section-head h2';
  const shadowCards='.pg-gallery-info,.pg-wave-choice,.pg-choice,.pg-result,.pg-empty>button,.pg-home-explore';
  const shadowMagnets='.pg-gallery-primary,.pg-game-intro .pg-primary,.pg-home-search';
  const shadowClicks='.pg-dialog button:not(.pg-rhythm-target),.pg-home button';
  const shadowBeams='.pg-gallery-display,.pg-game,.pg-search-field,.pg-home-explore';
  const registeredRoots=new Map(),modalLayers=new WeakMap();
  const eventOrigin=event=>event.composedPath?.().find(node=>node instanceof Element)||event.target;
  const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
  const reduced=()=>media.matches||document.documentElement.classList.contains('pd-reduced');
  const active=()=>!reduced()&&!document.hidden;
  const stateMap=new WeakMap(),magnetMap=new WeakMap(),textMap=new WeakMap();
  let cards=[],magnets=[],texts=[],root=null,queued=0,frame=0,last=0,pointer=null,aurora=null,auroraHost=null,scrollFrame=0,sparkFrame=0;
  let bursts=[],lastPress={time:-10000,x:0,y:0},layer=null;
  // SpotlightCard's original Gaussian/smoothstep gradient falloff.
  function falloff(color,softness){
    const core=(1-softness)**1.5*.85;
    const stop=(a,t)=>`color-mix(in srgb, ${color} ${(a*100).toFixed(2)}%, transparent) ${(t*100).toFixed(2)}%`;
    const list=[stop(1,0)];
    for(let i=0;i<=14;i++){const t=core+(1-core)*i/14,g=(t-core)/(1-core),smooth=1-g*g*(3-2*g),glow=Math.exp(-4.6*g*g)*(1-g**6);list.push(stop(smooth+(glow-smooth)*softness,t));}
    return list.join(', ');
  }
  const fillStops=falloff('#92bcff',.7),edgeStops=falloff('#b3cfff',1);
  const decor=(name,parent)=>{const el=document.createElement('span');el.className=name;el.setAttribute('aria-hidden','true');parent.append(el);return el;};
  // TiltedCard's sub-stepped damped harmonic solver.
  function step(s,key,target,omega,zeta,dt){
    const velocity='v'+key,n=Math.max(1,Math.ceil(dt/(1/240))),h=dt/n;
    for(let i=0;i<n;i++){s[velocity]+=(omega*omega*(target-s[key])-2*zeta*omega*s[velocity])*h;s[key]+=s[velocity]*h;}
    const settled=Math.abs(target-s[key])<.001&&Math.abs(s[velocity])<.01;
    if(settled){s[key]=target;s[velocity]=0;}return !settled;
  }
  function cardState(el){
    let s=stateMap.get(el);if(s)return s;
    el.classList.add('ref-card');
    s={el,light:decor('ref-light',el),edge:decor('ref-edge',el),x:0,y:0,presence:0,flare:0,rx:0,vrx:0,ry:0,vry:0,lift:0,vlift:0,pressed:false,rect:null};
    decor('ref-glare',el);stateMap.set(el,s);return s;
  }
  function magnetState(el){
    let s=magnetMap.get(el);if(s)return s;
    el.classList.add('ref-magnet');s={el,x:0,y:0,vx:0,vy:0,rect:null};magnetMap.set(el,s);return s;
  }
  function resetCard(s){
    Object.assign(s,{presence:0,flare:0,rx:0,vrx:0,ry:0,vry:0,lift:0,vlift:0,pressed:false,rect:null});
    s.light.style.opacity=s.edge.style.opacity='0';
    ['--ref-rx','--ref-ry','--ref-scale','--ref-lift','--ref-glare'].forEach(p=>s.el.style.removeProperty(p));s.el.removeAttribute('data-ref-active');
  }
  function resetMagnet(s){s.x=s.y=s.vx=s.vy=0;s.rect=null;s.el.style.removeProperty('--ref-mx');s.el.style.removeProperty('--ref-my');s.el.removeAttribute('data-magnet-active');}
  function render(now){
    frame=0;if(!active()||!fine.matches)return;
    const dt=last?clamp((now-last)/1000,.001,1/30):1/60;last=now;
    let busy=false,focusedElement=document.activeElement;
    while(focusedElement?.shadowRoot?.activeElement)focusedElement=focusedElement.shadowRoot.activeElement;
    for(const s of cards){
      if(!s.el.isConnected)continue;
      const focused=!!focusedElement&&s.el.contains(focusedElement)&&focusedElement.matches(':focus-visible');
      const r=s.rect||(s.rect=s.el.getBoundingClientRect());
      const px=focused?r.width/2:pointer?pointer.x-r.left:s.x,py=focused?r.height/2:pointer?pointer.y-r.top:s.y;
      const gap=pointer?Math.hypot(Math.max(0,-px,px-r.width),Math.max(0,-py,py-r.height)):Infinity;
      const inside=!!pointer&&s.el.contains(pointer.target),present=focused?1:Math.max(0,1-gap/80)**2;
      if(present===0&&s.presence===0&&s.lift===0)continue;
      if(s.presence<.02&&present>0){s.x=px;s.y=py;}
      const follow=1-Math.exp(-dt/(.015+.3*.22));s.x+=(px-s.x)*follow;s.y+=(py-s.y)*follow;
      s.presence+=(present-s.presence)*(1-Math.exp(-dt/(present>s.presence?.1:.32)));
      if(Math.abs(present-s.presence)<.002)s.presence=present;
      const press=s.pressed?1:0;s.flare+=(press-s.flare)*(1-Math.exp(-dt/(press?.05:.28)));
      if(Math.abs(press-s.flare)<.002)s.flare=press;
      const nx=inside?clamp((px/r.width-.5)*2,-1,1):0,ny=inside?clamp((py/r.height-.5)*2,-1,1):0;
      const omega=20*Math.pow(.2,.6),zeta=1-.3*.6;
      busy=step(s,'rx',-ny*12,omega,zeta,dt)||busy;busy=step(s,'ry',nx*12,omega,zeta,dt)||busy;
      busy=step(s,'lift',inside||focused?1:0,omega,Math.max(zeta,.85),dt)||busy;
      const size=240*(1+.2*s.flare),boost=1+.7*s.flare;
      s.light.style.background=`radial-gradient(circle ${size.toFixed(1)}px at ${s.x.toFixed(1)}px ${s.y.toFixed(1)}px, ${fillStops})`;
      s.edge.style.background=`radial-gradient(circle ${(size*.6).toFixed(1)}px at ${s.x.toFixed(1)}px ${s.y.toFixed(1)}px, ${edgeStops})`;
      s.light.style.opacity=String(Math.min(1,s.presence*.22*boost));s.edge.style.opacity=String(Math.min(1,s.presence*.9*boost));
      s.el.style.setProperty('--ref-rx',s.rx.toFixed(3)+'deg');s.el.style.setProperty('--ref-ry',s.ry.toFixed(3)+'deg');
      s.el.style.setProperty('--ref-scale',(1+.025*s.lift).toFixed(4));s.el.style.setProperty('--ref-lift',s.lift.toFixed(3));
      s.el.style.setProperty('--ref-gx',(50+s.ry/12*46).toFixed(2)+'%');s.el.style.setProperty('--ref-gy',(50-s.rx/12*46).toFixed(2)+'%');
      s.el.style.setProperty('--ref-glare',(.5*Math.max(s.lift,Math.min(1,Math.hypot(s.rx,s.ry)/12))).toFixed(3));
      s.el.toggleAttribute('data-ref-active',inside||focused);
      busy=busy||Math.abs(px-s.x)>.1||Math.abs(py-s.y)>.1||s.presence!==present||s.flare!==press;
      if(!present&&!busy)s.rect=null;
    }
    // Magnet arbitration keeps adjacent buttons from pulling simultaneously.
    let winner=null,nearest=Infinity,closest=Infinity;
    if(pointer)for(const s of magnets){
      if(s.el.disabled||!s.el.isConnected||s.el.matches(':focus-visible'))continue;
      const r=s.rect||(s.rect=s.el.getBoundingClientRect()),dx=pointer.x-r.left-r.width/2,dy=pointer.y-r.top-r.height/2;
      const outside=Math.hypot(Math.max(0,Math.abs(dx)-r.width/2),Math.max(0,Math.abs(dy)-r.height/2));
      const center=Math.hypot(dx,dy);
      if(outside<=35&&(outside<nearest||(outside===nearest&&center<closest))){winner={s,dx,dy,outside};nearest=outside;closest=center;}
    }
    for(const s of magnets){
      let tx=0,ty=0;
      if(winner?.s===s){const f=clamp((winner.outside-17.5)/17.5),pull=1-f*f*(3-2*f);tx=winner.dx/2*pull;ty=winner.dy/2*pull;const length=Math.hypot(tx,ty);if(length>14){tx*=14/length;ty*=14/length;}}
      const steps=Math.ceil(dt/(1/120)),h=dt/steps;
      for(let i=0;i<steps;i++){s.vx+=(170*(tx-s.x)-16*s.vx)*h;s.x+=s.vx*h;s.vy+=(170*(ty-s.y)-16*s.vy)*h;s.y+=s.vy*h;}
      const moving=Math.abs(tx-s.x)>.05||Math.abs(ty-s.y)>.05||Math.abs(s.vx)>.05||Math.abs(s.vy)>.05;
      if(!moving){s.x=tx;s.y=ty;s.vx=s.vy=0;}
      s.el.style.setProperty('--ref-mx',s.x.toFixed(2)+'px');s.el.style.setProperty('--ref-my',s.y.toFixed(2)+'px');s.el.toggleAttribute('data-magnet-active',winner?.s===s);busy=moving||busy;
    }
    if(busy)frame=requestAnimationFrame(render);else last=0;
  }
  function wake(){if(!frame&&active()&&fine.matches)frame=requestAnimationFrame(render);}
  function beam(el){if(el.querySelector(':scope>.ref-border'))return;el.classList.add('ref-beam-host');const border=decor('ref-border',el);border.append(document.createElement('i'),document.createElement('i'));}
  function split(el){
    if(textMap.has(el))return textMap.get(el);
    const original=el.textContent,parts=[];
    if(!original.trim())return null;
    // Preserve existing markup and authored Latin word wrapping; split CJK by character.
    const walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),nodes=[];
    while(walker.nextNode())if(walker.currentNode.textContent.trim()&&!walker.currentNode.parentElement.closest('a,button,code,svg,math,output'))nodes.push(walker.currentNode);
    for(const node of nodes){const f=document.createDocumentFragment();for(const token of node.textContent.split(/(\s+|[\u3400-\u9fff\u3000-\u303f\uff00-\uffef])/u).filter(Boolean)){
      if(/^\s+$/.test(token)){f.append(document.createTextNode(token));continue;}
      const word=document.createElement('span'),piece=document.createElement('span');word.className='ref-reveal-word';piece.className='ref-reveal-piece';word.setAttribute('aria-hidden','true');piece.textContent=token;word.append(piece);f.append(word);parts.push(piece);
    }node.replaceWith(f);}
    if(!parts.length)return null;
    el.classList.add('ref-reveal');el.setAttribute('aria-label',original.trim());const record={el,parts};textMap.set(el,record);return record;
  }
  function scroll(){
    scrollFrame=0;if(!root)return;
    const bounds=root.getBoundingClientRect(),view=root.clientHeight;
    for(const {el,parts} of texts){
      if(!el.isConnected)continue;const r=el.getBoundingClientRect();
      const start=view-.2*Math.min(r.height,view),end=view*.55;
      const p=reduced()?1:clamp((start-(r.top-bounds.top))/Math.max(1,start-end));
      const at=p*(.5+Math.max(0,parts.length-1)*.05);
      parts.forEach((piece,i)=>{const t=clamp((at-i*.05)/.5);piece.style.setProperty('--ref-word-opacity',(.1+.9*t).toFixed(3));piece.style.setProperty('--ref-word-blur',(4*(1-t)).toFixed(2)+'px');});
    }
  }
  function requestScroll(){if(!scrollFrame)scrollFrame=requestAnimationFrame(scroll);}
  function prepare(){
    queued=0;const route=document.body.dataset.bmRoute||'home';
    root=document.getElementById(route==='home'?'portal-hub-overlay':'product-root');if(!root)return;
    const exploring=document.body.hasAttribute('data-explore-open');
    const cardElements=route.startsWith('train/')||exploring?[]:[...root.querySelectorAll(cardsSelector)];
    const magnetElements=route==='train/session'||exploring?[]:[...document.querySelectorAll(magnetsSelector)];
    for(const shadow of registeredRoots.keys()){
      if(exploring&&shadow.host.id==='bm-explore-home')continue;
      cardElements.push(...[...shadow.querySelectorAll(shadowCards)].filter(el=>el.getClientRects().length));
      magnetElements.push(...shadow.querySelectorAll(shadowMagnets));
      shadow.querySelectorAll(shadowBeams).forEach(beam);
    }
    cards=cardElements.map(cardState);
    magnets=magnetElements.filter(el=>el.getClientRects().length).map(magnetState);
    root.querySelectorAll(beamSelector).forEach(beam);texts=[...root.querySelectorAll(textSelector)].map(split).filter(Boolean);
    visibility.disconnect();root.querySelectorAll('.ref-beam-host').forEach(el=>visibility.observe(el));
    for(const shadow of registeredRoots.keys())shadow.querySelectorAll('.ref-beam-host').forEach(el=>visibility.observe(el));
    const stage=document.getElementById('portal-welcome-stage');
    if(stage&&!auroraHost){auroraHost=document.createElement('div');auroraHost.className='ref-aurora';auroraHost.setAttribute('aria-hidden','true');stage.prepend(auroraHost);
      try{aurora=B.ReferenceAurora?.mount(auroraHost,{stops:['#5464ed','#80a9ff','#ad79f7'],height:.47,speed:1.1,layers:2,brightness:.8,dpr:innerWidth<640?1:1.25});}catch{aurora=null;}
      if(aurora)document.documentElement.classList.add('ref-aurora-ready');else auroraHost.hidden=true;
    }
    document.documentElement.classList.add('ref-effects-ready');
    document.documentElement.dataset.refCards=String(cards.length);document.documentElement.dataset.refEffects='aurora spotlight tilt magnet sparks border-beam scroll-reveal';
    sync();requestScroll();
  }
  function schedule(){if(!queued)queued=requestAnimationFrame(prepare);}
  // ClickSpark's line shape, ease-out travel, life jitter and ring formulas.
  function sparks(now){
    sparkFrame=0;
    for(const b of [...bursts]){
      const ctx=b.ctx,elapsed=now-b.start;ctx.clearRect(0,0,b.canvas.width,b.canvas.height);ctx.setTransform(b.ratio,0,0,b.ratio,b.size*b.ratio,b.size*b.ratio);
      let alive=false;
      for(const p of b.sparks){const t=elapsed/(500*p.life);if(t>=1)continue;alive=true;
        const e=1-Math.pow(1-clamp(t),3),distance=30*p.reach*e,length=14*p.scale*Math.pow(1-t,1.6),f=clamp((t-.55)/.45),fade=1-f*f*(3-2*f);
        ctx.strokeStyle=p.color;ctx.lineCap='round';ctx.lineWidth=2*p.scale;ctx.globalAlpha=fade;ctx.beginPath();ctx.moveTo(Math.cos(p.angle)*distance,Math.sin(p.angle)*distance);ctx.lineTo(Math.cos(p.angle)*(distance+length),Math.sin(p.angle)*(distance+length));ctx.stroke();
      }
      const rt=elapsed/400;if(rt<1){const radius=2+18*(1-Math.pow(1-rt,3));ctx.strokeStyle='#bcd5ff';ctx.lineWidth=Math.max(.5,2*(1-rt)*.9);ctx.globalAlpha=Math.pow(1-rt,2)*.7;ctx.beginPath();ctx.arc(0,0,radius,0,Math.PI*2);ctx.stroke();alive=true;}
      ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;
      if(!alive){b.canvas.remove();bursts.splice(bursts.indexOf(b),1);}
    }
    if(bursts.length)sparkFrame=requestAnimationFrame(sparks);
  }
  function spawn(x,y,origin){
    if(!active()||document.body.dataset.bmRoute==='train/session')return;
    const modal=origin?.closest?.('dialog[open]');let destination=layer,offsetX=0,offsetY=0;
    if(modal){
      destination=modalLayers.get(modal);
      if(!destination){destination=decor('ref-spark-layer ref-spark-modal',modal);modalLayers.set(modal,destination);}
      const box=modal.getBoundingClientRect();offsetX=box.left+modal.clientLeft;offsetY=box.top+modal.clientTop;
    }else if(!layer){layer=document.createElement('div');layer.className='ref-spark-layer';layer.setAttribute('aria-hidden','true');document.body.append(layer);destination=layer;}
    const size=64,ratio=Math.min(devicePixelRatio||1,2),canvas=document.createElement('canvas');canvas.width=canvas.height=size*2*ratio;
    Object.assign(canvas.style,{left:x-offsetX-size+'px',top:y-offsetY-size+'px',width:size*2+'px',height:size*2+'px'});canvas.setAttribute('aria-hidden','true');destination.append(canvas);
    const ctx=canvas.getContext('2d');if(!ctx){canvas.remove();return;}
    const colors=['#9cc4ff','#d0bcff','#edf5ff'],offset=Math.floor(Math.random()*colors.length);
    const pieces=Array.from({length:8},(_,i)=>({angle:-Math.PI/2+Math.PI*2/8*i+(Math.random()-.5)*.2*(Math.PI*2/8)*.9,reach:1+(Math.random()-.5)*.7*.2,scale:1+(Math.random()-.5)*.8*.2,life:1+(Math.random()-.5)*.5*.2,color:colors[(i+offset)%colors.length]}));
    bursts.push({canvas,ctx,ratio,size,sparks:pieces,start:performance.now()});while(bursts.length>12)bursts.shift().canvas.remove();
    if(!sparkFrame)sparkFrame=requestAnimationFrame(sparks);
  }
  function clickTarget(event){const el=eventOrigin(event)?.closest?.(clickSelector+','+shadowClicks);return el&&!el.disabled&&!el.closest('[inert]')?el:null;}
  document.addEventListener('pointermove',e=>{if(e.pointerType==='touch'||!fine.matches)return;pointer={x:e.clientX,y:e.clientY,target:eventOrigin(e)};wake();},{passive:true});
  document.addEventListener('pointerout',e=>{if(!e.relatedTarget){pointer=null;wake();}},{passive:true});
  document.addEventListener('pointerdown',e=>{const card=eventOrigin(e)?.closest?.('.ref-card'),s=card&&stateMap.get(card);if(s){s.pressed=true;wake();}const target=clickTarget(e);if(e.pointerType==='mouse'&&e.button===0&&target){lastPress={time:performance.now(),x:e.clientX,y:e.clientY};spawn(e.clientX,e.clientY,target);}},{passive:true});
  function release(){cards.forEach(s=>s.pressed=false);wake();}
  document.addEventListener('pointerup',release,{passive:true});document.addEventListener('pointercancel',release,{passive:true});window.addEventListener('blur',()=>{pointer=null;release();});
  document.addEventListener('click',e=>{const el=clickTarget(e);if(!el)return;if(e.detail===0){const r=el.getBoundingClientRect();spawn(r.left+r.width/2,r.top+r.height/2,el);}else if(performance.now()-lastPress.time>700||Math.hypot(e.clientX-lastPress.x,e.clientY-lastPress.y)>12)spawn(e.clientX,e.clientY,el);});
  document.addEventListener('focusin',wake);document.addEventListener('focusout',wake);
  document.addEventListener('scroll',e=>{if(!root?.contains(e.target)&&e.target!==root)return;cards.forEach(s=>s.rect=null);magnets.forEach(s=>s.rect=null);wake();requestScroll();},{capture:true,passive:true});
  function sync(){
    const off=reduced(),hidden=document.hidden;document.documentElement.classList.toggle('ref-effects-reduced',off);document.documentElement.classList.toggle('ref-paused',off||hidden);
    aurora?.setPaused(off||hidden||document.body.dataset.bmRoute!=='home'||document.body.hasAttribute('data-explore-open'));
    for(const shadow of registeredRoots.keys()){shadow.host.setAttribute('data-pg-reduced',String(off));shadow.host.setAttribute('data-pg-paused',String(off||hidden||(shadow.host.id==='bm-explore-home'&&document.body.hasAttribute('data-explore-open'))));}
    if(off||hidden||!fine.matches){cancelAnimationFrame(frame);frame=last=0;cards.forEach(resetCard);magnets.forEach(resetMagnet);cancelAnimationFrame(sparkFrame);sparkFrame=0;bursts.forEach(b=>b.canvas.remove());bursts=[];}else wake();requestScroll();
  }
  const visibility=new IntersectionObserver(entries=>{for(const e of entries)e.target.classList.toggle('ref-offscreen',!e.isIntersecting);},{rootMargin:'50px'});
  const routeObserver=new MutationObserver(()=>{cards.forEach(resetCard);magnets.forEach(resetMagnet);pointer=null;schedule();});routeObserver.observe(document.body,{attributes:true,attributeFilter:['data-bm-route','data-explore-open']});
  const prefsObserver=new MutationObserver(sync);prefsObserver.observe(document.documentElement,{attributes:true,attributeFilter:['class']});
  const contentObserver=new MutationObserver(records=>{if(records.some(r=>[...r.addedNodes].some(n=>n.nodeType===1&&!n.matches('[class^="ref-"],.cm-word,.cm-char,.cm-button-light,.pd-click-wave')&&(n.matches(cardsSelector+',.pd-content,.pd-main')||n.querySelector?.(cardsSelector)))))schedule();});
  for(const id of ['product-root','portal-welcome-stage']){const el=document.getElementById(id);if(el)contentObserver.observe(el,{childList:true,subtree:true});}
  window.addEventListener('bm:page-ready',schedule);window.addEventListener('resize',()=>{cards.forEach(s=>s.rect=null);magnets.forEach(s=>s.rect=null);schedule();},{passive:true});
  media.addEventListener('change',sync);fine.addEventListener('change',sync);document.addEventListener('visibilitychange',sync);window.addEventListener('pageshow',schedule);
  window.addEventListener('pagehide',()=>{cancelAnimationFrame(frame);cancelAnimationFrame(queued);cancelAnimationFrame(scrollFrame);frame=queued=scrollFrame=0;aurora?.setPaused(true);});
  function registerRoot(shadow){
    let released=false;const release=()=>{if(released)return;released=true;unregisterRoot(shadow);};
    const known=registeredRoots.get(shadow);if(known){known.users++;return release;}
    const changed=()=>{cards.forEach(s=>s.rect=null);magnets.forEach(s=>s.rect=null);wake();};
    const observer=new MutationObserver(records=>{if(records.some(r=>[...r.addedNodes,...r.removedNodes].some(n=>n.nodeType===1&&!n.matches('[class^="ref-"],.bm-text-fx-layer,.bm-text-char,.bm-text-word')&&(n.matches(shadowCards+','+shadowMagnets+','+shadowBeams)||n.querySelector?.(shadowCards+','+shadowMagnets+','+shadowBeams)))))schedule();});
    observer.observe(shadow,{childList:true,subtree:true});shadow.addEventListener('scroll',changed,{capture:true,passive:true});
    registeredRoots.set(shadow,{observer,changed,users:1});schedule();
    return release;
  }
  function unregisterRoot(shadow){
    const entry=registeredRoots.get(shadow);if(!entry||--entry.users>0)return;
    entry.observer.disconnect();shadow.removeEventListener('scroll',entry.changed,true);registeredRoots.delete(shadow);
    cards.filter(s=>s.el.getRootNode()===shadow).forEach(resetCard);magnets.filter(s=>s.el.getRootNode()===shadow).forEach(resetMagnet);
    for(const b of [...bursts])if(b.canvas.getRootNode()===shadow){b.canvas.remove();bursts.splice(bursts.indexOf(b),1);}
    schedule();
  }
  B.ReferenceEffects={ownsCard:el=>!!el?.matches?.(cardsSelector),ownsMagnet:el=>!!el?.matches?.(magnetsSelector),ownsClick:el=>!!el?.matches?.(clickSelector),refresh:schedule,registerRoot};
  prepare();
})();
