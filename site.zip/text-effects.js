/* BM//MD text motion: one effect per data-text-fx element, no animation library.
 * T01 is owned by the existing halftone renderer. This module records its hook.
 * T11/T12: data-fx-phrases='["短语一","短语二"]', data-fx-static="完整静态表达".
 * T14: a number-only element, data-fx-value="4"; keep units in a sibling.
 * T07: data-fx-variable="true" only with a verified variable font in its CSS.
 * T09: real button/link descendants. T18: .bm-text-circle-ring and -arrow.
 * T19: real button, aria-expanded, .bm-text-reveal-front / -back / -hint.
 * data-fx-key supplies a session-once identity across native page remounts.
 */
(function () {
  'use strict';
  window.BM = window.BM || {};
  if (window.BM.textFx) return;
  const config = Object.freeze({
    duration: 500, titleDuration: 650, splitDuration: 800, splitStagger: 360, particleDuration: 1000, particleScatter: 22, revealDuration: 550, countDuration: 650,
    decodeDuration: 540, decodeFrame: 45, countFrame: 40, glitchDuration: 360, phraseDuration: 440,
    shineDuration: 950, highlightDuration: 650, pointerDuration: 600, colourDuration: 650,
    typeDuration: 1100, typeStep: 55, caretDuration: 1500,
    phraseHold: 4600, focusDemoDelay: 1100, focusDemoStep: 700, circleDuration: 26000, hoverDuration: 180,
    continuousBudget: 2,
    ease: 'cubic-bezier(.22,.68,.25,1)', maxBlur: 3,
    colours: ['#2575ba', '#168aaf', '#5b9cca'], variableWeight: [400, 720],
    mobile: 'static-pointer-effects', once: ['T01','T04','T05','T09','T10','T13','T15','T20'],
  });
  const selector = '[data-text-fx],[data-text-upgrade]';
  const validUpgrade = (value) => /^U(?:0[1-9]|10)$/.test(value || '');
  const upgradeRenderers = Object.freeze({ U01: 'material', U02: 'halftone', U03: 'stroke', U04: 'depth', U06: 'fold', U09: 'stroke' });
  function effectiveUpgrade(el) {
    const candidate = el.dataset.textUpgrade;
    if (!validUpgrade(candidate)) return null;
    const renderer = el.dataset.headingRenderer;
    // A live ownership change must settle and remove this renderer before the
    // heading observer mounts its next Canvas/HTML owner on the following frame.
    return renderer !== undefined && upgradeRenderers[candidate] && renderer !== upgradeRenderers[candidate] ? null : candidate;
  }
  // Exact Inter variable wght 800 outlines, extracted with CoreText; SIL OFL 1.1.
  const brandGlyphs = {"text":"BM//MD","viewBox":"-15 -52 4103.28 909","glyphs":[{"char":"B","d":"M56.72 727.54L56.72 0L358.32 0Q439.69 0 494.63 23.34Q549.57 46.68 577.27 88.15Q604.97 129.63 604.97 184.33Q604.97 226.01 587.62 258.57Q570.27 291.13 539.83 312.35Q509.39 333.57 469.49 342L469.49 349.57Q513.32 351.15 550.6 372.82Q587.88 394.49 610.58 433.12Q633.29 471.74 633.29 524.41Q633.29 582.81 603.87 628.8Q574.46 674.78 518.15 701.16Q461.84 727.54 381.1 727.54ZM228.9 588.36L340.43 588.36Q398.3 588.36 426.03 566.03Q453.75 543.71 453.75 504.88Q453.75 476.43 440.39 455.5Q427.03 434.57 402.37 423.07Q377.72 411.56 343.83 411.56L228.9 411.56ZM228.9 300.04L328.95 300.04Q357.99 300.04 380.63 290.23Q403.28 280.41 416.27 261.98Q429.26 243.55 429.26 217.46Q429.26 180.86 402.98 159.28Q376.7 137.7 331.88 137.7L228.9 137.7Z"},{"char":"M","d":"M721.4 727.54L721.4 0L989.81 0L1082.54 283.08Q1090.37 309.22 1100.47 351.76Q1110.56 394.29 1120.71 443.21Q1130.86 492.13 1139.53 537.64Q1148.2 583.16 1153.43 615.62L1120.68 615.62Q1126.04 583.51 1134.52 538.11Q1143 492.71 1153.15 443.74Q1163.3 394.76 1173.27 352.05Q1183.24 309.33 1191.08 283.08L1282.48 0L1551.37 0L1551.37 727.54L1378.04 727.54L1378.04 414.06Q1378.04 389.75 1379.03 351.47Q1380.02 313.2 1381.31 268.1Q1382.6 223.01 1383.7 177.3Q1384.8 131.6 1384.93 92.31L1395.33 92.31Q1386.19 135.64 1374.9 182.06Q1363.62 228.48 1352.07 272.45Q1340.53 316.43 1330.02 353.12Q1319.51 389.81 1311.93 414.06L1208.71 727.54L1064.69 727.54L959.77 414.06Q952.19 389.92 941.61 353.41Q931.04 316.89 919.12 273.04Q907.21 229.18 895.68 182.65Q884.14 136.12 874.16 92.31L887.03 92.31Q887.27 130.78 888.37 176.25Q889.47 221.72 890.7 266.99Q891.94 312.26 892.98 350.83Q894.03 389.4 894.03 414.06L894.03 727.54Z"},{"char":"/","d":"M1997.93 -34.18L1763.56 836.91L1617.93 836.91L1852.3 -34.18Z"},{"char":"/","d":"M2397.62 -34.18L2163.25 836.91L2017.62 836.91L2251.99 -34.18Z"},{"char":"M","d":"M2464.18 727.54L2464.18 0L2732.58 0L2825.32 283.08Q2833.14 309.22 2843.24 351.76Q2853.34 394.29 2863.49 443.21Q2873.63 492.13 2882.3 537.64Q2890.98 583.16 2896.21 615.62L2863.46 615.62Q2868.81 583.51 2877.3 538.11Q2885.78 492.71 2895.93 443.74Q2906.07 394.76 2916.05 352.05Q2926.02 309.33 2933.85 283.08L3025.25 0L3294.14 0L3294.14 727.54L3120.82 727.54L3120.82 414.06Q3120.82 389.75 3121.81 351.47Q3122.79 313.2 3124.08 268.1Q3125.37 223.01 3126.48 177.3Q3127.58 131.6 3127.7 92.31L3138.11 92.31Q3128.97 135.64 3117.68 182.06Q3106.39 228.48 3094.85 272.45Q3083.3 316.43 3072.8 353.12Q3062.29 389.81 3054.71 414.06L2951.48 727.54L2807.46 727.54L2702.54 414.06Q2694.96 389.92 2684.39 353.41Q2673.81 316.89 2661.9 273.04Q2649.99 229.18 2638.45 182.65Q2626.91 136.12 2616.94 92.31L2629.81 92.31Q2630.04 130.78 2631.15 176.25Q2632.25 221.72 2633.48 266.99Q2634.71 312.26 2635.76 350.83Q2636.8 389.4 2636.8 414.06L2636.8 727.54Z"},{"char":"D","d":"M3675.08 727.54L3481.48 727.54L3481.48 580.19L3667.73 580.19Q3730.26 580.19 3773.39 559.06Q3816.52 537.93 3838.65 490.22Q3860.78 442.52 3860.78 363.79Q3860.78 284.92 3838.34 237.39Q3815.9 189.87 3772.49 168.61Q3729.08 147.35 3665.39 147.35L3478.33 147.35L3478.33 0L3675.08 0Q3785.98 0 3866.06 43.64Q3946.14 87.29 3989.58 168.77Q4033.01 250.25 4033.01 363.79Q4033.01 477.19 3989.7 558.79Q3946.39 640.39 3866.15 683.96Q3785.92 727.54 3675.08 727.54ZM3579.77 0L3579.77 727.54L3407.58 727.54L3407.58 0Z"}]};
  let svgSerial = 0;
  const scriptURL = document.currentScript && document.currentScript.src;
  const styleURL = new URL('text-effects.css', scriptURL || document.baseURI).href;
  const states = new Map(), roots = new Map(), seen = new Set(), countValues = new Map();
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const fine = matchMedia('(hover: hover) and (pointer: fine)');
  const compact = matchMedia('(max-width: 480px)');
  let manuallyPaused = false, destroyed = false, pointerFrame = 0, activeDialog = null, dialogOrder = 0;
  let knownDialogs = new Set();
  const dialogOrders = new WeakMap();
  const pointerQueue = new Set();
  const eligible = (s) => !destroyed && !reduced.matches && !manuallyPaused &&
    !document.hidden && s.visible && s.el.isConnected && !s.blocked;
  const active = (s) => eligible(s) && !s.budgetPaused;
  const continuous = (s) => s.upgrade === 'U01' && !compact.matches || s.type === 'T03' ||
    ((s.type === 'T11' || s.type === 'T12') && s.phrases && s.phrases.length > 1) ||
    (s.type === 'T18' && !compact.matches);
  const continuousPriority = (s) => s.type === 'T11' || s.type === 'T12' ? 0 : s.type === 'T18' ? 1 : 2;
  function composedContains(container, node) {
    for (let current = node; current;) {
      if (container === current || container.contains(current)) return true;
      const root = current.getRootNode();
      current = root && root.host || null;
    }
    return false;
  }
  function hiddenAncestor(node) {
    for (let current = node; current;) {
      if (current.closest && current.closest('[hidden],[inert]')) return true;
      const root = current.getRootNode();
      current = root && root.host || null;
    }
    return false;
  }
  function cacheVisibilityContext() {
    const openDialogs = [];
    // Native document selectors cannot enter React's shadow roots. Discover
    // open dialogs once per refresh, then cache the result for pointer events.
    for (const root of roots.keys()) {
      for (const dialog of root.querySelectorAll('dialog[open]')) {
        if (dialog.isConnected && !hiddenAncestor(dialog)) {
          openDialogs.push(dialog);
          if (!knownDialogs.has(dialog)) dialogOrders.set(dialog, ++dialogOrder);
        }
      }
    }
    knownDialogs = new Set(openDialogs);
    activeDialog = openDialogs.sort((a, b) => dialogOrders.get(b) - dialogOrders.get(a))[0] || null;
    for (const s of states.values()) s.blocked = hiddenAncestor(s.el) ||
      !!(activeDialog && !composedContains(activeDialog, s.el));
  }
  function allocateContinuousBudget() {
    const candidates = [...states.values()].filter((s) => eligible(s) && continuous(s) && !s.interactionPaused)
      .sort((a, b) => continuousPriority(a) - continuousPriority(b));
    const allowed = new Set();
    let phraseChosen = false;
    for (const s of candidates) {
      const phrase = s.type === 'T11' || s.type === 'T12';
      // T11 and T12 never rotate together, even if two registered roots overlap.
      if (allowed.size >= config.continuousBudget || phrase && phraseChosen) continue;
      allowed.add(s); if (phrase) phraseChosen = true;
    }
    for (const s of states.values()) s.budgetPaused = eligible(s) && continuous(s) && !allowed.has(s);
  }
  const element = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  };
  const own = (s, node) => { s.owned.push(node); return node; };
  const listen = (s, target, name, handler, options) => {
    target.addEventListener(name, handler, options);
    s.cleanups.push(() => target.removeEventListener(name, handler, options));
  };
  function timer(s, fn, delay) {
    const id = setTimeout(() => {
      s.timers.delete(id);
      if (!s.dead) fn();
      publishDiagnostics();
    }, delay);
    s.timers.add(id);
    publishDiagnostics();
    return id;
  }
  function stopTimers(s) {
    for (const id of s.timers) clearTimeout(id);
    s.timers.clear();
  }
  function animate(s, target, frames, options) {
    if (!target.animate || !active(s)) return null;
    const animation = target.animate(frames, { duration: config.duration, easing: config.ease, ...options });
    s.animations.add(animation);
    const finished = () => { s.animations.delete(animation); publishDiagnostics(); };
    animation.finished.then(finished, finished);
    publishDiagnostics();
    return animation;
  }
  function onceKey(s) {
    const key = s.el.dataset.fxKey;
    return key ? (s.upgrade || s.type) + ':' + key : null;
  }
  function played(s) {
    if (s.played) return true;
    const key = onceKey(s);
    if (!key) return false;
    if (seen.has(key)) return true;
    try { return sessionStorage.getItem('bm-text-fx:' + key) === '1'; } catch (_) { return false; }
  }
  function markPlayed(s) {
    s.played = true;
    const key = onceKey(s);
    if (!key) return;
    seen.add(key);
    try { sessionStorage.setItem('bm-text-fx:' + key, '1'); } catch (_) { /* private/file origins remain functional */ }
  }
  function preserveChildren(s) {
    if (!s.originalNodes) s.originalNodes = Array.from(s.el.childNodes);
    s.el.replaceChildren();
  }
  function split(s) {
    const text = s.el.textContent || '';
    preserveChildren(s);
    const accessible = own(s, element('span', 'bm-text-sr', text));
    const visual = own(s, element('span', 'bm-text-letters'));
    visual.setAttribute('aria-hidden', 'true');
    s.chars = Array.from(text, (char, index) => {
      const span = element('span', 'bm-text-letter', char === ' ' ? '\u00a0' : char);
      span.style.setProperty('--bm-letter-index', index);
      visual.append(span);
      return span;
    });
    s.letterVisual = visual;
    s.el.append(accessible, visual);
  }
  function decorate(s, className) {
    const node = own(s, element('span', className, s.plainText));
    node.setAttribute('aria-hidden', 'true');
    s.el.append(node);
    return node;
  }
  function svgElement(tag, attrs) {
    const node = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (const [name, value] of Object.entries(attrs || {})) node.setAttribute(name, String(value));
    return node;
  }
  function cancelAnimations(s) {
    for (const animation of s.animations) animation.cancel();
    s.animations.clear();
  }
  function setupBrandPaths(s) {
    // Only the supplied, verified Latin brand has a path renderer. Unknown text
    // immediately remains real HTML rather than a guessed or clipped glyph.
    if (s.plainText.trim() !== brandGlyphs.text) return false;
    const svg = svgElement('svg', { viewBox: brandGlyphs.viewBox, 'aria-hidden': 'true', focusable: 'false', class: 'bm-upgrade-path-svg', preserveAspectRatio: 'xMidYMid meet' });
    const defs = svgElement('defs');
    const gradientId = 'bm-text-metal-' + (++svgSerial);
    const gradient = svgElement('linearGradient', { id: gradientId, x1: '0', y1: '0', x2: '.35', y2: '1' });
    for (const [offset, className] of [['0','dark'],['.23','mid'],['.45','light'],['.50','dark'],['.69','mid'],['.87','light'],['1','dark']]) {
      gradient.append(svgElement('stop', { offset, class: 'bm-upgrade-metal-stop-' + className }));
    }
    defs.append(gradient); svg.append(defs);
    const base = svgElement('g', { class: 'bm-upgrade-path-base' });
    const fill = svgElement('g', { class: 'bm-upgrade-path-fill', fill: 'url(#' + gradientId + ')' });
    const detail = svgElement('g', { class: s.upgrade === 'U03' ? 'bm-upgrade-path-trace' : 'bm-upgrade-path-technical' });
    if (s.upgrade === 'U09') {
      const maskId = 'bm-text-tech-surface-' + svgSerial;
      const apertureId = 'bm-text-tech-window-' + svgSerial;
      const mask = svgElement('mask', { id: maskId, maskUnits: 'userSpaceOnUse', maskContentUnits: 'userSpaceOnUse', x: -15, y: -52, width: 4103.28, height: 909, 'mask-type': 'luminance' });
      mask.append(svgElement('rect', { x: -15, y: -52, width: 4103.28, height: 909, fill: 'white' }));
      s.technicalMaskCircle = svgElement('circle', { class: 'bm-upgrade-tech-mask-hole', cx: 2036.64, cy: 402.5, r: 0, fill: 'black' });
      mask.append(s.technicalMaskCircle);
      const aperture = svgElement('clipPath', { id: apertureId, clipPathUnits: 'userSpaceOnUse' });
      s.technicalClipCircle = svgElement('circle', { class: 'bm-upgrade-tech-aperture', cx: 2036.64, cy: 402.5, r: 0 });
      aperture.append(s.technicalClipCircle); defs.append(mask, aperture);
      base.setAttribute('mask', 'url(#' + maskId + ')'); fill.setAttribute('mask', 'url(#' + maskId + ')');
      detail.style.clipPath = 'url(#' + apertureId + ')';
    }
    s.pathTraces = [];
    for (const glyph of brandGlyphs.glyphs) {
      base.append(svgElement('path', { d: glyph.d, 'data-glyph': glyph.char, 'vector-effect': 'non-scaling-stroke' }));
      fill.append(svgElement('path', { d: glyph.d, 'data-glyph': glyph.char, 'vector-effect': 'non-scaling-stroke' }));
      const trace = svgElement('path', { d: glyph.d, 'data-glyph': glyph.char, 'vector-effect': 'non-scaling-stroke' });
      if (s.upgrade === 'U03') trace.setAttribute('pathLength', '1');
      detail.append(trace); s.pathTraces.push(trace);
    }
    svg.append(base, fill, detail);
    preserveChildren(s);
    s.pathSource = own(s, element('span', 'bm-upgrade-source', s.plainText));
    s.pathSvg = own(s, svg); s.pathFill = fill; s.pathDetail = detail;
    s.el.append(s.pathSource, svg);
    s.el.dataset.upgradeReady = 'true';
    s.el.classList.add('bm-upgrade-path-ready');
    if (s.upgrade === 'U09') {
      technicalRegion(s, 'off');
      pointer(s);
      listen(s, s.el, 'focusin', () => {
        if (active(s) && fine.matches) {
          s.technicalFocused = true;
          technicalRegion(s, 'full');
        }
      });
      listen(s, s.el, 'focusout', () => { s.technicalFocused = false; resetPointer(s); });
    } else {
      const replay = () => { if (active(s)) drawBrand(s); };
      listen(s, s.el, 'pointerenter', replay, { passive: true });
      listen(s, s.el, 'focusin', replay);
    }
    return true;
  }
  function technicalRegion(s, mode, x, y) {
    if (!s.technicalMaskCircle || !s.technicalClipCircle) return;
    let cx = 2036.64, cy = 402.5, radius = mode === 'full' ? 5000 : 0;
    if (mode === 'local' && s.rect) {
      // Match preserveAspectRatio=xMidYMid meet, including its letterboxing.
      // The SVG box is cached once on pointer entry, never measured each frame.
      const box = s.pathSvgRect || s.rect;
      const scale = Math.max(.001, Math.min(box.width / 4103.28, box.height / 909));
      const left = box.left - s.rect.left + (box.width - 4103.28 * scale) / 2;
      const top = box.top - s.rect.top + (box.height - 909 * scale) / 2;
      cx = -15 + (x - left) / scale;
      cy = -52 + (y - top) / scale;
      radius = 700;
    }
    for (const circle of [s.technicalMaskCircle, s.technicalClipCircle]) {
      circle.setAttribute('cx', cx.toFixed(2)); circle.setAttribute('cy', cy.toFixed(2)); circle.setAttribute('r', String(radius));
    }
    s.el.classList.toggle('bm-upgrade-tech-active', mode !== 'off');
    s.el.dataset.techRegion = mode;
  }
  function drawBrand(s) {
    if (!s.pathSvg || !active(s)) return;
    cancelAnimations(s);
    s.pathTraces.forEach((path, index) => animate(s, path,
      [{ strokeDasharray: '1', strokeDashoffset: '1' }, { strokeDasharray: '1', strokeDashoffset: '0' }],
      { duration: 740, delay: index * 24, easing: 'cubic-bezier(.45,0,.2,1)' }));
    animate(s, s.pathFill, [{ opacity: .05 }, { opacity: .05, offset: .35 }, { opacity: 1 }], { duration: 900, easing: 'ease-out' });
  }
  function setupDepth(s) {
    split(s);
    const stack = own(s, element('span', 'bm-upgrade-depth-stack'));
    stack.setAttribute('aria-hidden', 'true');
    for (let i = 3; i > 0; i--) {
      const layer = s.letterVisual.cloneNode(true);
      layer.className = 'bm-upgrade-depth-side bm-upgrade-depth-side-' + i;
      layer.setAttribute('data-depth-layer', String(i));
      stack.append(layer);
    }
    stack.append(s.letterVisual); s.el.append(stack); s.depthStack = stack;
    pointer(s);
  }
  function setupWarp(s) {
    split(s); s.warpSlices = [];
    for (const char of s.chars) {
      const text = char.textContent;
      const base = element('span', 'bm-upgrade-warp-letter-base', text);
      char.replaceChildren(base);
      const slices = [];
      for (let i = 0; i < 3; i++) {
        const slice = element('span', 'bm-upgrade-warp-slice bm-upgrade-warp-slice-' + i, text);
        slice.setAttribute('aria-hidden', 'true');
        slice.style.clipPath = 'inset(-12% ' + (i === 2 ? '-12%' : (100 - (i + 1) * 100 / 3 - .55) + '%') + ' -12% ' + (i === 0 ? '-12%' : (i * 100 / 3 - .55) + '%') + ')';
        char.append(slice); slices.push(slice);
      }
      s.warpSlices.push(slices);
    }
    pointer(s);
  }
  function setupFold(s) {
    let parts;
    try { parts = JSON.parse(s.el.dataset.fxSegments || 'null'); } catch (_) { /* fallback keeps a complete phrase */ }
    if (!Array.isArray(parts) || !parts.length || parts.join('') !== s.plainText) {
      const chars = Array.from(s.plainText);
      const cut = chars.length > 3 ? Math.ceil(chars.length / 2) : chars.length;
      parts = [chars.slice(0, cut).join(''), chars.slice(cut).join('')].filter(Boolean);
    }
    preserveChildren(s);
    const accessible = own(s, element('span', 'bm-text-sr', s.plainText));
    const visual = own(s, element('span', 'bm-upgrade-fold-lines'));
    visual.setAttribute('aria-hidden', 'true');
    if (parts.length > 3) parts = [parts[0], parts[1], parts.slice(2).join('')];
    s.foldPieces = parts.map((text) => {
      const piece = element('span', 'bm-upgrade-fold-piece', text); visual.append(piece); return piece;
    });
    s.el.append(accessible, visual);
  }
  function setupEcho(s) {
    preserveChildren(s);
    const main = own(s, element('span', 'bm-upgrade-echo-main', s.plainText));
    s.el.append(main); s.echoCopies = [];
    for (let i = 0; i < 3; i++) {
      const copy = decorate(s, 'bm-upgrade-echo-copy bm-upgrade-echo-copy-' + i);
      s.echoCopies.push(copy);
    }
  }
  function buttonUnavailable(s) {
    const control = s.buttonControl || s.el;
    return !!control.disabled || control.getAttribute('aria-disabled') === 'true' || control.getAttribute('aria-busy') === 'true' || control.hasAttribute('data-loading');
  }
  function buttonLetters(text) {
    return Array.from(text, (char, index) => {
      const letter = element('span', 'bm-upgrade-button-char', char);
      letter.style.setProperty('--bm-button-letter', String(index)); return letter;
    });
  }
  function syncButton(s) {
    const intact = s.buttonLabel && s.buttonLabel.parentNode === s.el && s.buttonDecor.parentNode === s.el && s.buttonAccessible && s.buttonAccessible.parentNode === s.el;
    // The true label is authoritative. Native/React loading and success updates
    // can replace it, or the complete button, at any time without an old clone
    // rewriting real product state.
    const text = currentButtonText(s);
    if (!intact || text !== s.buttonText) {
      cancelAnimations(s); s.buttonText = text;
      s.buttonLabel && s.buttonLabel.remove(); s.buttonDecor && s.buttonDecor.remove(); s.buttonAccessible && s.buttonAccessible.remove();
      s.owned = s.owned.filter((node) => node !== s.buttonLabel && node !== s.buttonDecor && node !== s.buttonAccessible);
      const accessible = own(s, element('span', 'bm-text-sr bm-upgrade-button-accessible', text));
      const label = own(s, element('span', 'bm-upgrade-button-label'));
      const decor = own(s, element('span', 'bm-upgrade-button-decor'));
      label.setAttribute('aria-hidden', 'true');
      decor.setAttribute('aria-hidden', 'true');
      label.append(...buttonLetters(text)); decor.append(...buttonLetters(text));
      s.buttonLabel = label; s.buttonDecor = decor; s.buttonAccessible = accessible;
      s.el.replaceChildren(accessible, label, decor); s.el.dataset.upgradeReady = 'true';
    }
    const unavailable = buttonUnavailable(s);
    s.el.classList.toggle('bm-upgrade-button-unavailable', unavailable);
    if (unavailable) {
      cancelAnimations(s); s.buttonShifted = false;
      for (const node of [...s.buttonLabel.children, ...s.buttonDecor.children]) node.style.removeProperty('transform');
    }
  }
  function currentButtonText(s) {
    // The two visual layers never contribute to accessible naming. Read the
    // authoritative first visual label when intact, or a replacement supplied
    // by native/React code; exclude our full accessible copy and second layer.
    return Array.from(s.el.childNodes).filter((node) => node !== s.buttonDecor && node !== s.buttonAccessible).map((node) => node.textContent || '').join('');
  }
  function flipButton(s, enter) {
    if (!active(s) || buttonUnavailable(s) || !s.buttonLabel) return;
    if (s.buttonShifted === enter) return;
    s.buttonShifted = enter;
    const groups = [s.buttonLabel.children, s.buttonDecor.children];
    const count = Math.max(1, groups[0].length);
    const stagger = Math.min(13, 65 / count);
    const duration = 205;
    // Read the interrupted visual frame before cancelling. A quick pointer
    // reversal continues smoothly, and never blocks the native click handler.
    const current = [...groups[0], ...groups[1]].map((node) => getComputedStyle(node).transform);
    cancelAnimations(s);
    let n = 0;
    groups.forEach((chars, layer) => Array.from(chars).forEach((char, index) => {
      const to = enter ? (layer ? 'translateY(0%) rotateX(0deg)' : 'translateY(-112%) rotateX(45deg)') : (layer ? 'translateY(112%) rotateX(-45deg)' : 'translateY(0%) rotateX(0deg)');
      const motion = animate(s, char, [{ transform: current[n++] === 'none' ? (layer ? 'translateY(112%) rotateX(-45deg)' : 'translateY(0%) rotateX(0deg)') : current[n - 1] }, { transform: to }], { duration, delay: index * stagger, easing: 'cubic-bezier(.2,.7,.25,1)' });
      if (motion) motion.finished.then(() => { if (!s.dead) char.style.transform = to; }, () => {});
    }));
  }
  function setupButton(s) {
    const control = /^(BUTTON|A)$/.test(s.el.tagName) ? s.el : s.el.closest('button,a');
    if (!control) return;
    s.buttonControl = control;
    s.originalButtonText = s.el.textContent || '';
    syncButton(s);
    const enter = () => { s.buttonHover = true; flipButton(s, true); };
    const leave = () => { s.buttonHover = false; if (!s.buttonFocus) flipButton(s, false); };
    listen(s, control, 'pointerenter', enter, { passive: true });
    listen(s, control, 'pointerleave', leave, { passive: true });
    listen(s, control, 'pointercancel', leave, { passive: true });
    listen(s, control, 'focusin', () => { s.buttonFocus = true; flipButton(s, true); });
    listen(s, control, 'focusout', (event) => {
      if (event.relatedTarget && control.contains(event.relatedTarget)) return;
      s.buttonFocus = false; if (!s.buttonHover) flipButton(s, false);
    });
  }
  function setPointer(s, event) {
    if (!active(s) || !fine.matches) return;
    // One layout read on entry. Pointer moves only write compositor/style values.
    if (!s.rect) s.rect = s.el.getBoundingClientRect();
    if (s.upgrade === 'U09' && s.pathSvg && !s.pathSvgRect) s.pathSvgRect = s.pathSvg.getBoundingClientRect();
    s.pointer = { x: event.clientX - s.rect.left, y: event.clientY - s.rect.top };
    pointerQueue.add(s);
    if (!pointerFrame) pointerFrame = requestAnimationFrame(flushPointers);
  }
  function flushPointers() {
    pointerFrame = 0;
    for (const s of pointerQueue) {
      if (!active(s) || !s.pointer || !s.rect) continue;
      const { x, y } = s.pointer;
      s.el.style.setProperty('--bm-pointer-x', x + 'px');
      s.el.style.setProperty('--bm-pointer-y', y + 'px');
      if (s.upgrade === 'U04') {
        const dx = Math.max(-1, Math.min(1, x / Math.max(1, s.rect.width) * 2 - 1));
        const dy = Math.max(-1, Math.min(1, y / Math.max(1, s.rect.height) * 2 - 1));
        s.el.style.setProperty('--bm-depth-x', (dx * 6).toFixed(2) + 'px');
        s.el.style.setProperty('--bm-depth-y', (dy * 4).toFixed(2) + 'px');
        s.el.style.setProperty('--bm-depth-rotate-x', (-dy * 4).toFixed(2) + 'deg');
        s.el.style.setProperty('--bm-depth-rotate-y', (dx * 5).toFixed(2) + 'deg');
      }
      if (s.upgrade === 'U09' && s.pathDetail) {
        const xp = Math.max(0, Math.min(100, x / Math.max(1, s.rect.width) * 100));
        const yp = Math.max(0, Math.min(100, y / Math.max(1, s.rect.height) * 100));
        technicalRegion(s, 'local', x, y);
        s.el.style.setProperty('--bm-tech-x', xp.toFixed(2) + '%');
        s.el.style.setProperty('--bm-tech-y', yp.toFixed(2) + '%');
      }
      if (s.type === 'T19') {
        const portion = Math.max(0, Math.min(100, x / Math.max(1, s.rect.width) * 100));
        s.el.style.setProperty('--bm-reveal', portion + '%');
      }
      if (s.chars && (s.type === 'T07' || s.type === 'T08')) {
        s.chars.forEach((char, i) => {
          const center = (i + .5) / Math.max(1, s.chars.length) * s.rect.width;
          const proximity = Math.max(0, 1 - Math.hypot(x - center, (y - s.rect.height / 2) * .6) / Math.max(90, s.rect.width * .5));
          if (s.type === 'T07' && s.el.dataset.fxVariable === 'true') {
            char.style.fontVariationSettings = '"wght" ' + Math.round(config.variableWeight[0] + proximity * (config.variableWeight[1] - config.variableWeight[0]));
          } else if (s.upgrade === 'U05' && s.warpSlices) {
            s.warpSlices[i].forEach((slice, part) => {
              const sliceCenter = (i + (part + .5) / 3) / s.chars.length * s.rect.width;
              const reach = Math.max(70, s.rect.width * .45);
              const near = Math.max(0, 1 - Math.hypot(x - sliceCenter, (y - s.rect.height / 2) * .7) / reach);
              const direction = Math.max(-1, Math.min(1, (x - sliceCenter) / reach));
              const vertical = Math.max(-1, Math.min(1, (y / Math.max(1, s.rect.height) - .5) * 2));
              const dx = direction * near * 8;
              const dy = near * (vertical * 9 + Math.sin(i * 1.15 + part * .72) * 4);
              slice.style.transform = 'translate3d(' + dx.toFixed(2) + 'px,' + dy.toFixed(2) + 'px,0) rotate(' + (direction * near * 5).toFixed(2) + 'deg) skewY(' + (direction * near * 11).toFixed(2) + 'deg) scaleX(' + (1 + near * (part - 1) * .035).toFixed(3) + ')';
            });
          } else if (s.type === 'T08') {
            char.style.transform = 'scale(' + (1 - proximity * .09).toFixed(3) + ',' + (1 + proximity * .13).toFixed(3) + ')';
          }
        });
      }
    }
    pointerQueue.clear();
    publishDiagnostics();
  }
  function resetPointer(s) {
    pointerQueue.delete(s); s.rect = null; s.pathSvgRect = null; s.pointer = null;
    s.el.classList.remove('bm-text-pointer');
    s.el.style.removeProperty('--bm-reveal');
    for (const property of ['--bm-depth-x','--bm-depth-y','--bm-depth-rotate-x','--bm-depth-rotate-y','--bm-tech-x','--bm-tech-y']) s.el.style.removeProperty(property);
    if (s.warpSlices) s.warpSlices.forEach((parts) => parts.forEach((part) => part.style.removeProperty('transform')));
    if (s.upgrade === 'U09' && s.pathDetail) {
      const focused = s.technicalFocused && active(s);
      technicalRegion(s, focused ? 'full' : 'off');
    }
    if (s.chars) s.chars.forEach((char) => {
      char.style.removeProperty('transform');
      char.style.removeProperty('font-variation-settings');
    });
    publishDiagnostics();
  }
  function invalidatePointerRects() {
    // Layout changes only invalidate cached boxes. The next local pointer event
    // measures once; resizing/font loading never starts an animation loop.
    for (const s of states.values()) if (s.rect) { s.rect = null; s.pathSvgRect = null; }
  }
  function pointer(s) {
    listen(s, s.el, 'pointerenter', (event) => {
      if (!active(s) || !fine.matches) return;
      s.rect = s.el.getBoundingClientRect();
      s.el.classList.add('bm-text-pointer'); setPointer(s, event);
    }, { passive: true });
    listen(s, s.el, 'pointermove', (event) => setPointer(s, event), { passive: true });
    listen(s, s.el, 'pointerleave', () => resetPointer(s), { passive: true });
    listen(s, s.el, 'pointercancel', () => resetPointer(s), { passive: true });
  }
  function phraseValues(el) {
    try {
      const values = JSON.parse(el.dataset.fxPhrases || '[]');
      return Array.isArray(values) ? values.filter((value) => typeof value === 'string' && value.trim()).slice(0, 8).map(value => window.BM.i18n?.t(value) ?? value) : [];
    } catch (_) { return []; }
  }
  function pauseOnInteraction(s) {
    const sync = () => {
      const paused = !!(s.hoverPaused || s.focusPaused);
      if (s.interactionPaused === paused) return;
      s.interactionPaused = paused;
      if (paused) stopTimers(s);
      // Pausing a loop releases its slot immediately for a visible gradient.
      // Hover and keyboard focus are independent so one cannot undo the other.
      refreshAll();
    };
    listen(s, s.el, 'pointerenter', () => { s.hoverPaused = true; sync(); }, { passive: true });
    listen(s, s.el, 'pointerleave', () => { s.hoverPaused = false; sync(); }, { passive: true });
    listen(s, s.el, 'pointercancel', () => { s.hoverPaused = false; sync(); }, { passive: true });
    listen(s, s.el, 'focusin', () => { s.focusPaused = true; sync(); });
    listen(s, s.el, 'focusout', (event) => {
      if (event.relatedTarget && s.el.contains(event.relatedTarget)) return;
      s.focusPaused = false; sync();
    });
  }
  function setupRotation(s) {
    const phrases = phraseValues(s.el);
    if (!phrases.length) return;
    s.phrases = phrases; s.phraseIndex = 0;
    const staticText = window.BM.i18n?.t(s.el.dataset.fxStatic || phrases.join('、')) ?? (s.el.dataset.fxStatic || phrases.join('、'));
    preserveChildren(s);
    const accessible = own(s, element('span', 'bm-text-sr', staticText));
    const box = own(s, element('span', 'bm-text-phrase-box'));
    box.setAttribute('aria-hidden', 'true');
    for (const phrase of phrases) {
      const ghost = element('span', 'bm-text-phrase-measure', phrase);
      box.append(ghost);
    }
    s.phraseNode = element('span', 'bm-text-phrase-current', phrases[0]);
    box.append(s.phraseNode);
    s.staticNode = own(s, element('span', 'bm-text-phrase-static', staticText));
    s.staticNode.setAttribute('aria-hidden', 'true');
    s.el.append(accessible, box, s.staticNode);
    pauseOnInteraction(s);
  }
  function schedulePhrase(s) {
    if (!s.phrases || s.phrases.length < 2 || !active(s) || s.interactionPaused || s.timers.size) return;
    timer(s, () => {
      if (!active(s) || s.interactionPaused) return;
      const node = s.phraseNode;
      animate(s, node, [{ opacity: 1, transform: 'translateY(0) rotateX(0)' }, { opacity: 0, transform: 'translateY(-.22em) rotateX(40deg)' }], { duration: config.phraseDuration / 2 });
      timer(s, () => {
        if (!active(s)) return;
        s.phraseIndex = (s.phraseIndex + 1) % s.phrases.length;
        node.textContent = s.phrases[s.phraseIndex];
        animate(s, node, [{ opacity: 0, transform: 'translateY(.22em) rotateX(-40deg)' }, { opacity: 1, transform: 'translateY(0) rotateX(0)' }], { duration: config.phraseDuration / 2 });
        schedulePhrase(s);
      }, config.phraseDuration / 2);
    }, config.phraseHold);
  }
  function focusItem(s, item) {
    for (const node of s.focusItems || []) node.classList.toggle('bm-text-focus-current', node === item);
  }
  function setupFocus(s) {
    s.focusItems = Array.from(s.el.querySelectorAll('a,button'));
    if (!s.focusItems.length) return;
    focusItem(s, s.focusItems[0]);
    for (const item of s.focusItems) {
      listen(s, item, 'pointerenter', () => { s.interactionPaused = true; stopTimers(s); focusItem(s, item); publishDiagnostics(); }, { passive: true });
      listen(s, item, 'focus', () => { s.interactionPaused = true; stopTimers(s); focusItem(s, item); publishDiagnostics(); });
    }
  }
  function setupCircle(s) {
    const ring = s.el.querySelector('.bm-text-circle-ring');
    if (!ring || ring.children.length) return;
    const text = ring.textContent || '';
    ring.textContent = '';
    ring.setAttribute('aria-hidden', 'true');
    const chars = Array.from(text);
    chars.forEach((char, i) => {
      const span = element('span', 'bm-text-circle-char', char === ' ' ? '\u00a0' : char);
      span.style.setProperty('--bm-circle-angle', (i / chars.length * 360) + 'deg');
      ring.append(span);
    });
    s.circleOriginal = text; s.circleRing = ring;
  }
  function setupCount(s) {
    s.value = Number(s.el.dataset.fxValue);
    if (!Number.isFinite(s.value)) return;
    s.countFinal = s.el.textContent || String(s.value);
    const key = s.el.dataset.fxKey;
    const hasPrevious = !!key && countValues.has(key);
    const previous = hasPrevious ? countValues.get(key) : s.upgrade === 'U08' ? s.value : 0;
    s.fromValue = previous;
    if (key) countValues.set(key, s.value);
    if (s.upgrade === 'U08') { s.flapFresh = !hasPrevious; renderFlap(s, false); }
  }
  function formattedCount(s, value) {
    return Number(value).toFixed(Math.min(3, Math.max(0, Number(s.el.dataset.fxDecimals) || 0)));
  }
  function renderFlap(s, moving) {
    if (!Number.isFinite(s.value)) return;
    const finalText = formattedCount(s, s.value);
    const before = formattedCount(s, s.fromValue);
    const renderKey = finalText + '|' + before + '|' + moving;
    if (s.flapRenderKey === renderKey && s.flapDisplay && s.flapDisplay.parentNode === s.el) return;
    s.flapRenderKey = renderKey;
    const width = Math.max(finalText.length, before.length);
    const oldChars = before.padStart(width, ' ');
    const newChars = finalText.padStart(width, ' ');
    if (!s.flapSource || s.flapSource.parentNode !== s.el) {
      preserveChildren(s);
      s.flapSource = own(s, element('span', 'bm-upgrade-flap-value', finalText));
      s.flapDisplay = own(s, element('span', 'bm-upgrade-flap-display'));
      s.flapDisplay.setAttribute('aria-hidden', 'true');
      s.el.append(s.flapSource, s.flapDisplay);
    }
    s.flapSource.textContent = finalText; s.countFinal = finalText;
    s.flapDisplay.replaceChildren(); s.flapCells = [];
    for (let i = 0; i < width; i++) {
      const cell = element('span', 'bm-upgrade-flap-cell');
      const oldChar = oldChars[i] === ' ' ? '\u00a0' : oldChars[i];
      const newChar = newChars[i] === ' ' ? '\u00a0' : newChars[i];
      const parts = {};
      for (const [name, character] of [['old-top',newChar],['new-bottom',moving ? oldChar : newChar],['turn-top',oldChar],['turn-bottom',newChar]]) {
        const half = element('span', 'bm-upgrade-flap-' + name);
        half.append(element('span', 'bm-upgrade-flap-digit', character));
        parts[name] = half; cell.append(half);
      }
      cell.dataset.flapValue = newChars[i];
      s.flapDisplay.append(cell); s.flapCells.push({ cell, parts, oldChar, newChar });
    }
    s.el.style.setProperty('--bm-flap-digits', String(width));
    s.el.dataset.upgradeReady = 'true';
  }
  function flipCount(s) {
    if (!Number.isFinite(s.value) || s.countedValue === s.value) return;
    s.countedValue = s.value;
    if (s.fromValue === s.value && !s.flapFresh) { renderFlap(s, false); return; }
    renderFlap(s, true);
    const duration = 560;
    let latest = 0;
    s.flapCells.forEach(({ cell, parts, oldChar, newChar }, index) => {
      if (oldChar === newChar && !s.flapFresh) return;
      cell.classList.add('bm-upgrade-flapping');
      const delay = Math.min(80, index * 22); latest = Math.max(latest, delay);
      animate(s, parts['turn-top'], [
        { transform: 'rotateX(0deg)', opacity: 1 },
        { transform: 'rotateX(-92deg)', opacity: 1, offset: .49 },
        { transform: 'rotateX(-92deg)', opacity: 0, offset: .5 },
        { transform: 'rotateX(-92deg)', opacity: 0 },
      ], { duration, delay, easing: 'linear' });
      animate(s, parts['turn-bottom'], [
        { transform: 'rotateX(92deg)', opacity: 0 },
        { transform: 'rotateX(92deg)', opacity: 0, offset: .49 },
        { transform: 'rotateX(92deg)', opacity: 1, offset: .5 },
        { transform: 'rotateX(0deg)', opacity: 1 },
      ], { duration, delay, easing: 'cubic-bezier(.35,0,.65,1)' });
    });
    s.flapFresh = false;
    timer(s, () => { renderFlap(s, false); }, duration + latest + 20);
  }
  function count(s) {
    if (!Number.isFinite(s.value) || s.countedValue === s.value) return;
    s.countedValue = s.value;
    if (!active(s) || s.value === s.fromValue) return;
    const finalText = Number(s.el.textContent) === s.value ? s.el.textContent : s.value.toFixed(Math.min(3, Math.max(0, Number(s.el.dataset.fxDecimals) || 0)));
    const decimals = Math.min(3, Math.max(0, Number(s.el.dataset.fxDecimals) || 0));
    // Real final text stays accessible and determines layout. Only an aria-hidden
    // visual copy changes; a screen reader never receives intermediate numbers.
    const visual = own(s, element('span', 'bm-text-count-visual', String(s.fromValue)));
    visual.setAttribute('aria-hidden', 'true');
    const source = element('span', 'bm-text-count-source', finalText);
    preserveChildren(s); s.el.append(source, visual); s.countSource = source;
    // Destroy/reconfigure must restore the latest real value, never an older
    // snapshot captured before a legitimate metric update.
    s.countFinal = finalText;
    const start = performance.now();
    const update = () => {
      if (!active(s)) { source.classList.remove('bm-text-count-source'); visual.remove(); s.countSource = null; return; }
      const t = Math.min(1, (performance.now() - start) / config.countDuration);
      const eased = 1 - Math.pow(1 - t, 3);
      visual.textContent = (s.fromValue + (s.value - s.fromValue) * eased).toFixed(decimals);
      if (t < 1) timer(s, update, config.countFrame);
      else { source.classList.remove('bm-text-count-source'); visual.remove(); s.countSource = null; }
    };
    update();
  }
  function decode(s) {
    if (!active(s) || s.decoding) return;
    s.decoding = true;
    const letters = 'BMMD0123456789';
    const text = s.decodeText;
    const start = performance.now();
    s.el.classList.add('bm-text-decoding');
    const step = () => {
      const progress = Math.min(1, (performance.now() - start) / config.decodeDuration);
      if (!active(s) || progress >= 1) {
        s.decodeNode.textContent = text; s.decoding = false; s.decoded = true;
        s.el.classList.remove('bm-text-decoding'); return;
      }
      const settled = Math.floor(progress * Array.from(text).length);
      s.decodeNode.textContent = Array.from(text, (char, index) => index < settled || /\s/.test(char) ? char : letters[Math.floor(Math.random() * letters.length)]).join('');
      timer(s, step, config.decodeFrame);
    };
    step();
  }
  function enter(s) {
    if (!active(s)) return;
    if (s.upgrade === 'U01' || s.upgrade === 'U04' || s.upgrade === 'U05' || s.upgrade === 'U09' || s.upgrade === 'U10') return;
    if (s.upgrade === 'U08') { flipCount(s); return; }
    if (s.upgrade === 'U03' || s.upgrade === 'U06' || s.upgrade === 'U07') {
      if (played(s)) { s.played = true; return; }
      if (s.upgrade === 'U03') drawBrand(s);
      if (s.upgrade === 'U06') (s.foldPieces || []).forEach((piece, index) => animate(s, piece, [
        { transform: 'perspective(600px) rotateX(-78deg) translateY(.08em)', filter: 'brightness(.55)', clipPath: 'inset(0 0 55% 0)' },
        { transform: 'perspective(600px) rotateX(9deg) translateY(0)', filter: 'brightness(1.16)', clipPath: 'inset(0)', offset: .72 },
        { transform: 'perspective(600px) rotateX(0deg) translateY(0)', filter: 'brightness(1)', clipPath: 'inset(0)' },
      ], { duration: 540, delay: index * 65, easing: 'cubic-bezier(.22,.61,.2,1)' }));
      if (s.upgrade === 'U07') (s.echoCopies || []).forEach((copy, index) => animate(s, copy, [
        { transform: 'translateX(' + (18 + index * 13) + 'px)', opacity: .27 - index * .055 },
        { transform: 'translateX(0px)', opacity: 0 },
      ], { duration: 650, delay: index * 30, easing: 'cubic-bezier(.18,.72,.23,1)' }));
      markPlayed(s); return;
    }
    if (s.type === 'T11' || s.type === 'T12') { schedulePhrase(s); return; }
    if (s.type === 'T14') { count(s); return; }
    if (played(s)) { s.played = true; return; }
    switch (s.type) {
      case 'T02':
        animate(s, s.el, [{ opacity: .55, filter: 'blur(' + config.maxBlur + 'px)', transform: 'translateY(5px)' }, { opacity: 1, filter: 'blur(0)', transform: 'translateY(0)' }], { duration: config.titleDuration, delay: parseFloat(s.el.dataset.fxDelay) || 0 });
        break;
      case 'T15':
        animate(s, s.el, [{ opacity: .5, transform: 'translateY(10px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: config.revealDuration });
        break;
      case 'T04': case 'T05': case 'T10': case 'T17': case 'T20':
        s.el.classList.add('bm-text-enter');
        s.cssRunning = true;
        timer(s, () => { s.cssRunning = false; }, s.type === 'T04' ? config.shineDuration + 350 :
          s.type === 'T05' ? config.highlightDuration + 180 : s.type === 'T10' ? config.pointerDuration :
          s.type === 'T17' ? config.colourDuration + (s.chars || []).length * 35 : config.glitchDuration);
        break;
      case 'T13': {
        const text = s.el.textContent || '';
        animate(s, s.el, [{ clipPath: 'inset(0 100% 0 0)' }, { clipPath: 'inset(0 0% 0 0)' }], { duration: Math.min(config.typeDuration, Math.max(600, Array.from(text).length * config.typeStep)), easing: 'steps(' + Math.max(1, Array.from(text).length) + ',end)' });
        s.el.classList.add('bm-text-typing');
        timer(s, () => s.el.classList.remove('bm-text-typing'), config.caretDuration);
        break;
      }
      case 'T09':
        (s.focusItems || []).forEach((item, index) => timer(s, () => { if (active(s) && !s.interactionPaused) focusItem(s, item); }, config.focusDemoDelay + index * config.focusDemoStep));
        break;
      default: break;
    }
    markPlayed(s);
  }
  function settle(s) {
    stopTimers(s); resetPointer(s);
    cancelAnimations(s);
    s.el.classList.remove('bm-upgrade-material-running');
    if (s.upgrade === 'U08' && Number.isFinite(s.value)) {
      renderFlap(s, false);
      if (reduced.matches || manuallyPaused) { s.countedValue = s.value; s.flapFresh = false; }
    }
    if (s.upgrade === 'U10' && s.buttonLabel) {
      for (const node of [...s.buttonLabel.children, ...s.buttonDecor.children]) node.style.removeProperty('transform');
      s.buttonShifted = false;
    }
    if (s.countSource) { s.countSource.classList.remove('bm-text-count-source'); s.countSource = null; }
    for (const node of s.el.querySelectorAll('.bm-text-count-visual')) node.remove();
    // Interrupted entrance accents settle into their readable final styles.
    // They never resume a half-finished glitch/shine when the page returns.
    s.el.classList.remove('bm-text-decoding', 'bm-text-typing', 'bm-text-enter');
    s.decoding = false; s.cssRunning = false;
  }
  function refresh(s) {
    const running = active(s);
    s.el.classList.toggle('bm-text-reduced', reduced.matches);
    s.el.classList.toggle('bm-text-paused', !running);
    if (s.upgrade === 'U01') s.el.classList.toggle('bm-upgrade-material-running', running && !compact.matches);
    if (!running) settle(s);
    else enter(s);
  }
  const intersection = typeof IntersectionObserver === 'function' ? new IntersectionObserver((entries) => {
    for (const entry of entries) {
      const s = states.get(entry.target);
      if (s) s.visible = entry.isIntersecting;
    }
    refreshAll();
  }, { rootMargin: '80px 0px', threshold: .01 }) : null;
  function mount(el, root) {
    const upgrade = effectiveUpgrade(el);
    const type = el.dataset.textFx || upgrade;
    if (!/^T(?:0[1-9]|1[0-9]|20)$/.test(type || '') && !upgrade) return;
    const s = { el, root, type, upgrade, plainText: el.textContent || '', visible: !intersection, played: false, owned: [], cleanups: [], timers: new Set(), animations: new Set(), dead: false };
    states.set(el, s);
    el.classList.add('bm-text-fx');
    el.style.setProperty('--bm-text-hover-duration', config.hoverDuration + 'ms');
    for (const name of ['shine','highlight','pointer','colour','glitch','circle']) {
      el.style.setProperty('--bm-text-' + name + '-duration', config[name + 'Duration'] + 'ms');
    }
    config.colours.forEach((colour, index) => el.style.setProperty('--bm-text-colour-' + index, colour));
    if (upgrade === 'U03' || upgrade === 'U09') setupBrandPaths(s);
    if (upgrade === 'U04') setupDepth(s);
    if (upgrade === 'U05') setupWarp(s);
    if (upgrade === 'U06') setupFold(s);
    if (upgrade === 'U07') setupEcho(s);
    if (upgrade === 'U10') setupButton(s);
    if (type === 'T04') decorate(s, 'bm-text-shine-copy');
    if (type === 'T06' && upgrade !== 'U03') { decorate(s, 'bm-text-outline-light'); pointer(s); }
    if ((type === 'T07' || type === 'T08' || type === 'T17') && !['U04','U05'].includes(upgrade)) { split(s); if (type !== 'T17') pointer(s); }
    if (type === 'T09') setupFocus(s);
    if (type === 'T11' || type === 'T12') setupRotation(s);
    if (type === 'T14') setupCount(s);
    if (type === 'T16') {
      s.decodeText = el.textContent || '';
      s.decodeNode = decorate(s, 'bm-text-decode-copy');
      listen(s, el, 'pointerenter', () => decode(s), { passive: true });
      listen(s, el, 'focusin', () => decode(s));
      // Entry text is often a span inside a real button/link. Focus does not
      // bubble downwards, so listen on that nearest actual control as well.
      const control = el.closest('button,a');
      if (control && control !== el) listen(s, control, 'focus', () => decode(s));
    }
    if (type === 'T18') { setupCircle(s); pauseOnInteraction(s); }
    if (type === 'T19') {
      if (!el.hasAttribute('aria-expanded')) el.setAttribute('aria-expanded', 'false');
      pointer(s);
      listen(s, el, 'click', () => {
        const expanded = el.getAttribute('aria-expanded') !== 'true';
        el.setAttribute('aria-expanded', String(expanded));
        const hint = el.querySelector('.bm-text-reveal-hint');
        if (hint) hint.textContent = expanded ? '用途已展开 · 再次点击收起' : '查看用途 · 点击揭示';
        publishDiagnostics();
      });
    }
    if (type === 'T20' && upgrade !== 'U07') { decorate(s, 'bm-text-glitch-blue'); decorate(s, 'bm-text-glitch-cyan'); }
    if (intersection) intersection.observe(el);
    return s;
  }
  function unmount(s, restore) {
    s.dead = true; settle(s); intersection && intersection.unobserve(s.el);
    s.cleanups.forEach((cleanup) => cleanup());
    for (const item of s.focusItems || []) item.classList.remove('bm-text-focus-current');
    if (restore) {
      if (s.upgrade === 'U10' && s.buttonText != null) s.el.textContent = currentButtonText(s);
      else if (s.type === 'T14' && s.countFinal != null) s.el.textContent = s.countFinal;
      else if (s.originalNodes && s.owned.some((node) => node.parentNode === s.el)) s.el.replaceChildren(...s.originalNodes);
      else s.owned.forEach((node) => node.remove());
      if (s.circleRing) s.circleRing.textContent = s.circleOriginal;
      s.el.classList.remove('bm-text-fx','bm-text-reduced','bm-text-paused','bm-text-enter','bm-text-pointer');
      s.el.classList.remove('bm-upgrade-material-running','bm-upgrade-tech-active','bm-upgrade-button-unavailable','bm-upgrade-path-ready');
      delete s.el.dataset.upgradeReady;
      delete s.el.dataset.techRegion;
      s.el.dataset.fxState = 'static';
    }
    states.delete(s.el);
  }
  let localeChanging = false;
  function beforeLanguageChange() {
    localeChanging = true;
    for (const s of [...states.values()]) {
      const label = s.upgrade === 'U10' ? window.BM.i18n?.source(currentButtonText(s)) ?? currentButtonText(s) : null;
      unmount(s, true);
      if (label !== null) s.el.textContent = label;
    }
  }
  function afterLanguageChange() {
    localeChanging = false;
    for (const root of roots.keys()) scan(root);
  }
  function scan(root = document) {
    if (destroyed || localeChanging) return;
    window.BM.i18n?.translate(root);
    for (const s of states.values()) {
      if (!s.el.isConnected || (s.el.dataset.textFx || s.el.dataset.textUpgrade) !== s.type || effectiveUpgrade(s.el) !== s.upgrade) unmount(s, s.el.isConnected);
    }
    const nodes = root.matches && root.matches(selector) ? [root, ...root.querySelectorAll(selector)] : Array.from(root.querySelectorAll(selector));
    for (const el of nodes) {
      const s = states.get(el);
      if (!s) mount(el, root);
      else if (s.upgrade === 'U10') syncButton(s);
      else if (s.type === 'T14' && Number(el.dataset.fxValue) !== s.value) {
        settle(s); s.fromValue = s.value; s.value = Number(el.dataset.fxValue); s.countedValue = undefined;
        s.countFinal = Number(el.textContent) === s.value ? el.textContent : String(s.value);
        if (s.upgrade === 'U08') { s.flapFresh = false; renderFlap(s, false); }
        else if (!active(s) && Number.isFinite(s.value)) el.textContent = s.countFinal;
        if (s.el.dataset.fxKey && Number.isFinite(s.value)) countValues.set(s.el.dataset.fxKey, s.value);
      }
    }
    refreshAll();
  }
  function registerRoot(root) {
    if (!root || destroyed) return () => {};
    if (roots.has(root)) { roots.get(root).refs++; return () => releaseRoot(root); }
    let link = null;
    if (root !== document && !root.querySelector('[data-bm-text-style]')) {
      link = element('link'); link.rel = 'stylesheet'; link.href = styleURL;
      link.setAttribute('data-bm-text-style', ''); root.prepend(link);
    }
    let queued = false;
    const observer = new MutationObserver(() => {
      if (queued || destroyed) return;
      queued = true;
      queueMicrotask(() => { queued = false; if (roots.has(root)) scan(root); });
    });
    observer.observe(root === document ? document.body : root, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['data-text-fx','data-text-upgrade','data-heading-renderer','data-fx-value','data-fx-variable','data-split-state','disabled','aria-disabled','aria-busy','data-loading','open','hidden','inert'] });
    roots.set(root, { observer, link, refs: 1 }); scan(root);
    return () => releaseRoot(root);
  }
  function releaseRoot(root) {
    const record = roots.get(root); if (!record) return;
    if (--record.refs > 0) return;
    record.observer.disconnect(); record.link && record.link.remove(); roots.delete(root);
    for (const s of states.values()) if (s.root === root || s.el.getRootNode() === root) unmount(s, true);
    refreshAll();
  }
  function refreshAll() {
    cacheVisibilityContext();
    allocateContinuousBudget();
    for (const s of states.values()) refresh(s);
    publishDiagnostics();
  }
  reduced.addEventListener('change', refreshAll);
  fine.addEventListener('change', refreshAll);
  compact.addEventListener('change', refreshAll);
  document.addEventListener('visibilitychange', refreshAll);
  document.addEventListener('bm:language-before-change', beforeLanguageChange);
  document.addEventListener('bm:language-change', afterLanguageChange);
  window.addEventListener('resize', invalidatePointerRects, { passive: true });
  if (document.fonts) document.fonts.addEventListener('loadingdone', invalidatePointerRects);
  function lifecycle(action) { document.dispatchEvent(new CustomEvent('bm-text-fx-lifecycle', { detail: { action } })); }
  function pause() { manuallyPaused = true; refreshAll(); lifecycle('pause'); }
  function resume() { manuallyPaused = false; refreshAll(); lifecycle('resume'); }
  function destroy() {
    destroyed = true;
    if (pointerFrame) cancelAnimationFrame(pointerFrame);
    pointerFrame = 0; pointerQueue.clear();
    for (const record of roots.values()) { record.observer.disconnect(); record.link && record.link.remove(); }
    roots.clear(); for (const s of states.values()) unmount(s, true);
    activeDialog = null; knownDialogs.clear();
    intersection && intersection.disconnect();
    reduced.removeEventListener('change', refreshAll); fine.removeEventListener('change', refreshAll); compact.removeEventListener('change', refreshAll);
    document.removeEventListener('visibilitychange', refreshAll);
    document.removeEventListener('bm:language-before-change', beforeLanguageChange);
    document.removeEventListener('bm:language-change', afterLanguageChange);
    window.removeEventListener('resize', invalidatePointerRects);
    if (document.fonts) document.fonts.removeEventListener('loadingdone', invalidatePointerRects);
    lifecycle('destroy');
    publishDiagnostics();
  }
  function effectState(s) {
    if (destroyed || reduced.matches) return 'static';
    if (!active(s)) return 'paused';
    if (s.type === 'T01') return s.el.dataset.splitState === 'playing' ? 'running' : 'complete';
    if (continuous(s)) return s.interactionPaused ? 'paused' : 'running';
    if (s.decoding || s.cssRunning || s.animations.size || s.countSource ||
      ((s.type === 'T09' || s.type === 'T13') && s.timers.size) ||
      ((['T06','T07','T08','T19'].includes(s.type) || s.upgrade === 'U09') && s.pointer)) return 'running';
    if (s.type === 'T19') return s.el.getAttribute('aria-expanded') === 'true' ? 'complete' : 'static';
    if (s.type === 'T16') return s.decoded ? 'complete' : 'static';
    if (['T06','T07','T08','T11','T12','T18'].includes(s.type)) return 'static';
    return s.played || s.type === 'T14' && s.countedValue === s.value ? 'complete' : 'static';
  }
  function diagnostics() {
    const list = [...states.values()];
    const effects = {}, upgrades = {};
    for (const s of list) {
      const entry = effects[s.type] || (effects[s.type] = { mounted: 0, visible: 0, activeTimers: 0, activeAnimations: 0, running: 0, paused: 0, complete: 0, static: 0 });
      entry.mounted++; if (s.visible) entry.visible++;
      entry.activeTimers += s.timers.size; entry.activeAnimations += s.animations.size;
      entry[effectState(s)]++;
      if (s.upgrade) {
        const upgradeEntry = upgrades[s.upgrade] || (upgrades[s.upgrade] = { mounted: 0, activeTimers: 0, activeAnimations: 0, running: 0, paused: 0, complete: 0, static: 0 });
        upgradeEntry.mounted++; upgradeEntry.activeTimers += s.timers.size; upgradeEntry.activeAnimations += s.animations.size; upgradeEntry[effectState(s)]++;
      }
    }
    const continuousRunning = list.filter((s) => continuous(s) && active(s) && !s.interactionPaused).length;
    const activeAnimations = list.reduce((n, s) => n + s.animations.size, 0);
    const cssAnimations = list.filter((s) => active(s) && s.cssRunning).length;
    return {
    mounted: states.size, roots: roots.size, reduced: reduced.matches, paused: manuallyPaused,
    dialogOpen: !!activeDialog,
    destroyed, activeTimers: list.reduce((n, s) => n + s.timers.size, 0),
    activeAnimations, cssAnimations, animations: activeAnimations + cssAnimations + continuousRunning,
    queuedPointerFrame: !!pointerFrame,
    continuousBudget: config.continuousBudget,
    continuousRunning,
    continuousBudgetPaused: list.filter((s) => s.budgetPaused).length,
    effects, upgrades,
    byEffect: list.reduce((result, s) => { result[s.type] = (result[s.type] || 0) + 1; return result; }, {}),
    };
  }
  function publishDiagnostics() {
    for (const s of states.values()) {
      const state = effectState(s);
      if (s.el.dataset.fxState !== state) s.el.dataset.fxState = state;
      if (s.type === 'T16' && s.el.dataset.fxDecoding !== String(!!s.decoding)) s.el.dataset.fxDecoding = String(!!s.decoding);
    }
    const host = document.documentElement;
    if (!host) return;
    const json = JSON.stringify(diagnostics());
    if (host.dataset.textFxDiagnostics !== json) host.dataset.textFxDiagnostics = json;
  }
  window.BM.textFx = { config, scan, registerRoot, pause, resume, destroy, diagnostics };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => registerRoot(document), { once: true });
  else registerRoot(document);
  document.dispatchEvent(new CustomEvent('bm:text-fx-ready'));
})();
