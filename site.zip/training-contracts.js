/* Additive v3 metadata. No new storage owner; IDs and historical snapshots stay intact. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)(root.BM||={}).TrainingData=api;})(typeof window==='undefined'?null:window,function(){
  'use strict';
  const executed=s=>s.sets.filter(r=>!r.deletedAt&&Number(r.reps)>0);
  function numberSessions(state){
    const ended=state.sessions.filter(s=>s.endedAt&&executed(s).length),used=new Set();let next=Math.max(1,state.preferences.nextTrainingNumber||1);
    for(const s of ended)if(Number.isSafeInteger(s.trainingNumber)&&s.trainingNumber>0&&!used.has(s.trainingNumber)){used.add(s.trainingNumber);next=Math.max(next,s.trainingNumber+1);}else if(s.trainingNumber!=null){s.importedTrainingNumber=s.trainingNumber;delete s.trainingNumber;}
    for(const s of ended.sort((a,b)=>a.endedAt.localeCompare(b.endedAt)||a.id.localeCompare(b.id)))if(!s.trainingNumber){while(used.has(next))next++;s.trainingNumber=next;used.add(next++);}
    state.preferences.nextTrainingNumber=next;
    return state;
  }
  function mergeNumbers(current,incoming,merged){
    const existing=new Set(current.sessions.map(s=>s.id)),used=new Set(current.sessions.map(s=>s.trainingNumber).filter(Number.isSafeInteger));
    merged.preferences.nextTrainingNumber=Math.max(current.preferences.nextTrainingNumber||1,incoming.preferences.nextTrainingNumber||1);
    for(const s of merged.sessions)if(!existing.has(s.id)&&s.trainingNumber&&used.has(s.trainingNumber)){s.importedTrainingNumber=s.trainingNumber;delete s.trainingNumber;}else if(s.trainingNumber)used.add(s.trainingNumber);
    return numberSessions(merged);
  }
  function csv(state){const columns=['session_id','training_number','date','plan','day','status','action','equipment','variant','side','set_index','set_type','reps','load','unit','load_basis','completed_at','notes'];
    const quote=v=>'"'+String(v??'').replace(/^[\s]*[=+@-]/,"'$&").replace(/"/g,'""')+'"';
    const rows=state.sessions.flatMap(s=>s.sets.map(r=>[s.id,s.trainingNumber,s.startedAt,s.planSnapshot.title,s.planSnapshot.days.find(d=>d.id===s.dayId)?.title,s.status,r.actionName||r.actionId,r.equipmentLabel||r.equipmentId,r.variant||'standard',r.sides||'both',r.setIndex+1,r.setType||'working',r.reps,r.inputLoadRaw??r.load,r.unit||'kg',r.loadBasis,r.completedAt,r.notes]));
    return '\uFEFF'+[columns,...rows].map(row=>row.map(quote).join(',')).join('\r\n');
  }
  return {executed,numberSessions,mergeNumbers,csv,revision:1};
});
