/* Browser-local profiles and durable-save feedback. No account, network or fingerprint. */
(() => {
  'use strict';
  const B = window.BM = window.BM || {};
  const MANIFEST = 'bmmd_local_profiles_v1';
  const PREFIX = 'bmmd_local_profile_v1_';
  const now = () => new Date().toISOString();
  const copy = x => JSON.parse(JSON.stringify(x));
  const text = (zh, en) => B.i18n?.getLanguage() === 'en' ? en : zh;
  const escape = x => String(x ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let native = null, manifest = null, manifestRaw = null, manifestError = '', persistence = 'checking', busy = false;
  let timer = 0, lastExport = '', lastFailure = '';
  try {
    native = window.localStorage;
    const raw = native.getItem(MANIFEST);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.version !== 1 || !Array.isArray(parsed.profiles) || !parsed.profiles.length || parsed.profiles.length > 20 ||
          !parsed.profiles.every(p => p && /^(default|p-[a-z0-9-]{8,64})$/.test(p.id) && typeof p.name === 'string' && p.name.length <= 80) ||
          new Set(parsed.profiles.map(p => p.id)).size !== parsed.profiles.length || !parsed.profiles.some(p => p.id === parsed.activeId)) throw Error('Invalid profile manifest');
      manifest = parsed;
      manifestRaw = raw;
    }
  } catch (error) { manifestError = String(error.message || error); }
  // Existing v3 keys remain untouched and are the default profile. No eager migration.
  manifest ||= { version: 1, activeId: 'default', profiles: [{ id: 'default', name: '', createdAt: now() }] };
  const currentId = manifest.activeId;
  const profilePrefix = currentId === 'default' ? '' : PREFIX + currentId + '__';
  const current = () => manifest.profiles.find(p => p.id === currentId);
  const profileName = p => p?.name || text('我的训练', 'My training');
  function writeManifest(next) {
    if (manifestError) return { ok: false, error: text('本机档案目录读取失败，原内容保留。请先下载训练备份。', 'The local profile directory could not be read. Original data is retained; download your training backup first.') };
    try {
      if (!native) throw Error('Storage unavailable');
      if (native.getItem(MANIFEST) !== manifestRaw) throw Error(text('另一标签页已更新档案目录。先保存当前输入，再刷新本页。', 'Another tab updated the profile directory. Save current input and reload this page.'));
      const raw = JSON.stringify(next);
      native.setItem(MANIFEST, raw);
      if (native.getItem(MANIFEST) !== raw) throw Error('Read-back failed');
      manifest = next;
      manifestRaw = raw;
      return { ok: true };
    } catch (error) { return { ok: false, error: text('无法保存本机档案：', 'Could not save local profile: ') + String(error.message || error) }; }
  }
  function scopedKeys() {
    if (!native) return [];
    const keys = [];
    for (let i = 0; i < native.length; i++) {
      const key = native.key(i);
      if (profilePrefix ? key?.startsWith(profilePrefix) : key && key !== MANIFEST && !key.startsWith(PREFIX)) keys.push(profilePrefix ? key.slice(profilePrefix.length) : key);
    }
    return keys;
  }
  const storage = native ? {
    get length() { return scopedKeys().length; },
    key(index) { return scopedKeys()[index] ?? null; },
    getItem(key) { return native.getItem(profilePrefix + key); },
    setItem(key, value) { native.setItem(profilePrefix + key, String(value)); },
    removeItem(key) { native.removeItem(profilePrefix + key); }
  } : null;
  function create(name) {
    name = String(name || '').trim();
    if (!name || name.length > 80) return { ok: false, error: text('填写 1–80 个字符的档案名称。', 'Use a profile name of 1–80 characters.') };
    if (manifest.profiles.length >= 20) return { ok: false, error: text('本机最多保留 20 个档案。', 'Up to 20 local profiles are supported.') };
    const id = 'p-' + (window.crypto?.randomUUID?.() || Date.now().toString(36) + '-' + Math.random().toString(36).slice(2));
    const next = copy(manifest);
    next.profiles.push({ id, name, createdAt: now() });
    const result = writeManifest(next);
    return { ...result, id: result.ok ? id : null };
  }
  function activate(id) {
    if (!manifest.profiles.some(p => p.id === id)) return { ok: false, error: text('找不到这份本机档案。', 'This local profile was not found.') };
    return writeManifest({ ...copy(manifest), activeId: id });
  }
  function rename(name) {
    name = String(name || '').trim();
    if (!name || name.length > 80) return { ok: false, error: text('填写 1–80 个字符的名称。', 'Use a name of 1–80 characters.') };
    const next = copy(manifest);
    next.profiles.find(p => p.id === currentId).name = name;
    return writeManifest(next);
  }
  const saveState = () => B.store?.getSaveStatus?.() || { hasData: false, unsaved: false, savedAt: null };
  function statusHTML() {
    return `<aside class="pd-local-status" data-local-status data-i18n-skip><a href="#settings/data" class="pd-local-identity"><span class="pd-local-dot" aria-hidden="true"></span><span>${escape(profileName(current()))}</span><span class="pd-local-label">${text('免登录 · 本机保存', 'No account · On this device')}</span></a><span class="pd-local-state" data-local-state></span></aside>`;
  }
  function settingsHTML() {
    return `<section class="pd-local-panel pd-plan" data-i18n-skip><p class="pd-overline">${text('你的数据，由你保管', 'YOUR DATA, IN YOUR HANDS')}</p><h2>${text('打开就用，下次接着练', 'Open it. Pick up where you left off.')}</h2><p>${text('计划和训练自动保存在当前设备的这个浏览器里。换设备时下载备份，再在新设备导入。', 'Plans and sessions save automatically in this browser on this device. Download a backup and import it to move to another device.')}</p><div class="pd-persistence"><div><strong>${text('减少浏览器自动清理', 'Reduce automatic browser cleanup')}</strong><p data-local-persistence></p></div><button type="button" data-local-action="persist">${text('保护本机记录', 'Protect local records')}</button></div><p class="pd-note">${text('保护生效后，手动清除网站数据仍会删除记录。备份文件请另外保存；不建议在无痕窗口长期记录。', 'Even with protection, clearing site data manually removes records. Keep downloaded backups separately and avoid private windows for long-term recording.')}</p><details class="pd-local-profiles"><summary>${text('本机训练档案', 'Training profiles on this device')} · ${escape(profileName(current()))}</summary><p>${text('共用一台设备时分别记录。档案用于区分数据，不设密码，也不提供账号级隐私隔离。切换前会保存当前输入。', 'Keep separate records on a shared device. These profiles have no passwords and are not private accounts. Current input is saved before switching.')}</p><div class="pd-profile-list">${manifest.profiles.map(p => `<div><span>${escape(profileName(p))}</span>${p.id === currentId ? `<span class="pd-profile-current">${text('当前档案', 'Current')}</span>` : `<button type="button" data-local-action="switch" data-profile="${escape(p.id)}">${text('切换', 'Switch')}</button>`}</div>`).join('')}</div><form id="pd-local-rename"><label>${text('当前档案名称', 'Current profile name')}<input name="name" maxlength="80" required value="${escape(profileName(current()))}"></label><button type="submit">${text('保存名称', 'Save name')}</button></form><form id="pd-local-create"><label>${text('新档案名称', 'New profile name')}<input name="name" maxlength="80" required placeholder="${text('例如：家人的训练', 'For example: Family training')}"></label><button type="submit">${text('新建并切换', 'Create and switch')}</button></form><p class="pd-note">${text('完整 JSON 备份和导入只针对当前档案，不会合并其他人的记录。', 'JSON backup and import apply only to the current profile, without merging anyone else’s records.')}</p></details><p class="pd-local-inline-error" role="alert" data-local-error></p></section>`;
  }
  function updateStatus() {
    const s = saveState();
    document.querySelectorAll('[data-local-status]').forEach(el => {
      el.classList.toggle('is-error', !!(s.unsaved || s.error || s.loadError));
      el.classList.toggle('is-saved', !!s.savedAt && !s.unsaved && !s.error && !s.loadError);
      const label = el.querySelector('[data-local-state]');
      if (label) label.textContent = s.unsaved || s.error || s.loadError ? text('有更改尚未保存 · 查看备份', 'Changes not saved · Check backup') :
        s.savedAt ? text('已保存', 'Saved') : s.hasData ? text('本机记录已恢复', 'Local records restored') : text('操作后自动保存', 'Saves as you go');
    });
  }
  function persistenceCopy() {
    const words = {
      checking: ['正在检查浏览器支持情况…', 'Checking browser support…'],
      granted: ['已启用持久存储保护；仍需保留下载备份。', 'Persistent storage is enabled. Keep a downloaded backup as well.'],
      available: ['可向浏览器申请持久存储，降低自动清理的风险。', 'Request persistent storage to reduce automatic cleanup.'],
      denied: ['浏览器未批准保护。自动保存仍然可用，请下载备份。', 'The browser did not grant protection. Autosave still works; download a backup.'],
      unavailable: ['当前环境不支持此保护。请使用固定 HTTPS 网址，并保留备份。', 'This environment does not support protection. Use a stable HTTPS address and keep backups.'],
      error: ['暂时无法检查保护状态；本机保存与备份仍独立可用。', 'Protection status is unavailable. Local saving and backup work independently.']
    };
    return text(...words[persistence]);
  }
  function paintPersistence() {
    document.querySelectorAll('[data-local-persistence]').forEach(el => el.textContent = persistenceCopy());
    document.querySelectorAll('[data-local-action="persist"]').forEach(el => {
      el.disabled = busy || ['granted', 'unavailable', 'checking'].includes(persistence);
      el.textContent = busy ? text('正在申请…', 'Requesting…') : persistence === 'granted' ? text('已启用保护', 'Protection enabled') : text('保护本机记录', 'Protect local records');
    });
  }
  async function checkPersistence() {
    if (!window.isSecureContext || !navigator.storage?.persisted || !navigator.storage?.persist) persistence = 'unavailable';
    else try { persistence = await navigator.storage.persisted() ? 'granted' : 'available'; } catch (_) { persistence = 'error'; }
    paintPersistence();
  }
  async function requestPersistence() {
    if (busy) return;
    if (!window.isSecureContext || !navigator.storage?.persist) return checkPersistence();
    busy = true; paintPersistence();
    try { persistence = await navigator.storage.persist() ? 'granted' : 'denied'; } catch (_) { persistence = 'error'; }
    busy = false; paintPersistence();
  }
  function reminderHTML() {
    const state = B.flow?.state();
    if (!state) return '';
    const completed = state.sessions.filter(s => s.endedAt && s.sets?.some(r => r.status === 'done' || r.reps > 0));
    if (!completed.length || Date.parse(state.preferences.localBackupSnoozeUntil || '') > Date.now()) return '';
    const exported = state.preferences.lastBackupDownloadRequestedAt;
    const count = completed.filter(s => !exported || s.endedAt > exported).length;
    if (count < 3 && (exported || completed.length > 1)) return '';
    return `<aside class="pd-backup-nudge" data-i18n-skip><span><strong>${text('给训练记录留一份备份', 'Keep a copy of your training')}</strong><span>${text('下载后保存在手机文件、电脑或自己的网盘里。', 'Save the download to Files, your computer or your own cloud drive.')}</span></span><a class="pd-button" href="#settings/data">${text('备份记录', 'Back up records')}</a><button type="button" data-local-action="snooze" aria-label="${text('七天后再提醒', 'Remind me in seven days')}">×</button></aside>`;
  }
  function mount() {
    updateStatus(); paintPersistence();
    const warning = document.querySelector('[data-local-error]');
    if (warning && manifestError) warning.textContent = text('档案目录读取失败，未覆盖原文。请先下载当前训练备份。', 'The profile directory could not be read; original data was not overwritten. Download your current training backup first.');
  }
  function fail(message) {
    const error = document.querySelector('[data-local-error]');
    if (error) error.textContent = message;
    B.Product?.notice(message, true);
  }
  function flush() {
    const result = B.ProductTraining?.collectSet?.();
    if (result && !result.ok) { fail(result.error); return false; }
    if (B.store?.hasUnsavedDraft() || saveState().error || saveState().loadError) { fail(text('当前输入尚未保存。先重试保存或下载备份，再切换档案。', 'Current changes are not saved. Retry or download a backup before switching profiles.')); return false; }
    return true;
  }
  function switchTo(id) {
    const result = activate(id);
    if (!result.ok) return fail(result.error);
    location.hash = 'train/plans';
    location.reload();
  }
  function markBackupDownload() {
    lastExport = now();
    B.store?.transact(s => { s.preferences.lastBackupDownloadRequestedAt = lastExport; });
  }
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-local-action]');
    if (!button) return;
    event.preventDefault();
    if (button.dataset.localAction === 'persist') requestPersistence();
    if (button.dataset.localAction === 'switch' && flush()) switchTo(button.dataset.profile);
    if (button.dataset.localAction === 'snooze') {
      const result = B.store.transact(s => { s.preferences.localBackupSnoozeUntil = new Date(Date.now() + 7 * 86400000).toISOString(); });
      if (result.ok) button.closest('.pd-backup-nudge')?.remove(); else fail(result.error);
    }
  });
  document.addEventListener('submit', event => {
    const form = event.target;
    if (!['pd-local-create', 'pd-local-rename'].includes(form.id)) return;
    event.preventDefault();
    const name = new FormData(form).get('name');
    if (form.id === 'pd-local-create') {
      if (!flush()) return;
      const result = create(name);
      if (result.ok) switchTo(result.id); else fail(result.error);
    } else {
      const result = rename(name);
      if (result.ok) { B.Product.go('settings/data'); B.Product.notice(text('档案名称已保存', 'Profile name saved')); } else fail(result.error);
    }
  });
  window.addEventListener('bm:storage-status', event => {
    clearTimeout(timer);
    const s = event.detail || saveState();
    updateStatus();
    if (s.savedAt && !s.unsaved && !s.error) {
      document.querySelectorAll('[data-local-status]').forEach(el => { el.classList.remove('just-saved'); void el.offsetWidth; el.classList.add('just-saved'); });
      timer = setTimeout(() => document.querySelectorAll('.just-saved').forEach(el => el.classList.remove('just-saved')), 650);
    }
    if (s.error && s.error !== lastFailure) { lastFailure = s.error; B.Product?.notice(text('未能保存到本机，请重试或下载备份。', 'Could not save locally. Retry or download a backup.'), true); }
    if (!s.error) lastFailure = '';
  });
  B.LocalVault = Object.freeze({ storage, currentId, profiles: () => copy(manifest.profiles), profileName: () => profileName(current()),
    create, activate, rename, statusHTML, settingsHTML, reminderHTML, mount, markBackupDownload,
    requestPersistence, checkPersistence, getPersistence: () => persistence });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', checkPersistence, { once: true }); else checkPersistence();
})();
