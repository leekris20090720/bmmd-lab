/* Presentation metadata for every catalog action. Node names refer only to the active rig builder.
 * No geometry, physical calculation, training record or adjustment whitelist changes. */
(function(global){'use strict';
  const profiles = {
  "arm": {
    "parts": [
      {
        "id": "pulley",
        "label": [
          "滑轮车与锁销",
          "Pulley carriage and pin"
        ],
        "nodes": [
          "carriage",
          "carriagePulley",
          "leftPin"
        ]
      },
      {
        "id": "handles",
        "label": [
          "左右握把",
          "Left and right grips"
        ],
        "nodes": [
          "handle",
          "rightHandle"
        ]
      },
      {
        "id": "cable",
        "label": [
          "钢索",
          "Cable"
        ],
        "nodes": [
          "cable",
          "rightCable"
        ]
      },
      {
        "id": "load",
        "label": [
          "配重塔",
          "Weight towers"
        ],
        "nodes": [
          "leftStackLift",
          "rightStackLift"
        ]
      }
    ],
    "preparePart": "pulley",
    "movingPart": "handles",
    "question": [
      "拉力大小不变，为什么滑轮位置仍会改变侧平举的理想力矩？",
      "With tension fixed, why does moving the pulley change the ideal moment?"
    ],
    "model": "pulley",
    "scenario": [
      "身体向侧面摆动，把握把甩高，或滑轮车锁销未锁定。",
      "Leaning sideways to swing the grip up, or leaving the pulley-carriage pin unsecured."
    ]
  },
  "cam": {
    "parts": [
      {
        "id": "seat",
        "label": [
          "坐垫",
          "Seat"
        ],
        "nodes": [
          "seat"
        ]
      },
      {
        "id": "back",
        "label": [
          "靠背",
          "Backrest"
        ],
        "nodes": [
          "backPad"
        ]
      },
      {
        "id": "axis",
        "label": [
          "器械转轴",
          "Machine pivot"
        ],
        "nodes": [
          "bearingHousing1"
        ]
      },
      {
        "id": "roller",
        "label": [
          "小腿垫",
          "Shin pads"
        ],
        "nodes": [
          "rollerCap11"
        ]
      }
    ],
    "preparePart": "axis",
    "movingPart": "roller",
    "question": [
      "为什么同样的力，作用位置不同，转动效果会变化？",
      "Why does the same force have a different turning effect at a different position?"
    ],
    "model": "cam",
    "scenario": [
      "膝关节与机器转轴没有对齐，或小腿垫压在脚背上。",
      "Misaligning the knee and machine pivot, or placing the shin pad on the top of the foot."
    ]
  },
  "incline": {
    "parts": [
      {
        "id": "footplate",
        "label": [
          "踏板与滑车",
          "Footplate and sled"
        ],
        "nodes": [
          "footPlate",
          "carriage"
        ]
      },
      {
        "id": "back",
        "label": [
          "靠背",
          "Backrest"
        ],
        "nodes": [
          "backPad"
        ]
      },
      {
        "id": "safety",
        "label": [
          "保险把手",
          "Racking handles"
        ],
        "nodes": [
          "rackHandleL",
          "rackHandleR"
        ]
      },
      {
        "id": "rails",
        "label": [
          "导轨",
          "Guide rails"
        ],
        "nodes": [
          "railL",
          "railR"
        ]
      }
    ],
    "preparePart": "safety",
    "movingPart": "footplate",
    "question": [
      "同一滑车推起与下放，摩擦怎样改变外力和机械功？",
      "How does friction change force and work during ascent and descent?"
    ],
    "model": "incline",
    "scenario": [
      "挂钩还没有承重，就移开双脚。",
      "Removing the feet before the racking hooks support the sled."
    ]
  },
  "pec": {
    "parts": [
      {
        "id": "seat",
        "label": [
          "坐垫",
          "Seat"
        ],
        "nodes": [
          "seat"
        ]
      },
      {
        "id": "back",
        "label": [
          "靠背",
          "Backrest"
        ],
        "nodes": [
          "backPad"
        ]
      },
      {
        "id": "handles",
        "label": [
          "左右握把",
          "Left and right grips"
        ],
        "nodes": [
          "gripL",
          "gripR"
        ]
      },
      {
        "id": "arms",
        "label": [
          "工作臂",
          "Working arms"
        ],
        "nodes": [
          "leftArm",
          "rightArm"
        ]
      }
    ],
    "preparePart": "seat",
    "movingPart": "arms",
    "question": [
      "飞鸟转臂绕轴运动时，为什么要看垂直力臂？",
      "Why look at the perpendicular arm as the fly arms rotate?"
    ],
    "model": "cam",
    "scenario": [
      "甩动转臂，返回时让配重砸落。",
      "Swinging the arms and letting the stack drop on return."
    ]
  },
  "lat": {
    "parts": [
      {
        "id": "seat",
        "label": [
          "坐垫",
          "Seat"
        ],
        "nodes": [
          "seat"
        ]
      },
      {
        "id": "thigh",
        "label": [
          "固定压腿垫",
          "Fixed thigh pads"
        ],
        "nodes": [
          "thighPadL",
          "thighPadR"
        ]
      },
      {
        "id": "handles",
        "label": [
          "左右握把",
          "Left and right grips"
        ],
        "nodes": [
          "gripL",
          "gripR"
        ]
      },
      {
        "id": "arms",
        "label": [
          "工作臂",
          "Working arms"
        ],
        "nodes": [
          "latArmL",
          "latArmR"
        ]
      }
    ],
    "preparePart": "thigh",
    "movingPart": "arms",
    "question": [
      "固定转臂上的作用位置，怎样影响轴上的力矩？",
      "How does force position on the fixed lever affect shaft torque?"
    ],
    "model": "cam",
    "scenario": [
      "大腿离开固定压腿垫，或回升时突然放开连接工作臂的握把。",
      "Lifting the thighs from the fixed pads, or suddenly releasing the attached grips on return."
    ]
  },
  "barbell-squat": {
    "parts": [
      {
        "id": "bar",
        "label": [
          "杠铃",
          "Barbell"
        ],
        "nodes": [
          "barShaft"
        ]
      },
      {
        "id": "hooks",
        "label": [
          "承杠J杯",
          "J-cups"
        ],
        "nodes": [
          "jCupL",
          "jCupR"
        ]
      },
      {
        "id": "safety",
        "label": [
          "保护装置",
          "Safeties"
        ],
        "nodes": [
          "safetyL",
          "safetyR"
        ]
      },
      {
        "id": "plates",
        "label": [
          "杠铃片",
          "Weight plates"
        ],
        "nodes": [
          "plateL",
          "plateR"
        ]
      }
    ],
    "preparePart": "safety",
    "movingPart": "bar",
    "question": [
      "杠铃重力方向不变，为什么支点与作用线的位置值得观察？",
      "With gravity vertical, why do pivot and force-line positions matter?"
    ],
    "model": "qualitative",
    "scenario": [
      "回架时没有确认两端都落入J杯。",
      "Releasing the bar before both ends rest in the J-cups."
    ]
  },
  "cable-row": {
    "parts": [
      {
        "id": "seat",
        "label": [
          "坐垫",
          "Seat"
        ],
        "nodes": [
          "seat"
        ]
      },
      {
        "id": "feet",
        "label": [
          "斜面脚踏",
          "Angled footplates"
        ],
        "nodes": [
          "footL",
          "footR"
        ]
      },
      {
        "id": "handles",
        "label": [
          "左右握把",
          "Left and right grips"
        ],
        "nodes": [
          "neutralGripL",
          "neutralGripR"
        ]
      },
      {
        "id": "arms",
        "label": [
          "工作臂",
          "Working arms"
        ],
        "nodes": [
          "rowYoke"
        ]
      }
    ],
    "preparePart": "feet",
    "movingPart": "arms",
    "question": [
      "划船转臂的角度改变，垂直力臂会怎样变化？",
      "How does the moment arm change as the rowing lever rotates?"
    ],
    "model": "cam",
    "scenario": [
      "脚没有稳在斜面踏板上，返回握把时躯干跟着前后摆动。",
      "Losing foot support on the angled plates and rocking the trunk as the grips return."
    ]
  },
  "barbell-bench": {
    "parts": [
      {
        "id": "bench",
        "label": [
          "平板凳",
          "Bench"
        ],
        "nodes": [
          "bench"
        ]
      },
      {
        "id": "bar",
        "label": [
          "杠铃",
          "Barbell"
        ],
        "nodes": [
          "barShaft"
        ]
      },
      {
        "id": "supports",
        "label": [
          "承杠立架",
          "Bar supports"
        ],
        "nodes": [
          "benchRackL",
          "benchRackR"
        ]
      },
      {
        "id": "plates",
        "label": [
          "杠铃片",
          "Weight plates"
        ],
        "nodes": [
          "plateL",
          "plateR"
        ]
      }
    ],
    "preparePart": "bench",
    "movingPart": "bar",
    "question": [
      "杠铃的重力怎样通过不同作用位置形成转动作用？",
      "How can a vertical barbell force create different turning effects?"
    ],
    "model": "qualitative",
    "scenario": [
      "用胸部弹起杠铃，或没有稳住就回杠。",
      "Bouncing the bar off the chest or racking it before it is steady."
    ]
  },
  "flat-press": {
    "parts": [
      {
        "id": "seat",
        "label": [
          "坐垫",
          "Seat"
        ],
        "nodes": [
          "seat"
        ]
      },
      {
        "id": "back",
        "label": [
          "靠背",
          "Backrest"
        ],
        "nodes": [
          "backPad"
        ]
      },
      {
        "id": "handles",
        "label": [
          "左右握把",
          "Left and right grips"
        ],
        "nodes": [
          "pronatedGripL",
          "pronatedGripR",
          "neutralGripL",
          "neutralGripR"
        ]
      },
      {
        "id": "arms",
        "label": [
          "工作臂",
          "Working arms"
        ],
        "nodes": [
          "armL",
          "armR"
        ]
      }
    ],
    "preparePart": "seat",
    "movingPart": "arms",
    "question": [
      "推胸工作臂转动时，同样的拉力怎样形成轴上力矩？",
      "How does the same pull create shaft torque as chest-press arms rotate?"
    ],
    "model": "cam",
    "scenario": [
      "返回时握把突然弹回，背部离开靠背。",
      "Letting the grips rebound while the back lifts from its support."
    ]
  },
  "incline-press": {
    "parts": [
      {
        "id": "seat",
        "label": [
          "坐垫",
          "Seat"
        ],
        "nodes": [
          "seat"
        ]
      },
      {
        "id": "back",
        "label": [
          "靠背",
          "Backrest"
        ],
        "nodes": [
          "backPad"
        ]
      },
      {
        "id": "handles",
        "label": [
          "左右握把",
          "Left and right grips"
        ],
        "nodes": [
          "handleL",
          "handleR"
        ]
      },
      {
        "id": "load",
        "label": [
          "工作臂挂片杆",
          "Working-arm loading horns"
        ],
        "nodes": [
          "hornL",
          "hornR"
        ]
      }
    ],
    "preparePart": "seat",
    "movingPart": "handles",
    "question": [
      "上斜推胸的工作臂转动时，作用线到轴的距离怎样变？",
      "How does the force-line distance change as incline-press arms rotate?"
    ],
    "model": "cam",
    "scenario": [
      "两侧工作臂回落不同步，未先确认握把起点与座位支撑。",
      "Returning the independent arms unevenly without checking the starting grips and seat support."
    ]
  },
  "cable-fly": {
    "parts": [
      {
        "id": "pulley",
        "label": [
          "双侧滑轮车",
          "Both pulley carriages"
        ],
        "nodes": [
          "carriage",
          "rightCarriage",
          "carriagePulley",
          "rightPulley"
        ]
      },
      {
        "id": "handles",
        "label": [
          "左右握把",
          "Left and right grips"
        ],
        "nodes": [
          "handleL",
          "handleR"
        ]
      },
      {
        "id": "pins",
        "label": [
          "滑轮锁销",
          "Pulley locking pins"
        ],
        "nodes": [
          "leftPin",
          "rightPin"
        ]
      },
      {
        "id": "cable",
        "label": [
          "双侧钢索",
          "Both cables"
        ],
        "nodes": [
          "cableL",
          "cableR"
        ]
      }
    ],
    "preparePart": "pins",
    "movingPart": "handles",
    "question": [
      "双侧钢索拉动同样配重时，怎样用更长行程换取更小拉力？",
      "How can longer handle travel trade for less force on an ideal cable transmission?"
    ],
    "model": "pulley",
    "scenario": [
      "张开时让钢索把身体拉回，连接扣没有先检查。",
      "Letting the cables pull the body backward on opening without checking the clips first."
    ]
  },
  "machine-fly": {
    "parts": [
      {
        "id": "seat",
        "label": [
          "坐垫",
          "Seat"
        ],
        "nodes": [
          "seat"
        ]
      },
      {
        "id": "back",
        "label": [
          "靠背",
          "Backrest"
        ],
        "nodes": [
          "backPad"
        ]
      },
      {
        "id": "handles",
        "label": [
          "左右握把",
          "Left and right grips"
        ],
        "nodes": [
          "leftArmGrip",
          "rightArmGrip"
        ]
      },
      {
        "id": "arms",
        "label": [
          "工作臂",
          "Working arms"
        ],
        "nodes": [
          "leftArm",
          "rightArm"
        ]
      }
    ],
    "preparePart": "seat",
    "movingPart": "arms",
    "question": [
      "蝴蝶机的转臂位置为什么会影响有效力臂？",
      "Why does fly-arm position affect the effective moment arm?"
    ],
    "model": "cam",
    "scenario": [
      "没有核对起始挡位，返回时握把撞回起点。",
      "Skipping the starting-position check and letting the grips strike the stop on return."
    ]
  },
  "scissor-pulldown": {
    "parts": [
      {
        "id": "seat",
        "label": [
          "坐垫",
          "Seat"
        ],
        "nodes": [
          "seat"
        ]
      },
      {
        "id": "thigh",
        "label": [
          "大腿垫",
          "Thigh pads"
        ],
        "nodes": [
          "thighL",
          "thighR"
        ]
      },
      {
        "id": "handles",
        "label": [
          "左右握把",
          "Left and right grips"
        ],
        "nodes": [
          "handleL",
          "handleR"
        ]
      },
      {
        "id": "arms",
        "label": [
          "工作臂",
          "Working arms"
        ],
        "nodes": [
          "armL",
          "armR"
        ]
      }
    ],
    "preparePart": "thigh",
    "movingPart": "arms",
    "question": [
      "分动下拉每侧工作臂怎样传递转动作用？",
      "How does each independent pulldown arm transmit a turning effect?"
    ],
    "model": "cam",
    "scenario": [
      "大腿离开固定位置，两侧转臂在返回时突然向上弹。",
      "Losing thigh support and allowing the independent arms to rebound upward."
    ]
  },
  "nautilus-pullover": {
    "parts": [
      {
        "id": "seat",
        "label": [
          "坐垫",
          "Seat"
        ],
        "nodes": [
          "seat"
        ]
      },
      {
        "id": "back",
        "label": [
          "靠背",
          "Backrest"
        ],
        "nodes": [
          "backPad"
        ]
      },
      {
        "id": "elbow",
        "label": [
          "肘垫",
          "Elbow pads"
        ],
        "nodes": [
          "elbowPadL",
          "elbowPadR"
        ]
      },
      {
        "id": "belt",
        "label": [
          "安全带",
          "Seat belt"
        ],
        "nodes": [
          "seatBelt"
        ]
      }
    ],
    "preparePart": "belt",
    "movingPart": "elbow",
    "question": [
      "肘垫绕器械轴运动时，应怎样区分支臂长度和力臂？",
      "How do we distinguish lever length from moment arm as the elbow pads rotate?"
    ],
    "model": "cam",
    "scenario": [
      "没有先确认型号与起始位置，就套用其他版本的调节方法。",
      "Using another version’s settings without checking the model and starting position."
    ]
  },
  "hammer-row": {
    "parts": [
      {
        "id": "seat",
        "label": [
          "坐垫",
          "Seat"
        ],
        "nodes": [
          "seat"
        ]
      },
      {
        "id": "chest",
        "label": [
          "胸垫",
          "Chest pad"
        ],
        "nodes": [
          "chestPad"
        ]
      },
      {
        "id": "handles",
        "label": [
          "左右握把",
          "Left and right grips"
        ],
        "nodes": [
          "handleL",
          "handleR"
        ]
      },
      {
        "id": "arms",
        "label": [
          "工作臂",
          "Working arms"
        ],
        "nodes": [
          "armL",
          "armR"
        ]
      }
    ],
    "preparePart": "chest",
    "movingPart": "arms",
    "question": [
      "胸托划船的转臂角度怎样改变垂直力臂？",
      "How does lever angle change the moment arm on a chest-supported row?"
    ],
    "model": "cam",
    "scenario": [
      "胸部离开胸垫，用躯干摆动把握把向后拉。",
      "Lifting the chest from its pad and using trunk swing to pull the handles."
    ]
  },
  "cable-pulldown": {
    "parts": [
      {
        "id": "bar",
        "label": [
          "高位下拉杆",
          "High pulldown bar"
        ],
        "nodes": [
          "bar",
          "barEndL",
          "barEndR"
        ]
      },
      {
        "id": "rowGrip",
        "label": [
          "低位划船握把",
          "Low-row grips"
        ],
        "nodes": [
          "rowGripL",
          "rowGripR"
        ]
      },
      {
        "id": "thigh",
        "label": [
          "大腿垫",
          "Thigh pads"
        ],
        "nodes": [
          "thighPadL",
          "thighPadR"
        ]
      },
      {
        "id": "feet",
        "label": [
          "划船脚踏",
          "Row foot supports"
        ],
        "nodes": [
          "rowFootPegL",
          "rowFootPegR"
        ]
      }
    ],
    "preparePart": "thigh",
    "movingPart": "bar",
    "question": [
      "抬升同一配重同样高度时，理想倍率怎样改变拉力与行程？",
      "At the same load and lift height, how does ideal ratio change force and travel?"
    ],
    "model": "pulley",
    "scenario": [
      "附件没有接牢，配重未落稳就松开握把。",
      "Using an unsecured attachment or releasing it before the stack settles."
    ]
  },
  "machine-military-press": {
    "parts": [
      {
        "id": "seat",
        "label": [
          "坐垫",
          "Seat"
        ],
        "nodes": [
          "seat"
        ]
      },
      {
        "id": "back",
        "label": [
          "靠背",
          "Backrest"
        ],
        "nodes": [
          "backPad"
        ]
      },
      {
        "id": "handles",
        "label": [
          "左右握把",
          "Left and right grips"
        ],
        "nodes": [
          "handleL",
          "handleR"
        ]
      },
      {
        "id": "arms",
        "label": [
          "工作臂",
          "Working arms"
        ],
        "nodes": [
          "armL",
          "armR"
        ]
      }
    ],
    "preparePart": "seat",
    "movingPart": "arms",
    "question": [
      "分动肩推的每侧转臂，怎样把外力传到转轴？",
      "How does each independent shoulder-press arm transmit force to its pivot?"
    ],
    "model": "cam",
    "scenario": [
      "一侧握把先下落，起始位置超出自己可控制的范围。",
      "Dropping one grip first or starting beyond a controllable range."
    ]
  },
  "seated-machine-shoulder": {
    "parts": [
      {
        "id": "seat",
        "label": [
          "坐垫",
          "Seat"
        ],
        "nodes": [
          "seat"
        ]
      },
      {
        "id": "back",
        "label": [
          "靠背",
          "Backrest"
        ],
        "nodes": [
          "backPad"
        ]
      },
      {
        "id": "handles",
        "label": [
          "左右握把",
          "Left and right grips"
        ],
        "nodes": [
          "overhandGripL",
          "overhandGripR",
          "neutralGripL",
          "neutralGripR"
        ]
      },
      {
        "id": "arms",
        "label": [
          "工作臂",
          "Working arms"
        ],
        "nodes": [
          "armL",
          "armR"
        ]
      }
    ],
    "preparePart": "seat",
    "movingPart": "arms",
    "question": [
      "肩推转臂运动时，垂距怎样决定轴上的转动作用？",
      "How does perpendicular distance determine turning effect on shoulder-press arms?"
    ],
    "model": "cam",
    "scenario": [
      "背部离开靠背，返回时任配重撞击。",
      "Losing backrest support and letting the stack collide on return."
    ]
  },
  "home-wall-press-up": {
    "parts": [
      {
        "id": "support",
        "label": [
          "牢固墙面",
          "Stable wall"
        ],
        "nodes": []
      },
      {
        "id": "hands",
        "label": [
          "双手位置",
          "Hand position"
        ],
        "nodes": []
      },
      {
        "id": "body",
        "label": [
          "躯干位置",
          "Trunk position"
        ],
        "nodes": []
      }
    ],
    "preparePart": "support",
    "movingPart": "body",
    "question": [
      "墙面支撑与身体位置",
      "Wall support and body position"
    ],
    "model": "qualitative",
    "scenario": [
      "手在墙面上打滑，或脚的位置无法保持稳定。",
      "Hands slipping on the wall or feet unable to stay stable."
    ]
  },
  "home-sit-to-stand": {
    "parts": [
      {
        "id": "support",
        "label": [
          "稳固椅子",
          "Stable chair"
        ],
        "nodes": []
      },
      {
        "id": "feet",
        "label": [
          "双脚位置",
          "Foot position"
        ],
        "nodes": []
      },
      {
        "id": "body",
        "label": [
          "躯干位置",
          "Trunk position"
        ],
        "nodes": []
      }
    ],
    "preparePart": "support",
    "movingPart": "body",
    "question": [
      "椅子支撑与起坐顺序",
      "Chair support and sit-to-stand sequence"
    ],
    "model": "qualitative",
    "scenario": [
      "椅子滑动，或坐下时直接跌落到椅面。",
      "The chair sliding, or dropping onto the seat instead of a controlled return."
    ]
  },
  "home-mini-squat": {
    "parts": [
      {
        "id": "support",
        "label": [
          "稳固椅背",
          "Stable chair back"
        ],
        "nodes": []
      },
      {
        "id": "feet",
        "label": [
          "双脚位置",
          "Foot position"
        ],
        "nodes": []
      },
      {
        "id": "body",
        "label": [
          "躯干位置",
          "Trunk position"
        ],
        "nodes": []
      }
    ],
    "preparePart": "support",
    "movingPart": "body",
    "question": [
      "椅背支撑与小幅屈膝",
      "Chair support and a small knee bend"
    ],
    "model": "qualitative",
    "scenario": [
      "扶着会移动的椅背，或屈膝幅度超出可控制范围。",
      "Holding a moving chair back or bending beyond a controllable range."
    ]
  },
  "home-calf-raise": {
    "parts": [
      {
        "id": "support",
        "label": [
          "稳固椅背",
          "Stable chair back"
        ],
        "nodes": []
      },
      {
        "id": "feet",
        "label": [
          "脚跟位置",
          "Heel position"
        ],
        "nodes": []
      },
      {
        "id": "body",
        "label": [
          "躯干位置",
          "Trunk position"
        ],
        "nodes": []
      }
    ],
    "preparePart": "support",
    "movingPart": "body",
    "question": [
      "椅背支撑与脚跟升降",
      "Chair support and heel movement"
    ],
    "model": "qualitative",
    "scenario": [
      "升降脚跟时支撑移动，返回时失去平衡。",
      "The support moving during heel raises or balance being lost on return."
    ]
  }
};
  function forAction(a){const p=profiles[a.id];if(!p)throw Error('Missing lesson profile: '+a.id);return p;}
  function anchors(sceneKey,parts){const p=profiles[sceneKey];const result={};if(!p)return result;for(const item of p.parts){const targets=item.nodes.map(n=>parts[n]).filter(n=>n?.isObject3D);if(!targets.length)continue;result[item.id]={node:targets[0],target:targets[0],targets,label:item.label[0],text:item.label[0],sourceNodes:item.nodes.filter(n=>parts[n]?.isObject3D)};}return result;}
  function lesson(a){
    const p=forAction(a),setup=a.setup||{general:[],model:[]},prepare=[...(a.steps?.[0]?.cues||[])];
    const errors=a.commonErrors?.length?a.commonErrors.map(e=>({...e,lookPart:e.phase==='prepare'?p.preparePart:p.movingPart})): [
      {example:['没有先确认支撑或器械固定，就开始练习。','Starting before checking the support and equipment setup.'],correction:setup.model?.at(-1)||setup.general?.[0]||prepare[0],phase:'prepare',lookPart:p.preparePart},
      {example:p.scenario,correction:p.model==='qualitative'?setup.general[0]:a.id==='nautilus-pullover'?setup.model[0]:a.steps[2].cues[0],phase:'return',lookPart:p.movingPart},
      {example:['返回时只顾结束，没有核对控制与收尾。','Finishing the return without checking control and completion.'],correction:a.steps[2].cues[0],phase:'return',lookPart:p.movingPart}
    ];
    return {...p,scenarioSource:{kind:'teaching-self-check',basis:'Current catalog setup and phase cues',sourceIds:(a.steps||[]).flatMap(s=>s.sourceIds||[]),measured:false},prepare,setup:[...(setup.model||[]),...(setup.general||[])],errors};
  }
  function translate(text,language){if(language!=='en')return text;for(const p of Object.values(profiles)){for(const item of p.parts)if(item.label[0]===text)return item.label[1];}return null;}
  const api={profiles,forAction,lesson,anchors,translate};
  if(typeof module==='object'&&module.exports)module.exports=api;else (global.BM=global.BM||{}).LessonProfiles=api;
})(typeof window==='object'?window:globalThis);
