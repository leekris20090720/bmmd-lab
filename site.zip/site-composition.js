/* Scroll composition around existing semantic content; no route or data owner. */
(function(){'use strict';
  const B=window.BM=window.BM||{},reduce=matchMedia('(prefers-reduced-motion:reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)'),home=document.getElementById('portal-hub-overlay'),copy=document.querySelector('.apple-hero-copy'),heading=copy?.querySelector('h1'),intro=document.getElementById('bm-home-intro');
  if(!home||!heading)return;
  const stage=document.createElement('div');stage.className='bm-heading-stage';heading.before(stage);stage.append(heading);
  const ghosts=[1,2].map(n=>{const e=document.createElement('span');e.className='bm-heading-ghost bm-ghost-'+n;e.setAttribute('aria-hidden','true');stage.append(e);return e;});
  const windowImage=document.createElement('span');windowImage.className='bm-inline-window';windowImage.setAttribute('aria-hidden','true');windowImage.innerHTML='<img src="assets/equipment-reference/op-le.png" alt="" decoding="async">';intro.querySelector('h2 mark')?.before(windowImage);
  let frame=0,lastScroll=home.scrollTop,lastTime=performance.now(),velocity=0,settle=0,lastRoute='';
  const clamp=x=>Math.max(0,Math.min(1,x));
  function text(){const words=B.i18n?.t('从学会一个动作开始。')||'从学会一个动作开始。';const font=getComputedStyle(heading);ghosts.forEach(e=>{e.textContent=words;e.style.font=font.font;e.style.letterSpacing=font.letterSpacing;});}
  function paint(now){frame=0;const visible=!document.hidden&&!document.body.hasAttribute('data-explore-open')&&document.body.dataset.bmRoute==='home';if(!visible)return;
    const y=home.scrollTop,p=reduce.matches?0:clamp(y/Math.max(360,innerHeight*.7));velocity=Math.min(1,Math.abs(y-lastScroll)/Math.max(1,now-lastTime)*.5);lastScroll=y;lastTime=now;
    stage.style.setProperty('--title-scale',String(1-p*.13));stage.style.setProperty('--title-rise',(-p*12)+'px');stage.style.setProperty('--title-trail',reduce.matches?'0':String(velocity*.24));
    const r=intro.getBoundingClientRect(),reveal=reduce.matches?1:clamp((innerHeight*.85-r.top)/(innerHeight*.55));intro.style.setProperty('--image-open',String(reveal));home.style.setProperty('--chapter-shift',(p*48)+'px');
    clearTimeout(settle);settle=setTimeout(()=>stage.style.setProperty('--title-trail','0'),180);
    document.documentElement.dataset.composition=JSON.stringify({homeModel:false,titleProgress:+p.toFixed(3),imageProgress:+reveal.toFixed(3),reduced:reduce.matches});
  }
  function schedule(){if(!frame)frame=requestAnimationFrame(paint);}
  const observed=new WeakSet(),observer=new IntersectionObserver(entries=>entries.forEach(({target,isIntersecting})=>{if(isIntersecting){target.classList.add('bm-chapter-arrived');observer.unobserve(target);}}),{threshold:.15});
  function scan(){document.querySelectorAll('#bm-learning-panel h2,#engineering-root .did-lab-intro h2,#beginner-root .bm-page-heading h1').forEach(el=>{if(observed.has(el)||el.hasAttribute('data-text-fx')||el.hasAttribute('data-heading-renderer'))return;observed.add(el);el.classList.add('bm-chapter-title');observer.observe(el);});const route=document.body.dataset.bmRoute;if(route!==lastRoute){lastRoute=route;const image=document.querySelector('#bm-learning-panel .did-reference img'),name=document.querySelector('#bm-learning-panel h1');if(image)image.style.viewTransitionName='bm-equipment-image';if(name)name.style.viewTransitionName='bm-equipment-name';}syncTitlePointer();schedule();}
  let scanFrame=0;const queue=()=>{if(!scanFrame)scanFrame=requestAnimationFrame(()=>{scanFrame=0;scan();});};
  new MutationObserver(records=>{if(records.some(r=>r.type==='attributes'||Array.from(r.addedNodes).some(n=>n.nodeType===1&&(n.matches?.('h1,h2,.did-reference')||n.querySelector?.('h1,h2,.did-reference')))))queue();}).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['data-bm-route']});
  const brand=document.querySelector('.apple-welcome-header strong');
  let titlePointerPaused=false;
  // Reuse the existing control's published state; keep its React owner and
  // persistence unchanged. The control pauses pointer effects, not scroll text.
  function syncTitlePointer(){titlePointerPaused=!!document.querySelector('[data-site-motion][aria-pressed="true"]');brand?.classList.toggle('bm-brand-static',titlePointerPaused||reduce.matches);if(titlePointerPaused||reduce.matches)brand?.classList.remove('bm-lens-active');}
  new MutationObserver(records=>{if(records.some(r=>r.target.hasAttribute('data-site-motion')))syncTitlePointer();}).observe(document.body,{subtree:true,attributes:true,attributeFilter:['aria-pressed']});
  if(brand){brand.classList.add('bm-brand-lens');const lens=document.createElement('span');lens.className='bm-brand-refraction';lens.setAttribute('aria-hidden','true');lens.textContent='BM//MD';brand.append(lens);brand.addEventListener('pointermove',event=>{if(!fine.matches||reduce.matches||titlePointerPaused||event.pointerType==='touch')return;const r=brand.getBoundingClientRect();brand.style.setProperty('--lens-x',(event.clientX-r.left)+'px');brand.style.setProperty('--lens-y',(event.clientY-r.top)+'px');brand.classList.add('bm-lens-active');});brand.addEventListener('pointerleave',()=>brand.classList.remove('bm-lens-active'));}
  const filters=document.createElementNS('http://www.w3.org/2000/svg','svg');filters.setAttribute('aria-hidden','true');filters.style.cssText='position:absolute;width:0;height:0;pointer-events:none';filters.innerHTML='<defs><filter id="bm-local-refraction"><feTurbulence type="fractalNoise" baseFrequency=".035" numOctaves="1" seed="3" result="noise"/><feDisplacementMap in="SourceGraphic" in2="noise" scale="2.6" xChannelSelector="R" yChannelSelector="G"/></filter></defs>';document.body.append(filters);
  function transitionTargets(){const image=document.querySelector('#bm-learning-panel .did-reference img'),name=document.querySelector('#bm-learning-panel h1');if(image)image.style.viewTransitionName='bm-equipment-image';if(name)name.style.viewTransitionName='bm-equipment-name';}
  B.composition={transition(update){
    if(reduce.matches||!document.startViewTransition){update();return;}
    try{
      const active=document.querySelector('bm-explore')?.shadowRoot,photo=active?.querySelector('.pg-gallery-object img'),name=active?.querySelector('.pg-gallery-info h3');
      if(photo)photo.style.viewTransitionName='bm-equipment-image';if(name)name.style.viewTransitionName='bm-equipment-name';
      document.documentElement.dataset.bmTransition='running';
      const transition=document.startViewTransition(()=>new Promise(resolve=>{
        // Rendering may be suspended inside this callback. Await the existing
        // route event rather than an animation frame, which can deadlock it.
        let timer=0;const done=()=>{clearTimeout(timer);window.removeEventListener('hashchange',done);transitionTargets();resolve();};
        window.addEventListener('hashchange',done,{once:true});timer=setTimeout(done,120);update();
      }));
      transition.finished.then(()=>document.documentElement.dataset.bmTransition='complete',()=>document.documentElement.dataset.bmTransition='fallback');
    }catch{document.documentElement.dataset.bmTransition='fallback';update();}
  }};
  home.addEventListener('scroll',schedule,{passive:true});window.addEventListener('resize',()=>{text();schedule();},{passive:true});document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;clearTimeout(settle);stage.style.setProperty('--title-trail','0');}else schedule();});document.addEventListener('bm:language-change',()=>{text();schedule();});reduce.addEventListener('change',()=>{syncTitlePointer();schedule();});text();scan();
})();
