/* Shared presentation lighting. No model geometry, coordinates or physics change. */
(function (global) {
  'use strict';
  const B=global.BM=global.BM||{};
  B.StudioRendering={
    create({THREE:T,renderer,scene,onDirty=()=>{}}){
      const owned=[],room=new T.Scene();
      const addPanel=(width,height,position,rotation,intensity)=>{
        const geometry=new T.PlaneGeometry(width,height),material=new T.MeshBasicMaterial({color:new T.Color(intensity,intensity,intensity),side:T.DoubleSide});
        const mesh=new T.Mesh(geometry,material);mesh.position.set(...position);mesh.rotation.set(...rotation);room.add(mesh);owned.push(geometry,material);
      };
      // Broad softboxes give steel a readable reflection without a downloaded HDRI.
      addPanel(8,6,[0,6,0],[-Math.PI/2,0,0],2.7);
      addPanel(5,8,[5,1,2],[0,-Math.PI/2,0],2.1);
      addPanel(3,6,[-5,2,-3],[0,Math.PI/2,0],1.3);
      let environment=null;
      try {const pmrem=new T.PMREMGenerator(renderer);environment=pmrem.fromScene(room,.04);pmrem.dispose();scene.environment=environment.texture;scene.environmentIntensity=.55;} catch(error){console.info('Studio reflections unavailable; directional lighting remains active.');}
      owned.forEach(resource=>resource.dispose());
      const hemi=new T.HemisphereLight(0xf4f7fa,0x6b7580,1.65),key=new T.DirectionalLight(0xfff8ed,3.2),rim=new T.DirectionalLight(0xb9d0e0,1.8);
      key.position.set(7,9,6);rim.position.set(-7,5,-4);scene.add(hemi,key,rim);
      const textureCanvas=document.createElement('canvas');textureCanvas.width=textureCanvas.height=128;
      const ctx=textureCanvas.getContext('2d'),gradient=ctx.createRadialGradient(64,64,4,64,64,64);gradient.addColorStop(0,'rgba(20,31,40,.38)');gradient.addColorStop(.45,'rgba(20,31,40,.16)');gradient.addColorStop(1,'rgba(20,31,40,0)');ctx.fillStyle=gradient;ctx.fillRect(0,0,128,128);
      const texture=new T.CanvasTexture(textureCanvas),floorGeometry=new T.PlaneGeometry(1,1),floorMaterial=new T.MeshBasicMaterial({map:texture,transparent:true,depthWrite:false,opacity:.7});
      const floor=new T.Mesh(floorGeometry,floorMaterial);floor.rotation.x=-Math.PI/2;floor.userData.inspectionDecoration=true;floor.name='Studio contact shadow · presentation only';scene.add(floor);
      function fitFloor(group){
        if(!group){floor.visible=false;return;}group.updateWorldMatrix(true,true);const box=new T.Box3();
        group.traverse(node=>{if(node.isMesh&&!node.userData.dragProxy&&!node.userData.forceIndicator&&node.visible&&node.geometry?.boundingBox!==null){box.union(new T.Box3().setFromObject(node));}else if(node.isMesh&&!node.userData.dragProxy&&!node.userData.forceIndicator&&node.visible)box.union(new T.Box3().setFromObject(node));});
        if(box.isEmpty()){floor.visible=false;return;}const size=box.getSize(new T.Vector3()),center=box.getCenter(new T.Vector3());floor.visible=true;floor.position.set(center.x,box.min.y-.008,center.z);floor.scale.set(Math.max(.3,size.x*1.4),Math.max(.3,size.z*1.45),1);onDirty();
      }
      function theme(){const dark=document.body.classList.contains('dark-mode');hemi.intensity=dark?1.8:1.65;rim.intensity=dark?2.2:1.8;floorMaterial.opacity=dark?.95:.7;onDirty();}
      const observer=new MutationObserver(theme);observer.observe(document.body,{attributes:true,attributeFilter:['class']});theme();
      return {fitFloor,dispose(){observer.disconnect();[hemi,key,rim,floor].forEach(node=>node.removeFromParent());floorGeometry.dispose();floorMaterial.dispose();texture.dispose();if(scene.environment===environment?.texture)scene.environment=null;environment?.dispose();}};
    }
  };
})(window);
