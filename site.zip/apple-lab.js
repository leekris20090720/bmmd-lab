/* Presentation only: existing simulation, controls and training storage stay in script.js. */
(() => {
  'use strict';
  const body = document.body;
  const themeKey = 'bmmd_apple_theme_v1';
  try { body.classList.toggle('dark-mode', localStorage.getItem(themeKey) === 'dark'); } catch {}
  const themeObserver = new MutationObserver(() => {
    try { localStorage.setItem(themeKey, body.classList.contains('dark-mode') ? 'dark' : 'light'); } catch {}
  });
  themeObserver.observe(body, { attributes: true, attributeFilter: ['class'] });

  const categoryImages = { chest: 'op-cp.png', shoulder: 'op-sp.png', back: 'il-row.png', legs: 'hsllp.png' };
  document.querySelectorAll('.lab-category-card[data-lab-category]').forEach((card) => {
    const file = categoryImages[card.dataset.labCategory];
    if (!file || card.querySelector('.apple-category-image')) return;
    const image = document.createElement('img');
    image.className = 'apple-category-image';
    image.src = `assets/equipment-reference/${file}`;
    image.alt = '';
    image.decoding = 'async';
    card.prepend(image);
  });
  const workspaceImages = ['op-dap.png', 'il-row.png'];
  document.querySelectorAll('.workspace-gateway-card').forEach((card, index) => {
    if (card.querySelector('.apple-workspace-image')) return;
    const image = document.createElement('img');
    image.className = 'apple-workspace-image';
    image.src = `assets/equipment-reference/${workspaceImages[index] || 'op-dap.png'}`;
    image.alt = '';
    image.decoding = 'async';
    card.append(image);
  });

  /* Explicit, local presentation effects. No model, storage or timer state is read here. */
  const B = window.BM = window.BM || {};
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const protectedSelector = 'canvas,.sphere-node,.sphere-center,#btn-m3-push,#btn-m3-release,[data-ui-no-motion]';
  const segments = new Map();
  const effects = new Map();
  const pending = new Map();
  const closingDialogs = new Map();
  let frame = 0;
  let suspended = document.hidden;
  let destroyed = false;

  function duration(token, fallback) {
    const raw = getComputedStyle(document.documentElement).getPropertyValue(token).trim();
    const n = Number.parseFloat(raw);
    return Number.isFinite(n) ? n * (raw.endsWith('ms') ? 1 : 1000) : fallback;
  }
  function ease() {
    return getComputedStyle(document.documentElement).getPropertyValue('--ui-motion-ease').trim() || 'cubic-bezier(.2,.8,.2,1)';
  }
  function cancelEffect(key) {
    const effect = effects.get(key);
    if (!effect) return;
    effects.delete(key);
    effect.animation.cancel();
  }
  function animate(element, key, keyframes, options) {
    cancelEffect(key);
    if (destroyed || suspended || reducedMotion.matches || !element?.isConnected || typeof element.animate !== 'function') return null;
    let animation;
    try { animation = element.animate(keyframes, { easing: ease(), ...options }); }
    catch { return null; } // Underlying DOM always stays visible when WAAPI is unavailable.
    const effect = { animation, element };
    effects.set(key, effect);
    animation.finished.then(() => {
      if (effects.get(key) !== effect) return;
      effects.delete(key);
      animation.cancel();
    }, () => {});
    return animation;
  }
  function protectedElement(element) {
    return !element || element.nodeType !== 1 || element.matches(protectedSelector) ||
      element.closest('.sphere-node,.sphere-center,[data-ui-no-motion]') ||
      element.querySelector(protectedSelector);
  }
  function cancelAll() {
    for (const key of [...effects.keys()]) cancelEffect(key);
  }
  function stopSegment(record, remove = false) {
    record.mutation?.disconnect();
    record.resize?.disconnect();
    cancelEffect(record.indicator);
    pending.delete(record);
    if (remove) {
      record.indicator.remove();
      record.element.classList.remove('ui-segment-ready', 'ui-segment-multiline');
      segments.delete(record.element);
    }
  }
  function buttonsFor(element) {
    return [...element.querySelectorAll('button[aria-pressed]')].filter(button =>
      button.closest('[data-ui-segment]') === element && !button.matches(protectedSelector));
  }
  function segmentKey(element) {
    return element.getAttribute('data-ui-segment')?.trim() || '';
  }
  function signature(buttons) {
    return buttons.map(button => button.dataset.mode || button.dataset.stage || button.dataset.day ||
      button.dataset.group || button.dataset.actionFilter || button.textContent.trim()).join('\u001f');
  }
  function measure(record, allowAnimation) {
    const element = record.element;
    if (!element.isConnected || !element.getClientRects().length) {
      record.indicator.hidden = true;
      return;
    }
    const buttons = buttonsFor(element).filter(button => button.getClientRects().length);
    const pressed = buttons.filter(button => button.getAttribute('aria-pressed') === 'true');
    const rects = buttons.map(button => button.getBoundingClientRect());
    const multiline = rects.some(rect => Math.abs(rect.top - rects[0].top) > 3);
    element.classList.toggle('ui-segment-multiline', multiline);
    const ready = !multiline && pressed.length === 1 && element.dataset.uiSegment !== 'multiple';
    element.classList.toggle('ui-segment-ready', ready);
    record.indicator.hidden = !ready;
    if (!ready) {
      cancelEffect(record.indicator);
      record.position = null;
      return;
    }
    const outer = element.getBoundingClientRect();
    const target = pressed[0].getBoundingClientRect();
    if (target.width <= 0 || target.height <= 0) {
      record.indicator.hidden = true;
      record.position = null;
      return;
    }
    const position = {
      x: target.left - outer.left + element.scrollLeft - element.clientLeft,
      y: target.top - outer.top + element.scrollTop - element.clientTop,
      width: target.width,
      height: target.height
    };
    let previous = record.position;
    if (previous && effects.has(record.indicator)) {
      const moving = record.indicator.getBoundingClientRect();
      if (moving.width > 0 && moving.height > 0) previous = {
        x: moving.left - outer.left + element.scrollLeft - element.clientLeft,
        y: moving.top - outer.top + element.scrollTop - element.clientTop,
        width: moving.width,
        height: moving.height
      };
    }
    const optionSignature = signature(buttons);
    const changed = previous && ['x', 'y', 'width', 'height'].some(k => Math.abs(previous[k] - position[k]) > .5);
    const canSlide = allowAnimation && previous && record.signature === optionSignature &&
      Math.abs(previous.y - position.y) < 3 && changed;
    const transform = p => `translate(${p.x}px,${p.y}px)`;
    cancelEffect(record.indicator);
    Object.assign(record.indicator.style, {
      width: `${position.width}px`, height: `${position.height}px`, transform: transform(position)
    });
    if (canSlide) {
      // Animate only our decoration, never the selectable button or projected model nodes.
      animate(record.indicator, record.indicator, [
        { transform: `${transform(previous)} scaleX(${previous.width / position.width})`, transformOrigin: 'left center', opacity: .85 },
        { transform: `${transform(position)} scaleX(1)`, transformOrigin: 'left center', opacity: 1 }
      ], { duration: duration('--ui-motion-content', 220) });
    }
    record.position = position;
    record.signature = optionSignature;
  }
  function schedule(record, animated = false) {
    if (destroyed || suspended) return;
    pending.set(record, !!pending.get(record) || animated);
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      const work = [...pending];
      pending.clear();
      for (const [item, shouldAnimate] of work) if (segments.get(item.element) === item) measure(item, shouldAnimate);
      for (const [key, effect] of effects) if (!effect.element.isConnected) cancelEffect(key);
    });
  }
  function observe(record) {
    if (suspended || destroyed) return;
    record.mutation.observe(record.element, { subtree: true, attributes: true, attributeFilter: ['aria-pressed'] });
    record.resize?.observe(record.element);
    for (const button of buttonsFor(record.element)) record.resize?.observe(button);
  }
  function install(element, predecessor) {
    const indicator = document.createElement('span');
    indicator.className = 'ui-segment-indicator';
    indicator.setAttribute('aria-hidden', 'true');
    indicator.setAttribute('inert', '');
    indicator.hidden = true;
    indicator.style.pointerEvents = 'none';
    element.prepend(indicator);
    const record = {
      element, indicator, key: segmentKey(element), position: predecessor?.position || null,
      signature: predecessor?.signature || '',
      mutation: null, resize: null
    };
    record.mutation = new MutationObserver(() => schedule(record, true));
    if (typeof ResizeObserver === 'function') record.resize = new ResizeObserver(() => schedule(record));
    segments.set(element, record);
    observe(record);
    return record;
  }
  function refresh(scope = document) {
    if (destroyed || !scope?.querySelectorAll) return;
    const replacements = new Map();
    for (const record of segments.values()) {
      if (!record.element.isConnected) {
        if (record.key) replacements.set(record.key, record);
        stopSegment(record, true);
      }
    }
    if (suspended) return;
    const containers = [...scope.querySelectorAll('[data-ui-segment]')];
    if (scope.nodeType === 1 && scope.matches('[data-ui-segment]')) containers.unshift(scope);
    for (const element of containers) {
      if (protectedElement(element)) continue;
      const key = segmentKey(element);
      let record = segments.get(element);
      if (!record) record = install(element, key ? replacements.get(key) : null);
      else { record.mutation.disconnect(); record.resize?.disconnect(); observe(record); }
      schedule(record, !!(key && replacements.has(key)));
    }
  }
  function enter(element, key = element) {
    const identity = `enter:${typeof key === 'string' ? key : ''}`;
    const ownedKey = typeof key === 'string' ? identity : key;
    cancelEffect(ownedKey);
    closingDialogs.get(element)?.finish(false);
    if (protectedElement(element)) return null;
    return animate(element, ownedKey,
      [{ opacity: .25, transform: 'translateY(7px)' }, { opacity: 1, transform: 'translateY(0)' }],
      { duration: duration('--ui-motion-content', 220) });
  }
  function notice(element, kind) {
    if (!['success', 'error', 'info'].includes(kind) || protectedElement(element)) return null;
    element.dataset.uiNotice = kind;
    // The caller owns the message and whether saving succeeded. This API only presents that result.
    return animate(element, element,
      [{ opacity: .35 }, { opacity: 1 }], { duration: duration('--ui-motion-container', 280) });
  }
  function closeDialog(dialog) {
    if (!dialog?.open || typeof dialog.close !== 'function') return Promise.resolve(false);
    const existing = closingDialogs.get(dialog);
    if (existing) return existing.promise;
    if (destroyed || suspended || reducedMotion.matches || typeof dialog.animate !== 'function') {
      dialog.close();
      return Promise.resolve(true);
    }
    const key = {};
    let resolve;
    const promise = new Promise(done => { resolve = done; });
    const record = { promise, finish: null };
    record.finish = shouldClose => {
      if (closingDialogs.get(dialog) !== record) return;
      closingDialogs.delete(dialog);
      dialog.removeEventListener('close', onClose);
      cancelEffect(key);
      if (shouldClose && dialog.open) dialog.close();
      resolve(!!shouldClose);
    };
    const onClose = () => record.finish(false);
    closingDialogs.set(dialog, record);
    dialog.addEventListener('close', onClose, { once: true });
    const animation = animate(dialog, key, [{ opacity: 1 }, { opacity: 0 }], {
      duration: Math.min(120, duration('--ui-motion-fast', 100))
    });
    if (animation) animation.finished.then(() => record.finish(true), () => record.finish(false));
    else record.finish(true);
    return promise;
  }
  function onResize() { for (const record of segments.values()) schedule(record); }
  function onMotionPreference() {
    if (reducedMotion.matches) for (const record of [...closingDialogs.values()]) record.finish(true);
    cancelAll();
    onResize();
  }
  function setSuspended(hidden) {
    suspended = hidden;
    if (suspended) {
      for (const record of [...closingDialogs.values()]) record.finish(true);
      cancelAll();
      if (frame) cancelAnimationFrame(frame);
      frame = 0;
      pending.clear();
      for (const record of segments.values()) stopSegment(record);
    } else refresh();
  }
  function onVisibility() { setSuspended(document.hidden); }
  function onPageHide(event) {
    // BFCache restores this same document; retain the API and resume local observation on return.
    if (event.persisted) setSuspended(true);
    else destroy();
  }
  function onPageShow(event) {
    if (event.persisted && !destroyed) setSuspended(document.hidden);
  }
  function destroy() {
    if (destroyed) return;
    for (const record of [...closingDialogs.values()]) record.finish(false);
    cancelAll();
    if (frame) cancelAnimationFrame(frame);
    frame = 0;
    pending.clear();
    for (const record of [...segments.values()]) stopSegment(record, true);
    window.removeEventListener('resize', onResize);
    document.removeEventListener('visibilitychange', onVisibility);
    window.removeEventListener('pagehide', onPageHide);
    window.removeEventListener('pageshow', onPageShow);
    if (reducedMotion.removeEventListener) reducedMotion.removeEventListener('change', onMotionPreference);
    else reducedMotion.removeListener(onMotionPreference);
    destroyed = true;
  }
  window.addEventListener('resize', onResize, { passive: true });
  document.addEventListener('visibilitychange', onVisibility);
  window.addEventListener('pagehide', onPageHide);
  window.addEventListener('pageshow', onPageShow);
  if (reducedMotion.addEventListener) reducedMotion.addEventListener('change', onMotionPreference);
  else reducedMotion.addListener(onMotionPreference);
  B.uiMotion = Object.freeze({ refresh, enter, notice, closeDialog, destroy });
  if (document.fonts?.ready) document.fonts.ready.then(() => { if (!destroyed) refresh(); });
  refresh();
})();
