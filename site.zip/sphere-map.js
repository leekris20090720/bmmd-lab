/* Three-dimensional navigation. Original cards remain the source of actions and routes. */
(() => {
  'use strict';
  const en=()=>window.BM?.i18n?.getLanguage()==='en',text=(z,e)=>en()?e:z,tr=v=>window.BM?.i18n?.t(v)||v;
  const partNames={chest:'Chest',shoulder:'Shoulders',back:'Back',legs:'Legs'};
  const partName=k=>en()?partNames[k]:parts[k].name,countText=n=>n+text(' 个动作',' movements');
  const motionReduced=()=>reducedMotion.matches||document.documentElement.classList.contains('pd-reduced');
  const stage = document.getElementById('portal-lab-stage');
  const overlay = document.getElementById('portal-hub-overlay');
  const categoryGrid = stage?.querySelector('.lab-category-grid');
  const actionGrid = stage?.querySelector('.lab-gateways-grid');
  if (!stage || !overlay || !categoryGrid || !actionGrid) return;
  const parts = {
    chest: { name: '胸部', image: 'op-cp.png' },
    shoulder: { name: '肩部', image: 'op-sp.png' },
    back: { name: '背部', image: 'il-row.png' },
    legs: { name: '下肢', image: 'hsllp.png' }
  };
  const equipment = {
    arm: ['滑轮侧平举', 'OP-DAP', 'op-dap.png'],
    cam: ['坐姿膝伸展', 'Axiom OP-LE', 'op-le.png'],
    incline: ['45° 倒蹬', 'Hammer Strength', 'hsllp.png'],
    pec: ['胸飞鸟 / 后束', 'Axiom OP-FLY', 'op-fly.png'],
    lat: ['高位下拉', 'Axiom OP-PD', 'op-pd.png'],
    'barbell-squat': ['杠铃深蹲', 'HD Athletic NX', 'nx-rack.jpg'],
    'barbell-bench': ['平板卧推', 'Hammer O-FB', 'o-fb.png'],
    'flat-press': ['器械推胸', 'Axiom OP-CP', 'op-cp.png'],
    'incline-press': ['上斜推胸', 'Hammer IL-IP', 'il-ip.png'],
    'cable-fly': ['滑轮夹胸', 'OP-DAP', 'op-dap.png'],
    'machine-fly': ['蝴蝶机夹胸', 'Insignia SS-PEC', 'ss-pec.png'],
    'cable-row': ['坐姿划船', 'Axiom OP-RW', 'op-rw.png'],
    'scissor-pulldown': ['宽握下拉', 'Hammer IL-WPD', 'il-wpd.png'],
    'nautilus-pullover': ['鹦鹉螺上拉', 'Nautilus IPPO3', 'nautilus-pullover.png'],
    'hammer-row': ['胸托划船', 'Hammer IL-ROW', 'il-row.png'],
    'cable-pulldown': ['下拉 / 低位划船', 'Axiom OP-LR', 'op-lr.png'],
    'machine-military-press': ['分动肩推', 'Hammer IL-SP', 'il-sp.png'],
    'seated-machine-shoulder': ['坐姿器械肩推', 'Axiom OP-SP', 'op-sp.png']
  };
  const map = document.createElement('section');
  map.className = 'sphere-map';
  map.setAttribute('aria-label', '立体部位与动作导图');
  map.innerHTML =
    '<nav class="sphere-part-switch" aria-label="导图部位切换">' +
      '<button type="button" data-sphere-part="all" aria-pressed="true">全部部位</button>' +
      Object.entries(parts).map(([key, part]) => '<button type="button" data-sphere-part="' + key + '" aria-pressed="false">' + part.name + '</button>').join('') +
    '</nav>' +
    '<div class="sphere-stage" tabindex="0" role="group" aria-roledescription="立体思维导图" aria-label="拖拽旋转；方向键转动；点击节点选择">' +
      '<canvas class="sphere-canvas" aria-hidden="true"></canvas>' +
      '<div class="sphere-node-layer"></div>' +
      '<button type="button" class="sphere-center" aria-label="重置导图视角">' +
        '<span class="sphere-center-label">训练部位</span><small class="sphere-center-count">18 个动作</small>' +
      '</button>' +
    '</div>' +
    '<div class="sphere-hover-info" role="status" aria-live="polite"></div>' +
    '<footer class="sphere-map-footer">' +
      '<p class="sphere-map-hint">拖动旋转 · 点选节点</p>' +
    '</footer>';
  stage.insertBefore(map, categoryGrid);
  const viewport = map.querySelector('.sphere-stage');
  const canvas = map.querySelector('.sphere-canvas');
  const context = canvas.getContext('2d');
  if (!context) { map.remove(); return; }
  const layer = map.querySelector('.sphere-node-layer');
  const center = map.querySelector('.sphere-center');
  const info = map.querySelector('.sphere-hover-info');
  const heading = stage.querySelector('.hub-hero h1');
  const caption = stage.querySelector('.hub-hero > span');
  const baseHeading = heading?.textContent || '';
  const baseCaption = caption?.textContent || '';
  const views = new Map();
  const pointers = new Map();
  let key = '', nodes = [], entries = [], view;
  let frame = 0, lastTime = 0, width = 1, height = 1, active = false;
  let dragStart = null, suppressClickUntil = 0;
  let dirty = true, layoutMoving = false, coreRadius = 0, pixelRatio = 1;
  let accentColor = '#0071e3', wireColor = '#6e6e73';
  let rotation = { cy: 1, sy: 0, cp: 1, sp: 0 };
  let motionSeconds = 0;
  const sizeObserver = new ResizeObserver(resize);
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const setInfo = (message) => { if (info.textContent !== message) info.textContent = message; };

  function readEntries() {
    const unique = new Map();
    actionGrid.querySelectorAll('.gateway-card').forEach(card => {
      const inline = card.getAttribute('onclick') || '';
      const scene = card.dataset.sceneCard || inline.match(/transitToWorkspace\(['"]([^'"]+)['"]\)/)?.[1];
      if (!scene || !equipment[scene] || unique.has(scene)) return;
      const [shortName, model, image] = equipment[scene],name=tr(window.BM?.flow?.byId[scene]?.name||shortName);
      unique.set(scene, { id: scene, part: card.dataset.actionGroup, name, model, image,title:name+' · '+model, card });
    });
    entries = [...unique.values()];
  }
  function countFor(part) { return entries.filter(entry => entry.part === part).length; }
  function defaultInfo() {
    return key ? partName(key)+' · '+countText(countFor(key))+text('，点击器械进入完整课程。','; select equipment to open the full course.') : text('胸、肩、背、下肢 · 从一个部位开始。','Chest, shoulders, back and legs. Start with one area.');
  }
  function activate(node) {
    if (node.partKey) {
      categoryGrid.querySelector('[data-lab-category="' + node.partKey + '"]')?.click();
    } else {
      // Resolve the live route at activation time; the simulation replaces it after loading.
      if(window.BM?.Product)window.BM.Product.openCourse(node.id,'learn/map');else window.transitToWorkspace?.(node.id);
    }
  }
  function makeNodes() {
    const data = key ? entries.filter(entry => entry.part === key) :
      Object.entries(parts).map(([partKey, part]) => ({
        id: partKey, partKey, name: partName(partKey), image: part.image,
        model: countText(countFor(partKey)), title: partName(partKey)+' · '+countText(countFor(partKey))
      }));
    nodes.forEach(node => sizeObserver.unobserve(node.button));
    layer.replaceChildren();
    nodes = data.map((entry, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'sphere-node';
      button.dataset.sphereNode = entry.id;
      button.setAttribute('aria-label', entry.partKey ? text('展开','Expand ')+entry.title : text('进入','Open ')+entry.title);
      button.title = entry.title;
      const image = document.createElement('img');
      image.src = 'assets/equipment-reference/' + entry.image;
      image.alt = '';
      image.draggable = false;
      image.decoding = 'async';
      const name = document.createElement('span');
      name.className = 'sphere-node-name';
      name.textContent = entry.name;
      const model = document.createElement('small');
      model.className = 'sphere-node-meta';
      model.textContent = entry.model;
      button.append(image, name, model);
      button.addEventListener('click', event => {
        if (event.detail && performance.now() < suppressClickUntil) {
          event.preventDefault(); return;
        }
        activate(entry);
      });
      button.addEventListener('pointerenter', () => {
        if (pointers.size) return;
        setInfo(entry.title); invalidate();
      });
      button.addEventListener('pointerleave', () => {
        if (pointers.size) return;
        setInfo(defaultInfo()); invalidate();
      });
      button.addEventListener('focus', () => { setInfo(entry.title); invalidate(); });
      button.addEventListener('blur', () => { setInfo(defaultInfo()); invalidate(); });
      layer.append(button);
      sizeObserver.observe(button);
      const angle = index * Math.PI * 2 / data.length + (data.length === 4 ? Math.PI / 4 : -Math.PI / 2);
      const z = index % 2 ? .42 : -.42;
      const r = Math.sqrt(1 - z * z);
      return { entry, button, region: null, width: 0, height: 0, point: { x: Math.cos(angle) * r, y: Math.sin(angle) * r, z } };
    });
  }
  function syncCategory(force = false) {
    readEntries();
    const selected = categoryGrid.classList.contains('lab-category-hidden') ?
      document.querySelector('.action-group-filter.active')?.dataset.actionFilter : '';
    const nextKey = parts[selected] ? selected : '';
    if (!force && view && key === nextKey && nodes.length === (nextKey ? countFor(nextKey) : 4)) return;
    key = nextKey;
    if (!views.has(key)) views.set(key, { yaw: .10, pitch: -.12, zoom: 1 });
    view = views.get(key);
    makeNodes();
    map.dataset.category = key || 'all';
    map.querySelectorAll('[data-sphere-part]').forEach(button => {
      button.setAttribute('aria-pressed', String(button.dataset.spherePart === (key || 'all')));
      button.textContent=button.dataset.spherePart==='all'?text('全部部位','All areas'):partName(button.dataset.spherePart);
    });
    center.querySelector('.sphere-center-label').textContent = key ? partName(key) : text('训练部位','Training areas');
    center.querySelector('.sphere-center-count').textContent = countText(key ? countFor(key) : entries.length);
    if (heading) heading.textContent = key ? parts[key].name + '动作，向外展开。' : baseHeading;
    if (caption) caption.textContent = '转动球体，找到你想练的动作。';
    map.setAttribute('aria-label',text('立体部位与动作导图','3D muscle-group and movement map'));
    viewport.setAttribute('aria-label',text('拖拽旋转；方向键转动；点击节点选择','Drag to rotate; turn with arrow keys; select a node'));
    map.querySelector('.sphere-map-hint').textContent=text('拖动旋转 · 点选节点','Drag to rotate · select a node');
    setInfo(defaultInfo());
    resize();
  }
  function rotate(point) {
    const { cy, sy, cp, sp } = rotation;
    const x = point.x * cy + point.z * sy;
    const z = point.z * cy - point.x * sy;
    return { x, y: point.y * cp - z * sp, z: point.y * sp + z * cp };
  }
  function project(point, radius) {
    const scale = 4.3 / (4.3 - point.z);
    return { x: width / 2 + point.x * radius * scale, y: height / 2 - point.y * radius * scale, z: point.z };
  }
  // Geometry and theme are invariant during a gesture. Batch each depth into one stroke.
  const wirePaths = [];
  for (const latitude of [-Math.PI / 3, -Math.PI / 6, 0, Math.PI / 6, Math.PI / 3]) {
    const points = [];
    for (let j = 0; j <= 48; j++) {
      const angle = j * Math.PI / 24;
      points.push({ x: Math.cos(angle) * Math.cos(latitude), y: Math.sin(latitude), z: Math.sin(angle) * Math.cos(latitude) });
    }
    wirePaths.push(points);
  }
  for (let longitude = 0; longitude < Math.PI; longitude += Math.PI / 4) {
    const points = [];
    for (let j = 0; j <= 48; j++) {
      const angle = j * Math.PI / 24;
      points.push({ x: Math.sin(angle) * Math.cos(longitude), y: Math.cos(angle), z: Math.sin(angle) * Math.sin(longitude) });
    }
    wirePaths.push(points);
  }
  function drawWire(radius, sphereRadius, color, alpha) {
    const paths = wirePaths.map(points => points.map(point => {
      const rotated = rotate(point);
      return project({ x: rotated.x * sphereRadius, y: rotated.y * sphereRadius, z: rotated.z * sphereRadius }, radius);
    }));
    context.strokeStyle = color;
    context.lineWidth = 1;
    for (const back of [true, false]) {
      context.globalAlpha = alpha * (back ? .28 : 1);
      context.beginPath();
      for (const points of paths) {
        for (let j = 1; j < points.length; j++) {
          if ((points[j].z < 0) !== back) continue;
          context.moveTo(points[j - 1].x, points[j - 1].y);
          context.lineTo(points[j].x, points[j].y);
        }
      }
      context.stroke();
    }
    context.globalAlpha = 1;
  }
  function refreshPalette() {
    const style = getComputedStyle(document.body);
    accentColor = style.getPropertyValue('--accent-color').trim() || '#0071e3';
    wireColor = style.getPropertyValue('--text-sub').trim() || '#6e6e73';
  }
  // One shared clock: a full outward-and-back pass takes eight seconds.
  // The straight ramps keep the small motion uniform instead of accelerating.
  function swayAt(seconds) {
    const phase = ((seconds / 8 + .25) % 1 + 1) % 1;
    return 1 - 4 * Math.abs(phase - .5);
  }
  function fixedRegions() {
    const scale = .94, margin = width < 500 ? 8 : 14;
    const halfWidth = Math.max(...nodes.map(node => node.width)) * scale / 2;
    const halfHeight = Math.max(...nodes.map(node => node.height)) * scale / 2;
    const roomX = Math.max(0, width / 2 - halfWidth - margin);
    const roomY = Math.max(0, height / 2 - halfHeight - margin);
    const side = Math.min(roomX, Math.max(coreRadius + halfWidth + 14,
      Math.min(width * .36, height * .35) * 1.12));
    // Keep all six labels readable on short desktops and narrow phones.
    const amplitude = Math.max(0, Math.min(4, side - halfWidth - coreRadius - 1,
      nodes.length > 4 ? (roomY - halfHeight * 2 - 8) / 2 : 4));
    let slots;
    if (nodes.length === 4) {
      slots = [[side, -roomY], [-side, -roomY], [-side, roomY], [side, roomY]];
    } else if (nodes.length === 3) {
      slots = roomY >= coreRadius + halfHeight + 14
        ? [[0, roomY], [side, -roomY], [-side, -roomY]]
        : [[-side, 0], [side, -roomY], [side, roomY]];
    } else {
      slots = [[-side, -roomY], [-side, 0], [-side, roomY],
        [side, roomY], [side, 0], [side, -roomY]];
    }
    nodes.forEach((node, index) => {
      const [x, y] = slots[index % slots.length];
      const distance = Math.hypot(x, y) || 1;
      node.region = { x: width / 2 + x, y: height / 2 + y,
        dx: x / distance * amplitude, dy: y / distance * amplitude };
      // Each wire stays on the same side as its fixed label.
      node.point = { x: x / distance * Math.sqrt(1 - .42 ** 2),
        y: -y / distance * Math.sqrt(1 - .42 ** 2), z: index % 2 ? .42 : -.42 };
    });
  }
  function placeLabels(projected, sway) {
    if (nodes.some(node => !node.region)) fixedRegions();
    layoutMoving = false;
    return projected.map((node, index) => {
      const region = nodes[index].region;
      return { ...node, x: region.x + region.dx * sway,
        y: region.y + region.dy * sway, scale: .94 };
    });
  }
  function render(delta) {
    if (!view) return;
    const sway = motionReduced() ? 0 : swayAt(motionSeconds);
    const yaw = view.yaw + sway * .08;
    rotation = { cy: Math.cos(yaw), sy: Math.sin(yaw), cp: Math.cos(view.pitch), sp: Math.sin(view.pitch) };
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    context.clearRect(0, 0, width, height);
    const radius = Math.min(width * .36, height * .35) * view.zoom;
    drawWire(radius, 1, wireColor, .15);
    drawWire(radius, .38, accentColor, .36);
    if (nodes.some(node => !node.region)) fixedRegions();
    const projected = nodes.map(node => {
      const rotated = rotate(node.point);
      return { ...node, z: rotated.z, anchor: project(rotated, radius),
        start: project(rotate({ x: node.point.x * .38, y: node.point.y * .38, z: node.point.z * .38 }), radius) };
    });
    const labels = placeLabels(projected, sway);
    context.strokeStyle = accentColor;
    for (const node of labels) {
      const visual = node;
      const emphasized = node.button.matches(':hover, :focus-visible');
      context.globalAlpha = emphasized ? .80 : clamp(.38 + node.z * .18, .16, .58);
      context.lineWidth = emphasized ? 1.8 : 1.15;
      context.beginPath();
      context.moveTo(node.start.x, node.start.y);
      context.lineTo(node.anchor.x, node.anchor.y);
      context.lineTo(visual.x, visual.y);
      context.stroke();
      context.globalAlpha = .9;
      context.fillStyle = accentColor;
      context.beginPath(); context.arc(node.anchor.x, node.anchor.y, emphasized ? 4 : 2.8, 0, Math.PI * 2); context.fill();
      node.button.style.transform = 'translate3d(' + (visual.x - node.width / 2).toFixed(3) +
        'px,' + (visual.y - node.height / 2).toFixed(3) + 'px,0) scale(' + visual.scale.toFixed(4) + ')';
      node.button.style.opacity = '.94';
      node.button.style.zIndex = '20';
    }
    context.globalAlpha = 1;
    viewport.dataset.yaw = yaw.toFixed(6);
    viewport.dataset.sway = sway.toFixed(6);
    viewport.dataset.pitch = view.pitch.toFixed(3);
    viewport.dataset.zoom = view.zoom.toFixed(3);
  }
  function tick(time) {
    frame = 0;
    if (!active || document.hidden) return;
    // Advance the shared oscillation clock at the same rate on every display.
    // Hidden pages and deliberate dragging suspend the clock without a catch-up jump.
    const elapsed = Math.max(0, (time - lastTime) / 1000);
    const delta = clamp(elapsed || .016, .001, .05);
    lastTime = time;
    if (!pointers.size && !motionReduced()) motionSeconds += elapsed;
    dirty = false;
    render(delta);
    if (layoutMoving || dirty || (!pointers.size && !motionReduced())) frame = requestAnimationFrame(tick);
  }
  function wake() {
    if (active && !document.hidden && !frame) { lastTime = performance.now(); frame = requestAnimationFrame(tick); }
  }
  function invalidate() { dirty = true; wake(); }
  function resize() {
    const rect = viewport.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;
    const nextWidth = Math.max(1, rect.width), nextHeight = Math.max(1, rect.height);
    const nextRatio = Math.min(devicePixelRatio || 1, 2);
    const dimensionsChanged = width !== nextWidth || height !== nextHeight || pixelRatio !== nextRatio;
    width = nextWidth; height = nextHeight; pixelRatio = nextRatio;
    if (dimensionsChanged) {
      canvas.width = Math.round(width * pixelRatio); canvas.height = Math.round(height * pixelRatio);
      nodes.forEach(node => { node.region = null; });
    }
    coreRadius = center.offsetWidth / 2 + 5;
    nodes.forEach(node => {
      const w = node.button.offsetWidth, h = node.button.offsetHeight;
      if (node.width !== w || node.height !== h) nodes.forEach(entry => { entry.region = null; });
      node.width = w; node.height = h;
    });
    invalidate();
  }
  function syncVisibility() {
    active = !document.body.hasAttribute('data-explore-open') && ((map.closest('#product-root')&&document.body.dataset.bmRoute==='learn/map')||stage.classList.contains('portal-stage-active') && overlay.style.display !== 'none' && overlay.style.pointerEvents !== 'none');
    if (active) {
      syncCategory();
      resize();
      if (!frame) { lastTime = performance.now(); frame = requestAnimationFrame(tick); }
    } else {
      if (frame) cancelAnimationFrame(frame);
      frame = 0; pointers.clear(); dragStart = null;
      viewport.classList.remove('is-dragging');
    }
  }
  function reset() {
    Object.assign(view, { yaw: .10, pitch: -.12, zoom: 1 });
    invalidate();
  }
  center.addEventListener('click', event => {
    if (event.detail && performance.now() < suppressClickUntil) {
      event.preventDefault(); return;
    }
    reset();
  });
  map.querySelectorAll('[data-sphere-part]').forEach(button => button.addEventListener('click', () => {
    const part = button.dataset.spherePart;
    if (part === 'all') document.getElementById('btn-back-to-lab-categories')?.click();
    else categoryGrid.querySelector('[data-lab-category="' + part + '"]')?.click();
  }));
  viewport.addEventListener('keydown', event => {
    const step = .15;
    if (event.key === 'ArrowLeft') view.yaw -= step;
    else if (event.key === 'ArrowRight') view.yaw += step;
    else if (event.key === 'ArrowUp') view.pitch = clamp(view.pitch + step, -Math.PI / 2, Math.PI / 2);
    else if (event.key === 'ArrowDown') view.pitch = clamp(view.pitch - step, -Math.PI / 2, Math.PI / 2);
    else if (event.key === 'Home') reset();
    else if (event.key === 'Escape' && key) document.getElementById('btn-back-to-lab-categories')?.click();
    else return;
    event.preventDefault(); invalidate();
  });
  viewport.addEventListener('pointerdown', event => {
    if (event.button !== 0 && event.pointerType === 'mouse') return;
    pointers.set(event.pointerId, { x: event.clientX, y: event.clientY, time: event.timeStamp });
    if (pointers.size === 1) dragStart = { x: event.clientX, y: event.clientY, moved: false };
    if (pointers.size === 2) {
      dragStart.moved = true;
      suppressClickUntil = performance.now() + 600;
    }
  });
  viewport.addEventListener('pointermove', event => {
    const previous = pointers.get(event.pointerId);
    if (!previous) return;
    pointers.set(event.pointerId, { x: event.clientX, y: event.clientY, time: event.timeStamp });
    if (pointers.size > 1) {
      event.preventDefault();
      return;
    }
    if (!dragStart?.moved && Math.hypot(event.clientX - dragStart.x, event.clientY - dragStart.y) <= 6) return;
    dragStart.moved = true;
    if (!viewport.hasPointerCapture(event.pointerId)) viewport.setPointerCapture(event.pointerId);
    viewport.classList.add('is-dragging');
    const dx = (event.clientX - previous.x) * .006;
    const dy = (event.clientY - previous.y) * .006;
    view.yaw += dx; view.pitch = clamp(view.pitch + dy, -Math.PI / 2, Math.PI / 2);
    event.preventDefault(); invalidate();
  });
  function endPointer(event) {
    if (dragStart?.moved) suppressClickUntil = performance.now() + 600;
    const previous = pointers.get(event.pointerId);
    if (!previous) return;
    pointers.delete(event.pointerId);
    if (viewport.hasPointerCapture(event.pointerId)) viewport.releasePointerCapture(event.pointerId);
    if (!pointers.size) {
      dragStart = null;
      viewport.classList.remove('is-dragging'); setInfo(defaultInfo());
    }
    else {
      const remaining = [...pointers.values()][0];
      dragStart = { x: remaining.x, y: remaining.y, moved: true };
    }
    wake();
  }
  viewport.addEventListener('pointerup', endPointer);
  viewport.addEventListener('pointercancel', endPointer);
  viewport.addEventListener('pointerleave', event => {
    if (!viewport.hasPointerCapture(event.pointerId)) endPointer(event);
  });
  let pendingSync = false;
  const sourceObserver = new MutationObserver(() => {
    if (pendingSync) return;
    pendingSync = true;
    queueMicrotask(() => { pendingSync = false; syncCategory(); syncVisibility(); });
  });
  sourceObserver.observe(categoryGrid, { attributes: true, attributeFilter: ['class'] });
  sourceObserver.observe(actionGrid, { attributes: true, attributeFilter: ['hidden'], childList: true, subtree: true });
  new MutationObserver(syncVisibility).observe(stage, { attributes: true, attributeFilter: ['class'] });
  new MutationObserver(syncVisibility).observe(overlay, { attributes: true, attributeFilter: ['style'] });
  new MutationObserver(syncVisibility).observe(document.body, { attributes: true, attributeFilter: ['data-explore-open','data-bm-route'] });
  new MutationObserver(() => { refreshPalette(); invalidate(); }).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  reducedMotion.addEventListener('change', () => { invalidate(); });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && frame) { cancelAnimationFrame(frame); frame = 0; }
    else invalidate();
  });
  sizeObserver.observe(viewport);
  sizeObserver.observe(center);
  // If a browser cancels a gesture or loses focus, the next pointerdown starts cleanly.
  window.addEventListener('blur', () => {
    pointers.clear(); dragStart = null;
    viewport.classList.remove('is-dragging');
  });
  (window.BM||={}).SphereMap={mount(container){container.append(map);syncCategory(true);syncVisibility();resize();},unmount(){if(map.closest('#product-root')){stage.insertBefore(map,categoryGrid);syncVisibility();}}};
  refreshPalette();
  stage.classList.add('sphere-nav-ready');
  syncCategory(true);
  syncVisibility();
  // Review links can open this map directly without changing the ordinary welcome flow.
  const previewPart = new URLSearchParams(location.search).get('map');
  if (previewPart === 'all' || Object.keys(parts).includes(previewPart)) {
    window.showPortalStage?.('lab');
    if (previewPart !== 'all') categoryGrid.querySelector('[data-lab-category="' + previewPart + '"]')?.click();
  }
})();
