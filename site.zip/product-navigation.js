/* Same-document Back support. Hash routing and training storage stay unchanged. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else (root.BM = root.BM || {}).Navigation = api;
})(typeof window === 'undefined' ? null : window, function () {
  'use strict';
  const KEY = 'bmmdPageBack';
  function parent(route) {
    if (route === 'learn' || route === 'settings' || route === 'train/plans') return 'home';
    if (route.startsWith('course/')) return 'learn/courses';
    if (route.startsWith('experiment/') || route.startsWith('engineering/')) return 'learn/experiments';
    if (route.startsWith('learn/')) return 'learn';
    if (route.startsWith('settings/')) return 'settings';
    if (route === 'train/preview') return 'train/recommend';
    if (route.startsWith('train/summary/')) return 'train/history';
    if (route.startsWith('train/')) return 'train/plans';
    return 'home';
  }
  function create(history, location) {
    const documentURL = location.href.split('#')[0];
    let current = null;
    const valid = value => value?.version === 1 && value.documentURL === documentURL &&
      typeof value.route === 'string' && Number.isInteger(value.depth) && value.depth >= 0;
    function visit(route) {
      const state = history.state, saved = state?.[KEY];
      if (valid(saved) && saved.route === route) { current = saved; return; }
      if (current?.route === route) return;
      current = { version: 1, documentURL, route, depth: current ? current.depth + 1 : 0,
        from: current?.route || null };
      // Preserve any other owner's history fields; never replace opaque state.
      if (state === null || state === undefined || typeof state === 'object' && !Array.isArray(state)) {
        try { history.replaceState({ ...state, [KEY]: current }, '', location.href); } catch (_) { /* Parent links remain available. */ }
      }
    }
    function target(fallback) { return current?.from || fallback || parent(current?.route || ''); }
    function back(navigate, fallback) {
      if (current?.from && current.depth > 0 && history.length > 1) history.back();
      else { const destination = fallback || parent(current?.route || ''); current = null; navigate(destination); }
    }
    return { visit, target, back };
  }
  return { create, parent };
});
