/* Presentation effects use real controls and never change training or simulation values. */
(() => {
  'use strict';
  const B = window.BM = window.BM || {};
  const media = matchMedia('(prefers-reduced-motion: reduce)');
  const fine = matchMedia('(hover:hover) and (pointer:fine)');
  const seen = new WeakSet(), headings = new WeakSet(), timers = new WeakMap();
  const animations = new Set(), rangeUI = new WeakMap(), numberMotion = new WeakMap();
  let activeTitle = null;
  let queued = 0, pointerFrame = 0, latestPointer = null, activeCard = null, entryObserver, visibilityObserver;
  const cardSelector = '.pd-home-directions>section,.pd-course-directory>a,.pd-learn-feature,.pd-learn-tools>a,.pd-learn-tools>button,.pd-learn-shelf>a,.pd-learn-questions li>a,.pd-doors>a,.pd-history-row,.pd-ex-theme li>a';
  const reduced = () => media.matches || document.documentElement.classList.contains('pd-reduced');
  function animate(el, frames, options) {
    if (!el?.animate || reduced() || document.hidden) return;
    const a = el.animate(frames, options); animations.add(a);
    a.finished.catch(() => {}).finally(() => animations.delete(a)); return a;
  }
  function rangeCaption(el) {
    if(el.id==='pd-course-progress'||el.id==='pd-ex-progress')return (Number(el.value)*100).toFixed(1).replace(/\.0$/,'')+'%';
    const out=el.closest('label')?.querySelector('output[data-ex-output]');
    const unit=out?.textContent.trim().replace(/^[+−-]?(?:\d+\.?\d*|\.\d+)\s*/, '')||'';
    return el.value+(unit?' '+unit:'');
  }
  function syncRange(el) {
    if (!el || el.type !== 'range') return;
    el.classList.add('cm-range');
    let ui=rangeUI.get(el);
    if(!ui || el.parentElement!==ui.shell){
      const shell=document.createElement('span'),bubble=document.createElement('span'),ticks=document.createElement('span');
      shell.className='cm-range-shell';bubble.className='cm-range-value';ticks.className='cm-range-ticks';
      bubble.setAttribute('aria-hidden','true');ticks.setAttribute('aria-hidden','true');
      el.before(shell);shell.append(el,ticks,bubble);ui={shell,bubble,last:Number(el.value),time:performance.now(),timer:0};rangeUI.set(el,ui);
    }
    ui.shell.hidden=el.hidden;
    const lo = Number(el.min || 0), hi = Number(el.max || 100),current=Number(el.value);
    const fraction=Math.max(0,Math.min(1,(current-lo)/(hi-lo||1))),fill=(fraction*100).toFixed(2)+'%';
    if (el.style.getPropertyValue('--cm-range') !== fill) el.style.setProperty('--cm-range', fill);
    if(ui.shell.style.getPropertyValue('--cm-range')!==fill){
      ui.shell.style.setProperty('--cm-range',fill);
      ui.shell.style.setProperty('--cm-thumb-x',`calc(${fill} + ${(10-20*fraction).toFixed(2)}px)`);
    }
    const caption=rangeCaption(el);if(ui.bubble.textContent!==caption)ui.bubble.textContent=caption;
    if(current!==ui.last){
      const now=performance.now(),v=Math.max(-1,Math.min(1,(current-ui.last)/(hi-lo||1)*200/Math.max(16,now-ui.time)*16));
      ui.shell.style.setProperty('--cm-velocity',reduced()?'0':v.toFixed(3));ui.last=current;ui.time=now;
      if(!el.disabled&&!el.hidden){ui.shell.classList.add('cm-range-live');clearTimeout(ui.timer);ui.timer=setTimeout(()=>{ui.shell.classList.remove('cm-range-live');ui.shell.style.setProperty('--cm-velocity','0');},280);}
    }
  }
  function syncRanges(root) { root?.querySelectorAll('input[type="range"]').forEach(syncRange); }
  function pulse(el, name, duration = 550) {
    if (!el || reduced()) return;
    clearTimeout(timers.get(el)); el.classList.add(name);
    timers.set(el, setTimeout(() => { el.classList.remove(name); timers.delete(el); }, duration));
  }
  function prepareTitle(title) {
    if (headings.has(title)) return;
    headings.add(title); title.classList.add('cm-title');
    if(!reduced()){title.classList.add('ct-decoding');setTimeout(()=>title.classList.remove('ct-decoding'),1000);}
    title.setAttribute('aria-label', title.innerText.replace(/\s+/g, ' ').trim());
    const walker = document.createTreeWalker(title, NodeFilter.SHOW_TEXT), nodes = [];
    while (walker.nextNode()) if (walker.currentNode.textContent.trim()) nodes.push(walker.currentNode);
    let index = 0;
    nodes.forEach(node => {
      const fragment = document.createDocumentFragment();
      // Keep Latin words intact at line wraps while allowing authored Chinese wrapping.
      for (const word of node.textContent.split(/(\s+|[\u3400-\u9fff\u3000-\u303f\uff00-\uffef])/u).filter(Boolean)) {
        if (/^\s+$/.test(word)) { fragment.append(document.createTextNode(word)); continue; }
        const group = document.createElement('span'); group.className = 'cm-word'; group.setAttribute('aria-hidden', 'true');
        for (const char of word) { const span = document.createElement('span'); span.className = 'cm-char'; span.textContent = char; span.style.setProperty('--cm-i', Math.min(index++, 28)); group.append(span); }
        fragment.append(group);
      }
      node.replaceWith(fragment);
    });
  }
  function ornaments(home) {
    if (!home || home.querySelector('.cm-constellation')) return;
    const layer = document.createElement('div'); layer.className = 'cm-constellation'; layer.setAttribute('aria-hidden', 'true');
    layer.innerHTML = '<span class="cm-orbit cm-orbit-a"></span><span class="cm-orbit cm-orbit-b"></span><span class="cm-orbit cm-orbit-c"></span>' +
      Array.from({length:12}, (_, i) => `<i style="--cm-star:${i};left:${7+(i*29)%86}%;top:${4+(i*23)%82}%"></i>`).join('');
    home.prepend(layer);
  }
  function enter(el, i) {
    if (B.ScrollMotion?.owns(el)) return;
    if (seen.has(el)) return; seen.add(el);
    if (reduced()) return;
    animate(el, [{ opacity:.15, filter:'blur(6px)', translate:'0 24px', scale:'.98' }, {opacity:1,filter:'blur(0)',translate:'0 0',scale:'1'}],
      { duration:720, delay:Math.min(i,5)*75, easing:'cubic-bezier(.16,1,.3,1)' });
  }
  function prepare() {
    queued = 0;
    const route = document.body.dataset.bmRoute || 'home';
    const surface = document.querySelector(route === 'home' ? '#portal-welcome-stage' : '#product-root');
    if (!surface) return;
    surface.querySelectorAll('.apple-hero-copy>h1,.pd-page-heading h1').forEach(prepareTitle);
    surface.querySelectorAll('.pd-main h2,.pd-main h3,.pd-home-directions h2').forEach(el=>el.classList.add('cm-subtitle'));
    ornaments(route === 'home' ? surface : null);
    const cards = surface.querySelectorAll(cardSelector);
    cards.forEach((el, i) => {
      el.classList.add('cm-card'); el.style.setProperty('--cm-i', i%7);
      el.querySelectorAll('img').forEach(img => {
        img.classList.add('cm-image'); img.style.setProperty('--cm-float-delay', -(i%6)*.7+'s');
        if (el.matches('.pd-course-directory>a,.pd-learn-shelf>a') && !img.parentElement.classList.contains('cm-image-frame')) {
          const frame=document.createElement('span');frame.className='cm-image-frame';frame.setAttribute('aria-hidden','true');img.before(frame);frame.append(img);
        }
      });
    });
    document.querySelectorAll('#product-root button,#product-root a.pd-button,.pd-home-directions a.pd-button,#pd-header button,#bm-dialog button,#bm-explore-root button').forEach(el => {
      el.classList.add('cm-button');
      if (!el.querySelector(':scope>.cm-button-light')) { const light = document.createElement('span'); light.className='cm-button-light'; light.setAttribute('aria-hidden','true'); el.append(light); }
    });
    surface.querySelectorAll('#equipment-hero-root img,.pd-learn-equipment img,.pd-model-fallback img').forEach((img,i) => {img.classList.add('cm-image');img.style.setProperty('--cm-float-delay',-i*.8+'s');});
    surface.querySelectorAll('.pd-ex-controls,.pd-ex-observe,.pd-auto-bar,.pd-live-lab,.pd-course-reader').forEach(el=>el.classList.add('cm-panel'));
    surface.querySelector('#pd-ex-diagram')?.classList.add('cm-diagram');
    surface.querySelectorAll('.pd-plot,#pd-ex-plots').forEach(el=>el.classList.add('cm-plot'));
    syncRanges(surface);
    visibilityObserver?.disconnect();
    visibilityObserver = new IntersectionObserver(entries => {
      for (const entry of entries) entry.target.classList.toggle('cm-offscreen', !entry.isIntersecting);
    }, {root:route==='home'?document.getElementById('portal-hub-overlay'):surface, rootMargin:'40px', threshold:0});
    surface.querySelectorAll('.cm-card,.cm-title,.cm-subtitle,.cm-panel,#equipment-hero-root,.pd-plot').forEach(el=>visibilityObserver.observe(el));
    entryObserver?.disconnect();
    entryObserver = new IntersectionObserver(entries => { let i=0; for (const e of entries) if(e.isIntersecting){enter(e.target,i++);entryObserver.unobserve(e.target);} },
      {root:route==='home'?document.getElementById('portal-hub-overlay'):surface,threshold:.06});
    surface.querySelectorAll(cardSelector+',.pd-ex-controls,.pd-ex-observe,.pd-live-lab,.pd-course-reader,.pd-ex-theme,.pd-fields,.pd-plan').forEach(el=>{if(!seen.has(el))entryObserver.observe(el);});
    document.documentElement.classList.add('cm-ready');
  }
  function schedule() { if (!queued) queued=requestAnimationFrame(prepare); }
  function resetTitle(title){if(!title)return;title.classList.remove('ct-title-active');title.querySelectorAll('.cm-char').forEach(el=>{el.style.setProperty('--ct-glow','0');el.style.setProperty('--ct-lift','0px');});}
  function resetCard(card) {if(!card)return;card.classList.remove('cm-pointer');card.style.setProperty('--cm-rx','0deg');card.style.setProperty('--cm-ry','0deg');}
  function pointer() {
    pointerFrame=0; const event=latestPointer; latestPointer=null;
    if (!event || reduced() || !fine.matches) return;
    const title=event.target.closest('.cm-title');
    if(activeTitle!==title){resetTitle(activeTitle);activeTitle=title;}
    if(title){title.classList.add('ct-title-active');title.querySelectorAll('.cm-char').forEach(char=>{
      const r=char.getBoundingClientRect(),distance=Math.hypot(event.clientX-r.left-r.width/2,(event.clientY-r.top-r.height/2)*1.1),light=Math.max(0,1-distance/125);
      char.style.setProperty('--ct-glow',light.toFixed(3));char.style.setProperty('--ct-lift',(-light*(document.body.classList.contains('pd-home')?9:5)).toFixed(2)+'px');
    });}
    const card=event.target.closest('.cm-card'), button=event.target.closest('.cm-button');
    if(activeCard!==card){resetCard(activeCard);activeCard=card;}
    if(card&&!B.ReferenceEffects?.ownsCard(card)){ const rect=card.getBoundingClientRect(),x=(event.clientX-rect.left)/rect.width,y=(event.clientY-rect.top)/rect.height;
      card.classList.add('cm-pointer');card.style.setProperty('--cm-rx',(1.5-y*3).toFixed(2)+'deg');card.style.setProperty('--cm-ry',(x*4-2).toFixed(2)+'deg');card.style.setProperty('--cm-px',(x*100).toFixed(1)+'%');card.style.setProperty('--cm-py',(y*100).toFixed(1)+'%'); }
    if(button){const r=button.getBoundingClientRect();button.style.setProperty('--cm-x',((event.clientX-r.left)/r.width*100).toFixed(1)+'%');button.style.setProperty('--cm-y',((event.clientY-r.top)/r.height*100).toFixed(1)+'%');}
  }
  document.addEventListener('pointermove',event=>{if(!fine.matches||reduced())return;latestPointer=event;if(!pointerFrame)pointerFrame=requestAnimationFrame(pointer);},{passive:true});
  document.addEventListener('pointerout',e=>{if(!e.relatedTarget){resetCard(activeCard);activeCard=null;resetTitle(activeTitle);activeTitle=null;}},{passive:true});
  document.addEventListener('pointerdown',event=>{const range=event.target.closest('input[type=range]');if(range){syncRange(range);range.classList.add('cm-range-active');range.parentElement.classList.add('cm-range-dragging');}const title=event.target.closest('.cm-title');if(title&&!reduced()&&!fine.matches){title.querySelectorAll('.cm-char').forEach((el,i)=>animate(el,[{translate:'0 0'},{translate:'0 -7px'},{translate:'0 0'}],{duration:550,delay:i*25,easing:'cubic-bezier(.18,.8,.2,1)'}));}},{passive:true});
  function endRangeDrag(){document.querySelectorAll('.cm-range-dragging').forEach(shell=>{shell.classList.remove('cm-range-dragging');shell.style.setProperty('--cm-velocity','0');});document.querySelectorAll('.cm-range-active').forEach(el=>el.classList.remove('cm-range-active'));}
  document.addEventListener('pointerup',endRangeDrag,{passive:true});
  document.addEventListener('pointercancel',endRangeDrag,{passive:true});
  window.addEventListener('blur',endRangeDrag);
  document.addEventListener('input',event=>{
    const el=event.target;if(el.type==='range'){
      syncRange(el);pulse(el,'cm-range-active',320);
      const output=el.closest('label')?.querySelector('output');pulse(output,'cm-number-active');
      if(output&&!reduced()){const prev=numberMotion.get(output),now=performance.now();if(!prev||now-prev.time>95){prev?.animation?.cancel();numberMotion.set(output,{time:now,animation:animate(output,[{translate:'0 4px',filter:'brightness(1.8)'},{translate:'0 0',filter:'brightness(1)'}],{duration:180,easing:'ease-out'})});}}
      pulse(document.querySelector('#pd-ex-diagram'),'cm-diagram-active');
      pulse(document.querySelector('#pd-ex-metrics'),'cm-number-active');
      pulse(document.querySelector('#pd-ex-plots'),'cm-plot-active');
    }
  });
  document.addEventListener('click',event=>{
    const el=event.target.closest('.cm-button');if(!el||el.disabled||reduced()||B.ReferenceEffects?.ownsClick(el))return;
    pulse(el,'cm-button-fired',450);
    // Small sparks stay within the control's own visual boundary.
    const light=el.querySelector(':scope>.cm-button-light');
    animate(light,[{opacity:.85,scale:'.15'},{opacity:0,scale:'2.2'}],{duration:540,easing:'cubic-bezier(.2,.8,.2,1)'});
  });
  function sync(){if(reduced()||document.hidden){animations.forEach(a=>a.cancel());animations.clear();resetCard(activeCard);resetTitle(activeTitle);}schedule();}
  const observer=new MutationObserver(records=>{
    if(records.some(r=>{
      const target=r.target;
      if(target.closest?.('svg,output,#pd-ex-diagram,#pd-ex-plots,#pd-ex-metrics,#pd-course-physics-readout,.cm-title,.cm-range-shell'))return false;
      return [...r.addedNodes].some(n=>n.nodeType===1&&!n.matches('.cm-button-light,.pd-click-wave,.cm-constellation,.cm-word,.cm-char,.cm-range-shell,.cm-range-value,.cm-range-ticks'));
    }))schedule();
  });
  function start(){
    const root=document.getElementById('product-root');if(root)observer.observe(root,{childList:true,subtree:true});
    const copy=document.querySelector('.apple-hero-copy');if(copy)observer.observe(copy,{childList:true});
    prepare();
  }
  media.addEventListener('change',sync);document.addEventListener('visibilitychange',sync);
  window.addEventListener('bm:page-ready',schedule);window.addEventListener('bm:store',sync);
  window.addEventListener('pagehide',()=>{animations.forEach(a=>a.cancel());entryObserver?.disconnect();visibilityObserver?.disconnect();});
  window.addEventListener('pageshow',sync);
  B.CosmicMotion={syncRange,syncRanges,refresh:schedule};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
