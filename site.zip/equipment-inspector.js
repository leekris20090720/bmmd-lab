/* Display-only inspection for the active equipment. Owns no training/physics state. */
(function (global) {
  'use strict';
  const BM = global.BM = global.BM || {};
  BM.createEquipmentInspector = function ({ THREE: T, rig, viewport, canvas, camera, controls, fit, cancelCamera, rigs = null, fitScene = null }) {
    const abort = new AbortController(), signal = abort.signal;
    const t = text => {const lesson=BM.LessonProfiles?.translate(text,BM.i18n?.getLanguage());return lesson&&lesson!==text?lesson:BM.i18n?.t(text)||text;};
    const registry=rigs||{cam:rig};let currentScene='cam';
    const ui = document.createElement('section'); ui.className = 'bm-structure-tools';
    ui.setAttribute('aria-label', '器械结构观察');
    ui.innerHTML = `<div class="bm-structure-views" role="group" aria-label="观察角度"><button type="button" data-view="front">正面</button><button type="button" data-view="side">侧面</button><button type="button" data-view="oblique">斜视</button></div><details><summary>看结构</summary><p class="bm-structure-note">OP-LE · 依据装配资料的视觉近似，尺寸未标定。</p><div class="bm-structure-parts" role="group" aria-label="选择部件"></div><p class="bm-structure-description" role="status">选择部件，查看位置与说明。</p><button type="button" data-whole>返回整体视图</button><label class="bm-explode-label"><span class="bm-explode-title">拆解查看</span> <output>0%</output><input type="range" min="0" max="100" step="1" value="0" aria-label="结构拆解程度"></label><div class="bm-explode-footer"><span>仅分离展示；不表示机械位移。</span><button type="button" data-restore>一键还原</button></div><p class="bm-explode-status" role="status"></p></details>`;
    const chips = ui.querySelector('.bm-structure-parts'), description = ui.querySelector('.bm-structure-description');
    const slider = ui.querySelector('input'), output = ui.querySelector('output'), status = ui.querySelector('.bm-explode-status');
    const layer = document.createElement('div'); layer.className = 'bm-structure-hotspots'; layer.hidden = true; viewport.append(layer);
    const focusLabel=document.createElement('span');focusLabel.className='bm-structure-focus-label';focusLabel.hidden=true;focusLabel.setAttribute('aria-hidden','true');layer.append(focusLabel);
    const leader=document.createElementNS('http://www.w3.org/2000/svg','svg');leader.classList.add('studio-part-leader');leader.setAttribute('aria-hidden','true');leader.innerHTML='<path fill="none"/><circle r="3"/>';leader.hidden=true;layer.prepend(leader);
    let items=[];
    function buildItems(){
      chips.replaceChildren();layer.querySelectorAll('button').forEach(b=>b.remove());
      items=Object.entries(rig.anchors||{}).map(([id,anchor],i)=>{
        const chip=document.createElement('button');chip.type='button';chip.textContent=t(anchor.label);chip.dataset.part=id;chip.setAttribute('aria-pressed','false');chips.append(chip);
        const button=document.createElement('button');button.type='button';button.className='bm-structure-hotspot';button.textContent=String(i+1);button.setAttribute('aria-label',t(anchor.label));button.dataset.part=id;button.hidden=true;layer.append(button);
        return {id,...anchor,chip,button};
      });
      ui.querySelector('.bm-structure-note').textContent=currentScene==='cam'?t('OP-LE · 依据装配资料的视觉近似，尺寸未标定。'):t('当前器械的结构示意，尺寸与档位以实物为准。');
      const hasExplode=typeof rig.setExplode==='function';
      ui.querySelectorAll('.bm-explode-label,.bm-explode-footer,.bm-explode-status').forEach(el=>{el.hidden=!hasExplode;el.inert=!hasExplode;});
      viewport.dataset.inspectionAnchors=JSON.stringify(items.map(i=>({id:i.id,targets:(i.targets||[i.target]).length,valid:i.node?.isObject3D===true,sourceNodes:i.sourceNodes||[]})));
    }
    buildItems();
    const lineGeometry = new T.BufferGeometry(); lineGeometry.setAttribute('position', new T.BufferAttribute(new Float32Array(36), 3));
    const lineMaterial = new T.LineBasicMaterial({ color: 0x6398a2, transparent: true, opacity: .7, depthTest: true });
    const lines = new T.LineSegments(lineGeometry, lineMaterial); lines.name = 'Display-only assembly connectors'; lines.visible = false; lines.userData.inspectionDecoration = true; rig.group.add(lines);
    let active = false, selected = '', transition = null, tweenFrame = 0, destroyed = false;
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    const highlights = new Map(), ray = new T.Raycaster(), world = new T.Vector3(), screen = new T.Vector3();
    const hitMeshes = [];
    function rebuildHits(){hitMeshes.length=0;rig.group.traverse(node=>{if(node.isMesh&&!node.userData.dragProxy&&!node.userData.forceIndicator)hitMeshes.push(node);});}
    rebuildHits();
    const directions = { front: [1, .10, 0], side: [.001, .12, -1], oblique: [.9, .24, .7] };
    function cancel() { cancelAnimationFrame(tweenFrame); tweenFrame = 0; transition = null; delete viewport.dataset.inspectionCamera; }
    function move(position, target) {
      cancel(); cancelCamera(); controls.autoRotate = false; document.getElementById('btn-auto-rotate')?.classList.remove('active');
      const start = { position: camera.position.clone(), target: controls.target.clone(), time: performance.now() };
      const end = { position: new T.Vector3(position.x, position.y, position.z), target: new T.Vector3(target.x, target.y, target.z) };
      const apply = amount => { const damping = controls.enableDamping; controls.enableDamping = false; camera.position.lerpVectors(start.position, end.position, amount); controls.target.lerpVectors(start.target, end.target, amount); controls.update(); controls.enableDamping = damping; camera.updateMatrixWorld(true); project(); };
      if (reduced.matches) { apply(1); return; }
      transition = start; viewport.dataset.inspectionCamera = 'moving';
      function tick(now) { if (transition !== start || !active) return; const p = Math.min(1, (now - start.time) / 580); apply(1 - Math.pow(1 - p, 3)); if (p < 1) tweenFrame = requestAnimationFrame(tick); else cancel(); }
      tweenFrame = requestAnimationFrame(tick);
    }
    function clearHighlight() { highlights.forEach((original, node) => { const current = node.material; node.material = original; (Array.isArray(current) ? current : [current]).forEach(m => m.dispose()); }); highlights.clear(); }
    function mark(item, contextual = false) {
      clearHighlight(); selected = item?.id || '';
      if(selected)viewport.dataset.inspectionPart=selected;else delete viewport.dataset.inspectionPart;
      if(!selected){focusLabel.hidden=true;leader.hidden=true;}
      viewport.toggleAttribute('data-inspection-context',contextual);
      items.forEach(entry => { entry.chip.setAttribute('aria-pressed', String(entry.id === selected)); entry.button.setAttribute('aria-pressed', String(entry.id === selected)); });
      document.dispatchEvent(new CustomEvent('bm:inspection-change',{detail:{scene:currentScene,part:selected,contextual}}));
      if (!item) { description.textContent = t('选择部件，查看位置与说明。'); return; }
      const selectedMeshes=new Set();(item.targets||[item.target]).forEach(target=>target.traverse(node=>{if(node.isMesh&&!node.userData.dragProxy)selectedMeshes.add(node);}));
      rig.group.traverse(node=>{if(!node.isMesh||node.userData.dragProxy||(!contextual&&!selectedMeshes.has(node)))return;highlights.set(node,node.material);const mats=(Array.isArray(node.material)?node.material:[node.material]).map(m=>{const copy=m.clone();if(selectedMeshes.has(node)){copy.emissive?.set(0x147a87);copy.emissiveIntensity=.25;}else copy.color?.multiplyScalar(.84);return copy;});node.material=Array.isArray(node.material)?mats:mats[0];});
      description.textContent = t(item.text);
    }
    function whole(view = 'oblique') { if (!active) return; mark(null); const preset = fitScene?fitScene(currentScene,new T.Vector3(...directions[view])):fit(new T.Vector3(...directions[view])); move(preset.position, preset.target); }
    function select(id) {
      const item = items.find(entry => entry.id === id); if (!item || !active) return;
      mark(item); rig.group.updateWorldMatrix(true, true);
      const box=new T.Box3();(item.targets||[item.target]).forEach(node=>box.union(new T.Box3().setFromObject(node)));const target=box.getCenter(new T.Vector3());
      const direction = new T.Vector3(.85, .3, 1).normalize();
      // Rigs use different scene scales. Keep enough of the surrounding machine
      // visible instead of applying the OP-LE's fixed close-up distance to all rigs.
      const overview=fitScene?fitScene(currentScene,direction):fit(direction);
      const overviewDistance=overview.position.distanceTo(overview.target);
      const size=box.getSize(new T.Vector3());
      const distance=Math.max(overviewDistance*.72,Math.min(overviewDistance,size.length()*1.6));
      move(target.clone().addScaledVector(direction, distance), target);
    }
    function explode(value) {
      if(!rig.setExplode)return;
      const amount = Math.max(0, Math.min(100, Number(value) || 0)); cancel(); cancelCamera();
      if (amount > 0 && rig.getExplode() === 0) document.dispatchEvent(new CustomEvent('bm:structure-inspect'));
      rig.setExplode(amount / 100); slider.value = String(amount); output.textContent = `${amount}%`;
      viewport.toggleAttribute('data-equipment-exploded', amount > 0);
      status.textContent = amount > 0 ? t('拆解中：动作播放与参数拖动已暂停；仍可旋转视角。') : '';
      lines.visible = amount > 0;
      const values = lineGeometry.attributes.position.array; let i = 0;
      Object.values(rig.assemblies).filter(a => a.offset.lengthSq() > 0).forEach(({ node, offset }) => {
        const end = rig.group.worldToLocal(new T.Box3().setFromObject(node).getCenter(new T.Vector3()));
        const start = end.clone().addScaledVector(offset, -amount / 100);
        [start, end].forEach(p => { values[i++] = p.x; values[i++] = p.y; values[i++] = p.z; });
      });
      lineGeometry.setDrawRange(0, i / 3); lineGeometry.attributes.position.needsUpdate = true; lineGeometry.computeBoundingSphere();
      if (active) project();
    }
    function reset() { cancel(); mark(null); if (rig.getExplode?.()) explode(0); }
    function sync() {
      if (destroyed) return;
      const route=document.body.dataset.bmRoute||'',action=route.startsWith('action/')?BM.flow?.byId[route.slice(7)]:null;
      const key=action?.sceneKey||(route==='action/cam'?'cam':'');
      if(registry[key]&&key!==currentScene){reset();lines.removeFromParent();rig=registry[key];currentScene=key;rig.group.add(lines);buildItems();rebuildHits();}
      const next=!!registry[key]&&document.body.dataset.learningMode!=='physics';
      if (active && !next) reset(); active = next; ui.hidden = !active; layer.hidden = !active;
      viewport.toggleAttribute('data-equipment-inspector', active);
      if(active)viewport.dataset.inspectionScene=currentScene;else delete viewport.dataset.inspectionScene;
      const panel = document.getElementById('bm-learning-panel'), tools = panel?.querySelector('.bm-play-tools');
      const courseMount=BM.Product?.route?.startsWith('course/')?document.getElementById('pd-model-support'):null;
      if(active&&courseMount){if(ui.parentNode!==courseMount)courseMount.append(ui);}else if (active && tools && ui.parentNode !== panel) tools.after(ui);
    }
    function project() {
      if (!active || !ui.isConnected) return;
      // Closed inspection with no selected part has no overlays to project.
      if (!selected && !ui.querySelector('details').open) { items.forEach(item => { if (!item.button.hidden) item.button.hidden = true; }); if (!focusLabel.hidden) focusLabel.hidden = true; if (!leader.hidden) leader.hidden = true; return; }
      rig.group.updateWorldMatrix(true, true); camera.updateMatrixWorld(true);
      const w = viewport.clientWidth, h = viewport.clientHeight, occupied = [];
      const item=items.find(entry=>entry.id===selected);
      focusLabel.hidden=leader.hidden=!item;
      if(item){
        item.node.getWorldPosition(world);screen.copy(world).project(camera);const distance=world.distanceTo(camera.position);ray.set(camera.position,world.clone().sub(camera.position).normalize());
        const blocked=ray.intersectObjects(hitMeshes,false).some(hit=>hit.distance<distance-.07&&!(item.targets||[item.target]).some(target=>isWithin(hit.object,target)));
        const outside=screen.z<-1||screen.z>1||Math.abs(screen.x)>.96||Math.abs(screen.y)>.94;
        focusLabel.hidden=leader.hidden=blocked||outside;
        const state=blocked?'occluded':outside?'outside':'visible';if(viewport.dataset.labelState!==state)viewport.dataset.labelState=state;
        if(!blocked&&!outside){
          const x=(screen.x+1)*w/2,y=(1-screen.y)*h/2,lx=Math.max(16,Math.min(w-184,x>w*.55?x-192:x+34)),ly=Math.max(36,Math.min(h-116,y-58));
          if(focusLabel.textContent!==t(item.label))focusLabel.textContent=t(item.label);focusLabel.style.left=lx+'px';focusLabel.style.top=ly+'px';
          leader.setAttribute('viewBox',`0 0 ${w} ${h}`);leader.querySelector('path').setAttribute('d',`M${x},${y}L${x+(lx>x?18:-18)},${ly+18}H${lx+76}`);leader.querySelector('circle').setAttribute('cx',x);leader.querySelector('circle').setAttribute('cy',y);
        }
      }else if(viewport.dataset.labelState)delete viewport.dataset.labelState;
      const open = ui.querySelector('details').open;
      if (!open) { items.forEach(item => { item.button.hidden = true; }); return; }
      items.forEach(item => {
        item.node.getWorldPosition(world); screen.copy(world).project(camera);
        const x = (screen.x + 1) * w / 2, y = (1 - screen.y) * h / 2;
        const distance = world.distanceTo(camera.position);
        ray.set(camera.position, world.clone().sub(camera.position).normalize());
        const occluded = ray.intersectObjects(hitMeshes, false).some(hit => hit.distance < distance - .10 && hit.object !== item.node && !(item.targets||[item.target]).some(target=>isWithin(hit.object,target)));
        const back = world.clone().sub(rig.group.getWorldPosition(new T.Vector3())).dot(camera.position.clone().sub(world)) < -.9;
        const overlap = occupied.some(p => Math.hypot(p.x - x, p.y - y) < 54);
        const hide = !open || screen.z < -1 || screen.z > 1 || x < 30 || x > w - 30 || y < 30 || y > h - 100 || overlap || occluded || back;
        // Keep an already focused marker stable; the labelled part list stays
        // available even when all in-scene markers are occluded.
        item.button.hidden = hide && document.activeElement !== item.button;
        item.button.style.transform = `translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,0)`;
        if (!hide) occupied.push({ x, y });
      });
    }
    function isWithin(node, parent) { for (let n = node; n; n = n.parent) if (n === parent) return true; return false; }
    ui.addEventListener('click', event => { const button = event.target.closest('button'); if (!button) return; if (button.dataset.part) select(button.dataset.part); else if (button.dataset.view) whole(button.dataset.view); else if (button.hasAttribute('data-whole')) whole(); else if (button.hasAttribute('data-restore')) { explode(0); whole(); } }, { signal });
    layer.addEventListener('pointerdown', event => event.stopPropagation(), { signal });
    layer.addEventListener('click', event => { event.stopPropagation(); const id = event.target.closest('button')?.dataset.part; if (id) select(id); }, { signal });
    slider.addEventListener('input', () => explode(slider.value), { signal });
    slider.addEventListener('change', () => { if (active && rig.getExplode?.()) whole(); }, { signal });
    ui.querySelector('details').addEventListener('toggle', project, { signal });
    canvas.addEventListener('pointerdown', () => { if (active) { cancel(); cancelCamera(); } }, { capture: true, signal });
    document.addEventListener('click', event => { if (active && event.target.closest('[data-bm="play"], [data-bm="restart"], [data-bm="stage"], [data-bm="mode"], [data-bm="camera"], [data-bm="next-stage"]')) reset(); }, { capture: true, signal });
    document.addEventListener('click', event => { if (active && event.target.closest('#btn-zoom-in, #btn-zoom-out, #btn-auto-rotate')) cancel(); }, { capture: true, signal });
    document.addEventListener('visibilitychange', () => { if (document.hidden) cancel(); }, { signal });
    function localizeUI() {
      ui.setAttribute('aria-label',t('器械结构观察'));
      ui.querySelector('.bm-structure-views').setAttribute('aria-label',t('观察角度'));
      chips.setAttribute('aria-label',t('选择部件'));slider.setAttribute('aria-label',t('结构拆解程度'));
      for(const [selector,text] of [['[data-view="front"]','正面'],['[data-view="side"]','侧面'],['[data-view="oblique"]','斜视'],['summary','看结构'],['[data-whole]','返回整体视图'],['.bm-explode-title','拆解查看'],['.bm-explode-footer>span','仅分离展示；不表示机械位移。'],['[data-restore]','一键还原']])ui.querySelector(selector).textContent=t(text);
      ui.querySelector('.bm-structure-note').textContent=t(currentScene==='cam'?'OP-LE · 依据装配资料的视觉近似，尺寸未标定。':'当前器械的结构示意，尺寸与档位以实物为准。');
      items.forEach(i=>{i.chip.textContent=t(i.label);i.button.setAttribute('aria-label',t(i.label));});
      description.textContent=t(items.find(i=>i.id===selected)?.text||'选择部件，查看位置与说明。');
      status.textContent=Number(slider.value)>0?t('拆解中：动作播放与参数拖动已暂停；仍可旋转视角。'):'';
    }
    localizeUI();
    document.addEventListener('bm:language-change', localizeUI, { signal });
    const observer = new MutationObserver(records => {
      if (records.some(record => record.type === 'attributes' && record.target === document.body ||
        record.type === 'childList' && [...record.addedNodes].some(node => node.nodeType === 1 &&
          (node.matches('#bm-learning-panel,#pd-model-support,.bm-play-tools') || node.querySelector('#bm-learning-panel,#pd-model-support,.bm-play-tools'))))) sync();
    }); observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-bm-route', 'data-learning-mode'] }); sync();
    return { element:ui, project, reset, select, whole, cancel, highlight(id,{contextual=false}={}){if(!active)return;const item=items.find(entry=>entry.id===id);if(item)mark(item,contextual);}, isActive: () => active, destroy() { if (destroyed) return; reset(); destroyed = true; observer.disconnect(); abort.abort(); ui.remove(); layer.remove(); lines.removeFromParent(); lineGeometry.dispose(); lineMaterial.dispose(); delete viewport.dataset.equipmentInspector; delete viewport.dataset.equipmentExploded; } };
  };
})(window);
