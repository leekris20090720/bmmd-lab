/* Analytic, unforced spring response in explicitly normalized demonstration units. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) { root.BM = root.BM || {}; root.BM.SpringLab = api; }
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  var defaults = { mass: 1, stiffness: 80, damping: 8, displacement: 1 };
  var bounds = { mass: [0.2, 5], stiffness: [1, 300], damping: [0, 60], displacement: [-10, 10] };
  var units = 'normalized-demo';
  var version = 'spring-1.0.0';
  function finite(value) { return typeof value === 'number' && Number.isFinite(value); }
  function normalize(input) {
    input = input || {};
    var params = {}, reasons = [];
    Object.keys(defaults).forEach(function (key) {
      var value = Object.prototype.hasOwnProperty.call(input, key) ? input[key] : defaults[key];
      var b = bounds[key];
      if (!finite(value) || value < b[0] || value > b[1]) reasons.push(key + ' 须在 [' + b[0] + ', ' + b[1] + '] 内。');
      params[key] = finite(value) ? value : null;
    });
    return { valid: reasons.length === 0, params: params, reasons: reasons };
  }
  function response(t, input) {
    var normalized = normalize(input), reasons = normalized.reasons.slice();
    if (!finite(t) || t < 0 || t > 120) reasons.push('演示时间须在 0 到 120 内。');
    var base = { version: version, valid: reasons.length === 0, reasons: reasons, t: finite(t) ? t : null, params: normalized.params, units: units, equation: 'm x″ + c x′ + k x = 0', initialCondition: 'x(0)=displacement, v(0)=0', x: null, v: null, a: null, regime: null, zeta: null, omega0: null, energy: null };
    if (reasons.length) return base;
    var p = normalized.params, alpha = p.damping / (2 * p.mass), omega0 = Math.sqrt(p.stiffness / p.mass);
    var zeta = alpha / omega0, x, v, regime;
    // The critical branch is the continuous repeated-root limit. The tiny
    // tolerance only prevents a floating-point sign choice at that root.
    if (Math.abs(zeta - 1) <= 1e-10) {
      regime = 'critical';
      var expCritical = Math.exp(-alpha * t);
      x = p.displacement * expCritical * (1 + alpha * t);
      v = -p.displacement * alpha * alpha * t * expCritical;
    } else if (zeta < 1) {
      regime = 'underdamped';
      var omega = Math.sqrt(omega0 * omega0 - alpha * alpha), wt = omega * t, expUnder = Math.exp(-alpha * t);
      x = p.displacement * expUnder * (Math.cos(wt) + alpha / omega * Math.sin(wt));
      v = -p.displacement * expUnder * (omega0 * omega0 / omega) * Math.sin(wt);
    } else {
      regime = 'overdamped';
      var root = Math.sqrt(alpha * alpha - omega0 * omega0);
      // This quotient avoids subtracting two nearly equal positive values
      // when high damping makes the slow root close to zero.
      var slow = -omega0 * omega0 / (alpha + root), fast = -alpha - root;
      var denominator = slow - fast;
      var slowCoefficient = -p.displacement * fast / denominator, fastCoefficient = p.displacement * slow / denominator;
      var slowTerm = slowCoefficient * Math.exp(slow * t), fastTerm = fastCoefficient * Math.exp(fast * t);
      x = slowTerm + fastTerm;
      v = slow * slowTerm + fast * fastTerm;
    }
    // Evaluate acceleration from the same ODE, rather than finite differencing.
    var a = -(p.damping * v + p.stiffness * x) / p.mass;
    var kinetic = 0.5 * p.mass * v * v, potential = 0.5 * p.stiffness * x * x;
    base.x = x; base.v = v; base.a = a; base.regime = regime; base.zeta = zeta; base.omega0 = omega0;
    base.energy = { kinetic: kinetic, potential: potential, total: kinetic + potential, dissipated: Math.max(0, 0.5 * p.stiffness * p.displacement * p.displacement - kinetic - potential) };
    return base;
  }
  function sample(params, duration, count) {
    if (duration === undefined) duration = 6;
    if (count === undefined) count = 241;
    if (!finite(duration) || duration <= 0 || duration > 120) throw new RangeError('演示时长须大于 0 且不超过 120。');
    if (!Number.isInteger(count) || count < 2 || count > 5001) throw new RangeError('采样数须为 2 到 5001 的整数。');
    var rows = [];
    for (var i = 0; i < count; i++) rows.push(response(duration * i / (count - 1), params));
    return rows;
  }
  return { version: version, defaults: defaults, bounds: bounds, units: units, normalize: normalize, response: response, sample: sample, notice: 'm、c、k 使用归一化演示单位；这是规定初始位移后自由回弹的解析模型，不代表真实材料或人体参数。' };
});
