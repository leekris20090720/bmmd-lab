/* DOM adapters for React Bits ScrollVelocity / DecryptedText and Magic UI
 * AnimatedGridPattern / NumberTicker. See assets/vendor/reference-effects/README.md.
 * This layer owns decorative nodes only. It never accesses visitor records. */
(() => {
  'use strict';
  const B = window.BM = window.BM || {};
  const media = matchMedia('(prefers-reduced-motion: reduce)');
  const fine = matchMedia('(hover:hover) and (pointer:fine)');
  const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
  const wrap = (min, max, value) => (((value - min) % (max - min)) + max - min) % (max - min) + min;
  const reduced = () => media.matches || document.documentElement.classList.contains('pd-reduced');
  const allowed = () => !reduced() && !document.hidden && !document.body.hasAttribute('data-explore-open') && document.body.dataset.bmRoute !== 'train/session';
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = (tag, attrs = {}) => {
    const element = document.createElementNS(svgNS, tag);
    Object.entries(attrs).forEach(([key, value]) => element.setAttribute(key, String(value)));
    return element;
  };
  const span = (className, text) => {
    const element = document.createElement('span'); element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  };
  let surface = null, cleanups = [], grid = null, strip = null, tasks = [];
  let entry = null, tree = null, frame = 0, queued = 0, last = 0, serial = 0;
  let velocity = 0, targetVelocity = 0, scrollAt = 0, previousScroll = 0, scrollTime = 0;
  let nav = null, indicator = null, navObserver = null, navTarget = null, previousNav = null;

  function finishTasks() {
    tasks.forEach(task => task.finish()); tasks = [];
  }
  function cleanup() {
    cancelAnimationFrame(frame); frame = 0; last = 0;
    entry?.disconnect(); tree?.disconnect(); navObserver?.disconnect();
    finishTasks(); cleanups.forEach(dispose => dispose()); cleanups = [];
    grid = null; strip = null; surface = null;
    velocity = targetVelocity = 0;
  }
  function wake() { if (!frame && allowed()) frame = requestAnimationFrame(tick); }

  // Keep authored glyph widths and readable screen-reader text during decoding.
  function decrypt(element) {
    const original = element.textContent;
    if (!original.trim() || original.length > 65) return;
    const visual = span('kx-decrypt-visual'); visual.setAttribute('aria-hidden', 'true');
    const cells = Array.from(original).map(char => {
      if (/\s/u.test(char)) { visual.append(document.createTextNode(char)); return null; }
      const cell = span('kx-glyph-cell'), ghost = span('kx-glyph-ghost', char), glyph = span('kx-glyph', char);
      cell.append(ghost, glyph); visual.append(cell); return { glyph, char };
    });
    const readable = span('kx-sr', original);
    element.replaceChildren(readable, visual); element.classList.add('kx-decrypt');
    let played = false, running = false;
    const finish = () => { cells.forEach(cell => { if (cell) cell.glyph.textContent = cell.char; }); element.dataset.kxState = 'settled'; running = false; };
    const play = () => {
      if (running || !allowed()) return;
      running = true; element.dataset.kxState = 'decoding';
      const letters = '0123456789/<>+−×';
      const start = performance.now(); let step = -1;
      tasks.push({ finish, update(now) {
        if (!element.isConnected) { finish(); return false; }
        const elapsed = now - start, next = Math.floor(elapsed / 45), progress = clamp(elapsed / 700, 0, 1);
        if (next !== step) {
          step = next;
          cells.forEach((cell, index) => { if (cell) cell.glyph.textContent = index / cells.length < progress ? cell.char : letters[(index * 7 + next * 3) % letters.length]; });
        }
        if (progress === 1) { finish(); return false; }
        return true;
      } });
      wake();
    };
    element.addEventListener('pointerenter', play);
    element._kxEnter = () => { if (!played) { played = true; play(); } };
    entry.observe(element);
    cleanups.push(() => { element.removeEventListener('pointerenter', play); delete element._kxEnter; element.replaceChildren(document.createTextNode(original)); element.classList.remove('kx-decrypt'); delete element.dataset.kxState; });
  }
  function number(element) {
    const target = Number(element.dataset.kxNumber), original = element.textContent;
    if (!Number.isFinite(target) || target < 0) return;
    const visual = span('kx-number-visual', original); visual.setAttribute('aria-hidden', 'true');
    element.replaceChildren(span('kx-sr', original), visual); element.classList.add('kx-number');
    let played = false;
    const finish = () => { visual.textContent = original; element.dataset.kxState = 'settled'; };
    element._kxEnter = () => {
      if (played || !allowed()) return;
      played = true; let value = 0, speed = 0; const start = performance.now();
      element.dataset.kxState = 'counting';
      tasks.push({ finish, update(now, dt) {
        if (!element.isConnected) { finish(); return false; }
        // NumberTicker's stiffness 100 / damping 60, sub-stepped for stability.
        const steps = Math.ceil(dt / (1 / 240)), h = dt / steps;
        for (let i = 0; i < steps; i++) { speed += (100 * (target - value) - 60 * speed) * h; value += speed * h; }
        visual.textContent = String(Math.round(clamp(value, 0, target)));
        if (now - start > 1800 || Math.abs(target - value) < .02) { finish(); return false; }
        return true;
      } }); wake();
    };
    entry.observe(element);
    cleanups.push(() => { delete element._kxEnter; element.replaceChildren(document.createTextNode(original)); element.classList.remove('kx-number'); delete element.dataset.kxState; });
  }
  function createGrid(host) {
    const layer = svg('svg', { class: 'kx-grid', 'aria-hidden': 'true', focusable: 'false' });
    const id = 'kx-grid-' + ++serial, defs = svg('defs');
    const pattern = svg('pattern', { id, width: 64, height: 64, patternUnits: 'userSpaceOnUse' });
    pattern.append(svg('path', { d: 'M.5 64V.5H64', fill: 'none', stroke: 'currentColor', 'stroke-opacity': '.13' }));
    defs.append(pattern); layer.append(defs, svg('rect', { width: '100%', height: '100%', fill: `url(#${id})` }));
    const cells = Array.from({ length: host.id === 'portal-welcome-stage' ? 14 : 8 }, () => {
      const rect = svg('rect', { width: 63, height: 63, rx: 3, fill: 'currentColor', opacity: 0 }); layer.append(rect); return { rect, animation: null };
    });
    const cursor = svg('rect', { class: 'kx-grid-cursor', width: 63, height: 63, rx: 3 }); layer.append(cursor);
    host.classList.add('kx-grid-host'); host.prepend(layer);
    const bounds = layer.getBoundingClientRect();
    const state = { layer, cursor, cells, width: bounds.width || 1, height: bounds.height || 1, visible: true, disposed: false };
    const position = cell => { cell.rect.setAttribute('x', Math.floor(Math.random() * state.width / 64) * 64 + 1); cell.rect.setAttribute('y', Math.floor(Math.random() * state.height / 64) * 64 + 1); };
    const pulse = (cell, delay = 0) => {
      if (state.disposed || !allowed() || !state.visible || !cell.rect.animate) return;
      position(cell);
      const animation = cell.rect.animate([{ opacity: 0 }, { opacity: .23, offset: .4 }, { opacity: 0 }], { duration: 4200, delay, easing: 'ease-in-out' });
      cell.animation = animation;
      animation.finished.then(() => { cell.animation = null; pulse(cell); }, () => {});
    };
    state.sync = () => {
      const paused = !allowed() || !state.visible;
      cells.forEach((cell, i) => { if (cell.animation) { if (paused) cell.animation.pause(); else cell.animation.play(); } else if (!paused) pulse(cell, i * 130); });
      if (paused) cursor.style.opacity = '0';
    };
    const resize = new ResizeObserver(() => { const rect = layer.getBoundingClientRect(); state.width = rect.width; state.height = rect.height; }); resize.observe(layer);
    const visible = new IntersectionObserver(items => { state.visible = items[0].isIntersecting; state.sync(); }, { threshold: .01 }); visible.observe(layer);
    state.sync();
    cleanups.push(() => { state.disposed = true; cells.forEach(cell => cell.animation?.cancel()); resize.disconnect(); visible.disconnect(); layer.remove(); host.classList.remove('kx-grid-host'); });
    return state;
  }
  function createStrip(anchor, after = false) {
    if (!anchor) return null;
    const layer = document.createElement('div'); layer.className = 'kx-velocity'; layer.setAttribute('aria-hidden', 'true');
    const en = document.documentElement.lang.startsWith('en');
    const label = en ? 'MOTION · STRUCTURE · FORCE · ' : '动作 · 结构 · 受力 · ';
    const rows = [1, -1].map(direction => {
      const viewport = document.createElement('div'); viewport.className = 'kx-velocity-row';
      const track = document.createElement('div'); track.className = 'kx-velocity-track';
      for (let i = 0; i < 8; i++) { const copy = document.createElement('div'); copy.className = 'kx-velocity-copy'; copy.textContent = label; track.append(copy); }
      viewport.append(track); layer.append(viewport); return { track, direction, x: 0, width: 1 };
    });
    if (after) anchor.after(layer); else anchor.append(layer);
    const resize = new ResizeObserver(() => rows.forEach(row => { row.width = row.track.firstElementChild.getBoundingClientRect().width || 1; })); resize.observe(layer);
    let visible = true;
    const observer = new IntersectionObserver(items => { visible = items[0].isIntersecting; if (visible) wake(); }, { root: surface, threshold: .01 }); observer.observe(layer);
    cleanups.push(() => { resize.disconnect(); observer.disconnect(); layer.remove(); });
    return { layer, rows, get visible() { return visible; } };
  }
  function tick(now) {
    frame = 0; if (!allowed()) return;
    const dt = last ? clamp((now - last) / 1000, .001, .04) : 1 / 60; last = now;
    tasks = tasks.filter(task => task.update(now, dt));
    if (now - scrollAt > 80) targetVelocity = 0;
    velocity += (targetVelocity - velocity) * (1 - Math.exp(-dt / .13));
    if (Math.abs(velocity) < .2) velocity = 0;
    if (strip?.visible) for (const row of strip.rows) {
      // ScrollVelocity's measured-copy wrapping, direction and velocity surge.
      row.x = wrap(-row.width, 0, row.x + velocity * dt * .14 * row.direction);
      const surge = Math.tanh(Math.abs(velocity) / 1600), heading = Math.sign(velocity) * row.direction;
      row.track.style.transform = `translate3d(${row.x.toFixed(2)}px,0,0) skewX(${(-heading * 7 * surge).toFixed(2)}deg) scaleY(${(1 + .08 * surge).toFixed(3)})`;
    }
    if (tasks.length || velocity || targetVelocity) frame = requestAnimationFrame(tick); else last = 0;
  }
  function onScroll(event) {
    if (event.target !== surface || !allowed()) return;
    const now = performance.now(), top = surface.scrollTop;
    targetVelocity = clamp((top - previousScroll) / clamp(now - scrollTime, 16, 80) * 1000, -3200, 3200);
    previousScroll = top; scrollTime = scrollAt = now; wake();
  }
  function pointNav(target) {
    if (!indicator || !nav) return;
    navTarget = target;
    if (!target) { indicator.style.opacity = '0'; return; }
    const x = target.offsetLeft, width = target.offsetWidth;
    indicator.style.opacity = '1'; indicator.style.width = width + 'px'; indicator.style.transform = `translateX(${x}px)`;
    previousNav = { x, width };
  }
  function syncNav() {
    const button = nav?.querySelector('[data-pd-explore]');
    button?.setAttribute('aria-expanded', String(document.body.hasAttribute('data-explore-open')));
    pointNav(document.body.hasAttribute('data-explore-open') ? button : nav?.querySelector('a[aria-current]'));
  }
  function mountNav() {
    nav = document.querySelector('#pd-header nav'); if (!nav) return;
    indicator = span('kx-nav-indicator'); indicator.setAttribute('aria-hidden', 'true'); nav.append(indicator); nav.classList.add('kx-nav-ready');
    if (previousNav && !reduced()) { indicator.style.width = previousNav.width + 'px'; indicator.style.transform = `translateX(${previousNav.x}px)`; }
    const over = event => { const target = event.target.closest('a,button'); if (target?.parentElement === nav) pointNav(target); };
    const leave = () => syncNav();
    nav.addEventListener('pointerover', over); nav.addEventListener('pointerleave', leave); nav.addEventListener('focusin', over); nav.addEventListener('focusout', leave);
    navObserver = new ResizeObserver(syncNav); navObserver.observe(nav);
    requestAnimationFrame(syncNav);
    cleanups.push(() => { nav.removeEventListener('pointerover', over); nav.removeEventListener('pointerleave', leave); nav.removeEventListener('focusin', over); nav.removeEventListener('focusout', leave); indicator.remove(); nav.classList.remove('kx-nav-ready'); });
  }
  function prepare() {
    queued = 0; cleanup(); mountNav();
    const route = document.body.dataset.bmRoute || 'home';
    surface = document.getElementById(route === 'home' ? 'portal-hub-overlay' : 'product-root');
    if (!surface || route === 'train/session') { sync(); return; }
    entry = new IntersectionObserver(items => { for (const item of items) if (item.isIntersecting) { item.target._kxEnter?.(); entry.unobserve(item.target); } }, { root: surface, threshold: .25 });
    const home = route === 'home';
    const heading = home ? document.getElementById('portal-welcome-stage') : surface.querySelector('.pd-page-heading');
    if (heading && (home || route === 'learn' || route === 'train/plans')) grid = createGrid(heading);
    surface.querySelectorAll(home ? '.apple-hero-copy>p,.pd-home-directions h2' : '.pd-page-heading>p').forEach(decrypt);
    surface.querySelectorAll('[data-kx-number]').forEach(number);
    if (home) strip = createStrip(surface.querySelector('.pd-home-directions'), true);
    else if (route === 'learn') strip = createStrip(surface.querySelector('.pd-learn-discover'), true);
    previousScroll = surface.scrollTop; scrollTime = performance.now();
    tree = new MutationObserver(requestPrepare); tree.observe(surface, { childList: true });
    document.documentElement.dataset.kineticEffects = 'scroll-velocity decrypted-text animated-grid number-ticker navigation-glide';
    sync();
  }
  function requestPrepare() { if (!queued) queued = requestAnimationFrame(prepare); }
  function sync() {
    const quiet = reduced();
    if (document.documentElement.classList.contains('kx-reduced') !== quiet) document.documentElement.classList.toggle('kx-reduced', quiet);
    if (!allowed()) { cancelAnimationFrame(frame); frame = 0; last = 0; velocity = targetVelocity = 0; finishTasks(); }
    if (quiet && strip) strip.rows.forEach(row => { row.track.style.transform = 'none'; });
    grid?.sync(); syncNav();
  }
  document.addEventListener('scroll', onScroll, { passive: true, capture: true });
  document.addEventListener('pointermove', event => {
    if (!grid || !grid.visible || !allowed() || !fine.matches || event.pointerType === 'touch' || event.buttons) return;
    const rect = grid.layer.getBoundingClientRect(), x = event.clientX - rect.left, y = event.clientY - rect.top;
    const inside = x >= 0 && y >= 0 && x <= rect.width && y <= rect.height;
    grid.cursor.style.opacity = inside ? '1' : '0';
    if (inside) grid.cursor.style.transform = `translate(${Math.floor(x / 64) * 64 + 1}px,${Math.floor(y / 64) * 64 + 1}px)`;
  }, { passive: true });
  const preferences = new MutationObserver(sync); preferences.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
  const state = new MutationObserver(records => { if (records.some(record => record.attributeName === 'data-bm-route')) requestPrepare(); else sync(); });
  state.observe(document.body, { attributes: true, attributeFilter: ['data-bm-route', 'data-explore-open'] });
  media.addEventListener('change', sync); document.addEventListener('visibilitychange', sync);
  window.addEventListener('bm:page-ready', requestPrepare); document.addEventListener('bm:language-change', requestPrepare);
  window.addEventListener('pagehide', () => { cancelAnimationFrame(queued); queued = 0; cleanup(); });
  window.addEventListener('pageshow', requestPrepare);
  B.KineticEffects = { refresh: requestPrepare };
  requestPrepare();
})();
