/* Engineering views share the existing Three.js scene, camera and canvas.
 * The commercial shell is a visual reference. Coloured geometry represents
 * the explicitly idealised mechanics-core model, not a reverse-engineered cam. */
(function (global) {
  'use strict';
  const BM = global.BM = global.BM || {};
  let queued = null;
  const subscribers = new Set();
  BM.engineering3D = {
    ready: false,
    set(state) { queued = state; },
    release() { queued = null; },
    onProgress(callback) { subscribers.add(callback); return () => subscribers.delete(callback); }
  };
  BM.createEngineering3DBridge = function ({ THREE, scene, canvas, viewport, camera, controls, rigs, activate, restore, requestResize, requestDraw = () => {}, evaluate }) {
    const modelScene = { pulley: 'arm', cam: 'cam', incline: 'incline' };
    const colors = { external: 0x257bd6, gravity: 0xd97440, normal: 0x8771d5, friction: 0xc19324, arm: 0x22a79b, shell: 0x8295a8 };
    const materialCache = new Map(), savedNodes = new Map(), selectedMeshes = new Map();
    const overlay = new THREE.Group(); overlay.name = 'ideal-engineering-model'; overlay.visible = false; scene.add(overlay);
    const structure = new THREE.Group(), forceLayer = new THREE.Group(), annotation = new THREE.Group(); overlay.add(structure, forceLayer, annotation);
    const resources = [], dragHandles = [];
    const cylinderGeometry = new THREE.CylinderGeometry(1, 1, 1, 12);
    const sphereGeometry = new THREE.SphereGeometry(1, 16, 12);
    const boxGeometry = new THREE.BoxGeometry(1, 1, 1);
    resources.push(cylinderGeometry, sphereGeometry, boxGeometry);
    const material = (color, opacity = 1) => { const m = new THREE.MeshStandardMaterial({ color, metalness: .2, roughness: .4, transparent: opacity < 1, opacity }); resources.push(m); return m; };
    const cableMat = material(0x22a79b), linkMat = material(0x257bd6), loadMat = material(0x51657b), pivotMat = material(0xc19324), ghostMat = material(0x91a3b6, .24);
    const makeRod = (parent, mat, radius = .025) => { const mesh = new THREE.Mesh(cylinderGeometry, mat); mesh.scale.set(radius, 1, radius); parent.add(mesh); return mesh; };
    const rod = (mesh, a, b, radius = .025) => {
      const vector = new THREE.Vector3().subVectors(b, a), length = vector.length(); mesh.visible = length > 1e-7;
      if (!mesh.visible) return;
      mesh.position.copy(a).add(b).multiplyScalar(.5); mesh.scale.set(radius, length, radius); mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), vector.divideScalar(length));
    };
    const point = (parent, mat, radius) => { const mesh = new THREE.Mesh(sphereGeometry, mat); mesh.scale.setScalar(radius); parent.add(mesh); return mesh; };
    const box = (parent, mat, size) => { const mesh = new THREE.Mesh(boxGeometry, mat); mesh.scale.set(...size); parent.add(mesh); return mesh; };
    const cableA = makeRod(structure, cableMat), cableB = makeRod(structure, cableMat), cableC = makeRod(structure, cableMat), lever = makeRod(structure, linkMat, .045);
    const trackA = makeRod(structure, loadMat, .035), trackB = makeRod(structure, loadMat, .035);
    const momentArm = makeRod(annotation, cableMat, .016), actionLine = makeRod(annotation, ghostMat, .013);
    const pivot = point(structure, pivotMat, .09), contact = point(structure, cableMat, .07);
    const referenceGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),new THREE.Vector3(),new THREE.Vector3(),new THREE.Vector3()]);
    const referenceMat = new THREE.LineDashedMaterial({color:0x8295a8,dashSize:.045,gapSize:.035,transparent:true,opacity:.7});
    resources.push(referenceGeo,referenceMat);
    const referenceArm = new THREE.LineSegments(referenceGeo,referenceMat);annotation.add(referenceArm);

    const handle = box(structure, linkMat, [.32, .1, .22]), load = box(structure, loadMat, [.35, .24, .3]);
    const wheelGeo = new THREE.TorusGeometry(.18, .027, 12, 36); resources.push(wheelGeo);
    const wheel = new THREE.Mesh(wheelGeo, loadMat), wheel2 = new THREE.Mesh(wheelGeo, loadMat); structure.add(wheel, wheel2);
    const dragMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false }); resources.push(dragMat);
    const dragProxy = box(structure, dragMat, [.45, .45, .45]); dragProxy.userData.dragProxy = true;
    const reevingGroup = new THREE.Group(); structure.add(reevingGroup);
    const reevingGeo = new THREE.BufferGeometry(); reevingGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(256 * 3), 3)); resources.push(reevingGeo);
    const reevingMat = new THREE.LineBasicMaterial({ color: 0x22a79b }); resources.push(reevingMat);
    const reevingLine = new THREE.Line(reevingGeo, reevingMat); reevingGroup.add(reevingLine);
    const reevingWheels = Array.from({ length: 4 }, () => { const m = new THREE.Mesh(wheelGeo, loadMat); reevingGroup.add(m); return m; });
    const movingBlock = box(reevingGroup, loadMat, [.55, .05, .06]);
    const angleGeo = new THREE.BufferGeometry().setFromPoints(Array.from({ length: 33 }, () => new THREE.Vector3())); resources.push(angleGeo);
    const angleMat = new THREE.LineBasicMaterial({ color: 0x8771d5, transparent: true, opacity: 1 }); resources.push(angleMat);
    const angleArc = new THREE.Line(angleGeo, angleMat); annotation.add(angleArc);
    const forceArrows = [];
    const labels = [];
    const labelRoot = document.createElement('div');
    labelRoot.className = 'engineering-model-labels'; labelRoot.setAttribute('aria-hidden', 'true');
    Object.assign(labelRoot.style, { position: 'absolute', inset: '0', pointerEvents: 'none', overflow: 'hidden', zIndex: '3', display: 'none' }); viewport.append(labelRoot);
    function label(text, color = '#257bd6') {
      const el = document.createElement('span'); el.textContent = text;
      Object.assign(el.style, { position: 'absolute', padding: '3px 7px', borderRadius: '6px', background: 'var(--card-bg, #fff)', color, font: '600 11px/1.25 system-ui', border: '1px solid currentColor', whiteSpace: 'nowrap', transform: 'translate(-50%, -50%)', boxShadow: '0 1px 8px #0001' });
      labelRoot.append(el); const item = { el, point: new THREE.Vector3(), visible: true }; labels.push(item); return item;
    }
    const pivotLabel = label('O · 转轴', '#9a711e'), armLabel = label('d · 垂直力臂', '#178f86'), thetaLabel = label('θ · 角度', '#8771d5');
    const objectLabel = label('分析对象', '#50687e');
    let current = null, result = null, snapshot = null, selection = null, active = false;
    let unitsPerM = 1, forceScale = .001, overlayOffset = new THREE.Vector3();
    let lastStateKey = '', lastProgressEvent = -1, fadeTween = null;
    const selectedPath = new Set();
    const asVector = (v) => new THREE.Vector3(Number(v?.x) || 0, Number(v?.y) || 0, Number(v?.z) || 0);
    const mapped = (v) => asVector(v).multiplyScalar(unitsPerM).add(overlayOffset);
    function cloneFor(mesh, emphasized, view) {
      const original = savedNodes.get(mesh)?.material || mesh.material;
      return (Array.isArray(original) ? original : [original]).map((source) => {
        const key = `${source.uuid}:${emphasized ? 1 : 0}:${view}`;
        if (materialCache.has(key)) return materialCache.get(key);
        const copy = source.clone(); copy.transparent = true; copy.depthWrite = emphasized || view === 'physical';
        copy.opacity = view === 'physical' ? source.opacity : emphasized ? .95 : view === 'force' ? .055 : .13;
        if (emphasized && copy.emissive) { copy.emissive.set(0x168aaa); copy.emissiveIntensity = .32; }
        materialCache.set(key, copy); return copy;
      });
    }
    function cacheRig(rig) {
      rig.group.traverse((node) => {
        if (savedNodes.has(node)) return;
        savedNodes.set(node, { material: node.material, position: node.position.clone(), quaternion: node.quaternion.clone(), scale: node.scale.clone(), visible: node.visible });
      });
    }
    function restoreNodes() {
      if (fadeTween) { fadeTween.kill?.(); fadeTween = null; }
      savedNodes.forEach((saved, node) => {
        node.position.copy(saved.position); node.quaternion.copy(saved.quaternion); node.scale.copy(saved.scale); node.visible = saved.visible;
        if (saved.material) node.material = saved.material;
      }); savedNodes.clear();
    }
    function addPath(root) { if (!root) return; root.traverse((node) => { if (node.isMesh && !node.userData.dragProxy) selectedPath.add(node); }); }
    function findPath(model) {
      selectedPath.clear(); const parts = rigs[model].parts;
      const names = model === 'pulley' ? ['carriagePulley', 'rightPulley', 'cable', 'rightCable', 'handle', 'rightHandle', 'leftStackLift', 'rightStackLift']
        : model === 'cam' ? ['cam', 'guidePulley', 'cableA', 'cableB', 'armPivot', 'workArm', 'shinRoll']
          : ['railL', 'railR', 'carriage', 'footPlate', 'hornWorkL', 'hornWorkR'];
      names.forEach((name) => addPath(parts[name]));
    }
    function applyMaterials(animate) {
      if (!current) return; findPath(current.model);
      if (fadeTween) fadeTween.kill?.();
      const transitions = [];
      rigs[current.model].group.traverse((node) => {
        if (!node.isMesh || node.userData.dragProxy || node.userData.forceIndicator) return;
        const source = savedNodes.get(node)?.material; if (!source) return;
        const highlighted = selectedPath.has(node) && (current.view !== 'physical' || Boolean(selection));
        const mats = cloneFor(node, highlighted, current.view);
        const oldMats = Array.isArray(node.material) ? node.material : [node.material];
        mats.forEach((mat, i) => { const end = mat.userData.engineeringOpacity ?? mat.opacity; mat.userData.engineeringOpacity = end;
          if (animate && global.gsap && !global.matchMedia('(prefers-reduced-motion: reduce)').matches) { const start = oldMats[i]?.opacity ?? 1; mat.opacity = start; transitions.push({ mat, start, end }); } else mat.opacity = end; });
        node.material = Array.isArray(source) ? mats : mats[0];
      });
      if (transitions.length) { const state = { t: 0 }; fadeTween = global.gsap.to(state, { t: 1, duration: .22, onUpdate() { transitions.forEach(({ mat, start, end }) => { mat.opacity = start + (end - start) * state.t; }); requestDraw(); } }); }
    }
    function ensureArrow(i) {
      if (forceArrows[i]) return forceArrows[i];
      const arrow = new THREE.ArrowHelper(new THREE.Vector3(0, 1, 0), new THREE.Vector3(), 1, 0x257bd6, .13, .075); arrow.renderOrder = 5;
      arrow.line.material.depthTest = false; arrow.cone.material.depthTest = false; forceLayer.add(arrow);
      const item = { arrow, label: label('F') }; forceArrows[i] = item; return item;
    }
    function focusStyles() {
      if (!current) return;
      const focus = current.focus;
      momentArm.material = cableMat;momentArm.scale.x = focus === 'd' ? .026 : .016;momentArm.scale.z = momentArm.scale.x;
      angleMat.color.set(0x8771d5);
      angleMat.opacity = focus && focus !== 'theta' ? .35 : 1;
      labels.forEach(({ el }) => { el.style.fontWeight = '600'; el.style.boxShadow = '0 1px 8px #0001'; });
      const highlighted = focus === 'd' ? armLabel : focus === 'theta' ? thetaLabel : null;
      if (highlighted) { highlighted.el.style.fontWeight = '800'; highlighted.el.style.boxShadow = '0 0 0 2px currentColor'; }
      forceArrows.forEach((item) => { const dimmed = focus === 'F' ? item.forceId !== 'external' : Boolean(focus); item.arrow.line.material.opacity = dimmed ? .28 : 1; item.arrow.line.material.transparent = true; item.arrow.cone.material.opacity = item.arrow.line.material.opacity; item.arrow.cone.material.transparent = true; item.label.el.style.opacity = dimmed ? '.45' : '1'; if (focus === 'F' && item.forceId === 'external') item.label.el.style.boxShadow = '0 0 0 2px currentColor'; });
    }
    function configureGeometry() {
      if (!current || !result?.valid) { overlay.visible = false; labelRoot.style.display = 'none'; canvas.dataset.engineeringState = JSON.stringify({ valid: false, reasons: result?.reasons || ['Model not selected'] }); return; }
      const rig = rigs[current.model], model = current.model;
      // All original shell state is restored on exit; experiment parameters never
      // enter telemetry, machineSceneTuning, the training store or its whitelist.
      rig.update(current.progress * 100, { fitProgress: current.progress * 100, percentProgress: true });
      const parts = rig.parts;
      if (model === 'cam') {
        if (rig.setDisplayAngle) rig.setDisplayAngle(result.angleRad);
        else { parts.armPivot.rotation.z = result.angleRad; parts.cam.rotation.z = result.angleRad; }
      }
      rig.group.updateWorldMatrix(true, true);
      const anchor = model === 'cam' ? parts.armPivot.getWorldPosition(new THREE.Vector3()) : model === 'pulley' ? parts.carriagePulley.getWorldPosition(new THREE.Vector3()) : rig.group.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(-.1, -.1, 0));
      // Uniform scene units per metre. The reference shell is not dimensionally calibrated.
      unitsPerM = model === 'cam' ? 2.1 : model === 'pulley' ? 1.45 : 1.45;
      overlayOffset.copy(anchor);
      if (model === 'pulley') overlayOffset.sub(asVector(result.geometry.pulleyCenters[0]).multiplyScalar(unitsPerM));
      overlayOffset.z += model === 'cam' ? .68 : .32;
      overlay.visible = current.view !== 'physical'; labelRoot.style.display = overlay.visible ? 'block' : 'none';
      structure.children.forEach((node) => { node.visible = false; }); annotation.children.forEach((node) => { node.visible = false; });
      labels.forEach((entry) => { entry.visible = false; });
      const p = mapped(result.position?.pivot), h = mapped(result.position?.handle), l = mapped(result.position?.load), a = mapped(result.position?.analysis);
      pivot.visible = model !== 'incline'; pivot.position.copy(p);
      if (model === 'pulley') {
        // One variable-ratio ideal transmission: the ratio is a mathematical
        // constraint; the fixed wheel marks redirection, not a fake reeving count.
        handle.visible = true; handle.position.copy(h); load.visible = true; load.position.copy(l);
        // Draw n vertical supporting rope segments so the reeving really has
        // Δx_handle = n Δy_load. A pair of fixed wheels alone is never labelled 2:1.
        reevingGroup.visible = true; reevingWheels.forEach((mesh) => { mesh.visible = false; });
        const n = result.params.ratio, top = result.geometry.fixedPulley.y;
        const loadY = result.position.load.y + .2, xs = n === 4 ? [.1, .3, .4, .6] : [.25, .45];
        const rope = [result.position.handle, { x: -.35, y: top }];
        function addWheel(index, x, y, radius) { const mesh = reevingWheels[index]; mesh.visible = true; mesh.position.copy(mapped({ x, y })); mesh.scale.setScalar(radius * unitsPerM / .18); }
        if (n === 1) {
          rope.push({ x: .35, y: top }, result.position.load); movingBlock.visible = false;
          addWheel(0, -.35, top, .1); addWheel(1, .35, top, .1);
        } else {
          rope.push({ x: xs[0], y: top }, { x: xs[0], y: loadY });
          for (let pair = 0; pair < n / 2; pair++) {
            const leftX = xs[pair * 2], rightX = xs[pair * 2 + 1], centerX = (leftX + rightX) / 2, radius = (rightX - leftX) / 2;
            for (let i = 1; i <= 16; i++) { const a = Math.PI + Math.PI * i / 16; rope.push({ x: centerX + radius * Math.cos(a), y: loadY + radius * Math.sin(a) }); }
            addWheel(pair, centerX, loadY, radius); rope.push({ x: rightX, y: top });
            if (pair < n / 2 - 1) {
              const nextX = xs[(pair + 1) * 2], cx = (rightX + nextX) / 2, rr = (nextX - rightX) / 2;
              for (let i = 1; i <= 16; i++) { const a = Math.PI - Math.PI * i / 16; rope.push({ x: cx + rr * Math.cos(a), y: top + rr * Math.sin(a) }); }
              addWheel(2, cx, top, rr); rope.push({ x: nextX, y: loadY });
            }
          }
          movingBlock.visible = true; movingBlock.position.copy(mapped({ x: .35, y: loadY - .13 })); movingBlock.scale.set(.55 * unitsPerM, .05, .06);
          addWheel(3, -.35, top, .1);
        }
        const values = reevingGeo.attributes.position.array;
        rope.forEach((v, i) => { const q = mapped(v); values[i * 3] = q.x; values[i * 3 + 1] = q.y; values[i * 3 + 2] = q.z; });
        reevingGeo.setDrawRange(0, rope.length); reevingGeo.attributes.position.needsUpdate = true; reevingGeo.computeBoundingSphere();
        pivotLabel.visible = true; pivotLabel.el.textContent = `${n} 条承载绳段 · ${n}:1`; pivotLabel.point.copy(p).add(new THREE.Vector3(0, .38, 0));
      } else if (model === 'cam') {
        handle.visible = true; handle.position.copy(h); rod(lever, p, h, .045);
        // d is the distance to the vertical load line x=d. This is deliberately
        // not drawn as a manufactured cam outline or as a radial contact radius.
        const contactPoint = p.clone().add(new THREE.Vector3(result.effectiveArmM * unitsPerM, 0, 0));
        contact.visible = true; contact.position.copy(contactPoint);
        rod(cableA, contactPoint, contactPoint.clone().add(new THREE.Vector3(0, -.9, 0)));
        rod(momentArm, p, contactPoint, .02);
        rod(actionLine, contactPoint.clone().add(new THREE.Vector3(0, -.9, 0)), contactPoint.clone().add(new THREE.Vector3(0, .65, 0)), .009);
        if(current.baselineParams){
          const baseline=BM.Mechanics.atCoordinate('cam',current.baselineParams,result.angleRad);
          if(baseline.valid){const q=p.clone().add(new THREE.Vector3(baseline.effectiveArmM*unitsPerM,0,.012));
            const values=referenceGeo.attributes.position.array,points=[p,q,q.clone().add(new THREE.Vector3(0,-.9,0)),q.clone().add(new THREE.Vector3(0,.65,0))];
            points.forEach((v,i)=>{values[i*3]=v.x;values[i*3+1]=v.y;values[i*3+2]=v.z;});
            referenceGeo.attributes.position.needsUpdate=true;referenceGeo.computeBoundingSphere();referenceArm.computeLineDistances();referenceArm.visible=true;
          }
        }

        pivotLabel.visible = true; pivotLabel.el.textContent = 'O · 转轴'; pivotLabel.point.copy(p).add(new THREE.Vector3(-.4, .1, 0));
        armLabel.visible = true; armLabel.point.copy(p).lerp(contactPoint, .5).add(new THREE.Vector3(0, -.32, 0)); armLabel.el.textContent = `d⊥ ${(result.effectiveArmM * 100).toFixed(1)} cm`;
      } else {
        const theta = result.angleRad, t = new THREE.Vector3(Math.cos(theta), Math.sin(theta), 0);
        const start = mapped({ x: 0, y: 0, z: 0 }), end = start.clone().addScaledVector(t, result.params.travelM * unitsPerM);
        rod(trackA, start.clone().add(new THREE.Vector3(0, 0, -.2)), end.clone().add(new THREE.Vector3(0, 0, -.2)), .025);
        rod(trackB, start.clone().add(new THREE.Vector3(0, 0, .2)), end.clone().add(new THREE.Vector3(0, 0, .2)), .025);
        load.visible = true; load.position.copy(a); load.rotation.z = theta;
      }
      if (model !== 'pulley') {
        const origin = model === 'cam' ? p : overlayOffset;
        const angle = model === 'cam' ? result.angleRad : result.angleRad;
        const values = angleGeo.attributes.position.array;
        for (let i = 0; i <= 32; i++) { const theta = angle * i / 32; values[i * 3] = origin.x + .3 * Math.cos(theta); values[i * 3 + 1] = origin.y + .3 * Math.sin(theta); values[i * 3 + 2] = origin.z + .025; }
        angleGeo.attributes.position.needsUpdate = true; angleGeo.computeBoundingSphere(); angleArc.visible = true;
        thetaLabel.visible = true; thetaLabel.el.textContent = `θ ${(angle * 180 / Math.PI).toFixed(1)}°`; thetaLabel.point.copy(origin).add(new THREE.Vector3(.45, .35, .03));
      }
      const forces = result.forces || [], peak = Math.max(1, ...forces.map((f) => f.magnitudeN || 0));
      // Exactly one linear scale for every force in this state. The scale changes
      // only to fit the visible vectors, and is disclosed in the panel and DOM.
      forceScale = Math.min(.004, 1.45 / peak);
      forceArrows.forEach(({ arrow }) => { arrow.visible = false; });
      forces.forEach((force, i) => {
        const entry = ensureArrow(i), magnitude = Number(force.magnitudeN) || 0; entry.forceId = force.id;
        const color = /gravity|weight|cable/.test(force.id) ? colors.gravity : /normal|reaction/.test(force.id) ? colors.normal : /friction/.test(force.id) ? colors.friction : colors.external;
        entry.arrow.visible = current.view === 'force' && magnitude > 1e-8;
        const vector = asVector(force.vector), origin = mapped(force.origin);
        if (vector.lengthSq() > 1e-12) entry.arrow.setDirection(vector.normalize());
        entry.arrow.position.copy(origin); const length = magnitude * forceScale;
        entry.arrow.setLength(Math.max(.00001, length), Math.min(.12, length * .24), Math.min(.07, length * .14)); entry.arrow.setColor(color);
        entry.label.visible = entry.arrow.visible; entry.label.el.textContent = `${force.symbol || force.id} ${magnitude.toFixed(magnitude < 10 ? 1 : 0)} N`; entry.label.el.style.color = `#${color.toString(16).padStart(6, '0')}`;
        entry.label.point.copy(origin).addScaledVector(vector, length).add(new THREE.Vector3(0, .12 + (i % 2) * .15, i * .02));
      });
      objectLabel.visible = false; // Analysis body is already identified in the adjacent accessible caption. objectLabel.el.textContent = model === 'incline' ? '分析对象：滑车' : model === 'cam' ? '分析对象：绕 O 转动的理想传动' : '分析对象：理想传动手柄'; objectLabel.point.copy(a).add(new THREE.Vector3(0, -.45, 0));
      forceLayer.visible = current.view === 'force'; annotation.visible = current.view !== 'physical';
      focusStyles();
      const target = model === 'cam' ? handle : model === 'incline' ? load : handle;
      dragHandles.length = 0; dragProxy.visible = true; dragProxy.position.copy(target.position);
      dragProxy.userData.dragScene = modelScene[model]; dragProxy.userData.dragControl = 'engineering'; dragProxy.userData.dragTarget = target; dragProxy.userData.engineeringDrag = true; dragHandles.push(dragProxy);
      canvas.dataset.engineeringState = JSON.stringify({ model, progress: current.progress, angleRad: result.angleRad, displacementM: result.displacementM, effectiveArmM: result.effectiveArmM, torqueNm: result.torqueNm, forceN: result.forceN, view: current.view, focus: current.focus, valid: result.valid, forceScale, unitsPerM, source: result.version || BM.Mechanics?.version || 'mechanics-core', vectors: forces.map((f) => ({ id: f.id, origin: f.origin, vector: f.vector, magnitudeN: f.magnitudeN, displayedLength: f.magnitudeN * forceScale })) });
      canvas.dataset.engineeringForceScale = `${forceScale.toPrecision(4)} scene-unit/N`;
      requestDraw(); projectLabels();
    }
    function projectLabels() {
      if (!active || !current) return;
      const rect = canvas.getBoundingClientRect();
      camera.updateMatrixWorld();
      const targets = (current.view === 'physical' ? [rigs[current.model].parts.actionHit] : dragHandles).filter(Boolean).map((mesh) => {
        const target = mesh.userData.dragTarget || mesh; target.updateWorldMatrix(true, false);
        const position = target.getWorldPosition(new THREE.Vector3()).project(camera);
        return { role: current.model === 'incline' ? 'sled' : 'handle', x: +(rect.left + (position.x + 1) * .5 * rect.width).toFixed(2), y: +(rect.top + (1 - position.y) * .5 * rect.height).toFixed(2), inView: position.z > -1 && position.z < 1 && Math.abs(position.x) < 1 && Math.abs(position.y) < 1 };
      });
      canvas.dataset.engineeringTargets = JSON.stringify(targets);
      canvas.dataset.engineeringCamera = JSON.stringify({ position: camera.position.toArray(), target: controls.target.toArray(), autoRotate: controls.autoRotate });
      if (!overlay.visible) return;
      labels.forEach((entry) => {
        const projected = entry.point.clone().project(camera);
        const visible = entry.visible && projected.z > -1 && projected.z < 1 && Math.abs(projected.x) < .96 && Math.abs(projected.y) < .96;
        entry.el.hidden = !visible; if (!visible) return;
        entry.el.style.left = `${(projected.x + 1) * .5 * rect.width}px`; entry.el.style.top = `${(1 - projected.y) * .5 * rect.height}px`;
      });
    }
    function set(state) {
      const model = modelScene[state?.model] ? state.model : 'cam';
      const next = { model, params: { ...(state.params || {}) }, progress: Math.max(0, Math.min(1, Number(state.progress) || 0)), view: ['physical', 'mechanism', 'force'].includes(state.view) ? state.view : 'physical', focus: ['F', 'd', 'theta'].includes(state.focus) ? state.focus : null, baselineParams: state.baselineParams ? {...state.baselineParams} : null };
      const changedModel = !active || current?.model !== model, changedView = current?.view !== next.view;
      if (!active) { snapshot = activate(modelScene[model], false); Object.values(rigs).forEach(cacheRig); active = true; }
      else if (changedModel) activate(modelScene[model], false);
      current = next; result = evaluate(model, next.params, next.progress);
      const key = JSON.stringify([model, next.params, next.progress, next.view, next.focus, next.baselineParams]);
      if (key === lastStateKey && !changedModel) return result;
      lastStateKey = key;
      configureGeometry(); if (changedModel || changedView) applyMaterials(changedView);
      if (changedModel) { requestResize(true); requestAnimationFrame(() => { if (active) requestResize(true); }); }
      return result;
    }
    function setProgress(progress, notify = true) { if (!active || !current) return; set({ ...current, progress }); if (notify) emitProgress(); }
    function emitProgress() {
      if (!active || !current || Math.abs(current.progress - lastProgressEvent) < 1e-7) return;
      lastProgressEvent = current.progress;
      const detail = { model: current.model, progress: current.progress, source: '3d-model' };
      subscribers.forEach((callback) => callback(detail.progress, detail));
      document.dispatchEvent(new CustomEvent('bm:engineering-progress', { detail }));
    }
    function release() {
      if (!active) { queued = null; return; }
      active = false; overlay.visible = false; labelRoot.style.display = 'none';
      restoreNodes(); current = null; result = null; selectedMeshes.clear(); dragHandles.length = 0; lastStateKey = ''; lastProgressEvent = -1;
      delete canvas.dataset.engineeringState; delete canvas.dataset.engineeringForceScale; delete canvas.dataset.engineeringTargets; delete canvas.dataset.engineeringCamera; delete canvas.dataset.engineeringRenderFlags; delete canvas.dataset.engineeringRenderState; delete canvas.dataset.engineeringRenderCount;
      restore(snapshot); snapshot = null;
    }
    function selectPart(mesh) {
      if (!active || !current) return;
      selection = mesh;
      // A selected real transmission part reveals its whole connected path.
      applyMaterials(false); requestDraw();
      document.dispatchEvent(new CustomEvent('bm:engineering-part', { detail: { model: current.model, part: mesh?.name || '传动路径', path: current.model === 'pulley' ? '配重—钢索—滑轮—手柄' : current.model === 'cam' ? '配重—钢索—凸轮轴—转臂' : '装片—滑车—脚踏板—导轨' } }));
    }
    const api = { ready: true, set, release, onProgress(callback) { subscribers.add(callback); return () => subscribers.delete(callback); },
      isActive: () => active, getModel: () => current?.model, getScene: () => current ? modelScene[current.model] : null, getProgress: () => current?.progress || 0,
      getMotionEnvelope() {
        if (!current || !result?.valid) return [];
        const points = [];
        for (let i = 0; i <= 16; i++) { const row = evaluate(current.model, current.params, i / 16); if (!row.valid) continue; ['handle', 'load', 'pivot'].forEach((key) => { if (row.position[key]) points.push(mapped(row.position[key])); }); }
        return points;
      },
      getDragHandles: () => !current || !result?.valid ? [] : current.view === 'physical' ? [rigs[current.model].parts.actionHit].filter(Boolean) : dragHandles, getRenderFlags: () => ({ overlay: overlay.visible, parent: overlay.parent?.type, structure: structure.visible, forceLayer: forceLayer.visible, forceOrigin: forceArrows[0]?.arrow.position.toArray(), arrowProjection: forceArrows[0]?.arrow.getWorldPosition(new THREE.Vector3()).project(camera).toArray(), visibleArrows: forceArrows.filter((item) => item.arrow.visible).length, labels: labels.filter((item) => item.visible).length }), getFitGroup: () => overlay, getPartMeshes: () => current ? [...selectedPath] : [], setProgress, emitProgress, projectLabels, selectPart,
      flushPending() { if (queued) { const pending = queued; queued = null; set(pending); } } };
    BM.engineering3D = api;
    queueMicrotask(() => document.dispatchEvent(new CustomEvent('bm:engineering-3d-ready')));
    return api;
  };
})(window);
