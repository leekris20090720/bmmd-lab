/* Interactive engineering workspace. Experiments never read or write training records. */
(() => {
  'use strict';
  const B=window.BM,M=B.Mechanics;
  if(!M||B.engineering)return;
  const $=(s)=>document.querySelector(s),esc=(v)=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const copy=v=>JSON.parse(JSON.stringify(v)),clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
  const paintText=(ctx,label,...args)=>ctx.fillText(B.i18n?.t(label)??label,...args);
  const fmt=(v,n=2)=>Number.isFinite(v)?v.toFixed(n):'不可计算';
  const names={pulley:'钢索滑轮',cam:'理想有效力臂传动',incline:'斜面滑车'};
  const sources={'model-example':'模型示例','user-measured':'用户测量','manufacturer':'厂家资料','assumed-range':'假设范围','unknown':'未知'};
  const tabs=[['observe','观察与函数'],['design','阻力曲线设计'],['calculus','导数与积分'],['energy','摩擦与能量'],['analysis','敏感性与范围'],['tasks','先预测，再验证'],['spring','弹簧与阻尼'],['archive','建模档案']];
  const palette={external:'#257bd6',cable:'#d97440',reaction:'#8771d5',gravity:'#d97440',normal:'#8771d5',friction:'#c19324',d:'#22a79b'};
  const storageKey='bmmd_mechanics_snapshots_v1';
  const bank=Object.fromEntries(Object.keys(names).map(k=>[k,{...copy(M.defaults[k]),sources:Object.fromEntries(Object.keys(M.defaults[k]).map(p=>[p,'model-example']))}]));
  const baselines=copy(bank),targets={},state={model:'cam',panel:'observe',view:'mechanism',medium:'model',progress:.35,quantity:'torqueNm',focus:null,range:[0,1],segments:16,method:'trapezoid',compare:[.25,.75],sensitivityKey:'eccentricity',fraction:.1,uncertaintyWidth:.1,uncertaintySource:'assumed-range',playing:false,trajectory:false,note:'',origin:'library',spring:{mass:1,stiffness:40,damping:8},prediction:null,taskBefore:null,taskAfter:null,search:null,tabFocus:false,scrollPanel:false};
  const root=document.createElement('section');root.id='engineering-root';root.hidden=true;root.setAttribute('aria-label','力学与数学实验室');document.body.append(root);
  let active=false,params=bank.cam,result=null,samples=[],baselineSamples=[],frame=0,playFrame=0,springFrame=0,playStart=0,searchController=null,drag=null,controller=null,twin=null,placeholder=null,diagramContext=null,plotScale=null,heatmapScale=null,springStarted=0,dirtyCurve=true,readyRetry=null;
  let pendingLesson=null,teachingContext=null;
  const media=matchMedia('(prefers-reduced-motion: reduce)');

  const button=(text,action,extra='',cls='')=>`<button type="button" class="${cls}" data-eng="${action}" ${extra}>${text}</button>`;
  const field=(key,label,min,max,step,value,unit='')=>`<label>${label} ${unit}<input aria-label="${esc(label)} ${esc(unit)}" type="range" data-control="${key}" min="${min}" max="${max}" step="${step}" value="${value}"><input aria-label="${label}数值" type="number" data-control="${key}" min="${min}" max="${max}" step="${step}" value="${value}"></label>`;
  function axis(r){return state.model==='cam'?r.angleRad:r.displacementM;}
  function axisLabel(r){return state.model==='cam'?`${fmt(r.angleRad*180/Math.PI,1)}°`:`${fmt(r.displacementM,3)} m`;}
  function coordinateLabel(value,n=2){return state.model==='cam'?`${fmt(value*180/Math.PI,n)}°`:`${fmt(value,n)} m`;}
  function plotValue(r){return state.panel==='calculus'&&state.model==='incline'&&r.params.direction==='down'?-r[state.quantity]:r[state.quantity];}
  function currentUnit(){return state.quantity==='torqueNm'?'N·m':'N';}
  function status(text){const el=root.querySelector('#eng-live-status');if(el)el.textContent=text;}
  function legalKey(){return M.schema[state.model].find(p=>p.key===state.sensitivityKey&&p.kind!=='select')?.key||M.schema[state.model].find(p=>p.kind!=='select').key;}
  function sourceOptions(value){return Object.entries(sources).map(([k,v])=>`<option value="${k}" ${k===value?'selected':''}>${v}</option>`).join('');}
  function parameterRow(s){
    const rad=s.unit==='rad',value=rad?params[s.key]*180/Math.PI:params[s.key],min=rad?s.min*180/Math.PI:s.min,max=rad?s.max*180/Math.PI:s.max,step=rad?.5:s.step;
    const id='eng-param-'+s.key,unit=rad?'°':s.unit;
    return `<div class="eng-field"><div class="eng-field-top"><label for="${id}">${esc(s.label)} ${esc(unit)}</label><span class="eng-muted" data-param-readout="${s.key}">${typeof value==='number'?fmt(value,rad?1:s.step<.1?3:0):value==='up'?'推起':'下放'}</span></div>${s.kind==='select'?`<select id="${id}" data-param="${s.key}">${s.options.map(v=>`<option value="${v}" ${v===params[s.key]?'selected':''}>${v==='up'?'推起':v==='down'?'受控下放':v+':1'}</option>`).join('')}</select>`:`<div class="eng-inputs"><input id="${id}" aria-label="${esc(s.label)}" data-param="${s.key}" data-display-rad="${rad}" type="range" min="${min}" max="${max}" step="${step}" value="${value}"><input aria-label="${esc(s.label)}数值 ${esc(unit)}" data-param="${s.key}" data-display-rad="${rad}" type="number" min="${min}" max="${max}" step="${step}" value="${fmt(value,rad?2:4)}"></div>`}</div>`;
  }
  function studyParameters(){
    const primary={cam:'baseArmM',pulley:'ratio',incline:'friction'}[state.model];
    const visible=s=>s.key===primary||(state.model==='incline'&&s.key==='direction');
    return `<h2>改变一个条件</h2><p class="eng-muted">${B.Didactics?.h(state.model+'Task')||''}</p><div class="eng-parameter-fields">${M.schema[state.model].filter(visible).map(parameterRow).join('')}</div><details class="did-more-parameters"><summary>${B.Didactics?.h('more')||'更多参数'}</summary><div class="eng-parameter-fields">${M.schema[state.model].filter(s=>!visible(s)).map(parameterRow).join('')}</div><details><summary>输入来源与假设</summary><p class="eng-chart-note">默认均为模型示例；只有有依据时才选择测量或厂家资料。</p>${M.schema[state.model].map(s=>`<label class="eng-source">${esc(s.label)}<select aria-label="${esc(s.label)}来源" data-source="${s.key}">${sourceOptions(params.sources[s.key])}</select></label>`).join('')}</details></details><div class="eng-actions">${button('固定为比较基准','baseline')}${button('恢复模型示例','reset-model')}</div>`;
  }
  function renderShell(){
    root.dataset.medium=state.medium;
    root.innerHTML=`<div class="eng-shell"><header class="eng-top"><a class="eng-brand" href="#home">BM//MD</a><small>ENGINEERING LAB · 模型 ${M.VERSION||M.version}</small>${button('← '+(state.origin.startsWith('action/')?'返回动作教学':({training:'返回训练',home:'返回首页',plans:'返回计划',history:'返回训练记录',data:'返回数据备份',sphere:'返回立体导图',wizard:'返回新手引导'})[state.origin]||'返回动作库'),'back','','eng-back')}${button('保存 / 建模档案','archive','','eng-archive-link')}</header><header class="eng-heading"><div><p class="eng-kicker">观察 → 建模 → 预测 → 验证 → 设计</p><h1 tabindex="-1">力学与数学实验室</h1><p class="eng-muted">以器械为研究对象，让结构、受力与函数说同一件事。</p></div><small>模型验证 · 无实物测量数据</small></header><nav class="eng-models" aria-label="实验模型">${Object.entries(names).map(([k,v])=>button(`<strong>${v}</strong><small>${k==='pulley'?'力与位移互换':k==='cam'?'有效力臂与曲线设计':'摩擦、方向与机械功'}</small>`,'model',`data-model="${k}" aria-pressed="${state.model===k}"`)).join('')}</nav>${B.Didactics?.labHeader(state.model)||''}${teachingContext?`<p class="did-context" data-i18n-skip>${B.i18n?.getLanguage()==='en'?'From this lesson: ':'从当前教学带入：'}${esc(teachingContext.question[B.i18n?.getLanguage()==='en'?1:0])} · ${B.i18n?.getLanguage()==='en'?'Model examples; not machine measurements or training loads.':'模型示例，非实物测量或训练负荷。'}</p>`:''}<div class="eng-stage-grid"><section class="eng-stage" aria-label="工程观察视图"><div class="eng-stage-toolbar"><div class="eng-segment" role="group" aria-label="工程视图">${[['physical','实物'],['mechanism','机构'],['force','受力']].map(([k,v])=>button(v,'view',`data-view="${k}" aria-pressed="${state.view===k}"`)).join('')}</div><div class="eng-segment" role="group" aria-label="显示方式">${button('3D','medium','data-medium="model" aria-pressed="'+(state.medium==='model')+'"')}${button('2D 图','medium','data-medium="diagram" aria-pressed="'+(state.medium==='diagram')+'"')}</div></div><div class="eng-stage-content"><div id="eng-model-slot"></div><canvas id="eng-diagram" aria-label="当前分析对象的机构和受力图；详细数值见下方列表"></canvas></div><div class="eng-stage-caption"><strong id="eng-analysis-body"></strong><br><span id="eng-part-description">实物作识别参考；彩色分析为理想机构，尺寸未标定。拖彩色手柄定位；空白处旋转相机。</span>${state.model==='cam'?'<br><small>外壳限制在教学行程；彩色理想机构使用当前实验角度。</small>':''}<br><span id="eng-force-scale">受力箭头同一线性比例随本帧最大力适配，大小以 N 读数为准。</span></div></section><section class="eng-parameters">${studyParameters()}</section></div><details class="did-detailed-readouts"><summary>${B.Didactics.h('fullReadouts')}</summary><div class="eng-readouts"><article><small>当前 ${state.model==='cam'?'角度 θ':'实际行程 x'}</small><strong id="eng-read-position">—</strong></article><article><small>手柄 / 沿轨道外力 F</small><strong id="eng-read-force">—</strong></article><article><small>阻力矩 τ</small><strong id="eng-read-torque">—</strong></article><article><small>${state.model==='cam'?'垂直力臂 d':'已做机械功 W'}</small><strong id="eng-read-extra">—</strong></article></div></details><div class="eng-position"><label for="eng-progress">当前姿态</label><input type="range" id="eng-progress" min="0" max="100" step=".1" value="${state.progress*100}" aria-label="当前姿态进度"><input type="number" id="eng-progress-number" min="0" max="100" step=".1" value="${fmt(state.progress*100,1)}" aria-label="当前姿态进度百分比">${button('播放规定轨迹','play')}${button(B.Didactics?.h('singleStep')||'单步 +5% 行程','step')}${button(B.Didactics?.h('resetPose')||'重置姿态','reset-pose')}${button(B.Didactics?.h('restoreBaseline')||'恢复比较基准','restore-baseline')}</div>${B.Didactics?.labResults()||''}<details id="did-formula-details" class="did-formula-details"><summary>${B.Didactics?.h('formula')||'查看公式解释'}</summary><p>${B.Didactics?.h('formulaNote')||''}</p><div class="eng-formula" id="eng-formula"></div></details><div class="eng-legend"><span style="--legend-color:#257bd6">F 外力</span><span style="--legend-color:#d97440">T / mg 钢索或重力</span><span style="--legend-color:#8771d5">N / R 支承或反力</span><span style="--legend-color:#c19324">f 摩擦</span><span style="--legend-color:#22a79b">d 垂直力臂</span></div><div id="eng-live-status" role="status" aria-live="polite"></div><details id="did-research-details" ${state.panel!=='observe'?'open':''}><summary>${B.Didactics?.h('further')||'进一步研究'}</summary><nav class="eng-tabs" role="tablist" aria-label="实验内容">${tabs.map(([k,v])=>button(v,'panel',`role="tab" data-panel="${k}" aria-selected="${state.panel===k}" aria-controls="eng-panel" id="eng-tab-${k}" tabindex="${state.panel===k?0:-1}"`)).join('')}</nav></details><section class="eng-panel" id="eng-panel" role="tabpanel" aria-labelledby="eng-tab-${state.panel}"></section></div>`;
    if(twin)root.querySelector('#eng-model-slot').append(twin);
    diagramContext=root.querySelector('#eng-diagram').getContext('2d');
    renderFormula();renderPanel();dirtyCurve=true;recalculate(true);B.textFx?.scan(root);
    B.Didactics?.bindLab({root,read:()=>({model:state.model,params,baseline:baselines[state.model],progress:state.progress,result})});
  }
  function renderFormula(){
    const variable=(text,key)=>button(text,'focus',`data-focus="${key}" aria-pressed="${state.focus===key}"`,'eng-var-'+key);
    $('#eng-formula').innerHTML=state.model==='cam'?`τ = ${variable('F','F')} · d = mg · ${variable('d(θ)','d')} ; d(${variable('θ','theta')}) = r₀ [1 + k sin(θ + φ)]`:
      state.model==='pulley'?`${variable('F','F')} = mg / n ; x负载 = x手柄 / n`:`${variable('F↑ / F↓','F')} = mg sin(${variable('β','theta')}) ± μmg cosβ`;
  }
  function chartMarkup(id='eng-curve'){return `<svg id="${id}" class="eng-chart" viewBox="0 0 820 330" role="img" aria-label="${id==='eng-spring-chart'?'归一化弹簧位移随演示时间变化的曲线':'来自当前模型的阻力曲线'}"></svg>`;}
  function quantityControl(){return `<label>曲线物理量<select aria-label="曲线物理量" data-control="quantity"><option value="forceN" ${state.quantity==='forceN'?'selected':''}>手柄 / 沿轨道外力 · N</option><option value="torqueNm" ${state.quantity==='torqueNm'?'selected':''}>绕所选轴的阻力矩 · N·m</option></select></label>`;}
  function renderPanel(){
    cancelAnimationFrame(springFrame);springFrame=0;
    const p=$('#eng-panel');p.setAttribute('aria-labelledby','eng-tab-'+state.panel);
    if(state.panel==='observe')p.innerHTML=`<div class="eng-panel-grid"><div><h2>同一姿态，同一个曲线点。</h2><p class="eng-panel-copy">拖动曲线定位模型，或拖动模型看点移动。虚线是固定比较基准。</p>${chartMarkup()}<p class="eng-chart-note" id="eng-extrema"></p></div><div class="eng-controls">${quantityControl()}<div class="eng-two">${field('compareA','比较位置 A',0,100,.5,state.compare[0]*100,'%')}${field('compareB','比较位置 B',0,100,.5,state.compare[1]*100,'%')}</div><div id="eng-comparison"></div><details><summary>当前自由体图与假设</summary><div id="eng-assumptions"></div></details><label><input type="checkbox" data-control="trajectory" ${state.trajectory?'checked':''}> 显示等时间位置标记（2D 图）</label><p class="eng-chart-note">规定轨迹 p(t)=(1−cos(2πt/6))/2；标记每 0.3 s。只是运动学示意，播放速度不改变准静态受力。</p></div></div>`;
    if(state.panel==='design')p.innerHTML=`<div class="eng-panel-grid"><div><h2>让阻力接近一条目标曲线。</h2><p class="eng-panel-copy">蓝色是预测，灰色虚线是固定基准，橙色虚线是“模型目标”。拖橙色控制点，或输入目标数值。</p>${chartMarkup()}<p class="eng-chart-note">目标只定义所选物理量；不会自动成为可制造凸轮轮廓。</p></div><div class="eng-controls">${quantityControl()}<label>模型目标<select aria-label="模型目标" data-control="target-preset"><option value="constant">近似恒定</option><option value="middle">中段较大</option><option value="late">末段较大</option><option value="custom">自定义控制点</option></select></label><div id="eng-target-fields"></div><div class="eng-actions">${button('搜索更接近的参数','search','','eng-primary')}${button('取消搜索','cancel-search','disabled')}</div><div class="eng-message" id="eng-search-result">采用有界网格搜索，以无量纲归一化 RMSE 比较；不承诺全局最优。无法实现时保留剩余误差。</div><details><summary>约束与误差定义</summary><p>RMSE = √mean((预测−目标)²) / max(目标均方根,1 SI单位)。所有采样等间隔于所显示的角度 / 位移。搜索只比较合法参数族，不加入任意轮廓、接触或制造假设。</p><div id="eng-search-constraints"></div></details></div></div>`;
    if(state.panel==='calculus'){
      state.quantity=state.model==='cam'?'torqueNm':'forceN';
      p.innerHTML=`<div class="eng-panel-grid"><div><h2>斜率说明变化，面积解释做功。</h2><p class="eng-panel-copy">${state.model==='cam'?'积分对象是所选传动的正向阻力矩 τ(θ)，不是所有力矩的净和。内部角度为 rad。':'积分对象是手柄 / 滑车外力沿实际运动方向的分量，位移使用 m。'}</p>${chartMarkup()}<div class="eng-mini-stats"><article>当前数值变化率<strong id="eng-derivative">—</strong></article><article>当前区间机械功<strong id="eng-integral">—</strong></article><article>与细分参考的差<strong id="eng-integration-error">—</strong></article></div><p class="eng-chart-note">曲线更陡表示阻力随位置变化更快；它不是角速度 dθ/dt，也不是角加速度。</p></div><div class="eng-controls">${field('rangeA','积分起点 A',0,100,.5,state.range[0]*100,'%行程')}${field('rangeB','积分终点 B',0,100,.5,state.range[1]*100,'%行程')}<label>分割数<select aria-label="分割数" data-control="segments">${[4,8,16,32,64,128].map(n=>`<option ${state.segments===n?'selected':''}>${n}</option>`).join('')}</select></label><label>数值积分方法<select aria-label="数值积分方法" data-control="method"><option value="left" ${state.method==='left'?'selected':''}>左矩形</option><option value="midpoint" ${state.method==='midpoint'?'selected':''}>中点矩形</option><option value="trapezoid" ${state.method==='trapezoid'?'selected':''}>梯形</option></select></label><div class="eng-message" id="eng-integral-info"></div><div id="eng-convergence"></div><details><summary>导数与正负方向</summary><p>内点中心差分，端点二阶单边差分。${state.model==='cam'?'显示 dτ/dθ，单位 N·m/rad；正转角为正做功方向。':'显示 dF/dx，单位 N/m；下放外力沿上坡取正，而运动向下，外力功可为负。'} 区间反选时有向积分反号。机械功不等于人体代谢能量。</p></details></div></div>`;
    }
    if(state.panel==='energy'&&state.model==='incline')state.quantity='forceN';
    if(state.panel==='energy')p.innerHTML=state.model!=='incline'?`<h2>摩擦与能量：先把问题放在滑车上。</h2><p class="eng-panel-copy">斜面滑车允许同时改变总质量、倾角、动摩擦系数和真实轨道行程。</p>${button('切换到斜面摩擦实验','model','data-model="incline"','eng-primary')}`:`<div class="eng-panel-grid"><div><h2>同一位置，推起和下放为何不同？</h2><p class="eng-panel-copy">准静态；忽略加速度。外力沿上坡为正，下放的外力可以为负。</p>${chartMarkup()}<div class="eng-mini-stats"><article>推起外力<strong id="eng-up-force">—</strong></article><article>下放外力<strong id="eng-down-force">—</strong></article><article>完整往返耗散<strong id="eng-cycle-loss">—</strong></article></div><div id="eng-energy-table"></div></div><div class="eng-controls"><div class="eng-message" id="eng-friction-notice"></div>${button('把摩擦调到零，检验预测','zero-friction','','eng-primary')}<p>观察两条外力线逐渐重合，摩擦耗散趋近零。支持力与沿轨道重力仍由倾角决定。</p><details><summary>功与能量账本</summary><p>W外 = ΔU + E耗散，ΔK=0；E耗散 = μmg cosβ · 实际已走行程。完整往返势能净变化为0，外力总功为2fL。恒速是规定条件，不是自由滑下求解。</p></details></div></div>`;
    if(state.panel==='analysis')p.innerHTML=`<div class="eng-panel-grid"><div><h2>哪些条件会改变结果？</h2><p class="eng-panel-copy">每次只改变一个输入。范围带来自有界输入网格传播，不是统计置信区间。</p>${chartMarkup()}<p class="eng-chart-note" id="eng-sensitivity-info"></p><div id="eng-sensitivity-table"></div><h3>二维参数图</h3><canvas id="eng-heatmap" width="820" height="250" aria-label="横轴姿态、纵轴所选设计参数、颜色为模型阻力；也可用参数与姿态数值框操作"></canvas><p id="eng-heatmap-legend" class="eng-chart-note"></p></div><div class="eng-controls">${quantityControl()}<label>每次改变的参数<select aria-label="每次改变的参数" data-control="sensitivityKey">${M.schema[state.model].filter(s=>s.kind!=='select').map(s=>`<option value="${s.key}" ${s.key===legalKey()?'selected':''}>${esc(s.label)} (${s.unit||'无量纲'})</option>`).join('')}</select></label>${field('fraction','比较改变量',1,30,1,state.fraction*100,'%基准')}<label>输入范围来源<select aria-label="输入范围来源" data-control="uncertaintySource">${sourceOptions(state.uncertaintySource)}</select></label>${field('uncertaintyWidth','范围半宽',0,40,1,state.uncertaintyWidth*100,'%基准')}<div class="eng-message" id="eng-uncertainty-info"></div><p class="eng-chart-note">比较不同单位使用无量纲变化率；基准为0时采用已说明的参考尺度。采样峰值不称为精确极值。</p></div></div>`;
    if(state.panel==='tasks')renderTaskPanel(p);
    if(state.panel==='spring')p.innerHTML=`<div class="eng-panel-grid"><div><h2>回弹为何有时快，有时会振荡？</h2><p class="eng-panel-copy">独立的归一化弹簧演示：m x″ + c x′ + k x = 0，x(0)=1，v(0)=0。它不改变正常导航的固定舒适参数。</p>${chartMarkup('eng-spring-chart')}<div class="eng-mini-stats"><article>位移 x<strong id="eng-spring-x">1.000</strong></article><article>阻尼比 ζ<strong id="eng-spring-zeta">—</strong></article><article>响应类型<strong id="eng-spring-regime">—</strong></article></div></div><div class="eng-controls">${field('spring-mass','质量 m',.2,5,.1,state.spring.mass,'归一化')}${field('spring-stiffness','刚度 k',1,300,1,state.spring.stiffness,'归一化')}${field('spring-damping','阻尼 c',0,60,.5,state.spring.damping,'归一化')}${field('spring-time','观察时间',0,6,.01,0,'s（演示）')}<div class="eng-actions">${button('释放一次','spring-play','','eng-primary')}${button('接近标题的固定响应','spring-title')}</div><div class="eng-message">曲线来自阻尼振子解析解；m、c、k 为演示单位，不是器械材料参数。标题仍使用原固定离散回弹：参考步长 1/60 的等效 m=1、k=235.62、c=13.8。</div></div></div>`;
    if(state.panel==='archive')renderArchive(p);
    if(state.panel==='design'){renderTargetFields();syncTargetPreset();const savedSearch=activeSearch();if(savedSearch)$('#eng-search-result').textContent=searchSummary(savedSearch);$('#eng-search-constraints').textContent=({cam:'仅枚举 r₀、k、φ；负载、手柄臂长和角度范围固定。',pulley:'仅枚举传动比1、2、4；负载与行程固定。',incline:'仅枚举倾角与摩擦系数；总质量、行程和方向固定。'})[state.model]+' 合法参数范围：'+JSON.stringify(M.bounds[state.model]);}
    if(state.panel==='calculus')p.insertAdjacentHTML('afterbegin',`<div class="did-math-story" data-i18n-skip><p>${B.Didactics.h('derivativeDef')}</p><p>${B.Didactics.h('integralDef')}</p><label>${B.Didactics.h('gap')}<input aria-label="${B.Didactics.txt('gap')}" data-did-label="gap" type="range" data-control="secant-gap" min=".002" max=".3" step=".002" value="${state.secantGap||.12}"></label><p id="did-math-reading"></p></div>`);
    if(state.panel==='spring')drawSpring(0);
    dirtyCurve=true;
  }

  function ensureTarget(reset=false,preset='constant'){
    const key=state.model+':'+state.quantity;
    if(!targets[key]||reset){const peak=Math.max(1,...M.sample(state.model,baselines[state.model],121).map(s=>Math.abs(s[state.quantity])));targets[key]=[0,.33,.67,1].map(p=>({progress:p,value:peak*(preset==='middle'?.65+.35*Math.sin(p*Math.PI):preset==='late'?.55+.55*p:.8)}));}
    return targets[key];
  }
  function syncTargetPreset(){const el=root.querySelector('[data-control=target-preset]');if(!el)return;const target=ensureTarget(),peak=Math.max(1,...M.sample(state.model,baselines[state.model],121).map(s=>Math.abs(s[state.quantity])));el.value=['constant','middle','late'].find(kind=>target.every(p=>Math.abs(p.value-peak*(kind==='middle'?.65+.35*Math.sin(p.progress*Math.PI):kind==='late'?.55+.55*p.progress:.8))<1e-6))||'custom';}
  function activeSearch(){const s=state.search;return s&&s.model===state.model&&s.quantity===state.quantity&&Object.keys(M.defaults[state.model]).every(k=>s.bestParams?.[k]===params[k])&&(!s.searchInput?.target||JSON.stringify(s.searchInput.target)===JSON.stringify(ensureTarget()))?s:null;}
  function searchSummary(s){return `有界网格搜索（61个姿态采样）比较 ${s.evaluated} 个组合；归一化 RMSE ${fmt(s.beforeError*100,2)}% → ${fmt(s.afterError*100,2)}%。剩余误差 ${fmt(s.afterError*100,2)}%。${s.afterError>.02?'当前参数族不能准确实现这个目标；不会伪造完美匹配。':'仅为已搜索网格中的接近结果。'}不承诺全局最优。`;}
  function renderTargetFields(){const t=ensureTarget();$('#eng-target-fields').innerHTML=`<div class="eng-two">${t.map((p,i)=>`<label>目标点 ${i+1} (${Math.round(p.progress*100)}%)<input type="number" data-target="${i}" min="-50000" max="50000" step=".1" value="${fmt(p.value,1)}" aria-label="目标点${i+1} ${currentUnit()}"></label>`).join('')}</div>`;}
  function plotData(){
    let envelope=null,extra=[],sensitivity=null;
    if(state.panel==='analysis'){
      const key=legalKey(),base=params[key],bounds=M.bounds[state.model][key],delta=Math.max(Math.abs(base), (bounds[1]-bounds[0])*.05)*state.uncertaintyWidth;
      const range=[clamp(base-delta,...bounds),clamp(base+delta,...bounds)];
      const uncertainty=M.uncertainty(state.model,params,key,...range,121,state.quantity,17);
      envelope=uncertainty.valid?uncertainty.envelope:null;
      const sens=M.sensitivity(state.model,params,key,state.fraction,121,state.quantity,state.range);
      sensitivity=sens;
      extra=[{samples:sens.low,color:'#7e78b3',dash:'4 4'},{samples:sens.high,color:'#2f9b96',dash:'4 4'}];
      $('#eng-uncertainty-info').textContent=`输入范围 ${fmt(range[0],4)} 至 ${fmt(range[1],4)} ${M.units[key]||''}。17 个有界参数值传播；${uncertainty.valid?`仅在所有输入共同物理域 ${coordinateLabel(uncertainty.commonDomain[0])} 至 ${coordinateLabel(uncertainty.commonDomain[1])} 绘制包络。`:uncertainty.reasons.join(' ')}有限网格范围不是95%置信区间。`;
      const sum=sens.summaries;
      const domain=M.coordinateDomain(state.model,params),comparableError=key=>M.normalizedRMSE(sens.comparisonSamples[key].map(row=>({...row,progress:(axis(row)-domain.min)/(domain.max-domain.min)})),ensureTarget(),state.quantity);
      $('#eng-sensitivity-table').innerHTML=`<div class="eng-table-wrap"><table><thead><tr><th>条件</th><th>采样峰值 ${currentUnit()}</th><th>峰值物理坐标</th><th>共同区间功 J</th><th>共同域目标误差</th></tr></thead><tbody>${[['较低',sum.low,'low'],['当前',sum.baseline,'baseline'],['较高',sum.high,'high']].map(([n,s,k])=>`<tr><td>${n}</td><td>${fmt(s.sampledPeak)}</td><td>${coordinateLabel(s.peakCoordinate)}</td><td>${fmt(s.workJ)}</td><td>${fmt(comparableError(k)*100,2)}%</td></tr>`).join('')}</tbody></table></div>`;
    }
    if(state.panel==='energy'&&state.model==='incline'){
      extra=[{samples:M.sample('incline',{...params,direction:params.direction==='up'?'down':'up'},121),color:'#d97440',dash:'5 4'}];
    }
    return {envelope,extra,sensitivity};
  }
  function drawPlot(){
    const svg=$('#eng-curve');if(!svg||!result?.valid)return;
    const {envelope,extra,sensitivity}=plotData(),target=state.panel==='design'?ensureTarget():null;
    const values=[...samples,...baselineSamples,...extra.flatMap(e=>e.samples)].map(plotValue);if(target)values.push(...target.map(t=>t.value));if(envelope)envelope.forEach(e=>values.push(e.min,e.max));
    let low=Math.min(0,...values),high=Math.max(1,...values);const pad=(high-low)*.12;high+=pad;if(low<0)low-=pad;
    const currentDomain=M.coordinateDomain(state.model,params),coordinates=[...samples,...baselineSamples,...extra.flatMap(e=>e.samples)].map(axis);if(envelope)coordinates.push(...envelope.map(e=>e.coordinate));
    const axisMin=Math.min(...coordinates),axisMax=Math.max(...coordinates),axisSpan=Math.max(1e-12,axisMax-axisMin);
    const sxCoordinate=value=>58+(value-axisMin)/axisSpan*730,sx=p=>sxCoordinate(currentDomain.min+p*(currentDomain.max-currentDomain.min)),sy=v=>278-(v-low)/(high-low)*234;
    plotScale={sx,sxCoordinate,sy,low,high,left:58,right:788,top:44,bottom:278,axisMin,axisMax,currentDomain,sensitivity};
    svg.dataset.physicalDomain=JSON.stringify({min:axisMin,max:axisMax,unit:currentDomain.unit,currentMin:currentDomain.min,currentMax:currentDomain.max});
    const path=arr=>arr.map((s,i)=>`${i?'L':'M'}${fmt(sxCoordinate(axis(s)),2)},${fmt(sy(plotValue(s)),2)}`).join(' ');
    let html=`<text x="58" y="23">${state.quantity==='torqueNm'?'阻力矩 τ':state.panel==='calculus'?'沿运动方向外力 F∥':'手柄 / 沿轨道外力 F'} (${currentUnit()})</text>`;
    const yTicks=B.Education.ticks(low,high),xTicks=B.Education.ticks(state.model==='cam'?axisMin*180/Math.PI:axisMin,state.model==='cam'?axisMax*180/Math.PI:axisMax);
    yTicks.values.forEach((v,i)=>{const y=sy(v);html+=`<line x1="58" x2="788" y1="${y}" y2="${y}" stroke="currentColor" opacity=".12"/><text x="49" y="${y+4}" text-anchor="end">${yTicks.labels[i]}</text>`;});
    xTicks.values.forEach((v,i)=>{const coordinate=state.model==='cam'?v*Math.PI/180:v;html+=`<text x="${sxCoordinate(coordinate)}" y="302" text-anchor="middle">${xTicks.labels[i]}${state.model==='cam'?'°':' m'}</text>`;});
    html+=`<text x="788" y="321" text-anchor="end">${state.model==='cam'?'角度 θ（显示°；内部rad）':'实际运动行程 x (m)'}</text><g id="eng-area"></g>`;
    if(envelope)html+=`<path d="${envelope.map((e,i)=>`${i?'L':'M'}${sxCoordinate(e.coordinate)},${sy(e.max)}`).join(' ')} ${envelope.slice().reverse().map(e=>`L${sxCoordinate(e.coordinate)},${sy(e.min)}`).join(' ')} Z" fill="#7f8fd8" opacity=".2"/>`;
    html+=`<path d="${path(baselineSamples)}" stroke="currentColor" opacity=".45" stroke-dasharray="6 5" stroke-width="2" fill="none"/>`;
    extra.forEach(e=>html+=`<path d="${path(e.samples)}" stroke="${e.color}" stroke-dasharray="${e.dash}" stroke-width="2" fill="none"/>`);
    html+=`<path id="eng-predicted-path" d="${path(samples)}" stroke="#257bd6" stroke-width="3" fill="none"/><line id="eng-tangent" stroke="#8771d5" stroke-width="2" opacity=".8"/><g id="did-math-geometry"></g><line id="eng-cursor" y1="44" y2="278" stroke="#257bd6" stroke-dasharray="3 4" opacity=".6"/><circle id="eng-current-point" r="6" fill="#257bd6" stroke="var(--ui-surface)" stroke-width="2"/>`;
    if(target)html+=`<path id="eng-target-path" stroke="#d97440" stroke-width="2.5" stroke-dasharray="7 5" fill="none"/>`;
    html+=`<rect class="eng-curve-drag" x="58" y="40" width="730" height="242" fill="transparent" role="slider" tabindex="0" aria-label="拖动或用左右方向键定位模型" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(state.progress*100)}"/>`;
    if(target)html+=target.map((t,i)=>`<circle class="eng-target-handle" data-target-handle="${i}" role="slider" tabindex="0" aria-label="目标点${i+1}；上下方向键调整" aria-valuemin="-50000" aria-valuemax="50000" aria-valuenow="${fmt(t.value,1)}" cx="${sx(t.progress)}" cy="${sy(t.value)}" r="9" fill="#d97440"/>`).join('');
    svg.innerHTML=html;
    updateTargetPlot();updateCursor();
    if(state.panel==='analysis')drawHeatmap();
    if(state.panel==='calculus')updateCalculus();
  }
  function updateTargetPlot(){
    const path=$('#eng-target-path');if(!path||!plotScale)return;
    const t=ensureTarget(),{sx,sy}=plotScale;path.setAttribute('d',t.map((p,i)=>`${i?'L':'M'}${sx(p.progress)},${sy(p.value)}`).join(' '));
    t.forEach((p,i)=>{const c=root.querySelector(`[data-target-handle="${i}"]`);if(c){c.setAttribute('cy',sy(p.value));c.setAttribute('aria-valuenow',fmt(p.value,1));}});
    syncTargetPreset();const el=$('#eng-search-result');if(el&&!searchController){const saved=activeSearch();el.textContent=saved?searchSummary(saved):`当前目标归一化 RMSE ${fmt(M.normalizedRMSE(samples,t,state.quantity)*100,2)}%。以有界网格搜索参数，不承诺全局最优。`;}
  }
  function updateCursor(){
    if(!plotScale||!result?.valid)return;
    const {sx,sy} =plotScale,x=sx(state.progress),y=sy(plotValue(result));
    const c=$('#eng-current-point'),line=$('#eng-cursor');if(c){c.setAttribute('cx',x);c.setAttribute('cy',y);}if(line){line.setAttribute('x1',x);line.setAttribute('x2',x);}
    const rect=root.querySelector('.eng-curve-drag');if(rect)rect.setAttribute('aria-valuenow',fmt(state.progress*100,1));
    const tangent=$('#eng-tangent');if(tangent){const h=.045,a=clamp(state.progress-h),b=clamp(state.progress+h),direction=state.panel==='calculus'&&state.model==='incline'&&params.direction==='down'?-1:1,slope=direction*M.derivative(state.model,params,state.progress,state.quantity),coordinate=axis(result),value=plotValue(result);tangent.setAttribute('x1',sx(a));tangent.setAttribute('x2',sx(b));tangent.setAttribute('y1',sy(value+slope*(axis(M.evaluate(state.model,params,a))-coordinate)));tangent.setAttribute('y2',sy(value+slope*(axis(M.evaluate(state.model,params,b))-coordinate)));tangent.setAttribute('opacity',state.panel==='calculus'?'1':'0');}
    updateMathStory();
    const info=$('#eng-sensitivity-info'),sens=plotScale.sensitivity;if(info&&sens&&state.panel==='analysis'){
      const curve=sens.normalizedCurve,inside=curve.length&&state.progress>=curve[0].progress-1e-10&&state.progress<=curve.at(-1).progress+1e-10,value=inside?M.targetValue(curve,state.progress):null;
      info.textContent=`同一物理坐标的当前无量纲灵敏度 S：${inside?fmt(value,4):'不可计算（当前姿态不在三组输入共同域）'}。S=(Δ输出/输出参考)/(Δ参数/参数参考)；参数参考 ${fmt(sens.referenceParameter,4)} ${M.units[sens.parameter]||''}，输出参考 max(1 SI单位,基准RMS)=${fmt(sens.referenceQuantity,4)} ${currentUnit()}。${sens.workRangeCoordinates?`功与目标误差在共同物理域比较；功区间 ${coordinateLabel(sens.workRangeCoordinates[0])} → ${coordinateLabel(sens.workRangeCoordinates[1])}。`:(sens.normalizedReason||'指定区间不在共同物理域内，比较功不可计算。')}峰值为各条完整曲线的采样峰值。`;
      info.dataset.normalizedSensitivity=inside?String(value):'unavailable';
    }
  }
  function updateMathStory(){
    const g=$('#did-math-geometry');if(!g||state.panel!=='calculus'||!plotScale||!result?.valid)return;
    const h=state.secantGap||.12,a=clamp(state.progress-h/2),b=clamp(state.progress+h/2);
    const A=M.evaluate(state.model,params,a),C=M.evaluate(state.model,params,b),{sx,sy}=plotScale;
    const slope=(plotValue(C)-plotValue(A))/(axis(C)-axis(A));
    let html=`<path d="M${sx(a)},${sy(plotValue(A))}L${sx(b)},${sy(plotValue(C))}" fill="none" stroke="#d97440" stroke-width="3" stroke-dasharray="6 3"/><circle cx="${sx(a)}" cy="${sy(plotValue(A))}" r="5" fill="#d97440"/><circle cx="${sx(b)}" cy="${sy(plotValue(C))}" r="5" fill="#d97440"/>`;
    const n=24,p=state.progress;
    for(let i=0;i<n;i++){const l=p*i/n,r=p*(i+1)/n,L=M.evaluate(state.model,params,l),R=M.evaluate(state.model,params,r);html+=`<path d="M${sx(l)},${sy(0)}L${sx(l)},${sy(plotValue(L))}L${sx(r)},${sy(plotValue(R))}L${sx(r)},${sy(0)}Z" fill="#257bd6" opacity=".12"/>`;}
    g.innerHTML=html;
    const read=$('#did-math-reading');if(read)read.textContent=`${B.Didactics.txt('secant')}: ${fmt(slope,3)} ${state.model==='cam'?'N·m/rad':'N/m'} · ${B.Didactics.txt('accumulated')}: ${fmt(result.energy.inputWorkJ,3)} J`;
  }
  function updateCalculus(){
    if(!$('#eng-integral')||!result?.valid)return;
    const [a,b]=state.range,n=state.segments,work=M.integrate(state.model,params,a,b,n,state.method),ref=M.integrate(state.model,params,a,b,2048,'trapezoid');
    $('#eng-derivative').textContent=fmt(M.derivative(state.model,params,state.progress,state.quantity),2)+' '+(state.model==='cam'?'N·m/rad':'N/m');
    $('#eng-integral').textContent=fmt(work,2)+' J';$('#eng-integration-error').textContent=fmt(Math.abs(work-ref),4)+' J';
    $('#eng-integral-info').textContent=`${state.model==='cam'?'W = ∫ τ(θ) dθ':'W = ∫ F∥ dx'}；${axisLabel(M.evaluate(state.model,params,a))} → ${axisLabel(M.evaluate(state.model,params,b))}。${state.model==='incline'&&params.direction==='down'?'下放时运动向下，外力以上坡为正。':''}细分参考是2048段梯形近似，不称为精确实测值。`;
    $('#eng-convergence').innerHTML=`<div class="eng-table-wrap"><table><tr><th>分割数</th><th>机械功 J</th><th>与参考差 J</th></tr>${[4,16,64,256].map(k=>{const v=M.integrate(state.model,params,a,b,k,state.method);return `<tr><td>${k}</td><td>${fmt(v,4)}</td><td>${fmt(Math.abs(v-ref),5)}</td></tr>`;}).join('')}</table></div>`;
    const g=$('#eng-area');if(!g||!plotScale)return;const {sx,sy}=plotScale;let html='';
    for(let i=0;i<n;i++){const l=a+(b-a)*i/n,r=a+(b-a)*(i+1)/n,p=state.method==='midpoint'?(l+r)/2:l,fl=plotValue(M.evaluate(state.model,params,p)),fr=state.method==='trapezoid'?plotValue(M.evaluate(state.model,params,r)):fl;html+=`<path d="M${sx(l)},${sy(0)} L${sx(l)},${sy(fl)} L${sx(r)},${sy(fr)} L${sx(r)},${sy(0)} Z" fill="#22a79b" fill-opacity=".18" stroke="#22a79b" stroke-opacity=".2"/>`;}
    g.innerHTML=html;
  }
  function drawDiagram(){
    const canvas=$('#eng-diagram');if(!canvas||!diagramContext||!result?.valid||state.medium!=='diagram'||document.hidden)return;
    const rect=canvas.getBoundingClientRect(),w=rect.width||660,h=rect.height||425,dpr=Math.min(2,devicePixelRatio||1);if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
    const ctx=diagramContext;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
    const dark=document.body.classList.contains('dark-mode'),ink=dark?'#c6d3e5':'#46566c',light=dark?'#293747':'#d7e0eb';
    const pos=result.position,points=Object.values(pos).filter(p=>p&&typeof p.x==='number');if(state.model==='incline')points.push(result.geometry.trackEnd);if(state.model==='pulley')points.push(...result.geometry.pulleyCenters);
    const xs=points.map(p=>p.x),ys=points.map(p=>p.y),cx=(Math.min(...xs)+Math.max(...xs))/2,cy=(Math.min(...ys)+Math.max(...ys))/2,span=Math.max(1.5,Math.max(...xs)-Math.min(...xs)+.8,Math.max(...ys)-Math.min(...ys)+.8),scale=Math.min(w-80,h-85)/span;
    const project=p=>({x:w*.5+(p.x-cx)*scale,y:h*.52-(p.y-cy)*scale});
    const line=(a,b,color=ink,width=2,dash=[])=>{a=project(a);b=project(b);ctx.beginPath();ctx.setLineDash(dash);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.setLineDash([]);};
    const circle=(p,r,color=ink,fill=false)=>{p=project(p);ctx.beginPath();ctx.arc(p.x,p.y,r,0,Math.PI*2);ctx.strokeStyle=color;ctx.lineWidth=2;if(fill){ctx.fillStyle=color;ctx.fill();}else ctx.stroke();};
    const text=(label,p,color=ink)=>{p=project(p);ctx.font='12px -apple-system,"PingFang SC",sans-serif';ctx.fillStyle=color;paintText(ctx,label,p.x+9,p.y-8);};
    // The scene and all vectors below use the shared kernel's metre coordinates.
    for(let i=-3;i<=3;i++){line({x:cx-3,y:cy+i*.25},{x:cx+3,y:cy+i*.25},light,.6);line({x:cx+i*.25,y:cy-3},{x:cx+i*.25,y:cy+3},light,.6);}
    if(state.model==='cam'){
      const g=result.geometry;const baseline=M.atCoordinate('cam',baselines.cam,result.angleRad);if(baseline.valid){line(baseline.geometry.armLine[0],baseline.geometry.armLine[1],ink,1.5,[6,4]);line(...baseline.geometry.cableLine,ink,1,[5,4]);}line(g.pivot,g.handle,'#537496',5);circle(g.pivot,5,'#8771d5',true);circle(g.handle,7,'#257bd6',true);
      line(g.cableLine[0],g.cableLine[1],'#d97440',2,[6,4]);line(g.armLine[0],g.armLine[1],palette.d,state.focus==='d'?6:3);text('d⊥ '+fmt(result.effectiveArmM,3)+' m',g.cableContact,palette.d);text('轴 O',g.pivot);text('手柄 L',g.handle);
      const o=project(g.pivot),angle=result.angleRad;ctx.beginPath();ctx.arc(o.x,o.y,35,0,-angle,angle>0);ctx.strokeStyle='#8771d5';ctx.lineWidth=state.focus==='theta'?4:2;ctx.stroke();text('θ '+fmt(angle*180/Math.PI,0)+'°',{x:0.12,y:.13},'#8771d5');
    }else if(state.model==='pulley'){
      const g=result.geometry,top=g.fixedPulley.y;line(g.handle,{x:g.handle.x,y:top},'#d97440',3);line({x:g.handle.x,y:top},{x:-.17,y:top},'#d97440',3);line({x:.17,y:top},{x:g.load.x,y:top},'#d97440',3);line({x:g.load.x,y:top},g.load,'#d97440',3);const a=project({x:-.17,y:top+.11}),b=project({x:.17,y:top-.11});ctx.fillStyle=dark?'#293d58':'#e4ecf8';ctx.strokeStyle='#8771d5';ctx.fillRect(a.x,a.y,b.x-a.x,b.y-a.y);ctx.strokeRect(a.x,a.y,b.x-a.x,b.y-a.y);text(`${params.ratio}:1 理想传动模块`,{x:-.18,y:top+.2});circle(g.handle,7,'#257bd6',true);circle(g.load,13,ink,true);text('手柄',g.handle);text('配重（另一个物体）',g.load);ctx.fillStyle=ink;ctx.font='11px sans-serif';paintText(ctx,'2D为等效传动方框图，不表示实际绕索；3D可查看承载绳段。',20,h-18);
    }else{const g=result.geometry;line(g.trackStart,g.trackEnd,ink,7);circle(g.sled,14,'#537496',true);text('滑车',g.sled);line(g.trackStart,{x:g.trackEnd.x,y:0},light,1,[4,4]);text('β '+fmt(params.inclineRad*180/Math.PI,1)+'°',g.trackStart,'#8771d5');}
    if(state.trajectory){for(let i=0;i<=10;i++){const t=i*.3,p=(1-Math.cos(2*Math.PI*t/6))/2,r=M.evaluate(state.model,params,p),q=r.position.analysis;circle(q,2.5,'#8771d5',false);}}
    if(state.view==='force'){
      const max=Math.max(1,...result.forces.map(f=>f.magnitudeN)),forceScale=Math.min(w,h)*.22/max;
      result.forces.forEach(f=>{if(f.magnitudeN<1e-9)return;const a=project(f.origin),dx=f.vector.x*forceScale,dy=-f.vector.y*forceScale,b={x:a.x+dx,y:a.y+dy},color=palette[f.id]||ink,angle=Math.atan2(dy,dx);ctx.beginPath();ctx.strokeStyle=color;ctx.fillStyle=color;ctx.lineWidth=state.focus==='F'&&f.id==='external'?5:2.5;ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.beginPath();ctx.moveTo(b.x,b.y);ctx.lineTo(b.x-9*Math.cos(angle-.4),b.y-9*Math.sin(angle-.4));ctx.lineTo(b.x-9*Math.cos(angle+.4),b.y-9*Math.sin(angle+.4));ctx.closePath();ctx.fill();ctx.font='11px sans-serif';paintText(ctx,`${f.symbol} ${fmt(f.magnitudeN,1)} N`,b.x+5,b.y-5);});
      ctx.fillStyle=ink;ctx.font='10px sans-serif';paintText(ctx,'同一物体受力；箭头按本帧统一比例 '+fmt(forceScale,3)+' px/N',18,23);
    }else{ctx.fillStyle=ink;ctx.font='11px sans-serif';paintText(ctx,'等效机构（不是制造图）· 方格 0.25 m',18,23);}
    const ruler=Math.min(100,scale*.25);ctx.strokeStyle=ink;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(w-130,h-24);ctx.lineTo(w-130+ruler,h-24);ctx.stroke();ctx.fillStyle=ink;ctx.font='10px sans-serif';paintText(ctx,fmt(ruler/scale,2)+' m',w-130,h-31);
  }

  let heatmapBitmap=null;
  function drawHeatmap(){
    const canvas=$('#eng-heatmap');if(!canvas)return;
    const ctx=canvas.getContext('2d'),key=legalKey(),range=M.bounds[state.model][key],values=[],cols=48,rows=17;
    for(let j=0;j<rows;j++)for(let i=0;i<cols;i++)values.push(M.evaluate(state.model,{...params,[key]:range[1]-(range[1]-range[0])*j/(rows-1)},i/(cols-1))[state.quantity]);
    const min=Math.min(...values),max=Math.max(...values),denom=Math.max(1e-9,max-min),left=65,top=24,width=715,height=174;
    ctx.clearRect(0,0,820,250);ctx.fillStyle=getComputedStyle(root).getPropertyValue('--ui-surface').trim()||'#fff';ctx.fillRect(0,0,820,250);
    values.forEach((v,index)=>{const y=Math.floor(index/cols),x=index%cols,t=(v-min)/denom;ctx.fillStyle=`rgb(${Math.round(226-164*t)},${Math.round(235-151*t)},${Math.round(250-104*t)})`;ctx.fillRect(left+x*width/cols,top+y*height/rows,width/cols+1,height/rows+1);});
    const rad=M.units[key]==='rad',show=v=>fmt(rad?v*180/Math.PI:v,rad?0:2);ctx.fillStyle=getComputedStyle(root).color;ctx.font='12px -apple-system,sans-serif';ctx.textAlign='right';paintText(ctx,show(range[1]),left-8,top+9);paintText(ctx,show(range[0]),left-8,top+height);ctx.textAlign='left';paintText(ctx,M.schema[state.model].find(s=>s.key===key).label+' '+(rad?'°':M.units[key]),left,15);paintText(ctx,'0%',left,top+height+23);ctx.textAlign='right';paintText(ctx,'100% 行程',left+width,top+height+23);ctx.textAlign='left';
    heatmapBitmap=document.createElement('canvas');heatmapBitmap.width=820;heatmapBitmap.height=250;heatmapBitmap.getContext('2d').drawImage(canvas,0,0);
    heatmapScale={key,range,left,top,width,height,min,max};
    $('#eng-heatmap-legend').textContent=`浅 → 深：${fmt(min,1)} → ${fmt(max,1)} ${currentUnit()}。${cols}×${rows} 网格采样；点击图内可选择参数与姿态。颜色不表示人体安全。`;
    updateHeatmapMarker();
  }
  function updateHeatmapMarker(){const canvas=$('#eng-heatmap');if(!canvas||!heatmapScale||!heatmapBitmap)return;const ctx=canvas.getContext('2d'),s=heatmapScale;ctx.clearRect(0,0,820,250);ctx.drawImage(heatmapBitmap,0,0);const x=s.left+state.progress*s.width,y=s.top+(s.range[1]-params[s.key])/(s.range[1]-s.range[0])*s.height;ctx.beginPath();ctx.arc(x,y,6,0,2*Math.PI);ctx.strokeStyle='#fff';ctx.lineWidth=3;ctx.fillStyle='#243450';ctx.fill();ctx.stroke();}
  function updateOtherReadouts(){
    const ext=$('#eng-extrema');if(ext){const sorted=samples.slice().sort((a,b)=>a[state.quantity]-b[state.quantity]),min=sorted[0],max=sorted.at(-1);ext.textContent=`121点等间隔采样：最大 ${fmt(max[state.quantity])} ${currentUnit()}（${axisLabel(max)}），最小 ${fmt(min[state.quantity])} ${currentUnit()}（${axisLabel(min)}）。这些是采样极值。`;}
    const cmp=$('#eng-comparison');if(cmp){const a=M.evaluate(state.model,params,state.compare[0]),b=M.evaluate(state.model,params,state.compare[1]);cmp.innerHTML=`<div class="eng-table-wrap"><table><tr><th>位置</th><th>坐标</th><th>${currentUnit()}</th></tr>${[['A',a],['B',b]].map(([label,r])=>`<tr><td>${label}</td><td>${axisLabel(r)}</td><td>${fmt(r[state.quantity])}</td></tr>`).join('')}<tr><td>差 B−A</td><td></td><td>${fmt(b[state.quantity]-a[state.quantity])}</td></tr></table></div>`;}
    const assumptions=$('#eng-assumptions');if(assumptions)assumptions.innerHTML=`<p>分析对象：${esc(result.analysisBody)}。图中仅列这个对象的力。</p><ul>${result.assumptions.map(s=>`<li>${esc(s)}</li>`).join('')}</ul><div class="eng-table-wrap"><table><tr><th>力</th><th>大小 N</th><th>分量 Fx / Fy (N)</th></tr>${result.forces.map(f=>`<tr><td>${esc(f.symbol+' '+f.name)}</td><td>${fmt(f.magnitudeN)}</td><td>${fmt(f.vector.x)} / ${fmt(f.vector.y)}</td></tr>`).join('')}</table></div>`;
    if($('#eng-up-force')){const g=result.geometry;$('#eng-up-force').textContent=fmt(g.upForceN,1)+' N';$('#eng-down-force').textContent=fmt(g.downForceN,1)+' N';$('#eng-cycle-loss').textContent=fmt(result.energy.roundTripDissipatedJ,1)+' J';$('#eng-friction-notice').textContent=g.motionNotice;$('#eng-friction-notice').classList.toggle('eng-warning',g.requiresDownPull);$('#eng-energy-table').innerHTML=`<div class="eng-table-wrap"><table><tr><th>当前这一程的能量</th><th>J</th></tr>${[['外力做功 W',result.energy.inputWorkJ],['势能变化 ΔU',result.energy.potentialJ],['摩擦耗散 E',result.energy.dissipatedJ],['平衡残差 W−ΔU−E',result.energy.balanceResidualJ]].map(([n,v])=>`<tr><td>${n}</td><td>${fmt(v,4)}</td></tr>`).join('')}</table></div>`;}
  }
  function recalculate(full=false,push=true){
    if(!active)return;
    result=M.evaluate(state.model,params,state.progress);root.dataset.model=state.model;root.dataset.modelVersion=result.version;root.dataset.progress=String(state.progress);root.dataset.result=JSON.stringify({valid:result.valid,angleRad:result.angleRad,displacementM:result.displacementM,forceN:result.forceN,torqueNm:result.torqueNm,effectiveArmM:result.effectiveArmM,energy:result.energy});
    root.querySelectorAll('[data-eng=play],[data-eng=step]').forEach(button=>button.disabled=!result.valid);
    if(!result.valid){B.Didactics?.updateLab();root.dataset.invalid='true';status('当前参数不可计算：'+result.reasons.join(' '));root.querySelectorAll('.eng-readouts strong').forEach(e=>e.textContent='不可计算');$('#eng-panel').hidden=true;if(diagramContext){diagramContext.save();diagramContext.setTransform(1,0,0,1,0,0);diagramContext.clearRect(0,0,$('#eng-diagram').width,$('#eng-diagram').height);diagramContext.restore();}B.engineering3D?.set({model:state.model,params,progress:state.progress,view:state.view,focus:state.focus,baselineParams:baselines[state.model]});return;}
    $('#eng-panel').hidden=false;if(root.dataset.invalid==='true'){status('参数已恢复有效。图形与读数已重新计算。');delete root.dataset.invalid;}
    const svg=$('#eng-curve');if(svg)svg.style.opacity='1';
    if(full||!samples.length){samples=M.sample(state.model,params,121);baselineSamples=M.sample(state.model,baselines[state.model],121);dirtyCurve=true;}
    $('#eng-read-position').textContent=axisLabel(result);$('#eng-read-force').textContent=fmt(result.forceN,1)+' N';$('#eng-read-torque').textContent=fmt(result.torqueNm,1)+' N·m';$('#eng-read-extra').textContent=state.model==='cam'?fmt(result.effectiveArmM,3)+' m':fmt(result.energy.inputWorkJ,1)+' J';
    $('#eng-progress').value=String(state.progress*100);if(document.activeElement!==$('#eng-progress-number'))$('#eng-progress-number').value=fmt(state.progress*100,1);
    $('#eng-analysis-body').textContent='分析对象：'+({handle:'手柄（不混入配重受力）','ideal-transmission':'理想传动轴与刚性手柄臂',sled:'滑车'}[result.analysisBody]||result.analysisBody);
    if(push)B.engineering3D?.set({model:state.model,params,progress:state.progress,view:state.view,focus:state.focus,baselineParams:baselines[state.model]});
    drawDiagram();
    if(dirtyCurve){drawPlot();dirtyCurve=false;}else{updateCursor();updateHeatmapMarker();}
    if(full)updateOtherReadouts();else if(state.panel==='energy'||$('#eng-assumptions')?.parentElement.open)updateOtherReadouts();
    if(state.panel==='calculus'&&!full){$('#eng-derivative').textContent=fmt(M.derivative(state.model,params,state.progress,state.quantity),2)+' '+(state.model==='cam'?'N·m/rad':'N/m');}
    B.Didactics?.updateLab();
    const forceScale=$('#digital-twin-canvas')?.dataset.engineeringForceScale;if(forceScale)$('#eng-force-scale').textContent=`箭头同一线性比例 ${forceScale}（3D单位/N，按本状态最大力适配）；大小以 N 读数为准。`;
  }
  function schedule(full=false,push=true){dirtyCurve=dirtyCurve||full;if(frame)return;frame=requestAnimationFrame(()=>{frame=0;recalculate(dirtyCurve,push);});}
  function syncParameters(){M.schema[state.model].forEach(s=>{root.querySelectorAll(`[data-param="${s.key}"]`).forEach(el=>{const v=s.unit==='rad'?params[s.key]*180/Math.PI:params[s.key];if(document.activeElement!==el)el.value=String(v);});const read=root.querySelector(`[data-param-readout="${s.key}"]`);if(read){const v=s.unit==='rad'?params[s.key]*180/Math.PI:params[s.key];read.textContent=typeof v==='number'?fmt(v,s.unit==='rad'?1:s.step<.1?3:0):v==='up'?'推起':'下放';}});}
  function stopPlayback(){cancelAnimationFrame(playFrame);playFrame=0;state.playing=false;const b=root.querySelector('[data-eng=play]');if(b)b.textContent='播放规定轨迹';}
  function play(){if(state.playing){stopPlayback();return;}if(media.matches){status('系统已启用减少动态效果。可拖动姿态或曲线逐点检查，所有计算仍可用。');return;}state.playing=true;playStart=performance.now()-Math.acos(1-2*state.progress)/(2*Math.PI)*6000;root.querySelector('[data-eng=play]').textContent='暂停当前姿态';const tick=t=>{if(!active||document.hidden||!state.playing||media.matches){stopPlayback();return;}state.progress=(1-Math.cos((t-playStart)/6000*2*Math.PI))/2;recalculate(false);playFrame=requestAnimationFrame(tick);};playFrame=requestAnimationFrame(tick);}

  function renderTaskPanel(p){
    const questions={pulley:['同样负载，理想传动比从1:1变成2:1，拉力与拉动距离会怎样？',['拉力变为一半，相同抬升高度需要双倍拉动距离','拉力与距离都变为一半','拉力不变']],cam:['保持同一姿态和负载，增大基准有效力臂，阻力矩会怎样？',['随有效力臂增大','与力臂无关','只改变动画速度']],incline:['只把摩擦系数改为零，推起与下放外力的差会怎样？',['趋近零（本来为零时保持零）','差变大','只由负载决定，与摩擦无关']]};
    p.innerHTML=`<div class="eng-task-steps"><span data-active="true">1 提出问题</span><span>2 记录预测</span><span>3 操作模型</span><span>4 检验与解释</span></div><div class="eng-panel-grid"><div><h2>${questions[state.model][0]}</h2><p class="eng-panel-copy">选择你的预测，然后改变条件。结论由当前模型计算，没有虚构分数或学习进步。</p><div class="eng-task-options">${questions[state.model][1].map((s,i)=>`<label><input type="radio" name="eng-prediction" value="${i}" ${state.prediction===i?'checked':''}>${s}</label>`).join('')}</div><div class="eng-actions">${button('记录预测并固定条件','task-predict','','eng-primary')}${button('改变指定条件','task-operate',state.taskBefore?'':'disabled')}${button('查看结果与解释','task-check',state.taskBefore?'':'disabled')}</div><div id="eng-task-feedback" class="eng-message">先给出一个预测，再用模型检验。也可以在上方自行改变参数。</div></div><div>${chartMarkup()}<p class="eng-chart-note">箭头、曲线与下方解释来自同一组参数。若你又改变了其他条件，结论需要按新条件重新检查。</p></div></div>`;
  }
  function taskPredict(){state.search=null;if(state.prediction===null){status('先选择一个预测。');return;}if(state.model==='pulley')params.ratio=1;state.taskBefore={model:state.model,params:copy(params),progress:state.progress,prediction:state.prediction};state.taskAfter=null;syncParameters();schedule(true);root.querySelectorAll('[data-eng=task-operate],[data-eng=task-check]').forEach(e=>e.disabled=false);$('#eng-task-feedback').textContent='预测已记录。基准条件已固定；现在操作指定条件，或在上方自己试。';}
  function taskOperate(){state.search=null;if(!state.taskBefore)return;const before=state.taskBefore.params;if(state.model==='pulley')params.ratio=2;else if(state.model==='cam')params.baseArmM=clamp(before.baseArmM+.05,0,.4);else params.friction=0;syncParameters();recalculate(true);taskCheck();}
  function taskCheck(){if(!state.taskBefore||state.taskBefore.model!==state.model)return;const t=state.taskBefore,before=M.evaluate(t.model,t.params,t.progress);let compareProgress=t.progress;if(state.model==='cam'){compareProgress=(before.angleRad-params.startAngleRad)/params.sweepRad;if(compareProgress<0||compareProgress>1){$('#eng-task-feedback').textContent='原来固定的角度不在新角度范围内，不能作同一姿态比较。恢复角度范围或重新记录预测。';return;}}const after=M.evaluate(state.model,params,compareProgress);if(!after.valid)return;let text='';if(state.model==='pulley')text=`原拉力 ${fmt(before.forceN,1)} N → 当前 ${fmt(after.forceN,1)} N。相同配重抬升 0.10 m，需拉动 ${fmt(.1*t.params.ratio,2)} m → ${fmt(.1*params.ratio,2)} m。理想无摩擦时两边做功同为 mg·0.10；省力以更长距离交换。`;else if(state.model==='cam')text=`同一 θ=${fmt(before.angleRad*180/Math.PI,1)}°：d 从 ${fmt(before.effectiveArmM,3)} m → ${fmt(after.effectiveArmM,3)} m，τ 从 ${fmt(before.torqueNm,2)} → ${fmt(after.torqueNm,2)} N·m。看青色垂直力臂与蓝色曲线；这是力臂模型，不是制造轮廓反求。`;else text=`推起/下放差由 ${fmt(before.geometry.upForceN-before.geometry.downForceN,2)} N → ${fmt(after.geometry.upForceN-after.geometry.downForceN,2)} N；完整往返耗散由 ${fmt(before.energy.roundTripDissipatedJ,2)} J → ${fmt(after.energy.roundTripDissipatedJ,2)} J。差来自反向的动摩擦。摩擦为零时两条线重合，面积账本相应变化。`;
    const changed=Object.keys(before.params).filter(k=>!['ratio','baseArmM','friction'].includes(k)&&before.params[k]!==after.params[k]);if(changed.length)text+=' 你还改变了 '+changed.join('、')+'，所以这不再是只改变一个条件的比较。';
    state.taskAfter={params:copy(params),result:after};$('#eng-task-feedback').textContent=text;state.focus=state.model==='cam'?'d':'F';state.view='force';root.querySelectorAll('[data-view]').forEach(e=>e.setAttribute('aria-pressed',String(e.dataset.view===state.view)));renderFormula();recalculate(false);}

  function renderArchive(p){
    p.innerHTML=`<div class="eng-panel-grid"><div><h2>把模型、假设和结果一起留下。</h2><p class="eng-panel-copy">实验快照独立于个人训练记录；包含模型版本、来源、单位、假设与121点曲线。这里没有实物测量数据。</p><label>本次实验备注<textarea id="eng-note" maxlength="2000" placeholder="我想检验什么？观察到了什么？还有哪些条件未验证？">${esc(state.note)}</textarea></label><div class="eng-actions">${button('保存本次实验快照','save-snapshot','','eng-primary')}${button('导出当前 JSON','export-json')}${button('导出当前 CSV','export-csv')}</div><div id="eng-snapshot-status" class="eng-message" role="status">保存在本浏览器的独立实验库，不改变训练备份格式。</div><div class="eng-archive-list" id="eng-snapshot-list"></div></div><div class="eng-archive-prose"><h3>研究与迭代档案</h3><ol><li><strong>问题：</strong>几何传动如何改变阻力函数，以及摩擦如何改变机械功？</li><li><strong>观察来源：</strong>现有器械模型、已保留的厂家资料入口和公开物理教材；未对实体器械测绘。</li><li><strong>模型选择：</strong>理想定比滑轮、参数化有效力臂传动、准静态直轨滑车。</li><li><strong>输入来源：</strong>当前每个参数旁可选择来源；默认均为模型示例，调整参数不会自动变成实测。</li><li><strong>假设：</strong>忽略惯性，滑轮无摩擦，滑车采用恒定动摩擦；具体假设随快照保存。</li><li><strong>数学：</strong>同源力向量与力矩、数值差分、数值积分、归一化误差、有界网格搜索。</li><li><strong>验证：</strong>解析极限、单位、力/力矩平衡、机械功与耗散账本、数值收敛及浏览器联动测试。</li><li><strong>偏差：</strong>商业外壳尺寸未标定；没有接触压力、钢索伸长、静摩擦或惯性校准，真实器械结果待实测验证。</li><li><strong>设计取舍：</strong>先保证可解释且可检验，再处理更复杂的接触与制造约束；不承诺全局最优。</li><li><strong>下一步：</strong>采集轨道/力臂和力传感器数据，比较残差后再改模型。</li><li><strong>AI与作者：</strong>本轮代码、文档和自动检查由AI协助生成并在本地运行；需求与取舍来自项目作者。作者的实物搭建、测量与独立复核尚未提供证据，标为待验证。</li></ol><details><summary>参考与完整模型说明</summary><p><a href="https://openstax.org/books/university-physics-volume-1/pages/10-6-torque" target="_blank" rel="noopener">OpenStax 力矩</a> · <a href="https://openstax.org/books/university-physics-volume-1/pages/10-8-work-and-power-for-rotational-motion" target="_blank" rel="noopener">转动做功</a> · <a href="https://ciechanow.ski/mechanical-watch/" target="_blank" rel="noopener">分层机构解释</a> · <a href="https://phet.colorado.edu/en/simulations/balancing-act" target="_blank" rel="noopener">PhET 平衡实验</a></p><p>前三份正文已阅读；PhET仅介绍页可读，未声称操作其模拟。项目内 docs/mechanics-models.md 记录公式、约束和验证边界。</p></details></div></div>`;
    renderSnapshots();
  }
  function currentSnapshot(){const search=activeSearch();return B.MechanicsSnapshots.create({model:state.model,params,progress:state.progress,quantity:state.quantity,target:ensureTarget(),range:state.range,note:state.note,search});}
  function renderSnapshots(){const el=$('#eng-snapshot-list');if(!el)return;const loaded=B.MechanicsSnapshots?.load();if(!loaded?.ok){el.textContent=loaded?.error||'快照模块加载中。';return;}el.innerHTML=loaded.snapshots.length?loaded.snapshots.slice().reverse().map(s=>`<article class="eng-snapshot"><div><strong>${esc(names[s.model])} · ${s.note?'<span data-i18n-skip>'+esc(s.note)+'</span>':'未填写备注'}</strong><small>${esc(new Date(s.createdAt).toLocaleString('zh-CN'))} · ${esc(s.modelVersion)}</small></div>${button('恢复参数与曲线','restore-snapshot',`data-id="${esc(s.id)}"`)}</article>`).join(''):'<p class="eng-muted">还没有实验快照。先改变一个参数，再保存你的观察。</p>';}
  let downloadUrl=null;
  function download(text,type,name){if(downloadUrl)URL.revokeObjectURL(downloadUrl);downloadUrl=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.id='eng-download-link';a.href=downloadUrl;a.download=name;a.textContent='再次下载 '+name;a.style.display='block';$('#eng-live-status').append(a);a.click();}
  function saveSnapshot(){try{const s=currentSnapshot(),saved=B.MechanicsSnapshots.save(s);$('#eng-snapshot-status').textContent=saved.ok?'已保存模型、来源、单位和曲线。可从下方恢复。':saved.error;renderSnapshots();}catch(e){$('#eng-snapshot-status').textContent='未保存：'+e.message;}}
  function restoreSnapshot(id){const loaded=B.MechanicsSnapshots.load(),s=loaded.snapshots?.find(s=>s.id===id),valid=B.MechanicsSnapshots.validate(s);if(!valid.ok){status(valid.error);return;}stopPlayback();state.taskBefore=null;state.taskAfter=null;state.prediction=null;state.focus=null;state.model=s.model;bank[s.model]=copy(s.params);params=bank[s.model];state.progress=s.progress;state.quantity=s.quantity;state.range=s.range.slice();state.note=s.note;state.search=s.search||null;targets[state.model+':'+state.quantity]=copy(s.target);state.sensitivityKey=M.schema[state.model].find(s=>s.kind!=='select').key;state.panel='archive';if(location.hash!=='#engineering/'+state.model+'/archive')location.hash='engineering/'+state.model+'/archive';renderShell();status('实验快照已恢复；当前参数与保存的曲线一致。');}

  function drawSpring(time=0){
    const S=B.SpringLab,svg=$('#eng-spring-chart');if(!S||!svg)return;const current=S.response(time,state.spring);state.springTime=time;root.querySelectorAll('[data-control=spring-time]').forEach(e=>e.value=String(time));if(!current.valid){status(current.reasons.join(' '));return;}
    const sx=t=>58+t/6*730,sy=x=>178-x*116;
    if(!svg.hasAttribute('data-painted')||svg.dataset.signature!==JSON.stringify(state.spring)){
      const arr=S.sample(state.spring,6,241);svg.dataset.signature=JSON.stringify(state.spring);svg.dataset.painted='true';svg.innerHTML=`<text x="58" y="24">归一化位移 x(t)；同一初始位移 1</text><line x1="58" x2="788" y1="178" y2="178" stroke="currentColor" opacity=".3"/><path d="${arr.map((r,i)=>`${i?'L':'M'}${sx(r.t)},${sy(r.x)}`).join(' ')}" fill="none" stroke="#257bd6" stroke-width="3"/><circle id="eng-spring-marker" r="7" fill="#d97440"/><text x="58" y="310">0</text><text x="788" y="310" text-anchor="end">6 s（演示时间）</text>`;
    }
    $('#eng-spring-marker').setAttribute('cx',sx(time));$('#eng-spring-marker').setAttribute('cy',sy(current.x));$('#eng-spring-x').textContent=fmt(current.x,3);$('#eng-spring-zeta').textContent=fmt(current.zeta,3);$('#eng-spring-regime').textContent=({underdamped:'欠阻尼',critical:'临界阻尼',overdamped:'过阻尼'})[current.regime];
  }
  function playSpring(){cancelAnimationFrame(springFrame);springFrame=0;if(media.matches){drawSpring(.5);status('减少动态效果：显示0.5 s的静态响应；可用观察时间输入逐点检查。');return;}springStarted=performance.now();const tick=t=>{if(!active||document.hidden||state.panel!=='spring'){springFrame=0;return;}const age=Math.min(6,(t-springStarted)/1000);drawSpring(age);root.querySelectorAll('[data-control=spring-time]').forEach(e=>e.value=age);if(age<6)springFrame=requestAnimationFrame(tick);else springFrame=0;};springFrame=requestAnimationFrame(tick);}
  async function search(){
    if(searchController||!result?.valid)return;
    const c=new AbortController();searchController=c;const searchModel=state.model,searchParams=copy(params),target=copy(ensureTarget()),quantity=state.quantity;
    root.querySelector('[data-eng=search]').disabled=true;root.querySelector('[data-eng=cancel-search]').disabled=false;
    $('#eng-search-result').textContent='正在分块比较合法参数，界面仍可操作；可随时取消。';
    try{
      const found=await M.search(searchModel,searchParams,target,{quantity,signal:c.signal,onProgress:p=>{if(active&&$('#eng-search-result'))$('#eng-search-result').textContent='已比较 '+(p.evaluated??p)+' 个合法组合…';}});
      if(!active||state.model!==searchModel||c.signal.aborted){if($('#eng-search-result'))$('#eng-search-result').textContent='已取消，当前参数保持不变。';return;}
      if(found.cancelled){$('#eng-search-result').textContent='已取消，当前参数保持不变。';return;}
      const designSources=copy(params.sources);Object.keys(found.bestParams).forEach(key=>{if(key!=='sources'&&found.bestParams[key]!==searchParams[key])designSources[key]='assumed-range';});
      bank[state.model]={...found.bestParams,sources:designSources};params=bank[state.model];state.search={...found,bestParams:copy(params),searchInput:{params:searchParams,target,quantity,sampleCount:61},sourceNotice:'搜索改变的参数为模型设计值，来源标为假设范围，不继承原测量或厂家来源。'};syncParameters();recalculate(true);
      $('#eng-search-result').textContent=searchSummary(found);
    }catch(e){if($('#eng-search-result'))$('#eng-search-result').textContent='搜索未应用：'+e.message;}
    finally{searchController=null;if(active){const b=root.querySelector('[data-eng=search]');if(b)b.disabled=false;const c=root.querySelector('[data-eng=cancel-search]');if(c)c.disabled=true;}}
  }

  function setPanel(panel,navigate=true){state.tabFocus=true;searchController?.abort();if(!tabs.some(([k])=>k===panel))panel='observe';cancelAnimationFrame(springFrame);springFrame=0;state.panel=panel;if(navigate){location.hash='engineering/'+state.model+'/'+panel;return;}root.querySelectorAll('[data-panel]').forEach(e=>{const selected=e.dataset.panel===panel;e.setAttribute('aria-selected',String(selected));e.tabIndex=selected?0:-1;});renderPanel();recalculate(true);}
  function setModel(model,navigate=true){if(!names[model])return;stopPlayback();searchController?.abort();state.model=model;teachingContext=null;params=bank[model];state.quantity=model==='cam'?'torqueNm':'forceN';state.sensitivityKey=model==='cam'?'eccentricity':model==='incline'?'friction':'massKg';state.taskBefore=null;state.taskAfter=null;state.prediction=null;state.search=null;state.range=[0,1];if(navigate){location.hash='engineering/'+model+'/'+state.panel;return;}renderShell();}
  root.addEventListener('click',e=>{
    const b=e.target.closest('[data-eng]');if(!b)return;const action=b.dataset.eng;
    if(action==='back')location.hash=state.origin||'library';
    if(action==='archive'){state.scrollPanel=true;setPanel('archive');}
    if(action==='panel')setPanel(b.dataset.panel);
    if(action==='model')setModel(b.dataset.model);
    if(action==='view'){state.view=b.dataset.view;root.querySelectorAll('[data-view]').forEach(e=>e.setAttribute('aria-pressed',String(e.dataset.view===state.view)));recalculate(false);}
    if(action==='medium'){state.medium=b.dataset.medium;root.dataset.medium=state.medium;root.querySelectorAll('[data-medium]').forEach(e=>e.setAttribute('aria-pressed',String(e.dataset.medium===state.medium)));drawDiagram();window.forceDigitalTwinResize?.();}
    if(action==='focus'){state.focus=state.focus===b.dataset.focus?null:b.dataset.focus;if(state.focus){state.view='force';root.querySelectorAll('[data-view]').forEach(e=>e.setAttribute('aria-pressed',String(e.dataset.view===state.view)));}renderFormula();recalculate(false);status(({F:'已高亮外力 F；颜色外还保留符号和N读数。',d:'已高亮转轴到力作用线的垂直距离 d。',theta:'已高亮角度与曲线当前位置。'})[state.focus]||'已取消局部高亮。');}
    if(action==='baseline'){if(!M.evaluate(state.model,params,state.progress).valid){status('请先修正无效参数，再固定比较基准。');return;}baselines[state.model]=copy(params);recalculate(true);status('当前参数已固定为虚线比较基准；之后调整不会改动它。');}
    if(action==='reset-model'){state.search=null;bank[state.model]={...copy(M.defaults[state.model]),sources:Object.fromEntries(Object.keys(M.defaults[state.model]).map(k=>[k,'model-example']))};params=bank[state.model];syncParameters();recalculate(true);status('恢复的是实验模型示例；个人训练数据保持原样。');}
    if(action==='play')play();
    if(action==='step'){stopPlayback();state.progress=B.Didactics.nextProgress(state.progress);recalculate(false);}
    if(action==='reset-pose'){stopPlayback();state.progress=0;recalculate(false);}
    if(action==='restore-baseline'){stopPlayback();bank[state.model]=copy(baselines[state.model]);params=bank[state.model];state.search=null;syncParameters();recalculate(true);}

    if(action==='search')search();if(action==='cancel-search')searchController?.abort();
    if(action==='zero-friction'){state.search=null;params.friction=0;syncParameters();recalculate(true);status('摩擦系数为0：检查上下外力差与耗散是否同时归零。');}
    if(action==='task-predict')taskPredict();if(action==='task-operate')taskOperate();if(action==='task-check')taskCheck();
    if(action==='spring-play')playSpring();if(action==='spring-title'){state.spring={mass:1,stiffness:235.62,damping:13.8};renderPanel();drawSpring(0);}
    if(action==='save-snapshot')saveSnapshot();if(action==='restore-snapshot')restoreSnapshot(b.dataset.id);
    if(action==='export-json'||action==='export-csv'){try{const s=currentSnapshot(),csv=action==='export-csv';status('已生成当前实验文件；不包含个人训练记录。若浏览器未开始下载，可使用下方链接。');download(csv?B.MechanicsSnapshots.csv(s):JSON.stringify(s,null,2),csv?'text/csv;charset=utf-8':'application/json','BMMD-experiment-'+state.model+'-'+s.id+'.'+(csv?'csv':'json'));}catch(e){status('未导出：'+e.message);}}
  });
  function input(e){
    const el=e.target;if(!active)return;if(el.matches('[data-control]')&&(el.type==='number'||el.type==='range')){if(el.value==='')return;const v=Number(el.value);if(!Number.isFinite(v))return;el.value=String(clamp(v,Number(el.min||0),Number(el.max||100000)));}
    if(el.matches('[data-param]')){
      stopPlayback();searchController?.abort();const key=el.dataset.param,s=M.schema[state.model].find(s=>s.key===key);let v=el.value;if(s.kind!=='select'||key==='ratio')v=v===''?NaN:Number(v);if(el.dataset.displayRad==='true')v=v*Math.PI/180;if(state.model==='pulley'&&key==='ratio'&&state.panel==='observe'){try{Object.assign(params,B.Didactics.sameLift(params,v));}catch(error){status(error.message);el.value=String(params.ratio);syncParameters();return;}}else params[key]=v;state.search=null;syncParameters();schedule(true);return;
    }
    if(el.matches('[data-source]')){params.sources[el.dataset.source]=el.value;schedule(true);return;}
    if(el.id==='eng-progress'||el.id==='eng-progress-number'){const v=Number(el.value);if(Number.isFinite(v)){stopPlayback();state.progress=clamp(v/100);schedule(false);}return;}
    if(el.matches('[data-target]')){searchController?.abort();if(el.value==='')return;const v=Number(el.value);if(Number.isFinite(v)){ensureTarget()[Number(el.dataset.target)].value=clamp(v,-50000,50000);state.search=null;updateTargetPlot();schedule(true);}return;}
    if(el.id==='eng-note'){state.note=el.value;return;}
    if(el.name==='eng-prediction'){state.prediction=Number(el.value);return;}
    const control=el.dataset.control;if(!control)return;
    root.querySelectorAll(`[data-control="${control}"]`).forEach(p=>{if(p!==el&&p.type!=='checkbox')p.value=el.value;});
    if(control==='secant-gap'){state.secantGap=Number(el.value);updateMathStory();}
    else if(control==='quantity'){searchController?.abort();state.quantity=el.value;state.search=null;if(state.panel==='design')renderTargetFields();schedule(true);}
    else if(control==='target-preset'){searchController?.abort();if(el.value!=='custom')ensureTarget(true,el.value);renderTargetFields();state.search=null;schedule(true);}
    else if(control==='compareA'||control==='compareB'){state.compare[control==='compareA'?0:1]=clamp(Number(el.value)/100);updateOtherReadouts();}
    else if(control==='rangeA'||control==='rangeB'){state.range[control==='rangeA'?0:1]=clamp(Number(el.value)/100);updateCalculus();}
    else if(control==='segments'){state.segments=Number(el.value);updateCalculus();}
    else if(control==='method'){state.method=el.value;updateCalculus();}
    else if(control==='trajectory'){state.trajectory=el.checked;drawDiagram();}
    else if(control==='sensitivityKey'){state.sensitivityKey=el.value;schedule(true);}
    else if(control==='fraction'||control==='uncertaintyWidth'){state[control]=Number(el.value)/100;schedule(true);}
    else if(control==='uncertaintySource'){state.uncertaintySource=el.value;status('范围来源：'+sources[el.value]+'；范围传播仍不属于统计置信区间。');}
    else if(control==='spring-time'){cancelAnimationFrame(springFrame);springFrame=0;drawSpring(Number(el.value));}
    else if(control.startsWith('spring-')){cancelAnimationFrame(springFrame);springFrame=0;state.spring[control.slice(7)]=Number(el.value);drawSpring(0);}
  }
  root.addEventListener('input',input);root.addEventListener('change',e=>{if(e.target.matches('select,input[type=radio],input[type=checkbox]'))input(e);});
  root.addEventListener('keydown',e=>{
    const target=e.target;
    if(target.matches('[data-panel]')&&['ArrowRight','ArrowLeft','Home','End'].includes(e.key)){e.preventDefault();const i=tabs.findIndex(([k])=>k===state.panel),j=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;setPanel(tabs[j][0]);queueMicrotask(()=>root.querySelector('#eng-tab-'+tabs[j][0])?.focus());}
    if(target.matches('.eng-curve-drag')&&['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();stopPlayback();state.progress=e.key==='Home'?0:e.key==='End'?1:clamp(state.progress+(e.key==='ArrowRight'?.01:-.01));schedule(false);}
    if(target.matches('[data-target-handle]')&&['ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();searchController?.abort();const p=ensureTarget()[Number(target.dataset.targetHandle)];p.value=clamp(p.value+(e.key==='ArrowUp'?1:-1)*Math.max(1,plotScale.high*.01),-50000,50000);state.search=null;updateTargetPlot();const input=root.querySelector(`[data-target="${target.dataset.targetHandle}"]`);if(input)input.value=fmt(p.value,1);}
  });
  function curvePointer(e){
    if(!drag||!plotScale)return;const rect=drag.svg.getBoundingClientRect(),x=(e.clientX-rect.left)/rect.width*820,y=(e.clientY-rect.top)/rect.height*330;
    if(drag.kind==='target'){searchController?.abort();const value=plotScale.low+(plotScale.bottom-y)/(plotScale.bottom-plotScale.top)*(plotScale.high-plotScale.low);ensureTarget()[drag.index].value=clamp(value,-50000,50000);state.search=null;updateTargetPlot();root.querySelector(`[data-target="${drag.index}"]`).value=fmt(ensureTarget()[drag.index].value,1);}
    else{stopPlayback();const coordinate=plotScale.axisMin+(x-plotScale.left)/(plotScale.right-plotScale.left)*(plotScale.axisMax-plotScale.axisMin),domain=plotScale.currentDomain;state.progress=clamp((coordinate-domain.min)/(domain.max-domain.min));schedule(false);}
  }
  root.addEventListener('pointerdown',e=>{
    const target=e.target.closest('[data-target-handle],.eng-curve-drag');if(target){e.preventDefault();drag={kind:target.hasAttribute('data-target-handle')?'target':'position',index:Number(target.dataset.targetHandle),svg:target.closest('svg'),target};target.setPointerCapture(e.pointerId);curvePointer(e);}
    if(e.target.id==='eng-heatmap'&&heatmapScale){const rect=e.target.getBoundingClientRect(),x=(e.clientX-rect.left)/rect.width*820,y=(e.clientY-rect.top)/rect.height*250,s=heatmapScale;if(x<s.left||x>s.left+s.width||y<s.top||y>s.top+s.height)return;stopPlayback();state.progress=clamp((x-s.left)/s.width);state.search=null;params[s.key]=s.range[1]-clamp((y-s.top)/s.height)*(s.range[1]-s.range[0]);syncParameters();schedule(true);}
  });
  root.addEventListener('pointermove',curvePointer);root.addEventListener('pointerup',()=>{if(drag?.kind==='target')schedule(true);drag=null;});root.addEventListener('pointercancel',()=>{drag=null;});

  function open(route,origin){
    const [,model='cam',panel='observe']=route.split('/');
    if(!active){if(origin&&!origin.startsWith('action/'))teachingContext=null;state.origin=origin&&!origin.startsWith('engineering')?origin:state.origin||'library';active=true;document.body.classList.add('eng-active');const header=$('.system-header');if(header){header.hidden=true;header.inert=true;}const portal=$('#portal-hub-overlay');portal.style.display='none';portal.style.pointerEvents='none';portal.inert=true;window.enterPortalWorkspace?.('lab');twin=$('.twin-pane');if(twin){placeholder=document.createComment('engineering viewport return');twin.before(placeholder);}controller=new AbortController();document.addEventListener('visibilitychange',()=>{if(document.hidden){stopPlayback();cancelAnimationFrame(springFrame);springFrame=0;}},{signal:controller.signal});window.addEventListener('resize',()=>{if(active)drawDiagram();},{signal:controller.signal,passive:true});}
    root.hidden=false;root.inert=false;state.panel=tabs.some(([k])=>k===panel)?panel:'observe';if(names[model]&&model!==state.model){state.model=model;teachingContext=null;params=bank[model];state.quantity=model==='cam'?'torqueNm':'forceN';state.sensitivityKey=model==='cam'?'eccentricity':model==='incline'?'friction':'massKg';state.taskBefore=null;state.taskAfter=null;state.prediction=null;state.search=null;state.range=[0,1];}
    if(pendingLesson&&pendingLesson.model===model&&state.origin==='action/'+pendingLesson.action){const item=pendingLesson;bank[model]={...copy(item.params),sources:Object.fromEntries(Object.keys(M.defaults[model]).map(k=>[k,'model-example']))};params=bank[model];baselines[model]={...copy(item.baseline),sources:copy(params.sources)};state.progress=item.progress;teachingContext=item;pendingLesson=null;}else if(pendingLesson)pendingLesson=null;
    renderShell();window.forceDigitalTwinResize?.();requestAnimationFrame(()=>{if(active){recalculate(false);const target=state.tabFocus?root.querySelector('#eng-tab-'+state.panel):root.querySelector('h1');state.tabFocus=false;target?.focus({preventScroll:true});if(state.scrollPanel){state.scrollPanel=false;$('#eng-panel').scrollIntoView({block:'start'});}}});
  }
  function close(){
    if(!active)return;active=false;if(downloadUrl){URL.revokeObjectURL(downloadUrl);downloadUrl=null;}stopPlayback();searchController?.abort();cancelAnimationFrame(frame);frame=0;cancelAnimationFrame(springFrame);springFrame=0;controller?.abort();controller=null;drag=null;B.engineering3D?.release();if(twin&&placeholder?.parentNode){placeholder.replaceWith(twin);placeholder=null;}root.hidden=true;root.inert=true;document.body.classList.remove('eng-active');const header=$('.system-header');if(header){header.hidden=false;header.inert=false;}const portal=$('#portal-hub-overlay');if(portal)portal.inert=false;heatmapBitmap=null;clearTimeout(readyRetry);readyRetry=null;window.forceDigitalTwinResize?.();
  }
  document.addEventListener('bm:engineering-progress',e=>{if(!active)return;const p=e.detail?.progress;if(Number.isFinite(p)){stopPlayback();state.progress=clamp(p);schedule(false,false);}});
  document.addEventListener('bm:engineering-part',e=>{if(active){const el=$('#eng-part-description');if(el)el.textContent=e.detail?.path||'已选择传动路径。';}});
  document.addEventListener('bm:engineering-3d-ready',()=>{if(active)recalculate(false);});
  media.addEventListener('change',()=>{if(media.matches){stopPlayback();cancelAnimationFrame(springFrame);springFrame=0;if(active&&state.panel==='spring')drawSpring(state.springTime||0);}});
  document.addEventListener('bm:language-change',()=>{if(!active)return;const context=root.querySelector('.did-context');if(context&&teachingContext)context.textContent=(B.i18n?.getLanguage()==='en'?'From this lesson: ':'从当前教学带入：')+teachingContext.question[B.i18n?.getLanguage()==='en'?1:0]+(B.i18n?.getLanguage()==='en'?' · Model examples; not machine measurements or training loads.':' · 模型示例，非实物测量或训练负荷。');heatmapBitmap=null;dirtyCurve=true;recalculate(true);if(state.panel==='spring'){const svg=$('#eng-spring-chart');svg?.removeAttribute('data-painted');drawSpring(state.springTime||0);}});
  B.engineering={open,close,fromTeaching(value){if(!value||!names[value.model]||!Array.isArray(value.question)||typeof value.action!=='string'||!M.evaluate(value.model,value.params,value.progress).valid||!M.evaluate(value.model,value.baseline,value.progress).valid)return false;pendingLesson=copy(value);return true;}};
})();
