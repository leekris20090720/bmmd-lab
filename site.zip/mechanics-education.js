/* Shared presentation math only. No training storage or alternate physics engine. */
(function(global){'use strict';
  function ticks(min,max,count=5){
    if(!Number.isFinite(min)||!Number.isFinite(max))return {valid:false,values:[],labels:[]};
    if(max<min)[min,max]=[max,min];
    if(max===min){const pad=Math.abs(min)*.1||1;min=min===0?0:min-pad;max+=pad;}
    const raw=(max-min)/Math.max(2,count-1),power=10**Math.floor(Math.log10(raw)),fraction=raw/power;
    const step=(fraction<=1?1:fraction<=2?2:fraction<=2.5?2.5:fraction<=5?5:10)*power;
    const first=Math.ceil(min/step-1e-10),last=Math.floor(max/step+1e-10),values=[];
    for(let i=first;i<=last&&values.length<100;i++)values.push(+(i*step).toPrecision(13));
    const digits=Math.max(0,Math.min(12,Math.ceil(-Math.log10(step))+1));
    const format=v=>{if(Math.abs(v)<step*1e-8)v=0;return v!==0&&(Math.abs(v)<1e-4||Math.abs(v)>=1e7)?v.toExponential(2):String(+v.toFixed(digits));};
    return {valid:true,values,labels:values.map(format),step,min,max,format};
  }
  function leverBalance(tensionN,cableArmM,handleArmM){
    if(![tensionN,cableArmM,handleArmM].every(Number.isFinite)||tensionN<0||cableArmM<0||handleArmM<=0)return {valid:false,reason:'Nonnegative tension/arm and positive handle arm required'};
    const torqueNm=tensionN*cableArmM;
    return {valid:true,tensionN,cableArmM,handleArmM,torqueNm,handleForceN:torqueNm/handleArmM};
  }
  function angleBetween(a,b){const len=Math.hypot(a.x,a.y,a.z||0)*Math.hypot(b.x,b.y,b.z||0);return len?Math.acos(Math.max(-1,Math.min(1,(a.x*b.x+a.y*b.y+(a.z||0)*(b.z||0))/len))):null;}
  const api={ticks,leverBalance,angleBetween};
  if(typeof module==='object'&&module.exports)module.exports=api;else (global.BM=global.BM||{}).Education=api;
})(typeof window==='object'?window:globalThis);
