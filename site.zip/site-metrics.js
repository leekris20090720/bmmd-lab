/* Local, in-memory diagnostics. No identities, URLs, persistence or transmission. */
(function(){'use strict';
  const m={firstContentfulPaintMs:null,longTasks:0,longTaskTotalMs:0,longestTaskMs:0,modelReadyMs:null,modelBuildMs:null,frames:0,frameP50Ms:null,frameP95Ms:null},root=document.documentElement;
  const write=()=>root.dataset.bmPerformance=JSON.stringify(m);
  try{new PerformanceObserver(list=>{for(const e of list.getEntries())if(e.name==='first-contentful-paint')m.firstContentfulPaintMs=+e.startTime.toFixed(1);write();}).observe({type:'paint',buffered:true});new PerformanceObserver(list=>{for(const e of list.getEntries()){m.longTasks++;m.longTaskTotalMs=+(m.longTaskTotalMs+e.duration).toFixed(1);m.longestTaskMs=Math.max(m.longestTaskMs,+e.duration.toFixed(1));}write();}).observe({type:'longtask',buffered:true});}catch{}
  const frames=[];let previous=0,until=performance.now()+12000,raf=0;
  function sample(now){raf=0;if(previous&&!document.hidden)frames.push(now-previous);previous=now;if(now<until){raf=requestAnimationFrame(sample);return;}const sorted=frames.filter(v=>v>0).sort((a,b)=>a-b);m.frames=sorted.length;m.frameP50Ms=sorted.length?+sorted[Math.floor((sorted.length-1)*.5)].toFixed(2):null;m.frameP95Ms=sorted.length?+sorted[Math.floor((sorted.length-1)*.95)].toFixed(2):null;write();}
  raf=requestAnimationFrame(sample);
  document.addEventListener('visibilitychange',()=>{previous=0;if(document.hidden){cancelAnimationFrame(raf);raf=0;}else if(performance.now()<until&&!raf)raf=requestAnimationFrame(sample);});
  document.addEventListener('bm:model-ready',event=>{m.modelReadyMs=event.detail.ms;m.modelBuildMs=event.detail.buildMs;write();});
  document.addEventListener('DOMContentLoaded',()=>{const canvas=document.getElementById('digital-twin-canvas');if(!canvas)return;const observer=new MutationObserver(()=>{if(canvas.dataset.modelStatus==='ready'){if(m.modelReadyMs===null)m.modelReadyMs=+performance.now().toFixed(1);write();observer.disconnect();}});observer.observe(canvas,{attributes:true,attributeFilter:['data-model-status']});});write();
})();
