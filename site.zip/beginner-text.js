/* Pure local text-plan parsing. No storage, network, load or equipment inference. */
(function () {
  'use strict';

  const limits = Object.freeze({ textLength: 50000, lines: 500, lineLength: 2000, days: 31, rowsPerDay: 100 });
  const week = { '一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '日': 7, '天': 7 };
  const dash = '[-–—~～至]';
  const before = '(?<![\\dA-Za-z.\\-–—~～至/])';
  const pairPattern = before + '(\\d+)\\s*(?:组\\s*(?:[×xX*✕]\\s*)?|[×xX*✕]\\s*)(\\d+)(?:\\s*' + dash + '\\s*(\\d+))?(?:\\s*(次))?';
  const setPattern = before + '(\\d+)\\s*组';
  const repPattern = before + '(\\d+)(?:\\s*' + dash + '\\s*(\\d+))?\\s*次';

  function normalized(value) {
    return value.normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();
  }

  function matchingNames(catalog) {
    const entries = Array.isArray(catalog) ? catalog : [
      ...(Array.isArray(catalog?.actions) ? catalog.actions : []),
      ...(Array.isArray(catalog?.homeActions) ? catalog.homeActions : []),
    ];
    const index = new Map();
    for (const action of entries) {
      if (!action || typeof action.id !== 'string' || !action.id.trim()) continue;
      const names = [action.name, ...(Array.isArray(action.aliases) ? action.aliases : [])];
      for (const value of names) {
        if (typeof value !== 'string' || !value.trim()) continue;
        const key = normalized(value);
        if (!index.has(key)) index.set(key, new Set());
        index.get(key).add(action.id);
      }
    }
    return index;
  }

  function undecorated(line) {
    return line.normalize('NFKC').trim()
      .replace(/^#{1,6}\s+/, '')
      .replace(/^(?:[-*+•·]\s+|\d{1,3}[.、]\s+|\(\d{1,3}\)\s+)/, '')
      .trim();
  }

  function cleanName(value) {
    return value.trim().replace(/[：:|,，;；]\s*$/, '').replace(/\s+[-–—]\s*$/, '').trim();
  }

  function cleanNotes(value) {
    return value.trim().replace(/^[：:|,，;；]+\s*/, '').trim();
  }

  function wholeQuantity(line, match) {
    if (/[A-Za-z][+-]$/.test(line.slice(0, match.index))) return false;
    const tail = line.slice(match.index + match[0].length);
    // Reject partial numbers and physical units, e.g. 3x10.5, 3x10kg or 3x10秒.
    if (/^[\dA-Za-z.]/.test(tail)) return false;
    if (/^\s*[-–—~～至/]\s*\d/.test(tail)) return false;
    if (/^\s*(?:kg|lb|lbs|cm|mm|公斤|千克|克|磅|厘米|毫米|秒|分钟)(?:\b|$|[^A-Za-z])/i.test(tail)) return false;
    return true;
  }

  function matches(line, pattern) {
    const found = [];
    const regex = new RegExp(pattern, 'g');
    let match;
    while ((match = regex.exec(line))) {
      if (wholeQuantity(line, match)) found.push(match);
    }
    return found;
  }

  function positive(value) {
    const number = Number(value);
    return Number.isSafeInteger(number) && number > 0 ? number : null;
  }

  function quantities(line) {
    const pairs = matches(line, pairPattern);
    if (pairs.length) {
      if (pairs.length !== 1) return null; // A compound prescription needs human editing.
      const m = pairs[0], sets = positive(m[1]), min = positive(m[2]), max = positive(m[3] || m[2]);
      if (sets == null || min == null || max == null || min > max) return null;
      return { sets, repsMin: min, repsMax: max, spans: [{ start: m.index, end: m.index + m[0].length }] };
    }
    const setMatches = matches(line, setPattern), repMatches = matches(line, repPattern);
    if (setMatches.length > 1 || repMatches.length > 1 || (!setMatches.length && !repMatches.length)) return null;
    const sets = setMatches.length ? positive(setMatches[0][1]) : null;
    const min = repMatches.length ? positive(repMatches[0][1]) : null;
    const max = repMatches.length ? positive(repMatches[0][2] || repMatches[0][1]) : null;
    if ((setMatches.length && sets == null) || (repMatches.length && (min == null || max == null || min > max))) return null;
    return { sets, repsMin: min, repsMax: max, spans: [...setMatches, ...repMatches]
      .map(m => ({ start: m.index, end: m.index + m[0].length })).sort((a, b) => a.start - b.start) };
  }

  function heading(line) {
    const chinese = /^(?:周|星期|礼拜)([一二三四五六日天1-7])(?!\d)/.exec(line);
    const english = /^day\s*(\d+)(?![\dA-Za-z]|\.\d)/i.exec(line);
    const numbered = /^第\s*(?:[1-9]\d*|[一二三四五六七八九十]+)\s*[天日]/.test(line);
    if (!chinese && !(english && positive(english[1])) && !numbered) return null;
    // A weekday prefix attached to a prescription, even an invalid count, remains a row.
    if (new RegExp(before + '\\d+\\s*(?:组|[×xX*✕]\\s*\\d|次)').test(line)) return null;
    return chinese ? { title: line, weekday: week[chinese[1]] || Number(chinese[1]) } : { title: line };
  }

  function row(original, line, index) {
    const dose = quantities(line);
    let name = line, notes = '';
    if (dose) {
      const first = dose.spans[0];
      name = line.slice(0, first.start);
      let remaining = line.slice(first.end), offset = first.end;
      // Remove any separate, explicitly labelled quantity after the first token.
      for (const span of dose.spans.slice(1).reverse()) {
        remaining = remaining.slice(0, span.start - offset) + remaining.slice(span.end - offset);
      }
      if (name.trim().endsWith('(') && remaining.trimStart().startsWith(')')) {
        name = name.trimEnd().slice(0, -1);
        remaining = remaining.trimStart().slice(1);
      }
      if (!name.trim()) { name = remaining; remaining = ''; }
      name = cleanName(name); notes = cleanNotes(remaining);
    }
    name = cleanName(name);
    const ids = index.get(normalized(name));
    return {
      original, name, sets: dose?.sets ?? null,
      repsMin: dose?.repsMin ?? null, repsMax: dose?.repsMax ?? null,
      notes, actionId: ids?.size === 1 ? [...ids][0] : null,
    };
  }

  function parse(text, catalog) {
    if (typeof text !== 'string') throw new TypeError('课表应为文字。');
    if (text.length > limits.textLength) throw new RangeError('课表超过50000字，请分段粘贴。');
    const lines = text.split(/\r\n|\r|\n/);
    if (lines.length > limits.lines) throw new RangeError('课表超过500行，请分段粘贴。');
    const days = [], index = matchingNames(catalog);
    let current = null;
    for (let number = 0; number < lines.length; number++) {
      const original = lines[number];
      if (original.length > limits.lineLength) throw new RangeError('第' + (number + 1) + '行超过2000字，请拆成多行。');
      const line = undecorated(original);
      if (!line) continue;
      const title = heading(line);
      if (title) {
        if (days.length >= limits.days) throw new RangeError('课表超过31个训练日，请分成多个计划。');
        current = { ...title, rows: [] }; days.push(current);
        continue;
      }
      if (!current) { current = { title: '未指定训练日', rows: [] }; days.push(current); }
      if (current.rows.length >= limits.rowsPerDay) throw new RangeError('单个训练日超过100行，请拆分训练日。');
      current.rows.push(row(original, line, index));
    }
    return { days };
  }

  const api = Object.freeze({ parse, limits });
  if (typeof window !== 'undefined') { window.BM ||= {}; window.BM.textPlan = api; }
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
