/* Local action catalog. Focused teaching text has a source-specific review scope. */
(() => {
  "use strict";
  const catalog = {
  "version": 1,
  "status": "installed_local",
  "reviewedAt": "2026-10-14",
  "actions": [
    {
      "id": "arm",
      "sceneKey": "arm",
      "name": "滑轮侧平举",
      "aliases": [
        "侧平举",
        "绳索侧平举",
        "肩部侧举",
        "OP-DAP",
        "Life Fitness OP-DAP 双塔可调滑轮训练器",
        "OP-DAP 双塔可调滑轮侧平举"
      ],
      "group": "shoulder",
      "target": "三角肌中束",
      "equipmentKey": "cable",
      "equipmentId": "life-fitness-op-dap",
      "model": "Life Fitness OP-DAP 双塔可调滑轮训练器",
      "equipmentName": "Life Fitness OP-DAP 双塔可调滑轮训练器",
      "image": "assets/equipment-reference/op-dap.png",
      "officialUrl": "https://shop.lifefitness.com/products/axiom-dual-adjustable-pulley",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "滑轮侧平举",
          "group": "shoulder"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（单侧配重塔标示值）",
      "loadBasis": "per_stack_nominal",
      "sides": [
        "left",
        "right"
      ],
      "includesMachineBase": false,
      "note": "左右不同就分别记录，记录使用侧；2:1只描述当前型号机械结构，不自动把标重除二写成个人工作重量。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides",
              "dap-manual"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "OP-DAP 有两座配重塔，厂家标示 2:1 阻力比；记录配重塔标示值，不把模型换算当训练能力。",
            "sourceIds": [
              "equipment-arm"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "滑轮设为低位并扣好握把，确认锁销、配重插销和连接扣扣牢；双侧训练设为同高、同重量。",
            "sourceIds": [
              "equipment-arm",
              "dap-manual",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "单侧：侧身靠近一塔，远侧手握住低位握把，手在靠塔侧髋前。",
            "双侧可各握一个低位握把；双脚约肩宽，重心均匀。"
          ],
          "text": "单侧：侧身靠近一塔，远侧手握住低位握把，手在靠塔侧髋前。 双侧可各握一个低位握把；双脚约肩宽，重心均匀。",
          "sourceIds": [
            "ace-cable-lateral"
          ],
          "reviewStatus": "focused_text_reviewed",
          "reviewLabel": "通用动作文字已核对"
        },
        {
          "phase": "work",
          "label": "发力",
          "cues": [
            "肘保持微弯，把上臂向侧面平稳抬到约肩高。",
            "双脚站稳，保留起始的肘部微弯。"
          ],
          "text": "肘保持微弯，把上臂向侧面平稳抬到约肩高。 双脚站稳，保留起始的肘部微弯。",
          "sourceIds": [
            "ace-cable-lateral"
          ],
          "reviewStatus": "focused_text_reviewed",
          "reviewLabel": "通用动作文字已核对"
        },
        {
          "phase": "return",
          "label": "返回",
          "cues": [
            "沿原路缓慢放回起始位置。",
            "单侧做完后换另一侧，分别记下两侧记录。"
          ],
          "text": "沿原路缓慢放回起始位置。 单侧做完后换另一侧，分别记下两侧记录。",
          "sourceIds": [
            "ace-cable-lateral"
          ],
          "reviewStatus": "focused_text_reviewed",
          "reviewLabel": "通用动作文字已核对"
        }
      ],
      "cue": "低位握把，肘微弯，抬到肩高慢回。",
      "cautions": [
        "本文的侧平举提示不等于OP-DAP所有动作的使用说明。",
        "无法稳定慢回时先减轻重量；滑轮档位仍以实物牌示为准。"
      ],
      "teachingSources": [
        {
          "id": "equipment-arm",
          "title": "Life Fitness OP-DAP 双塔可调滑轮训练器 厂家资料",
          "url": "https://shop.lifefitness.com/products/axiom-dual-adjustable-pulley",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-DAP 有两座配重塔，厂家标示 2:1 阻力比；记录配重塔标示值，不把模型换算当训练能力。"
        },
        {
          "id": "dap-manual",
          "title": "Life Fitness OP-DAP 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360039412093-Life-Fitness-Axiom-OP-DAP-Dual-Adjustable-Pulley-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1013248-0001；型号操作全文待核对"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        },
        {
          "id": "ace-cable-lateral",
          "title": "ACE：滑轮侧平举（Certified News 2009，第9页）",
          "url": "https://contentcdn.eacefitness.com/cp/pdfs/CertifiedNews/AugSept09Cert.pdf#page=9",
          "scope": "已读官方期刊的低位、单侧站位、肘微弯、肩高终点、慢回及双侧选项。错误条目是据这些要求编写的文字自查例子；未复制原图或创建人体示范。",
          "kind": "professional_exercise_instruction",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "primary_text_reviewed",
          "reviewLabel": "通用文字已核对；自查例子由要求整理"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Life Fitness OP-DAP 官方使用手册",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360039412093-Life-Fitness-Axiom-OP-DAP-Dual-Adjustable-Pulley-Owner-s-Manual",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "ACE 绳索训练：侧平举",
          "url": "https://www.acefitness.org/cp/pdfs/CertifiedNews/AugSept09Cert.pdf",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "2:1 钢索传动 · 固定双塔机架",
        "editableKeys": [
          "pulleyLeftPercent",
          "pulleyRightPercent"
        ],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "focused_text_reviewed",
        "reviewedAt": "2026-10-14",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "text_examples_only",
        "authorizedAnimation": false,
        "note": "文字按 ACE 官方期刊侧平举段落核对，型号结构参考 OP-DAP 官方资料；具体锁销与实物版本操作仍待现场确认。没有人体动画或姿势检测。",
        "label": "重点文字已核对",
        "scope": "滑轮侧平举通用文字、厂家结构信息及文字自查例子。",
        "shortNote": "可看器械示意、读文字步骤；暂无经核实的人体演示。",
        "modelVersionNote": "按现有型号资料编写；实物版本、调节档位和保护装置仍应以现场牌示为准。",
        "resourceScope": "现有器械实物图与模型；文字自查例子。暂无经核实且获授权的人体教学素材。"
      },
      "sources": [
        {
          "id": "equipment-arm",
          "title": "Life Fitness OP-DAP 双塔可调滑轮训练器 厂家资料",
          "url": "https://shop.lifefitness.com/products/axiom-dual-adjustable-pulley",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-DAP 有两座配重塔，厂家标示 2:1 阻力比；记录配重塔标示值，不把模型换算当训练能力。"
        },
        {
          "id": "dap-manual",
          "title": "Life Fitness OP-DAP 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360039412093-Life-Fitness-Axiom-OP-DAP-Dual-Adjustable-Pulley-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1013248-0001；型号操作全文待核对"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        },
        {
          "id": "ace-cable-lateral",
          "title": "ACE：滑轮侧平举（Certified News 2009，第9页）",
          "url": "https://contentcdn.eacefitness.com/cp/pdfs/CertifiedNews/AugSept09Cert.pdf#page=9",
          "scope": "已读官方期刊的低位、单侧站位、肘微弯、肩高终点、慢回及双侧选项。错误条目是据这些要求编写的文字自查例子；未复制原图或创建人体示范。",
          "kind": "professional_exercise_instruction",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "primary_text_reviewed",
          "reviewLabel": "通用文字已核对；自查例子由要求整理"
        }
      ],
      "setup": {
        "general": [
          "先确认器械名称、配重塔标示单位和所用握把。",
          "器械静止后设为低位，检查滑轮锁销、配重销与连接扣固定。"
        ],
        "model": [
          "OP-DAP左右配重独立，厂家标示2:1阻力比；训练记录仍按实物标示口径填写。",
          "单侧先确认所在侧和训练手；双侧时分别接握把，不自动换算一侧与双侧重量。"
        ]
      },
      "teachingFocus": true,
      "identification": {
        "label": "认出双塔可调滑轮",
        "points": [
          "左右各一座配重塔，握把连在可以升降的滑轮上。",
          "侧平举使用低位单手握把；这台双塔也能做其他动作。"
        ],
        "imageLabel": "现有 OP-DAP 器械实物照片；照片中的滑轮位置不代表侧平举准备位置",
        "sourceIds": [
          "equipment-arm",
          "ace-cable-lateral"
        ]
      },
      "commonErrors": [
        {
          "title": "越抬越弯肘",
          "example": "动作变成用弯肘把绳索拉向身体。",
          "correction": "保持起始的肘部微弯，以手臂向侧面抬起完成动作。",
          "phase": "work",
          "sourceIds": [
            "ace-cable-lateral"
          ],
          "kind": "text_self_check_example",
          "observed": false,
          "note": "文字自查例子；网站没有检测你的身体动作。"
        },
        {
          "title": "身体随握把侧倒",
          "example": "侧举时重心移到一只脚，身体明显倾斜。",
          "correction": "重心均匀留在两脚，减轻重量后平稳侧举。",
          "phase": "work",
          "sourceIds": [
            "ace-cable-lateral"
          ],
          "kind": "text_self_check_example",
          "observed": false,
          "note": "文字自查例子；网站没有检测你的身体动作。"
        },
        {
          "title": "抬过肩高后快速落下",
          "example": "借惯性把手甩高，再突然放松。",
          "correction": "先以约肩高为终点，沿原路缓慢降低。",
          "phase": "return",
          "sourceIds": [
            "ace-cable-lateral"
          ],
          "kind": "text_self_check_example",
          "observed": false,
          "note": "文字自查例子；网站没有检测你的身体动作。"
        }
      ]
    },
    {
      "id": "cam",
      "sceneKey": "cam",
      "name": "坐姿腿屈伸",
      "aliases": [
        "膝伸展",
        "坐姿踢腿",
        "腿伸展",
        "OP-LE",
        "Life Fitness Axiom OP-LE 膝伸展机",
        "Life Fitness Axiom OP-LE 膝伸展机"
      ],
      "group": "legs",
      "target": "股四头肌",
      "equipmentKey": "selectorized",
      "equipmentId": "life-fitness-axiom-op-le",
      "model": "Life Fitness Axiom OP-LE 膝伸展机",
      "equipmentName": "Life Fitness Axiom OP-LE 膝伸展机",
      "image": "assets/equipment-reference/op-le.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-leg-extension",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "坐姿腿屈伸",
          "group": "legs"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（当前器械标称配重）",
      "loadBasis": "machine_nominal",
      "sides": [
        "machine"
      ],
      "includesMachineBase": false,
      "note": "按实物标示记录；相同kg在不同型号不能自动视为相同训练能力。若实物使用lb须记录原单位。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides",
              "axiom-manual"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "OP-LE 官方页列出可调靠背和小腿垫；按实物牌示对齐后检查固定。",
            "sourceIds": [
              "equipment-cam"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "调靠背让膝关节对准器械转轴，小腿垫放在脚踝上方；选轻重量并插牢配重销。",
            "sourceIds": [
              "equipment-cam",
              "axiom-manual",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "坐稳靠背，双手握住座椅侧把手。",
            "膝关节对齐转轴，小腿垫位于脚踝上方。"
          ],
          "text": "坐稳靠背，双手握住座椅侧把手。 膝关节对齐转轴，小腿垫位于脚踝上方。",
          "sourceIds": [
            "axiom-op-le-excerpt"
          ],
          "reviewStatus": "focused_text_reviewed",
          "reviewLabel": "OP-LE相关段落已核对；实物版本待确认"
        },
        {
          "phase": "work",
          "label": "发力",
          "cues": [
            "平稳抬起小腿，伸到膝接近伸直。",
            "保持动作顺畅，不把膝关节猛锁死。"
          ],
          "text": "平稳抬起小腿，伸到膝接近伸直。 保持动作顺畅，不把膝关节猛锁死。",
          "sourceIds": [
            "mayo-knee-extension",
            "axiom-op-le-excerpt"
          ],
          "reviewStatus": "focused_text_reviewed",
          "reviewLabel": "通用动作文字已核对"
        },
        {
          "phase": "return",
          "label": "返回",
          "cues": [
            "缓慢屈膝回到起始位置，再开始下一次。",
            "保持坐姿稳定，避免配重突然落下。"
          ],
          "text": "缓慢屈膝回到起始位置，再开始下一次。 保持坐姿稳定，避免配重突然落下。",
          "sourceIds": [
            "mayo-knee-extension",
            "axiom-op-le-excerpt"
          ],
          "reviewStatus": "focused_text_reviewed",
          "reviewLabel": "通用动作文字已核对"
        }
      ],
      "cue": "对齐转轴，平稳伸膝，慢慢回。",
      "cautions": [
        "不靠猛踢或突然锁膝完成动作。",
        "有不适时停止本组；这里的文字和模型不判断疼痛原因。"
      ],
      "teachingSources": [
        {
          "id": "equipment-cam",
          "title": "Life Fitness Axiom OP-LE 膝伸展机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-leg-extension",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-LE 官方页列出可调靠背和小腿垫；按实物牌示对齐后检查固定。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        },
        {
          "id": "mayo-knee-extension",
          "title": "Mayo Clinic：机器膝伸展文字稿",
          "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/knee-extension/vid-20084686",
          "scope": "已读官方文字稿：平稳伸膝、避免锁膝、受控完整返回。该页为视频页面，本轮只核验文字；未采用其组次数建议或个体医疗判断。",
          "kind": "professional_exercise_instruction",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "primary_text_reviewed",
          "reviewLabel": "通用文字已核对；视频未播放核验"
        },
        {
          "id": "axiom-op-le-excerpt",
          "title": "Life Fitness：OP-LE 操作段落（手册第48页）",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=48",
          "scope": "核对官方PDF索引中的膝对齐转轴、小腿垫位置、扶手和受控伸膝段落；不是整册审核或实机认证。",
          "kind": "manufacturer_manual",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "official_indexed_section_reviewed",
          "reviewLabel": "相关段落已核对；实物版本待确认"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Life Fitness Axiom 官方使用手册",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "ACE 膝伸展：躯干稳定与缓慢伸膝",
          "url": "https://www.acefitness.org/getfit/studies/FunctionFitness.pdf",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "Life Fitness OP-LE 官方靠背与胫骨垫说明",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-leg-extension",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "预设凸轮轮廓 · 固定转轴与传动结构",
        "editableKeys": [],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "focused_text_reviewed",
        "reviewedAt": "2026-10-14",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "text_examples_only",
        "authorizedAnimation": false,
        "note": "重点文字按 Mayo Clinic 文字稿与 OP-LE 手册相关段落核对。Mayo页面视频未播放核验；没有人体动画、错误对照图或姿势检测。",
        "label": "重点文字已核对",
        "scope": "机器腿屈伸通用文字、OP-LE准备段落及文字自查例子。",
        "shortNote": "可看器械示意、读文字步骤；暂无经核实的人体演示。",
        "modelVersionNote": "按现有型号资料编写；实物版本、调节档位和保护装置仍应以现场牌示为准。",
        "resourceScope": "现有器械实物图与模型；文字自查例子。暂无经核实且获授权的人体教学素材。"
      },
      "sources": [
        {
          "id": "equipment-cam",
          "title": "Life Fitness Axiom OP-LE 膝伸展机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-leg-extension",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-LE 官方页列出可调靠背和小腿垫；按实物牌示对齐后检查固定。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        },
        {
          "id": "mayo-knee-extension",
          "title": "Mayo Clinic：机器膝伸展文字稿",
          "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/knee-extension/vid-20084686",
          "scope": "已读官方文字稿：平稳伸膝、避免锁膝、受控完整返回。该页为视频页面，本轮只核验文字；未采用其组次数建议或个体医疗判断。",
          "kind": "professional_exercise_instruction",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "primary_text_reviewed",
          "reviewLabel": "通用文字已核对；视频未播放核验"
        },
        {
          "id": "axiom-op-le-excerpt",
          "title": "Life Fitness：OP-LE 操作段落（手册第48页）",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=48",
          "scope": "核对官方PDF索引中的膝对齐转轴、小腿垫位置、扶手和受控伸膝段落；不是整册审核或实机认证。",
          "kind": "manufacturer_manual",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "official_indexed_section_reviewed",
          "reviewLabel": "相关段落已核对；实物版本待确认"
        }
      ],
      "setup": {
        "general": [
          "先确认器械名称和标示单位，选择能平稳控制的练习重量。",
          "器械静止后调节；开始前检查靠背、小腿垫和配重销固定。"
        ],
        "model": [
          "调靠背，让膝关节与器械转轴对齐。",
          "小腿垫放在脚踝上方的舒适位置；坐稳、背靠垫、握住侧把手。"
        ]
      },
      "teachingFocus": true,
      "identification": {
        "label": "认出腿屈伸机",
        "points": [
          "座椅前方有小腿滚垫，座椅两侧有扶手。",
          "这里是 OP-LE：靠背与小腿垫可以按实物调节。"
        ],
        "imageLabel": "现有 OP-LE 器械实物照片",
        "sourceIds": [
          "equipment-cam"
        ]
      },
      "commonErrors": [
        {
          "title": "膝没有对齐器械转轴",
          "example": "坐下后膝的位置明显偏离机器的转动中心。",
          "correction": "先停下，按当前型号调靠背并重新对齐；不确定时请现场工作人员确认。",
          "phase": "prepare",
          "sourceIds": [
            "axiom-op-le-excerpt"
          ],
          "kind": "text_self_check_example",
          "observed": false,
          "note": "文字自查例子；网站没有检测你的身体动作。"
        },
        {
          "title": "末端猛锁膝",
          "example": "把小腿快速踢起，最后一下撞到直腿。",
          "correction": "减慢抬起速度，在接近伸直时受控停住。",
          "phase": "work",
          "sourceIds": [
            "mayo-knee-extension"
          ],
          "kind": "text_self_check_example",
          "observed": false,
          "note": "文字自查例子；网站没有检测你的身体动作。"
        },
        {
          "title": "返回只走一小段",
          "example": "每次只在靠近伸直的位置来回弹动。",
          "correction": "按舒适的原起始位置受控返回；不为了幅度强压不适的关节。",
          "phase": "return",
          "sourceIds": [
            "mayo-knee-extension"
          ],
          "kind": "text_self_check_example",
          "observed": false,
          "note": "文字自查例子；网站没有检测你的身体动作。"
        }
      ]
    },
    {
      "id": "incline",
      "sceneKey": "incline",
      "name": "45°倒蹬",
      "aliases": [
        "腿举",
        "倒蹬机",
        "斜板腿举",
        "HSLLP",
        "Hammer Strength HSLLP 45° 线性倒蹬机",
        "Hammer Strength 45° 线性倒蹬机"
      ],
      "group": "legs",
      "target": "臀腿",
      "equipmentKey": "plate-loaded",
      "equipmentId": "hammer-strength-hsllp-model-version-unconfirmed",
      "model": "Hammer Strength HSLLP 45° 线性倒蹬机",
      "equipmentName": "Hammer Strength HSLLP 45° 线性倒蹬机",
      "image": "assets/equipment-reference/hsllp.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-linear-leg-press",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "45°倒蹬",
          "group": "legs"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "barbell-squat"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（所有工作挂片轴新增片重合计）",
      "loadBasis": "total_added_plates",
      "sides": [
        "total"
      ],
      "includesMachineBase": false,
      "note": "不含滑车、储片杆；模型45kg仅示例，当前官网53kg起始阻力不能当滑车质量直接相加。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "HSLLP 当前官方页列出45°导轨、挂回机构、可调靠背和行程；现有模型版本与当前产品页未完全对应。",
            "sourceIds": [
              "equipment-incline"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "先确认滑车挂在承重挂钩上，认清保险把手；左右对称装片，初次先用空车或轻负荷。",
            "sourceIds": [
              "equipment-incline",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "背和臀贴住靠垫，双脚放在踏板上；稍伸腿托住滑车，再按器械标示解除挂钩。"
          ],
          "text": "背和臀贴住靠垫，双脚放在踏板上；稍伸腿托住滑车，再按器械标示解除挂钩。",
          "sourceIds": [
            "equipment-incline",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "控制滑车下降到背臀仍贴垫的位置，再用全脚掌推回；膝盖随脚尖方向移动。"
          ],
          "text": "控制滑车下降到背臀仍贴垫的位置，再用全脚掌推回；膝盖随脚尖方向移动。",
          "sourceIds": [
            "equipment-incline",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "结束时先推到能重新挂回的位置，复位保险把手并缓慢落车；确认挂钩承重后再移开双脚。"
          ],
          "text": "结束时先推到能重新挂回的位置，复位保险把手并缓慢落车；确认挂钩承重后再移开双脚。",
          "sourceIds": [
            "equipment-incline",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "背臀贴垫、全脚踩稳；结束先挂牢。",
      "cautions": [
        "不要猛锁膝、抬脚跟或下放到骨盆卷起离垫；下降深度以能保持姿势为限。",
        "第一次请现场教练演示挂钩和限位装置；滑车尚未挂牢时不要起身或拿开脚。"
      ],
      "teachingSources": [
        {
          "id": "equipment-incline",
          "title": "Hammer Strength HSLLP 45° 线性倒蹬机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-linear-leg-press",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "HSLLP 当前官方页列出45°导轨、挂回机构、可调靠背和行程；现有模型版本与当前产品页未完全对应。"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Hammer Strength HSLLP 官方产品与挂钩说明",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-linear-leg-press",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "ACE 腿举动作指导",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/154/seated-leg-press/",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "45° 导轨 · 预设滑车与脚踏结构",
        "editableKeys": [],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-incline",
          "title": "Hammer Strength HSLLP 45° 线性倒蹬机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-linear-leg-press",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "HSLLP 当前官方页列出45°导轨、挂回机构、可调靠背和行程；现有模型版本与当前产品页未完全对应。"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "HSLLP 当前官方页列出45°导轨、挂回机构、可调靠背和行程；现有模型版本与当前产品页未完全对应。",
          "先确认滑车挂在承重挂钩上，认清保险把手；左右对称装片，初次先用空车或轻负荷。"
        ]
      }
    },
    {
      "id": "pec",
      "sceneKey": "pec",
      "name": "器械胸飞鸟",
      "aliases": [
        "胸飞鸟",
        "后束飞鸟",
        "反向飞鸟",
        "OP-FLY",
        "Life Fitness Axiom OP-FLY 胸飞鸟 / 后束机",
        "Life Fitness Axiom OP-FLY 胸飞鸟 / 后束机"
      ],
      "group": "chest",
      "target": "胸大肌",
      "equipmentKey": "selectorized",
      "equipmentId": "life-fitness-axiom-op-fly",
      "model": "Life Fitness Axiom OP-FLY 胸飞鸟 / 后束机",
      "equipmentName": "Life Fitness Axiom OP-FLY 胸飞鸟 / 后束机",
      "image": "assets/equipment-reference/op-fly.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-pectoral-fly-rear-deltoid",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "chest-fly",
          "name": "胸飞鸟",
          "group": "chest"
        },
        {
          "id": "rear-delt-fly",
          "name": "后束飞鸟",
          "group": "shoulder"
        }
      ],
      "defaultVariant": "chest-fly",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "machine-fly",
        "cable-fly"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（当前器械标称配重）",
      "loadBasis": "machine_nominal",
      "sides": [
        "machine"
      ],
      "includesMachineBase": false,
      "note": "按实物标示记录；相同kg在不同型号不能自动视为相同训练能力。若实物使用lb须记录原单位。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides",
              "axiom-manual"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "OP-FLY 为胸飞鸟／后束双动作机；切换模式和起始档位的操作需核对当前实物牌示。",
            "sourceIds": [
              "equipment-pec"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "选轻重量并锁好起始档位：胸飞鸟设较宽起点、背靠垫；后束设靠前起点、面朝垫。",
            "sourceIds": [
              "equipment-pec",
              "axiom-manual",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "调座椅让握把略低于肩，双脚站稳；胸飞鸟握竖把，后束握横把，肘保持微弯。"
          ],
          "text": "调座椅让握把略低于肩，双脚站稳；胸飞鸟握竖把，后束握横把，肘保持微弯。",
          "sourceIds": [
            "equipment-pec",
            "axiom-manual",
            "ace-fly",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "胸飞鸟把双手向前合拢；后束保持胸部贴垫，将双手向两侧打开。"
          ],
          "text": "胸飞鸟把双手向前合拢；后束保持胸部贴垫，将双手向两侧打开。",
          "sourceIds": [
            "equipment-pec",
            "axiom-manual",
            "ace-fly",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "沿原路慢慢返回，在能控制的范围内重复，别甩动转臂或让配重砸落。"
          ],
          "text": "沿原路慢慢返回，在能控制的范围内重复，别甩动转臂或让配重砸落。",
          "sourceIds": [
            "equipment-pec",
            "axiom-manual",
            "ace-fly",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "胸飞鸟向前合拢，后束向两侧打开。",
      "cautions": [
        "不要耸肩、挺腰或硬把手臂拉到身后；打开到肩部舒适的位置即可。",
        "切换胸飞鸟与后束前，先让配重落稳，再确认两侧起始档位锁住。"
      ],
      "teachingSources": [
        {
          "id": "equipment-pec",
          "title": "Life Fitness Axiom OP-FLY 胸飞鸟 / 后束机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-pectoral-fly-rear-deltoid",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-FLY 为胸飞鸟／后束双动作机；切换模式和起始档位的操作需核对当前实物牌示。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "ace-fly",
          "title": "ACE 站姿钢索飞鸟",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/160/standing-chest-fly/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "站姿钢索飞鸟一般动作；不能当 SS-PEC 或 OP-FLY 的型号操作手册"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Life Fitness Axiom 官方使用手册",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "ACE 通用飞鸟动作：肘微弯、慢速合拢与回放",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/160/standing-chest-fly/",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "Life Fitness OP-FLY 官方双动作说明",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-pectoral-fly-rear-deltoid",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "预设独立凸轮 · 铰接式握把",
        "editableKeys": [
          "seatHeightCm",
          "startOpenDeg"
        ],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-pec",
          "title": "Life Fitness Axiom OP-FLY 胸飞鸟 / 后束机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-pectoral-fly-rear-deltoid",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-FLY 为胸飞鸟／后束双动作机；切换模式和起始档位的操作需核对当前实物牌示。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "ace-fly",
          "title": "ACE 站姿钢索飞鸟",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/160/standing-chest-fly/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "站姿钢索飞鸟一般动作；不能当 SS-PEC 或 OP-FLY 的型号操作手册"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "OP-FLY 为胸飞鸟／后束双动作机；切换模式和起始档位的操作需核对当前实物牌示。",
          "选轻重量并锁好起始档位：胸飞鸟设较宽起点、背靠垫；后束设靠前起点、面朝垫。"
        ]
      }
    },
    {
      "id": "lat",
      "sceneKey": "lat",
      "name": "固定转臂高位下拉",
      "aliases": [
        "高位下拉",
        "下拉",
        "背阔肌下拉",
        "OP-PD",
        "Life Fitness Axiom OP-PD 高位下拉机",
        "Life Fitness Axiom OP-PD 固定转臂高位下拉机"
      ],
      "group": "back",
      "target": "背阔肌",
      "equipmentKey": "selectorized",
      "equipmentId": "life-fitness-axiom-op-pd",
      "model": "Life Fitness Axiom OP-PD 高位下拉机",
      "equipmentName": "Life Fitness Axiom OP-PD 高位下拉机",
      "image": "assets/equipment-reference/op-pd.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-lat-pulldown",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "固定转臂高位下拉",
          "group": "back"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "scissor-pulldown",
        "cable-pulldown"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（当前器械标称配重）",
      "loadBasis": "machine_nominal",
      "sides": [
        "machine"
      ],
      "includesMachineBase": false,
      "note": "按实物标示记录；相同kg在不同型号不能自动视为相同训练能力。若实物使用lb须记录原单位。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides",
              "axiom-manual"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "OP-PD 有可调座椅，但压腿垫为固定结构；不得按通用下拉教学把固定压腿垫改成可调项。",
            "sourceIds": [
              "equipment-lat"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "选轻重量并插牢配重销；调整座椅，让坐下后大腿稳在固定压腿垫下方。",
            "sourceIds": [
              "equipment-lat",
              "axiom-manual",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "握稳长握把，坐下让大腿稳在压腿垫下方。",
            "背部保持自然，躯干按本型号牌示略向前。"
          ],
          "text": "握稳长握把，坐下让大腿稳在压腿垫下方。 背部保持自然，躯干按本型号牌示略向前。",
          "sourceIds": [
            "axiom-op-pd-excerpt"
          ],
          "reviewStatus": "focused_text_reviewed",
          "reviewLabel": "OP-PD相关段落已核对；实物版本待确认"
        },
        {
          "phase": "work",
          "label": "发力",
          "cues": [
            "顺着固定转臂轨迹拉下，双手到约肩高。",
            "肘向下收，躯干保持稳定。"
          ],
          "text": "顺着固定转臂轨迹拉下，双手到约肩高。 肘向下收，躯干保持稳定。",
          "sourceIds": [
            "axiom-op-pd-excerpt",
            "ace-lat"
          ],
          "reviewStatus": "focused_text_reviewed",
          "reviewLabel": "型号段落与通用稳定提示已核对"
        },
        {
          "phase": "return",
          "label": "返回",
          "cues": [
            "受控让握把回升，手肘逐渐伸直。",
            "保持握稳，不用身体摆动带动回程。"
          ],
          "text": "受控让握把回升，手肘逐渐伸直。 保持握稳，不用身体摆动带动回程。",
          "sourceIds": [
            "axiom-op-pd-excerpt",
            "ace-lat"
          ],
          "reviewStatus": "focused_text_reviewed",
          "reviewLabel": "通用动作文字已核对"
        }
      ],
      "cue": "大腿稳住，肘向下收，握把慢回。",
      "cautions": [
        "OP-PD握把沿固定轨迹运动，通用横杆“拉到胸前”的终点不能直接套用。",
        "不靠大幅后仰抢拉；不要放手让握把弹回。"
      ],
      "teachingSources": [
        {
          "id": "equipment-lat",
          "title": "Life Fitness Axiom OP-PD 高位下拉机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-lat-pulldown",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-PD 有可调座椅，但压腿垫为固定结构；不得按通用下拉教学把固定压腿垫改成可调项。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "ace-lat",
          "title": "ACE：坐姿横杆下拉",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/158/seated-lat-pulldown/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "仅采用肘向下、躯干稳定与缓慢回程等共通提示；ACE自由横杆的后倾角度、拉胸终点和可调大腿垫不用于OP-PD。",
          "reviewedAt": "2026-10-14",
          "reviewLabel": "通用文字已核对；部分细节不适用于本型号"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        },
        {
          "id": "axiom-op-pd-excerpt",
          "title": "Life Fitness：OP-PD 操作段落（手册第50页）",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=50",
          "scope": "核对官方PDF索引中的坐入、躯干略前倾、握把至肩高及受控返回段落；不是整册审核或现场版本认证。",
          "kind": "manufacturer_manual",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "official_indexed_section_reviewed",
          "reviewLabel": "相关段落已核对；实物版本待确认"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Life Fitness Axiom 官方使用手册",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "Life Fitness Axiom OP-PD 官方座椅与压腿垫说明",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-lat-pulldown",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "ACE 下拉：肘向下、躯干稳定与受控回程",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/158/seated-lat-pulldown/",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "固定转臂 · 预设握把与钢索传动结构",
        "editableKeys": [],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "focused_text_reviewed",
        "reviewedAt": "2026-10-14",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "text_examples_only",
        "authorizedAnimation": false,
        "note": "OP-PD相关段落已核对；动作路径以固定转臂为准。ACE自由横杆教学只作共通提示，未移植其后倾角度、拉胸终点和压腿垫调节。没有人体动画或姿势检测。",
        "label": "重点文字已核对",
        "scope": "OP-PD专属准备和动作段落、通用稳定提示及文字自查例子。",
        "shortNote": "可看器械示意、读文字步骤；暂无经核实的人体演示。",
        "modelVersionNote": "按现有型号资料编写；实物版本、调节档位和保护装置仍应以现场牌示为准。",
        "resourceScope": "现有器械实物图与模型；文字自查例子。暂无经核实且获授权的人体教学素材。"
      },
      "sources": [
        {
          "id": "equipment-lat",
          "title": "Life Fitness Axiom OP-PD 高位下拉机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-lat-pulldown",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-PD 有可调座椅，但压腿垫为固定结构；不得按通用下拉教学把固定压腿垫改成可调项。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "ace-lat",
          "title": "ACE：坐姿横杆下拉",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/158/seated-lat-pulldown/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "仅采用肘向下、躯干稳定与缓慢回程等共通提示；ACE自由横杆的后倾角度、拉胸终点和可调大腿垫不用于OP-PD。",
          "reviewedAt": "2026-10-14",
          "reviewLabel": "通用文字已核对；部分细节不适用于本型号"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        },
        {
          "id": "axiom-op-pd-excerpt",
          "title": "Life Fitness：OP-PD 操作段落（手册第50页）",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=50",
          "scope": "核对官方PDF索引中的坐入、躯干略前倾、握把至肩高及受控返回段落；不是整册审核或现场版本认证。",
          "kind": "manufacturer_manual",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "official_indexed_section_reviewed",
          "reviewLabel": "相关段落已核对；实物版本待确认"
        }
      ],
      "setup": {
        "general": [
          "先确认器械名称和标示单位，选择能平稳控制的练习重量。",
          "器械静止后调节座椅并检查配重销；确认能安全坐入和起身。"
        ],
        "model": [
          "OP-PD压腿垫为固定结构；通过调座椅让大腿位于垫下。",
          "站起握稳长握把，受控拉低后坐下；按本型号牌示保持背部自然、从髋部稍向前。"
        ]
      },
      "teachingFocus": true,
      "identification": {
        "label": "认出固定转臂下拉机",
        "points": [
          "上方是连在转臂上的长握把，座位前有压腿垫。",
          "这里是 OP-PD：调座椅配合固定压腿垫。"
        ],
        "imageLabel": "现有 OP-PD 器械实物照片",
        "sourceIds": [
          "equipment-lat"
        ]
      },
      "commonErrors": [
        {
          "title": "把固定压腿垫当作可调项",
          "example": "找不到压腿垫档位，仍尝试扳动固定结构。",
          "correction": "确认型号；OP-PD通过调座椅配合压腿垫。",
          "phase": "prepare",
          "sourceIds": [
            "equipment-lat"
          ],
          "kind": "text_self_check_example",
          "observed": false,
          "note": "文字自查例子；网站没有检测你的身体动作。"
        },
        {
          "title": "身体后仰抢拉",
          "example": "每一下都先把身体向后甩，再拉握把。",
          "correction": "降低重量并稳定坐姿，让肘沿器械轨迹向下运动。",
          "phase": "work",
          "sourceIds": [
            "ace-lat"
          ],
          "kind": "text_self_check_example",
          "observed": false,
          "note": "文字自查例子；网站没有检测你的身体动作。"
        },
        {
          "title": "回程失去控制",
          "example": "握把快速向上弹，身体被一起拉起。",
          "correction": "保持握稳，逐渐伸肘并减慢返回速度。",
          "phase": "return",
          "sourceIds": [
            "ace-lat",
            "axiom-op-pd-excerpt"
          ],
          "kind": "text_self_check_example",
          "observed": false,
          "note": "文字自查例子；网站没有检测你的身体动作。"
        }
      ]
    },
    {
      "id": "barbell-squat",
      "sceneKey": "barbell-squat",
      "name": "杠铃深蹲",
      "aliases": [
        "自由深蹲",
        "背蹲",
        "深蹲架",
        "HD Athletic NX",
        "Hammer Strength HD Athletic NX 四柱力量架",
        "Hammer Strength HD Athletic NX 四柱力量架"
      ],
      "group": "legs",
      "target": "股四头/臀/竖脊肌",
      "equipmentKey": "barbell",
      "equipmentId": "hammer-strength-hd-athletic-nx",
      "model": "Hammer Strength HD Athletic NX 四柱力量架",
      "equipmentName": "Hammer Strength HD Athletic NX 四柱力量架",
      "image": "assets/equipment-reference/nx-rack.jpg",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/racks-rigs-platforms/hd-athletic-nx-power-rack",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "杠铃深蹲",
          "group": "legs"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "incline"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（杠铃总重量，含实际杠铃杆）",
      "loadBasis": "barbell_total",
      "sides": [
        "total"
      ],
      "includesMachineBase": true,
      "note": "杆重未确认时标记未知，不能默认20kg；记录整根杆与两侧片重合计。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "当前模型为 HD Athletic NX 架和自由杠铃；J杯及保护装置按现场器械说明检查，不推荐个人档位。",
            "sourceIds": [
              "equipment-barbell-squat"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "J 杯调到略低于肩；保护杆或安全带设在计划最低点略下方并锁牢，先用空杆练习。",
            "sourceIds": [
              "equipment-barbell-squat",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "钻到杠下，让杠落在上背肌肉上；握紧杠、站起出架，再小步后退站稳。"
          ],
          "text": "钻到杠下，让杠落在上背肌肉上；握紧杠、站起出架，再小步后退站稳。",
          "sourceIds": [
            "equipment-barbell-squat",
            "ace-squat",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "收紧腹部，屈髋屈膝向下蹲；脚跟不抬起，膝盖沿脚尖方向移动，下降到能控制的位置。"
          ],
          "text": "收紧腹部，屈髋屈膝向下蹲；脚跟不抬起，膝盖沿脚尖方向移动，下降到能控制的位置。",
          "sourceIds": [
            "equipment-barbell-squat",
            "ace-squat",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "全脚掌压地，髋和胸一起起身；结束后向前回架，确认杠铃两端都落入 J 杯再松手。"
          ],
          "text": "全脚掌压地，髋和胸一起起身；结束后向前回架，确认杠铃两端都落入 J 杯再松手。",
          "sourceIds": [
            "equipment-barbell-squat",
            "ace-squat",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "收紧腹部、全脚压地，髋胸一起起身。",
      "cautions": [
        "杠不要压在颈椎上；别为了蹲深而弓背、脚跟离地或让膝盖向内塌。",
        "初次负重请教练检查保护装置并协助保护；姿势开始失控就结束该组。"
      ],
      "teachingSources": [
        {
          "id": "equipment-barbell-squat",
          "title": "Hammer Strength HD Athletic NX 四柱力量架 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/racks-rigs-platforms/hd-athletic-nx-power-rack",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "当前模型为 HD Athletic NX 架和自由杠铃；J杯及保护装置按现场器械说明检查，不推荐个人档位。"
        },
        {
          "id": "ace-squat",
          "title": "ACE 杠铃背蹲动作库",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/11/back-squat/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "自由杠铃背蹲；原站标注 Advanced，不能改称默认新手适用"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "ACE 杠铃背蹲动作指导",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/11/back-squat/",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "Hammer Strength HD Athletic NX 官方保护装置说明",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/racks-rigs-platforms/hd-athletic-nx-power-rack",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "固定机架结构 · 自由杠铃",
        "editableKeys": [],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-barbell-squat",
          "title": "Hammer Strength HD Athletic NX 四柱力量架 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/racks-rigs-platforms/hd-athletic-nx-power-rack",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "当前模型为 HD Athletic NX 架和自由杠铃；J杯及保护装置按现场器械说明检查，不推荐个人档位。"
        },
        {
          "id": "ace-squat",
          "title": "ACE 杠铃背蹲动作库",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/11/back-squat/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "自由杠铃背蹲；原站标注 Advanced，不能改称默认新手适用"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "当前模型为 HD Athletic NX 架和自由杠铃；J杯及保护装置按现场器械说明检查，不推荐个人档位。",
          "J 杯调到略低于肩；保护杆或安全带设在计划最低点略下方并锁牢，先用空杆练习。"
        ]
      }
    },
    {
      "id": "cable-row",
      "sceneKey": "cable-row",
      "name": "坐姿器械划船",
      "aliases": [
        "坐姿划船",
        "拉背",
        "低位划船",
        "OP-RW",
        "Life Fitness Axiom OP-RW 坐姿划船机",
        "Life Fitness Axiom OP-RW 坐姿划船机"
      ],
      "group": "back",
      "target": "背阔/菱形肌",
      "equipmentKey": "selectorized",
      "equipmentId": "life-fitness-axiom-op-rw",
      "model": "Life Fitness Axiom OP-RW 坐姿划船机",
      "equipmentName": "Life Fitness Axiom OP-RW 坐姿划船机",
      "image": "assets/equipment-reference/op-rw.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-seated-row",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "坐姿器械划船",
          "group": "back"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "hammer-row"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（当前器械标称配重）",
      "loadBasis": "machine_nominal",
      "sides": [
        "machine"
      ],
      "includesMachineBase": false,
      "note": "按实物标示记录；相同kg在不同型号不能自动视为相同训练能力。若实物使用lb须记录原单位。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides",
              "axiom-manual"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "OP-RW 有自调节握把和斜面脚踏；不要把脚踏或固定转轴当作模型中任意可调参数。",
            "sourceIds": [
              "equipment-cable-row"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "双脚放在斜面脚踏上，膝盖微弯，坐直并握住自调节握把；确认配重选择到位。",
            "sourceIds": [
              "equipment-cable-row",
              "axiom-manual",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "抬头、胸部自然挺起，保持背部稳定，双臂向前伸到自己能控制的位置。"
          ],
          "text": "抬头、胸部自然挺起，保持背部稳定，双臂向前伸到自己能控制的位置。",
          "sourceIds": [
            "equipment-cable-row",
            "axiom-manual",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "双脚持续压住脚踏，平稳拉回握把，让手肘随动作向身后移动。"
          ],
          "text": "双脚持续压住脚踏，平稳拉回握把，让手肘随动作向身后移动。",
          "sourceIds": [
            "equipment-cable-row",
            "axiom-manual",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "控制握把返回起始位置，躯干保持稳定，避免配重猛落。"
          ],
          "text": "控制握把返回起始位置，躯干保持稳定，避免配重猛落。",
          "sourceIds": [
            "equipment-cable-row",
            "axiom-manual",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "脚踩稳，肘向后拉，握把慢慢送回。",
      "cautions": [
        "不要靠躯干大幅前后摆动把重量拉起来。",
        "不要为追求更远的回拉而耸肩或弓背，保持手腕随握把自然对齐。"
      ],
      "teachingSources": [
        {
          "id": "equipment-cable-row",
          "title": "Life Fitness Axiom OP-RW 坐姿划船机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-seated-row",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-RW 有自调节握把和斜面脚踏；不要把脚踏或固定转轴当作模型中任意可调参数。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Life Fitness Axiom 厂家使用手册：OP-RW（第51页）",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "Life Fitness Axiom OP-RW 厂家产品页",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-seated-row",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "固定脚踏与转轴 · 自调节握把",
        "editableKeys": [],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-cable-row",
          "title": "Life Fitness Axiom OP-RW 坐姿划船机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-seated-row",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-RW 有自调节握把和斜面脚踏；不要把脚踏或固定转轴当作模型中任意可调参数。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "OP-RW 有自调节握把和斜面脚踏；不要把脚踏或固定转轴当作模型中任意可调参数。",
          "双脚放在斜面脚踏上，膝盖微弯，坐直并握住自调节握把；确认配重选择到位。"
        ]
      }
    },
    {
      "id": "barbell-bench",
      "sceneKey": "barbell-bench",
      "name": "杠铃平板卧推",
      "aliases": [
        "卧推",
        "平板卧推",
        "卧推架",
        "O-FB",
        "Hammer Strength O-FB 奥林匹克平板卧推架",
        "Hammer Strength O-FB Olympic Flat Bench"
      ],
      "group": "chest",
      "target": "胸大肌",
      "equipmentKey": "barbell",
      "equipmentId": "hammer-strength-o-fb",
      "model": "Hammer Strength O-FB 奥林匹克平板卧推架",
      "equipmentName": "Hammer Strength O-FB 奥林匹克平板卧推架",
      "image": "assets/equipment-reference/o-fb.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/benches/olympic-flat-bench",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "杠铃平板卧推",
          "group": "chest"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "flat-press",
        "incline-press"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（杠铃总重量，含实际杠铃杆）",
      "loadBasis": "barbell_total",
      "sides": [
        "total"
      ],
      "includesMachineBase": true,
      "note": "杆重未确认时标记未知，不能默认20kg；记录整根杆与两侧片重合计。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "O-FB 为平板卧推架；杠铃、承杠钩和保护人员的准备按实际场地确认。",
            "sourceIds": [
              "equipment-barbell-bench"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "确认杠铃稳放在承杠钩内、杠铃片固定可靠，并安排保护同伴协助出杠和回杠；仰卧后双脚踩稳，双手全握杠铃。",
            "sourceIds": [
              "equipment-barbell-bench",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "稳定肩背与臀部的位置，在保护同伴协助下将杠铃移出承杠钩，先稳住杠铃。"
          ],
          "text": "稳定肩背与臀部的位置，在保护同伴协助下将杠铃移出承杠钩，先稳住杠铃。",
          "sourceIds": [
            "equipment-barbell-bench",
            "ace-bench",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "缓慢把杠铃降向胸前，让手肘保持在手腕下方，不用胸部弹起杠铃。"
          ],
          "text": "缓慢把杠铃降向胸前，让手肘保持在手腕下方，不用胸部弹起杠铃。",
          "sourceIds": [
            "equipment-barbell-bench",
            "ace-bench",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "脚持续踩稳，把杠铃平稳推回；结束时先稳住杠铃，再由保护同伴协助放回两侧承杠钩。"
          ],
          "text": "脚持续踩稳，把杠铃平稳推回；结束时先稳住杠铃，再由保护同伴协助放回两侧承杠钩。",
          "sourceIds": [
            "equipment-barbell-bench",
            "ace-bench",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "脚踩稳、肩背贴凳，杠铃慢放稳推。",
      "cautions": [
        "不要使用拇指不环握的握法，也不要抬臀或突然反弹借力。",
        "没有确认杠铃已可靠回到两侧承杠钩前，不要松手；初学时请保护同伴全程在旁。"
      ],
      "teachingSources": [
        {
          "id": "equipment-barbell-bench",
          "title": "Hammer Strength O-FB 奥林匹克平板卧推架 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/benches/olympic-flat-bench",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "O-FB 为平板卧推架；杠铃、承杠钩和保护人员的准备按实际场地确认。"
        },
        {
          "id": "ace-bench",
          "title": "ACE 杠铃卧推动作库",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/5/chest-press/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "自由杠铃卧推的一般动作，非 O-FB 具体档位"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Hammer Strength O-FB 厂家产品页",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/benches/olympic-flat-bench",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "ACE 动作库：杠铃卧推",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/5/chest-press/",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "ACE 杠铃卧推动作说明",
          "url": "https://www.acefitness.org/certifiednewsarticle/3003/what-are-the-top-3-most-effective-chest-exercises/",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "ACE 重量训练与保护同伴建议",
          "url": "https://www.acefitness.org/resources/everyone/blog/5502/a-woman-s-guide-to-gaining-muscle-with-weight-training/",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "固定水平卧推凳 · 自由杠铃",
        "editableKeys": [],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-barbell-bench",
          "title": "Hammer Strength O-FB 奥林匹克平板卧推架 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/benches/olympic-flat-bench",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "O-FB 为平板卧推架；杠铃、承杠钩和保护人员的准备按实际场地确认。"
        },
        {
          "id": "ace-bench",
          "title": "ACE 杠铃卧推动作库",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/5/chest-press/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "自由杠铃卧推的一般动作，非 O-FB 具体档位"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "O-FB 为平板卧推架；杠铃、承杠钩和保护人员的准备按实际场地确认。",
          "确认杠铃稳放在承杠钩内、杠铃片固定可靠，并安排保护同伴协助出杠和回杠；仰卧后双脚踩稳，双手全握杠铃。"
        ]
      }
    },
    {
      "id": "flat-press",
      "sceneKey": "flat-press",
      "name": "坐姿器械推胸",
      "aliases": [
        "推胸",
        "胸推",
        "平板推胸",
        "OP-CP",
        "Life Fitness Axiom OP-CP 选择式推胸机",
        "Life Fitness Axiom OP-CP Chest Press"
      ],
      "group": "chest",
      "target": "胸大肌",
      "equipmentKey": "selectorized",
      "equipmentId": "life-fitness-axiom-op-cp",
      "model": "Life Fitness Axiom OP-CP 选择式推胸机",
      "equipmentName": "Life Fitness Axiom OP-CP 选择式推胸机",
      "image": "assets/equipment-reference/op-cp.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-chest-press",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "坐姿器械推胸",
          "group": "chest"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "barbell-bench",
        "incline-press"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（当前器械标称配重）",
      "loadBasis": "machine_nominal",
      "sides": [
        "machine"
      ],
      "includesMachineBase": false,
      "note": "按实物标示记录；相同kg在不同型号不能自动视为相同训练能力。若实物使用lb须记录原单位。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides",
              "axiom-manual"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "OP-CP 有可调座椅和两种握法，靠背和转臂轨迹固定。",
            "sourceIds": [
              "equipment-flat-press"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "调好座椅，使握把接近胸部中间高度；肩部贴靠背垫，握稳一组握把，确认配重选择到位。",
            "sourceIds": [
              "equipment-flat-press",
              "axiom-manual",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "背靠垫、脚踩稳；握把在胸部中间高度。",
            "肩膀保持向后、向下，手腕自然伸直。"
          ],
          "text": "背靠垫、脚踩稳；握把在胸部中间高度。 肩膀保持向后、向下，手腕自然伸直。",
          "sourceIds": [
            "axiom-op-cp-excerpt",
            "ace-chest-press",
            "nasm-chest-press"
          ],
          "reviewStatus": "focused_text_reviewed",
          "reviewLabel": "通用动作文字已核对"
        },
        {
          "phase": "work",
          "label": "发力",
          "cues": [
            "平稳向前推，手臂逐渐伸直，肘不猛锁死。",
            "推起时呼气；背和肩保持稳定。"
          ],
          "text": "平稳向前推，手臂逐渐伸直，肘不猛锁死。 推起时呼气；背和肩保持稳定。",
          "sourceIds": [
            "ace-chest-press",
            "nasm-chest-press"
          ],
          "reviewStatus": "focused_text_reviewed",
          "reviewLabel": "通用动作文字已核对"
        },
        {
          "phase": "return",
          "label": "返回",
          "cues": [
            "慢慢弯肘，让握把受控回到起点。",
            "肩背继续贴垫，避免突然弹回。"
          ],
          "text": "慢慢弯肘，让握把受控回到起点。 肩背继续贴垫，避免突然弹回。",
          "sourceIds": [
            "ace-chest-press",
            "nasm-chest-press"
          ],
          "reviewStatus": "focused_text_reviewed",
          "reviewLabel": "通用动作文字已核对"
        }
      ],
      "cue": "背靠垫，平稳推，缓慢回。",
      "cautions": [
        "动作靠惯性或腰部明显拱起时，先降低重量重新准备。",
        "动作幅度不舒服时停止调整，不靠强推到末端完成次数。"
      ],
      "teachingSources": [
        {
          "id": "equipment-flat-press",
          "title": "Life Fitness Axiom OP-CP 选择式推胸机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-chest-press",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-CP 有可调座椅和两种握法，靠背和转臂轨迹固定。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        },
        {
          "id": "ace-chest-press",
          "title": "ACE：坐姿推胸",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/188/seated-chest-press/",
          "scope": "通用坐姿推胸的稳定姿势、呼气推起、肘不锁死与受控返回；本轮核对官方索引文字。",
          "kind": "professional_exercise_instruction",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "primary_text_reviewed",
          "reviewLabel": "通用文字已核对"
        },
        {
          "id": "nasm-chest-press",
          "title": "NASM：器械推胸步骤与常见错误",
          "url": "https://www.nasm.org/resource-center/exercise-library/chest-press-machine",
          "scope": "已读官方文字步骤及错误清单；没有采用固定45°肘角或该页组次数建议。视频链接未播放核验。",
          "kind": "professional_exercise_instruction",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "primary_text_reviewed",
          "reviewLabel": "通用文字已核对"
        },
        {
          "id": "axiom-op-cp-excerpt",
          "title": "Life Fitness：OP-CP 操作段落（手册第46页）",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=46",
          "scope": "核对官方PDF索引中的OP-CP准备与运动段落；不是整册审核，也未核验现场实物版本。",
          "kind": "manufacturer_manual",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "official_indexed_section_reviewed",
          "reviewLabel": "相关段落已核对；实物版本待确认"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Life Fitness Axiom 厂家使用手册：OP-CP（第46页）",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "Life Fitness Axiom OP-CP 厂家产品页",
          "url": "https://www.lifefitness.com/en-gb/catalog/strength-training/selectorized/axiom-series-chest-press",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "固定靠背与推柄结构 · 预设转臂轨迹",
        "editableKeys": [
          "seatHeightCm"
        ],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "focused_text_reviewed",
        "reviewedAt": "2026-10-14",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "text_examples_only",
        "authorizedAnimation": false,
        "note": "重点文字按 ACE、NASM 和 OP-CP 手册相关段落核对；未核验现场实物版本，也没有人体动画或姿势检测。",
        "label": "重点文字已核对",
        "scope": "坐姿推胸的通用文字、OP-CP相关准备段落及文字自查例子。",
        "shortNote": "可看器械示意、读文字步骤；暂无经核实的人体演示。",
        "modelVersionNote": "按现有型号资料编写；实物版本、调节档位和保护装置仍应以现场牌示为准。",
        "resourceScope": "现有器械实物图与模型；文字自查例子。暂无经核实且获授权的人体教学素材。"
      },
      "sources": [
        {
          "id": "equipment-flat-press",
          "title": "Life Fitness Axiom OP-CP 选择式推胸机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-chest-press",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-CP 有可调座椅和两种握法，靠背和转臂轨迹固定。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        },
        {
          "id": "ace-chest-press",
          "title": "ACE：坐姿推胸",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/188/seated-chest-press/",
          "scope": "通用坐姿推胸的稳定姿势、呼气推起、肘不锁死与受控返回；本轮核对官方索引文字。",
          "kind": "professional_exercise_instruction",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "primary_text_reviewed",
          "reviewLabel": "通用文字已核对"
        },
        {
          "id": "nasm-chest-press",
          "title": "NASM：器械推胸步骤与常见错误",
          "url": "https://www.nasm.org/resource-center/exercise-library/chest-press-machine",
          "scope": "已读官方文字步骤及错误清单；没有采用固定45°肘角或该页组次数建议。视频链接未播放核验。",
          "kind": "professional_exercise_instruction",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "primary_text_reviewed",
          "reviewLabel": "通用文字已核对"
        },
        {
          "id": "axiom-op-cp-excerpt",
          "title": "Life Fitness：OP-CP 操作段落（手册第46页）",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=46",
          "scope": "核对官方PDF索引中的OP-CP准备与运动段落；不是整册审核，也未核验现场实物版本。",
          "kind": "manufacturer_manual",
          "reviewedAt": "2026-10-14",
          "reviewStatus": "official_indexed_section_reviewed",
          "reviewLabel": "相关段落已核对；实物版本待确认"
        }
      ],
      "setup": {
        "general": [
          "先确认器械名称和标示单位，选择能平稳控制的练习重量。",
          "器械静止后调节；开始前检查座椅固定、配重销插到位。"
        ],
        "model": [
          "调座椅，使握把约在胸部中间高度。",
          "坐稳后背靠垫、双脚踩稳；握住一组手位，手肘略低于肩。"
        ]
      },
      "teachingFocus": true,
      "identification": {
        "label": "认出坐姿推胸机",
        "points": [
          "有座椅与长靠背，左右握把位于胸前。",
          "这里是 OP-CP：座椅可调，握把提供两种手位。"
        ],
        "imageLabel": "现有 OP-CP 器械实物照片",
        "sourceIds": [
          "equipment-flat-press"
        ]
      },
      "commonErrors": [
        {
          "title": "腰部拱起抢推",
          "example": "推的时候背明显离开靠垫。",
          "correction": "先减轻重量，重新靠稳后平缓推起。",
          "phase": "work",
          "sourceIds": [
            "ace-chest-press",
            "nasm-chest-press"
          ],
          "kind": "text_self_check_example",
          "observed": false,
          "note": "文字自查例子；网站没有检测你的身体动作。"
        },
        {
          "title": "肘部猛锁死",
          "example": "快到末端时突然撞直手臂。",
          "correction": "把末端也控制住，肘接近伸直时停止猛推。",
          "phase": "work",
          "sourceIds": [
            "nasm-chest-press"
          ],
          "kind": "text_self_check_example",
          "observed": false,
          "note": "文字自查例子；网站没有检测你的身体动作。"
        },
        {
          "title": "握把快速弹回",
          "example": "返回时突然松力，身体也跟着前倾。",
          "correction": "保持握稳，慢慢弯肘并留住肩背位置。",
          "phase": "return",
          "sourceIds": [
            "ace-chest-press",
            "nasm-chest-press"
          ],
          "kind": "text_self_check_example",
          "observed": false,
          "note": "文字自查例子；网站没有检测你的身体动作。"
        }
      ]
    },
    {
      "id": "incline-press",
      "sceneKey": "incline-press",
      "name": "上斜器械推胸",
      "aliases": [
        "上斜推胸",
        "悍马上斜推",
        "IL-IP",
        "Hammer Strength IL-IP Iso-Lateral 上斜推胸机",
        "上斜片加载推胸"
      ],
      "group": "chest",
      "target": "上胸/前三角",
      "equipmentKey": "plate-loaded",
      "equipmentId": "hammer-strength-il-ip",
      "model": "Hammer Strength IL-IP Iso-Lateral 上斜推胸机",
      "equipmentName": "Hammer Strength IL-IP Iso-Lateral 上斜推胸机",
      "image": "assets/equipment-reference/il-ip.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-incline-press",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "上斜器械推胸",
          "group": "chest"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "flat-press",
        "barbell-bench"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（每侧工作臂新增装片）",
      "loadBasis": "per_arm_added_plates",
      "sides": [
        "left",
        "right"
      ],
      "includesMachineBase": false,
      "note": "分别记录左右新增片重；不把储片杆的片重计入，也不把空臂起始阻力自动并入。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "IL-IP 为左右独立工作臂，装片按每侧工作臂分别记录；固定靠背倾角不能任意改。",
            "sourceIds": [
              "equipment-incline-press"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "确认两侧工作臂的杠铃片固定可靠；坐稳并靠住背垫，握住横向握把，让起始手柄接近胸部中间或略高的位置。",
            "sourceIds": [
              "equipment-incline-press",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "胸部自然挺起，手肘略低于肩部，手腕与前臂保持对齐。"
          ],
          "text": "胸部自然挺起，手肘略低于肩部，手腕与前臂保持对齐。",
          "sourceIds": [
            "equipment-incline-press",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "保持躯干稳定，让两侧独立工作臂沿器械上斜轨迹平稳伸展。"
          ],
          "text": "保持躯干稳定，让两侧独立工作臂沿器械上斜轨迹平稳伸展。",
          "sourceIds": [
            "equipment-incline-press",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "慢慢弯肘把握把送回起始位置，两侧都保持控制。"
          ],
          "text": "慢慢弯肘把握把送回起始位置，两侧都保持控制。",
          "sourceIds": [
            "equipment-incline-press",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "肩背靠稳，沿上斜轨迹推起、慢回。",
      "cautions": [
        "不要耸肩、抬臀或用腰部反弓抢推。",
        "不要把杠铃片装在储片杆上当作工作阻力；装卸前先让工作臂回到稳定位置。"
      ],
      "teachingSources": [
        {
          "id": "equipment-incline-press",
          "title": "Hammer Strength IL-IP Iso-Lateral 上斜推胸机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-incline-press",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "IL-IP 为左右独立工作臂，装片按每侧工作臂分别记录；固定靠背倾角不能任意改。"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Hammer Strength IL-IP 厂家产品页",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-incline-press",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "Hammer Strength Iso-Lateral 厂家手册：上斜推胸（转载，第18页）",
          "url": "https://www.manualslib.com/manual/1070990/Hammer-Strength-Iso-Lateral.html?page=18",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "ACE 动作库：上斜推胸的身体与手腕稳定",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/25/incline-chest-press/",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "预设上斜靠背 · 左右分动杠杆",
        "editableKeys": [],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-incline-press",
          "title": "Hammer Strength IL-IP Iso-Lateral 上斜推胸机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-incline-press",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "IL-IP 为左右独立工作臂，装片按每侧工作臂分别记录；固定靠背倾角不能任意改。"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "IL-IP 为左右独立工作臂，装片按每侧工作臂分别记录；固定靠背倾角不能任意改。",
          "确认两侧工作臂的杠铃片固定可靠；坐稳并靠住背垫，握住横向握把，让起始手柄接近胸部中间或略高的位置。"
        ]
      }
    },
    {
      "id": "cable-fly",
      "sceneKey": "cable-fly",
      "name": "滑轮夹胸",
      "aliases": [
        "绳索夹胸",
        "龙门架夹胸",
        "站姿飞鸟",
        "OP-DAP",
        "Life Fitness OP-DAP 双侧可调滑轮夹胸",
        "双塔绳索夹胸"
      ],
      "group": "chest",
      "target": "胸大肌",
      "equipmentKey": "cable",
      "equipmentId": "life-fitness-op-dap",
      "model": "Life Fitness OP-DAP 双侧可调滑轮夹胸",
      "equipmentName": "Life Fitness OP-DAP 双侧可调滑轮夹胸",
      "image": "assets/equipment-reference/op-dap.png",
      "officialUrl": "https://shop.lifefitness.com/products/axiom-dual-adjustable-pulley",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "滑轮夹胸",
          "group": "chest"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "pec",
        "machine-fly"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（单侧配重塔标示值）",
      "loadBasis": "per_stack_nominal",
      "sides": [
        "left",
        "right"
      ],
      "includesMachineBase": false,
      "note": "左右不同就分别记录，记录使用侧；2:1只描述当前型号机械结构，不自动把标重除二写成个人工作重量。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides",
              "dap-manual"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "OP-DAP 的双侧钢索与配重塔分别使用；滑轮位置只作示意，不给真实档位数字。",
            "sourceIds": [
              "equipment-cable-fly"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "把双侧滑轮设在肩部附近或略高的位置，确认滑轮车锁销完全入位、握把连接可靠；握住两侧把手，前后错步站稳。",
            "sourceIds": [
              "equipment-cable-fly",
              "dap-manual",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "向前站到钢索有张力的位置，躯干保持稳定，手肘微弯，双臂向两侧打开。"
          ],
          "text": "向前站到钢索有张力的位置，躯干保持稳定，手肘微弯，双臂向两侧打开。",
          "sourceIds": [
            "equipment-cable-fly",
            "dap-manual",
            "ace-fly",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "保持手肘弯曲幅度大致不变，把两只握把沿弧线带到身体前方。"
          ],
          "text": "保持手肘弯曲幅度大致不变，把两只握把沿弧线带到身体前方。",
          "sourceIds": [
            "equipment-cable-fly",
            "dap-manual",
            "ace-fly",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "控制双臂慢慢打开，回到可控制的起始位置，不让钢索把身体拉回去。"
          ],
          "text": "控制双臂慢慢打开，回到可控制的起始位置，不让钢索把身体拉回去。",
          "sourceIds": [
            "equipment-cable-fly",
            "dap-manual",
            "ace-fly",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "站稳、肘微弯，画弧合拢再慢慢打开。",
      "cautions": [
        "不要甩手、过度交叉双手或靠身体大幅前后摆动夹胸。",
        "每次调整滑轮高度后，都先确认锁销已完全卡入，再开始拉动钢索。"
      ],
      "teachingSources": [
        {
          "id": "equipment-cable-fly",
          "title": "Life Fitness OP-DAP 双侧可调滑轮夹胸 厂家资料",
          "url": "https://shop.lifefitness.com/products/axiom-dual-adjustable-pulley",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-DAP 的双侧钢索与配重塔分别使用；滑轮位置只作示意，不给真实档位数字。"
        },
        {
          "id": "dap-manual",
          "title": "Life Fitness OP-DAP 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360039412093-Life-Fitness-Axiom-OP-DAP-Dual-Adjustable-Pulley-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1013248-0001；型号操作全文待核对"
        },
        {
          "id": "ace-fly",
          "title": "ACE 站姿钢索飞鸟",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/160/standing-chest-fly/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "站姿钢索飞鸟一般动作；不能当 SS-PEC 或 OP-FLY 的型号操作手册"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Life Fitness OP-DAP 厂家使用手册（第27页）",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/AI_OP_DAP_Dual_Adj_Pulley_1013248-0001_English.pdf",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "ACE 动作库：站姿绳索夹胸",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/160/standing-chest-fly/",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "ACE 绳索夹胸：站姿和弧线动作",
          "url": "https://www.acefitness.org/certifiednewsarticle/3003/what-are-the-top-3-most-effective-chest-exercises/",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "2:1 钢索传动 · 固定双塔机架",
        "editableKeys": [
          "pulleyHeightCm"
        ],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-cable-fly",
          "title": "Life Fitness OP-DAP 双侧可调滑轮夹胸 厂家资料",
          "url": "https://shop.lifefitness.com/products/axiom-dual-adjustable-pulley",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-DAP 的双侧钢索与配重塔分别使用；滑轮位置只作示意，不给真实档位数字。"
        },
        {
          "id": "dap-manual",
          "title": "Life Fitness OP-DAP 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360039412093-Life-Fitness-Axiom-OP-DAP-Dual-Adjustable-Pulley-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1013248-0001；型号操作全文待核对"
        },
        {
          "id": "ace-fly",
          "title": "ACE 站姿钢索飞鸟",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/160/standing-chest-fly/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "站姿钢索飞鸟一般动作；不能当 SS-PEC 或 OP-FLY 的型号操作手册"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "OP-DAP 的双侧钢索与配重塔分别使用；滑轮位置只作示意，不给真实档位数字。",
          "把双侧滑轮设在肩部附近或略高的位置，确认滑轮车锁销完全入位、握把连接可靠；握住两侧把手，前后错步站稳。"
        ]
      }
    },
    {
      "id": "machine-fly",
      "sceneKey": "machine-fly",
      "name": "蝴蝶机夹胸",
      "aliases": [
        "器械夹胸",
        "固定飞鸟",
        "蝴蝶机",
        "SS-PEC",
        "Life Fitness Insignia SS-PEC 蝶式胸肌训练机",
        "Life Fitness Insignia SS-PEC 蝶式胸肌训练机"
      ],
      "group": "chest",
      "target": "胸大肌",
      "equipmentKey": "selectorized",
      "equipmentId": "life-fitness-insignia-ss-pec",
      "model": "Life Fitness Insignia SS-PEC 蝶式胸肌训练机",
      "equipmentName": "Life Fitness Insignia SS-PEC 蝶式胸肌训练机",
      "image": "assets/equipment-reference/ss-pec.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/insignia-series-pectoral-fly",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "蝴蝶机夹胸",
          "group": "chest"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "pec",
        "cable-fly"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（当前器械标称配重）",
      "loadBasis": "machine_nominal",
      "sides": [
        "machine"
      ],
      "includesMachineBase": false,
      "note": "按实物标示记录；相同kg在不同型号不能自动视为相同训练能力。若实物使用lb须记录原单位。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides",
              "insignia-manual"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "官方产品页确认 SS-PEC 已停产；现有旧型号图和模型保留，不能把替代新型号的调整说明直接套用。",
            "sourceIds": [
              "equipment-machine-fly"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "调座椅，使握住把手时手肘略低于肩；起始打开幅度选肩部舒适的一档，锁牢并选轻重量。",
            "sourceIds": [
              "equipment-machine-fly",
              "insignia-manual",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "背靠垫、胸自然抬起，双脚踩稳；握住把手，肘保持微弯。"
          ],
          "text": "背靠垫、胸自然抬起，双脚踩稳；握住把手，肘保持微弯。",
          "sourceIds": [
            "equipment-machine-fly",
            "insignia-manual",
            "ace-fly",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "保持背肩贴垫，平稳把两侧握把向前合拢，不靠身体前冲带动。"
          ],
          "text": "保持背肩贴垫，平稳把两侧握把向前合拢，不靠身体前冲带动。",
          "sourceIds": [
            "equipment-machine-fly",
            "insignia-manual",
            "ace-fly",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "缓慢打开到设定起点，保持肩部稳定，别让配重砸落。"
          ],
          "text": "缓慢打开到设定起点，保持肩部稳定，别让配重砸落。",
          "sourceIds": [
            "equipment-machine-fly",
            "insignia-manual",
            "ace-fly",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "背肩贴垫，双手合拢，再慢慢打开。",
      "cautions": [
        "不要耸肩、挺腰或把起点开得过深；肩前侧出现刺痛就停止。",
        "调座椅或起始档位前先让配重落稳；不要在转臂运动中拔调节销。"
      ],
      "teachingSources": [
        {
          "id": "equipment-machine-fly",
          "title": "Life Fitness Insignia SS-PEC 蝶式胸肌训练机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/insignia-series-pectoral-fly",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "官方产品页确认 SS-PEC 已停产；现有旧型号图和模型保留，不能把替代新型号的调整说明直接套用。"
        },
        {
          "id": "insignia-manual",
          "title": "Life Fitness Insignia SS-PEC 手册",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/Life_Fitness_Insignia_Series_Owners_Manual_9481201_Rev_BE.pdf",
          "kind": "manufacturer_manual",
          "reviewStatus": "existing_official_link_content_pending",
          "scope": "旧型号 SS-PEC；PDF全文待核对"
        },
        {
          "id": "ace-fly",
          "title": "ACE 站姿钢索飞鸟",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/160/standing-chest-fly/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "站姿钢索飞鸟一般动作；不能当 SS-PEC 或 OP-FLY 的型号操作手册"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Life Fitness Insignia 官方使用手册：SS-PEC",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/Life_Fitness_Insignia_Series_Owners_Manual_9481201_Rev_BE.pdf",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "ACE 通用飞鸟动作：肘微弯、慢速合拢与回放",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/160/standing-chest-fly/",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "固定靠背倾角 · 预设独立凸轮",
        "editableKeys": [
          "seatHeightCm",
          "startOpenDeg"
        ],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-machine-fly",
          "title": "Life Fitness Insignia SS-PEC 蝶式胸肌训练机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/insignia-series-pectoral-fly",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "官方产品页确认 SS-PEC 已停产；现有旧型号图和模型保留，不能把替代新型号的调整说明直接套用。"
        },
        {
          "id": "insignia-manual",
          "title": "Life Fitness Insignia SS-PEC 手册",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/Life_Fitness_Insignia_Series_Owners_Manual_9481201_Rev_BE.pdf",
          "kind": "manufacturer_manual",
          "reviewStatus": "existing_official_link_content_pending",
          "scope": "旧型号 SS-PEC；PDF全文待核对"
        },
        {
          "id": "ace-fly",
          "title": "ACE 站姿钢索飞鸟",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/160/standing-chest-fly/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "站姿钢索飞鸟一般动作；不能当 SS-PEC 或 OP-FLY 的型号操作手册"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "官方产品页确认 SS-PEC 已停产；现有旧型号图和模型保留，不能把替代新型号的调整说明直接套用。",
          "调座椅，使握住把手时手肘略低于肩；起始打开幅度选肩部舒适的一档，锁牢并选轻重量。"
        ]
      }
    },
    {
      "id": "scissor-pulldown",
      "sceneKey": "scissor-pulldown",
      "name": "分动宽握下拉",
      "aliases": [
        "大剪刀",
        "大剪刀下拉",
        "宽握下拉",
        "IL-WPD",
        "Hammer Strength IL-WPD Iso-Lateral 宽握下拉机",
        "Hammer Strength IL-WPD 分动宽握下拉"
      ],
      "group": "back",
      "target": "背阔外侧",
      "equipmentKey": "plate-loaded",
      "equipmentId": "hammer-strength-il-wpd",
      "model": "Hammer Strength IL-WPD Iso-Lateral 宽握下拉机",
      "equipmentName": "Hammer Strength IL-WPD Iso-Lateral 宽握下拉机",
      "image": "assets/equipment-reference/il-wpd.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-wide-pulldown",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "分动宽握下拉",
          "group": "back"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "lat",
        "cable-pulldown"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（每侧工作臂新增装片）",
      "loadBasis": "per_arm_added_plates",
      "sides": [
        "left",
        "right"
      ],
      "includesMachineBase": false,
      "note": "分别记录左右新增片重；不把储片杆的片重计入，也不把空臂起始阻力自动并入。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "IL-WPD 为左右独立工作臂、正握握把；装片按每侧记录。",
            "sourceIds": [
              "equipment-scissor-pulldown"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "确认工作臂片重固定可靠；调好座椅和大腿垫，双脚踩地，正手握住上方把手后坐稳，让大腿处在垫下。",
            "sourceIds": [
              "equipment-scissor-pulldown",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "保持背部稳定、双脚着地，让两侧手臂进入可控制的上举位置。"
          ],
          "text": "保持背部稳定、双脚着地，让两侧手臂进入可控制的上举位置。",
          "sourceIds": [
            "equipment-scissor-pulldown",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "沿器械的宽握弧线向下拉，手肘随握把向下移动，身体保持稳定。"
          ],
          "text": "沿器械的宽握弧线向下拉，手肘随握把向下移动，身体保持稳定。",
          "sourceIds": [
            "equipment-scissor-pulldown",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "慢慢让工作臂回到上方，保持坐姿与大腿固定，不突然放手。"
          ],
          "text": "慢慢让工作臂回到上方，保持坐姿与大腿固定，不突然放手。",
          "sourceIds": [
            "equipment-scissor-pulldown",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "大腿固定，肘沿弧线下收，慢慢回升。",
      "cautions": [
        "不要靠身体大幅后仰或晃动把工作臂拽下来。",
        "不要把手柄硬拉到不舒服的范围；两侧独立运动时也要避免扭转躯干。"
      ],
      "teachingSources": [
        {
          "id": "equipment-scissor-pulldown",
          "title": "Hammer Strength IL-WPD Iso-Lateral 宽握下拉机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-wide-pulldown",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "IL-WPD 为左右独立工作臂、正握握把；装片按每侧记录。"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Hammer Strength IL-WPD 厂家产品页",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-wide-pulldown",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "Hammer Strength Iso-Lateral 厂家手册：IL-WPD（转载，第30页）",
          "url": "https://www.manualslib.com/manual/1070990/Hammer-Strength-Iso-Lateral.html?page=30",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "固定转轴与装片轴 · 左右分动杠杆",
        "editableKeys": [],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-scissor-pulldown",
          "title": "Hammer Strength IL-WPD Iso-Lateral 宽握下拉机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-wide-pulldown",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "IL-WPD 为左右独立工作臂、正握握把；装片按每侧记录。"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "IL-WPD 为左右独立工作臂、正握握把；装片按每侧记录。",
          "确认工作臂片重固定可靠；调好座椅和大腿垫，双脚踩地，正手握住上方把手后坐稳，让大腿处在垫下。"
        ]
      }
    },
    {
      "id": "nautilus-pullover",
      "sceneKey": "nautilus-pullover",
      "name": "器械直臂上拉",
      "aliases": [
        "鹦鹉螺",
        "上拉机",
        "Pullover",
        "IPPO3",
        "Nautilus Inspiration IPPO3 Pull Over 上拉机",
        "鹦鹉螺 Pullover 凸轮"
      ],
      "group": "back",
      "target": "背阔/大圆肌",
      "equipmentKey": "selectorized",
      "equipmentId": "nautilus-inspiration-ippo3",
      "model": "Nautilus Inspiration IPPO3 Pull Over 上拉机",
      "equipmentName": "Nautilus Inspiration IPPO3 Pull Over 上拉机",
      "image": "assets/equipment-reference/nautilus-pullover.png",
      "officialUrl": "https://www.corehandf.com/products/nautilus-inspiration-pull-over",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "器械直臂上拉",
          "group": "back"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（当前器械标称配重）",
      "loadBasis": "machine_nominal",
      "sides": [
        "machine"
      ],
      "includesMachineBase": false,
      "note": "按实物标示记录；相同kg在不同型号不能自动视为相同训练能力。若实物使用lb须记录原单位。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "现有模型标为IPPO3，官方URL目前为IPPO5；当前型号的脚踏、肘撑和配重操作仍待版本核对。",
            "sourceIds": [
              "equipment-nautilus-pullover"
            ],
            "reviewStatus": "model_version_mismatch"
          },
          {
            "text": "按机身图示调好座椅与起始位置，坐稳、靠住背垫并使用安全带；确认肩部位置与标示转轴相配，准备握把和肘垫。",
            "sourceIds": [
              "equipment-nautilus-pullover",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "按机身图示使用辅助脚踏进入起始位置，握稳把手，把双肘放好在肘垫上。"
          ],
          "text": "按机身图示使用辅助脚踏进入起始位置，握稳把手，把双肘放好在肘垫上。",
          "sourceIds": [
            "equipment-nautilus-pullover",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "保持躯干贴靠背垫，以上臂带动肘垫向身体前下方转动，双肘持续贴垫。"
          ],
          "text": "保持躯干贴靠背垫，以上臂带动肘垫向身体前下方转动，双肘持续贴垫。",
          "sourceIds": [
            "equipment-nautilus-pullover",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "慢慢回到可控制的起始位置；结束时按图示用辅助脚踏协助退出，确认转臂稳定后再解除安全带离开。"
          ],
          "text": "慢慢回到可控制的起始位置；结束时按图示用辅助脚踏协助退出，确认转臂稳定后再解除安全带离开。",
          "sourceIds": [
            "equipment-nautilus-pullover",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "双肘贴垫，用上臂带动转臂下压。",
      "cautions": [
        "不要靠蹬脚踏、抬臀或弯腰完成重复动作，也不要让肘垫突然把双臂拉回。",
        "首次使用请场馆教练演示辅助脚踏的进入与退出方式；不要硬拉到肩部不适的位置。"
      ],
      "teachingSources": [
        {
          "id": "equipment-nautilus-pullover",
          "title": "Nautilus Inspiration IPPO3 Pull Over 上拉机 厂家资料",
          "url": "https://www.corehandf.com/products/nautilus-inspiration-pull-over",
          "kind": "manufacturer_product",
          "reviewStatus": "official_page_model_version_mismatch",
          "scope": "现有模型标为IPPO3，官方URL目前为IPPO5；当前型号的脚踏、肘撑和配重操作仍待版本核对。"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Core Health & Fitness：Nautilus IPPO3 厂家产品说明（2020年，转载）",
          "url": "https://fitnessengros.dk/media/51/ea/4f/1607679426/Nautilus%20Inspiration%20Pull%20Over.pdf",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "预设凸轮 · 脚踏与肘撑联动机构",
        "editableKeys": [],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "model_version_review_required",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "different_current_sku",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-nautilus-pullover",
          "title": "Nautilus Inspiration IPPO3 Pull Over 上拉机 厂家资料",
          "url": "https://www.corehandf.com/products/nautilus-inspiration-pull-over",
          "kind": "manufacturer_product",
          "reviewStatus": "official_page_model_version_mismatch",
          "scope": "现有模型标为IPPO3，官方URL目前为IPPO5；当前型号的脚踏、肘撑和配重操作仍待版本核对。"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "现有模型标为IPPO3，官方URL目前为IPPO5；当前型号的脚踏、肘撑和配重操作仍待版本核对。",
          "按机身图示调好座椅与起始位置，坐稳、靠住背垫并使用安全带；确认肩部位置与标示转轴相配，准备握把和肘垫。"
        ]
      }
    },
    {
      "id": "hammer-row",
      "sceneKey": "hammer-row",
      "name": "胸托划船",
      "aliases": [
        "悍马划船",
        "器械划船",
        "胸托拉背",
        "IL-ROW",
        "Hammer Strength IL-ROW Iso-Lateral 划船机",
        "悍马 / 胸托划船"
      ],
      "group": "back",
      "target": "中背/背阔",
      "equipmentKey": "plate-loaded",
      "equipmentId": "hammer-strength-il-row",
      "model": "Hammer Strength IL-ROW Iso-Lateral 划船机",
      "equipmentName": "Hammer Strength IL-ROW Iso-Lateral 划船机",
      "image": "assets/equipment-reference/il-row.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-row",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "胸托划船",
          "group": "back"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "cable-row"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（每侧工作臂新增装片）",
      "loadBasis": "per_arm_added_plates",
      "sides": [
        "left",
        "right"
      ],
      "includesMachineBase": false,
      "note": "分别记录左右新增片重；不把储片杆的片重计入，也不把空臂起始阻力自动并入。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "IL-ROW 为胸托和左右独立工作臂，厂家按每工作臂列载荷；胸托位置按当前实物确认。",
            "sourceIds": [
              "equipment-hammer-row"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "确认两侧工作臂片重固定可靠；调好座椅，胸部贴住胸垫，双脚踩实脚踏，握住把手，让手腕与手肘的路线自然对齐。",
            "sourceIds": [
              "equipment-hammer-row",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "保持胸部贴垫，双臂向前伸到可控制的位置，先稳住身体。"
          ],
          "text": "保持胸部贴垫，双臂向前伸到可控制的位置，先稳住身体。",
          "sourceIds": [
            "equipment-hammer-row",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "平稳把握把拉向胸前，让手肘随动作向身后移动，两侧独立工作臂都保持控制。"
          ],
          "text": "平稳把握把拉向胸前，让手肘随动作向身后移动，两侧独立工作臂都保持控制。",
          "sourceIds": [
            "equipment-hammer-row",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "慢慢向前送回握把，胸部继续贴垫，回到起始位置。"
          ],
          "text": "慢慢向前送回握把，胸部继续贴垫，回到起始位置。",
          "sourceIds": [
            "equipment-hammer-row",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "胸部贴垫，肘向后拉，身体不晃。",
      "cautions": [
        "不要让胸部离开胸垫，再靠后仰或甩动身体拉重量。",
        "不要耸肩或过度掰手腕；单侧动作时也要保持躯干正对胸垫。"
      ],
      "teachingSources": [
        {
          "id": "equipment-hammer-row",
          "title": "Hammer Strength IL-ROW Iso-Lateral 划船机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-row",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "IL-ROW 为胸托和左右独立工作臂，厂家按每工作臂列载荷；胸托位置按当前实物确认。"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Hammer Strength IL-ROW 厂家产品页",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-row",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "Hammer Strength Iso-Lateral 厂家手册：IL-ROW（转载，第27页）",
          "url": "https://www.manualslib.com/manual/1070990/Hammer-Strength-Iso-Lateral.html?page=27",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "预设胸托与握把结构 · 左右分动杠杆",
        "editableKeys": [],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-hammer-row",
          "title": "Hammer Strength IL-ROW Iso-Lateral 划船机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-row",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "IL-ROW 为胸托和左右独立工作臂，厂家按每工作臂列载荷；胸托位置按当前实物确认。"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "IL-ROW 为胸托和左右独立工作臂，厂家按每工作臂列载荷；胸托位置按当前实物确认。",
          "确认两侧工作臂片重固定可靠；调好座椅，胸部贴住胸垫，双脚踩实脚踏，握住把手，让手腕与手肘的路线自然对齐。"
        ]
      }
    },
    {
      "id": "cable-pulldown",
      "sceneKey": "cable-pulldown",
      "name": "钢索下拉／低位划船",
      "aliases": [
        "组合下拉",
        "钢索下拉",
        "低位划船",
        "OP-LR",
        "Life Fitness Axiom OP-LR 高位下拉 / 低位划船机",
        "Life Fitness Axiom OP-LR 下拉 / 低位划船组合机"
      ],
      "group": "back",
      "target": "背阔肌/菱形肌",
      "equipmentKey": "cable",
      "equipmentId": "life-fitness-axiom-op-lr",
      "model": "Life Fitness Axiom OP-LR 高位下拉 / 低位划船机",
      "equipmentName": "Life Fitness Axiom OP-LR 高位下拉 / 低位划船机",
      "image": "assets/equipment-reference/op-lr.png",
      "officialUrl": "https://www.lifefitness.com/en-gb/catalog/strength-training/selectorized/axiom-series-lat-pulldown-low-row",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "lat-pulldown",
          "name": "高位下拉",
          "group": "back"
        },
        {
          "id": "low-row",
          "name": "低位划船",
          "group": "back"
        }
      ],
      "defaultVariant": "lat-pulldown",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "lat",
        "scissor-pulldown"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（当前器械标称配重）",
      "loadBasis": "machine_nominal",
      "sides": [
        "machine"
      ],
      "includesMachineBase": false,
      "note": "按实物标示记录；相同kg在不同型号不能自动视为相同训练能力。若实物使用lb须记录原单位。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides",
              "axiom-manual"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "OP-LR 共用配重塔，附件为下拉杆和中性划船握把，划船有脚踏，下拉有大腿垫；两动作分开记。",
            "sourceIds": [
              "equipment-cable-pulldown"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "高位下拉使用上方横杆并把大腿放在大腿垫下；低位划船使用下方中性握把、双脚踩脚踏。切换前让配重回落，再按机身标示连接对应附件。",
            "sourceIds": [
              "equipment-cable-pulldown",
              "axiom-manual",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "握住上方下拉杆后坐稳，大腿放在垫下，双脚稳定。"
          ],
          "text": "握住上方下拉杆后坐稳，大腿放在垫下，双脚稳定。",
          "sourceIds": [
            "equipment-cable-pulldown",
            "axiom-manual",
            "ace-lat",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "保持躯干稳定，肘向下收，把横杆受控拉向胸前。"
          ],
          "text": "保持躯干稳定，肘向下收，把横杆受控拉向胸前。",
          "sourceIds": [
            "equipment-cable-pulldown",
            "axiom-manual",
            "ace-lat",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "慢慢送回起始位置，配重落稳后再放下附件。"
          ],
          "text": "慢慢送回起始位置，配重落稳后再放下附件。",
          "sourceIds": [
            "equipment-cable-pulldown",
            "axiom-manual",
            "ace-lat",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "下拉肘向下，划船肘向后；回程放慢。",
      "cautions": [
        "高位下拉把横杆拉在身体前方，不拉到颈后，也不靠大幅后仰抢拉。",
        "低位划船不要弓背或前后甩动；配重还悬起时不要更换握把或调节配重。"
      ],
      "teachingSources": [
        {
          "id": "equipment-cable-pulldown",
          "title": "Life Fitness Axiom OP-LR 高位下拉 / 低位划船机 厂家资料",
          "url": "https://www.lifefitness.com/en-gb/catalog/strength-training/selectorized/axiom-series-lat-pulldown-low-row",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-LR 共用配重塔，附件为下拉杆和中性划船握把，划船有脚踏，下拉有大腿垫；两动作分开记。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "ace-lat",
          "title": "ACE 坐姿横杆下拉",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/158/seated-lat-pulldown/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "自由横杆钢索下拉；其中可调大腿垫不能移植到 OP-PD 固定压腿垫"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Life Fitness Axiom 厂家使用手册：OP-LR 下拉与划船（第60页）",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "Life Fitness Axiom OP-LR 厂家产品页",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-lat-pulldown-low-row",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "固定机架与导轮 · 下拉和划船共用配重塔",
        "editableKeys": [],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-cable-pulldown",
          "title": "Life Fitness Axiom OP-LR 高位下拉 / 低位划船机 厂家资料",
          "url": "https://www.lifefitness.com/en-gb/catalog/strength-training/selectorized/axiom-series-lat-pulldown-low-row",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-LR 共用配重塔，附件为下拉杆和中性划船握把，划船有脚踏，下拉有大腿垫；两动作分开记。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "ace-lat",
          "title": "ACE 坐姿横杆下拉",
          "url": "https://www.acefitness.org/resources/everyone/exercise-library/158/seated-lat-pulldown/",
          "kind": "professional_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "自由横杆钢索下拉；其中可调大腿垫不能移植到 OP-PD 固定压腿垫"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "OP-LR 共用配重塔，附件为下拉杆和中性划船握把，划船有脚踏，下拉有大腿垫；两动作分开记。",
          "高位下拉使用上方横杆并把大腿放在大腿垫下；低位划船使用下方中性握把、双脚踩脚踏。切换前让配重回落，再按机身标示连接对应附件。"
        ]
      }
    },
    {
      "id": "machine-military-press",
      "sceneKey": "machine-military-press",
      "name": "分动器械肩推",
      "aliases": [
        "悍马肩推",
        "推肩",
        "肩上推举",
        "IL-SP",
        "Hammer Strength IL-SP Iso-Lateral 肩推机",
        "Hammer Strength IL-SP 片加载肩推"
      ],
      "group": "shoulder",
      "target": "三角肌/肱三头肌",
      "equipmentKey": "plate-loaded",
      "equipmentId": "hammer-strength-il-sp",
      "model": "Hammer Strength IL-SP Iso-Lateral 肩推机",
      "equipmentName": "Hammer Strength IL-SP Iso-Lateral 肩推机",
      "image": "assets/equipment-reference/il-sp.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-shoulder-press",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "分动器械肩推",
          "group": "shoulder"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "seated-machine-shoulder"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（每侧工作臂新增装片）",
      "loadBasis": "per_arm_added_plates",
      "sides": [
        "left",
        "right"
      ],
      "includesMachineBase": false,
      "note": "分别记录左右新增片重；不把储片杆的片重计入，也不把空臂起始阻力自动并入。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "IL-SP 为左右独立工作臂，26°座椅倾角为型号结构；每侧装片分别记录。",
            "sourceIds": [
              "equipment-machine-military-press"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "确认两侧工作臂的杠铃片固定可靠；调好座椅，让起始握把接近肩部或略高，坐稳并把肩背贴住背垫。",
            "sourceIds": [
              "equipment-machine-military-press",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "头和胸部自然抬起，握稳把手，保持手腕与前臂自然对齐。"
          ],
          "text": "头和胸部自然抬起，握稳把手，保持手腕与前臂自然对齐。",
          "sourceIds": [
            "equipment-machine-military-press",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "保持躯干稳定，让两侧工作臂平稳向上运动，手肘随推举逐渐伸展。"
          ],
          "text": "保持躯干稳定，让两侧工作臂平稳向上运动，手肘随推举逐渐伸展。",
          "sourceIds": [
            "equipment-machine-military-press",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "慢慢弯肘，把把手降回自己能控制的起始位置，两侧都不突然放松。"
          ],
          "text": "慢慢弯肘，把把手降回自己能控制的起始位置，两侧都不突然放松。",
          "sourceIds": [
            "equipment-machine-military-press",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "肩背贴垫，沿固定弧线向上推。",
      "cautions": [
        "不要抬臀或用腰部反弓把重量顶上去。",
        "不要耸肩抢推或突然撞击动作末端；装卸片重前让工作臂回到稳定位置。"
      ],
      "teachingSources": [
        {
          "id": "equipment-machine-military-press",
          "title": "Hammer Strength IL-SP Iso-Lateral 肩推机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-shoulder-press",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "IL-SP 为左右独立工作臂，26°座椅倾角为型号结构；每侧装片分别记录。"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Hammer Strength IL-SP 厂家产品页",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-shoulder-press",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "Hammer Strength Iso-Lateral 厂家手册：IL-SP（转载，第28页）",
          "url": "https://www.manualslib.com/manual/1070990/Hammer-Strength-Iso-Lateral.html?page=28",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "预设座椅倾角 · 左右分动杠杆",
        "editableKeys": [],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-machine-military-press",
          "title": "Hammer Strength IL-SP Iso-Lateral 肩推机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-shoulder-press",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "IL-SP 为左右独立工作臂，26°座椅倾角为型号结构；每侧装片分别记录。"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "IL-SP 为左右独立工作臂，26°座椅倾角为型号结构；每侧装片分别记录。",
          "确认两侧工作臂的杠铃片固定可靠；调好座椅，让起始握把接近肩部或略高，坐稳并把肩背贴住背垫。"
        ]
      }
    },
    {
      "id": "seated-machine-shoulder",
      "sceneKey": "seated-machine-shoulder",
      "name": "坐姿器械肩推",
      "aliases": [
        "肩推机",
        "坐姿推肩",
        "肩上推举",
        "OP-SP",
        "Life Fitness Axiom OP-SP 选择式肩推机",
        "Life Fitness Axiom OP-SP Shoulder Press"
      ],
      "group": "shoulder",
      "target": "三角肌",
      "equipmentKey": "selectorized",
      "equipmentId": "life-fitness-axiom-op-sp",
      "model": "Life Fitness Axiom OP-SP 选择式肩推机",
      "equipmentName": "Life Fitness Axiom OP-SP 选择式肩推机",
      "image": "assets/equipment-reference/op-sp.png",
      "officialUrl": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-shoulder-press",
      "modelAvailable": true,
      "venue": [
        "gym"
      ],
      "imageProvenance": "existing_project_resource_not_newly_downloaded",
      "movementVariants": [
        {
          "id": "standard",
          "name": "坐姿器械肩推",
          "group": "shoulder"
        }
      ],
      "defaultVariant": "standard",
      "historyIdentityFields": [
        "id",
        "equipmentId",
        "movementVariant",
        "loadBasis",
        "unit",
        "sides"
      ],
      "alternatives": [
        "machine-military-press"
      ],
      "alternativeNote": "替换会创建不同动作记录，不换算能力；所列动作不是同一动作或个体适用程度保证。",
      "unitLabel": "kg（当前器械标称配重）",
      "loadBasis": "machine_nominal",
      "sides": [
        "machine"
      ],
      "includesMachineBase": false,
      "note": "按实物标示记录；相同kg在不同型号不能自动视为相同训练能力。若实物使用lb须记录原单位。",
      "preparation": {
        "general": [
          {
            "text": "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
            "sourceIds": [
              "project-guides"
            ],
            "reviewStatus": "existing_project_guidance"
          },
          {
            "text": "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
            "sourceIds": [
              "project-guides",
              "axiom-manual"
            ],
            "reviewStatus": "existing_guidance_manual_detail_pending"
          },
          {
            "text": "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。",
            "sourceIds": [
              "nhs-strength-general",
              "acsm-2026"
            ],
            "reviewStatus": "general_principle_reviewed"
          }
        ],
        "currentModel": [
          {
            "text": "OP-SP 有中立／正握把位，座椅位置影响起始行程；背垫和转臂轨迹不能任意改。",
            "sourceIds": [
              "equipment-seated-machine-shoulder"
            ],
            "reviewStatus": "product_structure_reviewed"
          },
          {
            "text": "调好座椅，使握把接近肩部或略高；选择舒服的一组握把，双脚踩稳、肩背靠垫，并确认配重选择到位。",
            "sourceIds": [
              "equipment-seated-machine-shoulder",
              "axiom-manual",
              "project-guides"
            ],
            "reviewStatus": "existing_model_setup_manual_detail_pending"
          }
        ]
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "头和胸部自然抬起，握稳把手，保持肩背贴住背垫。"
          ],
          "text": "头和胸部自然抬起，握稳把手，保持肩背贴住背垫。",
          "sourceIds": [
            "equipment-seated-machine-shoulder",
            "axiom-manual",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "沿器械轨迹向上推握把，让手肘逐渐伸展，身体保持稳定。"
          ],
          "text": "沿器械轨迹向上推握把，让手肘逐渐伸展，身体保持稳定。",
          "sourceIds": [
            "equipment-seated-machine-shoulder",
            "axiom-manual",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "慢慢弯肘返回起始位置，控制配重下降，不让配重猛撞。"
          ],
          "text": "慢慢弯肘返回起始位置，控制配重下降，不让配重猛撞。",
          "sourceIds": [
            "equipment-seated-machine-shoulder",
            "axiom-manual",
            "project-guides"
          ],
          "reviewStatus": "existing_text_partial_review"
        }
      ],
      "cue": "坐稳、肩背贴垫，向上推起再慢放。",
      "cautions": [
        "不要抬臀、反弓腰部或耸肩借力。",
        "起始握把位置或动作幅度不舒服时先停下调整，不要硬顶着继续推。"
      ],
      "teachingSources": [
        {
          "id": "equipment-seated-machine-shoulder",
          "title": "Life Fitness Axiom OP-SP 选择式肩推机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-shoulder-press",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-SP 有中立／正握把位，座椅位置影响起始行程；背垫和转臂轨迹不能任意改。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "legacySourceLinks": [
        {
          "title": "Life Fitness Axiom 厂家使用手册：OP-SP（第52页）",
          "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        },
        {
          "title": "Life Fitness Axiom OP-SP 厂家产品页",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-shoulder-press",
          "reviewStatus": "existing_link_not_individually_reviewed_this_pass"
        }
      ],
      "modelSettings": {
        "fixed": "固定靠背与握把结构 · 预设转臂轨迹",
        "editableKeys": [
          "seatHeightCm"
        ],
        "displayNote": "只复用当前模型现有白名单。模型示意数值不能当作实物精确档位；实物准备可能包含模型未模拟的座椅等调整。"
      },
      "review": {
        "status": "partial_text_review",
        "reviewedAt": "2026-10-13",
        "officialProductIdentity": "confirmed",
        "humanDemonstration": "missing",
        "errorComparison": "missing",
        "authorizedAnimation": false,
        "note": "产品身份与已说明的结构事实已核对；全文型号操作和18动作教学尚需逐项审核。本条不是经验证人体动作示范。"
      },
      "sources": [
        {
          "id": "equipment-seated-machine-shoulder",
          "title": "Life Fitness Axiom OP-SP 选择式肩推机 厂家资料",
          "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-shoulder-press",
          "kind": "manufacturer_product",
          "reviewStatus": "official_product_identity_reviewed",
          "scope": "OP-SP 有中立／正握把位，座椅位置影响起始行程；背垫和转臂轨迹不能任意改。"
        },
        {
          "id": "axiom-manual",
          "title": "Life Fitness Axiom 官方手册入口",
          "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
          "kind": "manufacturer_manual",
          "reviewStatus": "official_document_identity_confirmed_content_pending",
          "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
        },
        {
          "id": "project-guides",
          "title": "现有项目 ACTION_GUIDES",
          "localFile": "script.js",
          "kind": "existing_project_text",
          "reviewStatus": "structure_audited_technique_partial_review",
          "scope": "复用现有18项提示；不等于已验证人体演示"
        }
      ],
      "setup": {
        "general": [
          "先辨认器械、动作和重量单位；不了解调节或保护装置时先请现场工作人员演示。",
          "先确认动作和器械处于静止状态，再选择负荷或做调整；完成固定检查后再开始。",
          "从能控制的练习量逐渐开始；没有训练记录时不显示个人推荐公斤数。"
        ],
        "model": [
          "OP-SP 有中立／正握把位，座椅位置影响起始行程；背垫和转臂轨迹不能任意改。",
          "调好座椅，使握把接近肩部或略高；选择舒服的一组握把，双脚踩稳、肩背靠垫，并确认配重选择到位。"
        ]
      }
    }
  ],
  "homeActions": [
    {
      "id": "home-wall-press-up",
      "name": "墙壁俯卧撑",
      "aliases": [
        "靠墙俯卧撑",
        "墙推"
      ],
      "group": "chest",
      "equipmentKey": "bodyweight",
      "equipmentId": "wall",
      "model": "无3D模型；NHS文字练习",
      "requiredEquipment": [
        "wall"
      ],
      "alternatives": [],
      "sceneKey": null,
      "modelAvailable": false,
      "image": null,
      "venue": [
        "home",
        "gym"
      ],
      "officialUrl": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
      "unitLabel": "自重（记录完成次数）",
      "loadBasis": "bodyweight_no_kg",
      "preparation": {
        "general": [
          "使用稳固不滑动、无轮子的椅子或牢固墙面。",
          "从少量练习开始，逐渐增加。"
        ],
        "currentModel": []
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "站在离墙约一臂的位置，手掌放在胸口高度。"
          ],
          "text": "站在离墙约一臂的位置，手掌放在胸口高度。",
          "sourceIds": [
            "nhs-home"
          ],
          "reviewStatus": "primary_text_paraphrase_reviewed"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "保持背部直，慢慢屈肘靠向墙。"
          ],
          "text": "保持背部直，慢慢屈肘靠向墙。",
          "sourceIds": [
            "nhs-home"
          ],
          "reviewStatus": "primary_text_paraphrase_reviewed"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "平稳推回起点。"
          ],
          "text": "平稳推回起点。",
          "sourceIds": [
            "nhs-home"
          ],
          "reviewStatus": "primary_text_paraphrase_reviewed"
        }
      ],
      "teachingSources": [
        {
          "id": "nhs-home",
          "title": "NHS 居家力量练习",
          "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
          "kind": "public_health_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "墙壁俯卧撑、坐站、扶椅小幅深蹲、扶椅提踵的文字步骤；图片未复制"
        }
      ],
      "review": {
        "status": "primary_text_reviewed_no_visual_asset",
        "reviewedAt": "2026-10-13",
        "humanDemonstration": "not_provided",
        "authorizedAnimation": false,
        "note": "仅文字步骤；可以后续自行绘制示意，但本候选没有图或3D，不能显示模型演示按钮。"
      },
      "sources": [
        {
          "id": "nhs-home",
          "title": "NHS 居家力量练习",
          "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
          "kind": "public_health_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "墙壁俯卧撑、坐站、扶椅小幅深蹲、扶椅提踵的文字步骤；图片未复制"
        }
      ],
      "setup": {
        "general": [
          "使用稳固不滑动、无轮子的椅子或牢固墙面。",
          "从少量练习开始，逐渐增加。"
        ],
        "model": []
      }
    },
    {
      "id": "home-sit-to-stand",
      "name": "坐站练习",
      "aliases": [
        "椅子起立",
        "坐站"
      ],
      "group": "legs",
      "equipmentKey": "bodyweight",
      "equipmentId": "stable-chair",
      "model": "无3D模型；NHS文字练习",
      "requiredEquipment": [
        "stable-chair"
      ],
      "alternatives": [],
      "sceneKey": null,
      "modelAvailable": false,
      "image": null,
      "venue": [
        "home",
        "gym"
      ],
      "officialUrl": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
      "unitLabel": "自重（记录完成次数）",
      "loadBasis": "bodyweight_no_kg",
      "preparation": {
        "general": [
          "使用稳固不滑动、无轮子的椅子或牢固墙面。",
          "从少量练习开始，逐渐增加。"
        ],
        "currentModel": []
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "坐在稳固无轮椅子的前缘，脚距约髋宽。"
          ],
          "text": "坐在稳固无轮椅子的前缘，脚距约髋宽。",
          "sourceIds": [
            "nhs-home"
          ],
          "reviewStatus": "primary_text_paraphrase_reviewed"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "稍前倾，用腿慢慢站起，目光向前。"
          ],
          "text": "稍前倾，用腿慢慢站起，目光向前。",
          "sourceIds": [
            "nhs-home"
          ],
          "reviewStatus": "primary_text_paraphrase_reviewed"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "站稳后慢慢坐回。"
          ],
          "text": "站稳后慢慢坐回。",
          "sourceIds": [
            "nhs-home"
          ],
          "reviewStatus": "primary_text_paraphrase_reviewed"
        }
      ],
      "teachingSources": [
        {
          "id": "nhs-home",
          "title": "NHS 居家力量练习",
          "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
          "kind": "public_health_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "墙壁俯卧撑、坐站、扶椅小幅深蹲、扶椅提踵的文字步骤；图片未复制"
        }
      ],
      "review": {
        "status": "primary_text_reviewed_no_visual_asset",
        "reviewedAt": "2026-10-13",
        "humanDemonstration": "not_provided",
        "authorizedAnimation": false,
        "note": "仅文字步骤；可以后续自行绘制示意，但本候选没有图或3D，不能显示模型演示按钮。"
      },
      "sources": [
        {
          "id": "nhs-home",
          "title": "NHS 居家力量练习",
          "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
          "kind": "public_health_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "墙壁俯卧撑、坐站、扶椅小幅深蹲、扶椅提踵的文字步骤；图片未复制"
        }
      ],
      "setup": {
        "general": [
          "使用稳固不滑动、无轮子的椅子或牢固墙面。",
          "从少量练习开始，逐渐增加。"
        ],
        "model": []
      }
    },
    {
      "id": "home-mini-squat",
      "name": "扶椅小幅深蹲",
      "aliases": [
        "扶椅蹲",
        "小幅深蹲"
      ],
      "group": "legs",
      "equipmentKey": "bodyweight",
      "equipmentId": "stable-chair",
      "model": "无3D模型；NHS文字练习",
      "requiredEquipment": [
        "stable-chair"
      ],
      "alternatives": [],
      "sceneKey": null,
      "modelAvailable": false,
      "image": null,
      "venue": [
        "home",
        "gym"
      ],
      "officialUrl": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
      "unitLabel": "自重（记录完成次数）",
      "loadBasis": "bodyweight_no_kg",
      "preparation": {
        "general": [
          "使用稳固不滑动、无轮子的椅子或牢固墙面。",
          "从少量练习开始，逐渐增加。"
        ],
        "currentModel": []
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "轻扶稳固椅背，双脚约髋宽。"
          ],
          "text": "轻扶稳固椅背，双脚约髋宽。",
          "sourceIds": [
            "nhs-home"
          ],
          "reviewStatus": "primary_text_paraphrase_reviewed"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "保持背部直，向前屈膝到舒适幅度。"
          ],
          "text": "保持背部直，向前屈膝到舒适幅度。",
          "sourceIds": [
            "nhs-home"
          ],
          "reviewStatus": "primary_text_paraphrase_reviewed"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "缓慢恢复站立。"
          ],
          "text": "缓慢恢复站立。",
          "sourceIds": [
            "nhs-home"
          ],
          "reviewStatus": "primary_text_paraphrase_reviewed"
        }
      ],
      "teachingSources": [
        {
          "id": "nhs-home",
          "title": "NHS 居家力量练习",
          "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
          "kind": "public_health_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "墙壁俯卧撑、坐站、扶椅小幅深蹲、扶椅提踵的文字步骤；图片未复制"
        }
      ],
      "review": {
        "status": "primary_text_reviewed_no_visual_asset",
        "reviewedAt": "2026-10-13",
        "humanDemonstration": "not_provided",
        "authorizedAnimation": false,
        "note": "仅文字步骤；可以后续自行绘制示意，但本候选没有图或3D，不能显示模型演示按钮。"
      },
      "sources": [
        {
          "id": "nhs-home",
          "title": "NHS 居家力量练习",
          "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
          "kind": "public_health_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "墙壁俯卧撑、坐站、扶椅小幅深蹲、扶椅提踵的文字步骤；图片未复制"
        }
      ],
      "setup": {
        "general": [
          "使用稳固不滑动、无轮子的椅子或牢固墙面。",
          "从少量练习开始，逐渐增加。"
        ],
        "model": []
      }
    },
    {
      "id": "home-calf-raise",
      "name": "扶椅提踵",
      "aliases": [
        "踮脚",
        "小腿提踵"
      ],
      "group": "legs",
      "equipmentKey": "bodyweight",
      "equipmentId": "stable-chair",
      "model": "无3D模型；NHS文字练习",
      "requiredEquipment": [
        "stable-chair"
      ],
      "alternatives": [],
      "sceneKey": null,
      "modelAvailable": false,
      "image": null,
      "venue": [
        "home",
        "gym"
      ],
      "officialUrl": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
      "unitLabel": "自重（记录完成次数）",
      "loadBasis": "bodyweight_no_kg",
      "preparation": {
        "general": [
          "使用稳固不滑动、无轮子的椅子或牢固墙面。",
          "从少量练习开始，逐渐增加。"
        ],
        "currentModel": []
      },
      "steps": [
        {
          "phase": "prepare",
          "label": "准备",
          "cues": [
            "轻扶稳固椅背，双脚落地。"
          ],
          "text": "轻扶稳固椅背，双脚落地。",
          "sourceIds": [
            "nhs-home"
          ],
          "reviewStatus": "primary_text_paraphrase_reviewed"
        },
        {
          "phase": "work",
          "label": "完成动作",
          "cues": [
            "慢慢抬起双脚脚跟。"
          ],
          "text": "慢慢抬起双脚脚跟。",
          "sourceIds": [
            "nhs-home"
          ],
          "reviewStatus": "primary_text_paraphrase_reviewed"
        },
        {
          "phase": "return",
          "label": "受控返回",
          "cues": [
            "受控放回地面。"
          ],
          "text": "受控放回地面。",
          "sourceIds": [
            "nhs-home"
          ],
          "reviewStatus": "primary_text_paraphrase_reviewed"
        }
      ],
      "teachingSources": [
        {
          "id": "nhs-home",
          "title": "NHS 居家力量练习",
          "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
          "kind": "public_health_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "墙壁俯卧撑、坐站、扶椅小幅深蹲、扶椅提踵的文字步骤；图片未复制"
        }
      ],
      "review": {
        "status": "primary_text_reviewed_no_visual_asset",
        "reviewedAt": "2026-10-13",
        "humanDemonstration": "not_provided",
        "authorizedAnimation": false,
        "note": "仅文字步骤；可以后续自行绘制示意，但本候选没有图或3D，不能显示模型演示按钮。"
      },
      "sources": [
        {
          "id": "nhs-home",
          "title": "NHS 居家力量练习",
          "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
          "kind": "public_health_exercise_instruction",
          "reviewStatus": "primary_text_reviewed",
          "scope": "墙壁俯卧撑、坐站、扶椅小幅深蹲、扶椅提踵的文字步骤；图片未复制"
        }
      ],
      "setup": {
        "general": [
          "使用稳固不滑动、无轮子的椅子或牢固墙面。",
          "从少量练习开始，逐渐增加。"
        ],
        "model": []
      }
    }
  ],
  "sources": {
    "cdc-adults": {
      "title": "CDC 成人身体活动建议",
      "url": "https://www.cdc.gov/physical-activity-basics/guidelines/adults.html",
      "kind": "public_health_guidance",
      "reviewStatus": "primary_text_reviewed",
      "scope": "一般成人；主要肌群每周至少两天"
    },
    "cdc-sets": {
      "title": "CDC 成人肌力活动与组次说明",
      "url": "https://www.cdc.gov/physical-activity-basics/adding-adults/what-counts.html",
      "kind": "public_health_guidance",
      "reviewStatus": "primary_text_reviewed",
      "scope": "8至12次为一组；至少一组，2至3组可有更多收益；不规定个人公斤数"
    },
    "nhs-strength-general": {
      "title": "NHS 如何提高力量和柔韧性",
      "url": "https://www.nhs.uk/live-well/exercise/how-to-improve-strength-flexibility/",
      "kind": "public_health_guidance",
      "reviewStatus": "primary_text_reviewed",
      "scope": "一般成人；逐渐开始，8至12次与2至3组的一般说明"
    },
    "nhs-home": {
      "title": "NHS 居家力量练习",
      "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
      "kind": "public_health_exercise_instruction",
      "reviewStatus": "primary_text_reviewed",
      "scope": "墙壁俯卧撑、坐站、扶椅小幅深蹲、扶椅提踵的文字步骤；图片未复制"
    },
    "acsm-2026": {
      "title": "ACSM 2026 抗阻训练指南官方说明",
      "url": "https://acsm.org/resistance-training-guidelines-update-2026/",
      "kind": "professional_society_guidance",
      "reviewStatus": "primary_text_reviewed",
      "scope": "健康成人；稳定参与、主要肌群至少每周两次；不同设备和居家训练可行；并非个人公斤数处方"
    },
    "ace-bench": {
      "title": "ACE 杠铃卧推动作库",
      "url": "https://www.acefitness.org/resources/everyone/exercise-library/5/chest-press/",
      "kind": "professional_exercise_instruction",
      "reviewStatus": "primary_text_reviewed",
      "scope": "自由杠铃卧推的一般动作，非 O-FB 具体档位"
    },
    "ace-squat": {
      "title": "ACE 杠铃背蹲动作库",
      "url": "https://www.acefitness.org/resources/everyone/exercise-library/11/back-squat/",
      "kind": "professional_exercise_instruction",
      "reviewStatus": "primary_text_reviewed",
      "scope": "自由杠铃背蹲；原站标注 Advanced，不能改称默认新手适用"
    },
    "ace-fly": {
      "title": "ACE 站姿钢索飞鸟",
      "url": "https://www.acefitness.org/resources/everyone/exercise-library/160/standing-chest-fly/",
      "kind": "professional_exercise_instruction",
      "reviewStatus": "primary_text_reviewed",
      "scope": "站姿钢索飞鸟一般动作；不能当 SS-PEC 或 OP-FLY 的型号操作手册"
    },
    "ace-lat": {
      "title": "ACE：坐姿横杆下拉",
      "url": "https://www.acefitness.org/resources/everyone/exercise-library/158/seated-lat-pulldown/",
      "kind": "professional_exercise_instruction",
      "reviewStatus": "primary_text_reviewed",
      "scope": "仅采用肘向下、躯干稳定与缓慢回程等共通提示；ACE自由横杆的后倾角度、拉胸终点和可调大腿垫不用于OP-PD。",
      "id": "ace-lat",
      "reviewedAt": "2026-10-14",
      "reviewLabel": "通用文字已核对；部分细节不适用于本型号"
    },
    "axiom-manual": {
      "title": "Life Fitness Axiom 官方手册入口",
      "url": "https://support.lifefitness.com/hc/en-us/articles/360053163033-Life-Fitness-Axiom-Series-Single-and-Dual-Stations-Owner-s-Manual",
      "kind": "manufacturer_manual",
      "reviewStatus": "official_document_identity_confirmed_content_pending",
      "scope": "1014208-0001 Rev AD；PDF全文受读取限制，本轮不冒称全文审核"
    },
    "dap-manual": {
      "title": "Life Fitness OP-DAP 官方手册入口",
      "url": "https://support.lifefitness.com/hc/en-us/articles/360039412093-Life-Fitness-Axiom-OP-DAP-Dual-Adjustable-Pulley-Owner-s-Manual",
      "kind": "manufacturer_manual",
      "reviewStatus": "official_document_identity_confirmed_content_pending",
      "scope": "1013248-0001；型号操作全文待核对"
    },
    "insignia-manual": {
      "title": "Life Fitness Insignia SS-PEC 手册",
      "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/Life_Fitness_Insignia_Series_Owners_Manual_9481201_Rev_BE.pdf",
      "kind": "manufacturer_manual",
      "reviewStatus": "existing_official_link_content_pending",
      "scope": "旧型号 SS-PEC；PDF全文待核对"
    },
    "project-guides": {
      "title": "现有项目 ACTION_GUIDES",
      "localFile": "script.js",
      "kind": "existing_project_text",
      "reviewStatus": "structure_audited_technique_partial_review",
      "scope": "复用现有18项提示；不等于已验证人体演示"
    },
    "equipment-arm": {
      "title": "Life Fitness OP-DAP 双塔可调滑轮训练器 厂家资料",
      "url": "https://shop.lifefitness.com/products/axiom-dual-adjustable-pulley",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "OP-DAP 有两座配重塔，厂家标示 2:1 阻力比；记录配重塔标示值，不把模型换算当训练能力。"
    },
    "equipment-cam": {
      "title": "Life Fitness Axiom OP-LE 膝伸展机 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-leg-extension",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "OP-LE 官方页列出可调靠背和小腿垫；按实物牌示对齐后检查固定。"
    },
    "equipment-incline": {
      "title": "Hammer Strength HSLLP 45° 线性倒蹬机 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-linear-leg-press",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "HSLLP 当前官方页列出45°导轨、挂回机构、可调靠背和行程；现有模型版本与当前产品页未完全对应。"
    },
    "equipment-pec": {
      "title": "Life Fitness Axiom OP-FLY 胸飞鸟 / 后束机 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-pectoral-fly-rear-deltoid",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "OP-FLY 为胸飞鸟／后束双动作机；切换模式和起始档位的操作需核对当前实物牌示。"
    },
    "equipment-lat": {
      "title": "Life Fitness Axiom OP-PD 高位下拉机 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-lat-pulldown",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "OP-PD 有可调座椅，但压腿垫为固定结构；不得按通用下拉教学把固定压腿垫改成可调项。"
    },
    "equipment-barbell-squat": {
      "title": "Hammer Strength HD Athletic NX 四柱力量架 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/racks-rigs-platforms/hd-athletic-nx-power-rack",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "当前模型为 HD Athletic NX 架和自由杠铃；J杯及保护装置按现场器械说明检查，不推荐个人档位。"
    },
    "equipment-cable-row": {
      "title": "Life Fitness Axiom OP-RW 坐姿划船机 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-seated-row",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "OP-RW 有自调节握把和斜面脚踏；不要把脚踏或固定转轴当作模型中任意可调参数。"
    },
    "equipment-barbell-bench": {
      "title": "Hammer Strength O-FB 奥林匹克平板卧推架 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/benches/olympic-flat-bench",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "O-FB 为平板卧推架；杠铃、承杠钩和保护人员的准备按实际场地确认。"
    },
    "equipment-flat-press": {
      "title": "Life Fitness Axiom OP-CP 选择式推胸机 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-chest-press",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "OP-CP 有可调座椅和两种握法，靠背和转臂轨迹固定。"
    },
    "equipment-incline-press": {
      "title": "Hammer Strength IL-IP Iso-Lateral 上斜推胸机 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-incline-press",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "IL-IP 为左右独立工作臂，装片按每侧工作臂分别记录；固定靠背倾角不能任意改。"
    },
    "equipment-cable-fly": {
      "title": "Life Fitness OP-DAP 双侧可调滑轮夹胸 厂家资料",
      "url": "https://shop.lifefitness.com/products/axiom-dual-adjustable-pulley",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "OP-DAP 的双侧钢索与配重塔分别使用；滑轮位置只作示意，不给真实档位数字。"
    },
    "equipment-machine-fly": {
      "title": "Life Fitness Insignia SS-PEC 蝶式胸肌训练机 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/insignia-series-pectoral-fly",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "官方产品页确认 SS-PEC 已停产；现有旧型号图和模型保留，不能把替代新型号的调整说明直接套用。"
    },
    "equipment-scissor-pulldown": {
      "title": "Hammer Strength IL-WPD Iso-Lateral 宽握下拉机 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-wide-pulldown",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "IL-WPD 为左右独立工作臂、正握握把；装片按每侧记录。"
    },
    "equipment-nautilus-pullover": {
      "title": "Nautilus Inspiration IPPO3 Pull Over 上拉机 厂家资料",
      "url": "https://www.corehandf.com/products/nautilus-inspiration-pull-over",
      "kind": "manufacturer_product",
      "reviewStatus": "official_page_model_version_mismatch",
      "scope": "现有模型标为IPPO3，官方URL目前为IPPO5；当前型号的脚踏、肘撑和配重操作仍待版本核对。"
    },
    "equipment-hammer-row": {
      "title": "Hammer Strength IL-ROW Iso-Lateral 划船机 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-row",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "IL-ROW 为胸托和左右独立工作臂，厂家按每工作臂列载荷；胸托位置按当前实物确认。"
    },
    "equipment-cable-pulldown": {
      "title": "Life Fitness Axiom OP-LR 高位下拉 / 低位划船机 厂家资料",
      "url": "https://www.lifefitness.com/en-gb/catalog/strength-training/selectorized/axiom-series-lat-pulldown-low-row",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "OP-LR 共用配重塔，附件为下拉杆和中性划船握把，划船有脚踏，下拉有大腿垫；两动作分开记。"
    },
    "equipment-machine-military-press": {
      "title": "Hammer Strength IL-SP Iso-Lateral 肩推机 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-iso-lateral-shoulder-press",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "IL-SP 为左右独立工作臂，26°座椅倾角为型号结构；每侧装片分别记录。"
    },
    "equipment-seated-machine-shoulder": {
      "title": "Life Fitness Axiom OP-SP 选择式肩推机 厂家资料",
      "url": "https://www.lifefitness.com/en-us/catalog/strength-training/selectorized/axiom-series-shoulder-press",
      "kind": "manufacturer_product",
      "reviewStatus": "official_product_identity_reviewed",
      "scope": "OP-SP 有中立／正握把位，座椅位置影响起始行程；背垫和转臂轨迹不能任意改。"
    },
    "ace-chest-press": {
      "id": "ace-chest-press",
      "title": "ACE：坐姿推胸",
      "url": "https://www.acefitness.org/resources/everyone/exercise-library/188/seated-chest-press/",
      "scope": "通用坐姿推胸的稳定姿势、呼气推起、肘不锁死与受控返回；本轮核对官方索引文字。",
      "kind": "professional_exercise_instruction",
      "reviewedAt": "2026-10-14",
      "reviewStatus": "primary_text_reviewed",
      "reviewLabel": "通用文字已核对"
    },
    "nasm-chest-press": {
      "id": "nasm-chest-press",
      "title": "NASM：器械推胸步骤与常见错误",
      "url": "https://www.nasm.org/resource-center/exercise-library/chest-press-machine",
      "scope": "已读官方文字步骤及错误清单；没有采用固定45°肘角或该页组次数建议。视频链接未播放核验。",
      "kind": "professional_exercise_instruction",
      "reviewedAt": "2026-10-14",
      "reviewStatus": "primary_text_reviewed",
      "reviewLabel": "通用文字已核对"
    },
    "axiom-op-cp-excerpt": {
      "id": "axiom-op-cp-excerpt",
      "title": "Life Fitness：OP-CP 操作段落（手册第46页）",
      "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=46",
      "scope": "核对官方PDF索引中的OP-CP准备与运动段落；不是整册审核，也未核验现场实物版本。",
      "kind": "manufacturer_manual",
      "reviewedAt": "2026-10-14",
      "reviewStatus": "official_indexed_section_reviewed",
      "reviewLabel": "相关段落已核对；实物版本待确认"
    },
    "mayo-knee-extension": {
      "id": "mayo-knee-extension",
      "title": "Mayo Clinic：机器膝伸展文字稿",
      "url": "https://www.mayoclinic.org/healthy-lifestyle/fitness/multimedia/knee-extension/vid-20084686",
      "scope": "已读官方文字稿：平稳伸膝、避免锁膝、受控完整返回。该页为视频页面，本轮只核验文字；未采用其组次数建议或个体医疗判断。",
      "kind": "professional_exercise_instruction",
      "reviewedAt": "2026-10-14",
      "reviewStatus": "primary_text_reviewed",
      "reviewLabel": "通用文字已核对；视频未播放核验"
    },
    "axiom-op-le-excerpt": {
      "id": "axiom-op-le-excerpt",
      "title": "Life Fitness：OP-LE 操作段落（手册第48页）",
      "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=48",
      "scope": "核对官方PDF索引中的膝对齐转轴、小腿垫位置、扶手和受控伸膝段落；不是整册审核或实机认证。",
      "kind": "manufacturer_manual",
      "reviewedAt": "2026-10-14",
      "reviewStatus": "official_indexed_section_reviewed",
      "reviewLabel": "相关段落已核对；实物版本待确认"
    },
    "axiom-op-pd-excerpt": {
      "id": "axiom-op-pd-excerpt",
      "title": "Life Fitness：OP-PD 操作段落（手册第50页）",
      "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=50",
      "scope": "核对官方PDF索引中的坐入、躯干略前倾、握把至肩高及受控返回段落；不是整册审核或现场版本认证。",
      "kind": "manufacturer_manual",
      "reviewedAt": "2026-10-14",
      "reviewStatus": "official_indexed_section_reviewed",
      "reviewLabel": "相关段落已核对；实物版本待确认"
    },
    "ace-cable-lateral": {
      "id": "ace-cable-lateral",
      "title": "ACE：滑轮侧平举（Certified News 2009，第9页）",
      "url": "https://contentcdn.eacefitness.com/cp/pdfs/CertifiedNews/AugSept09Cert.pdf#page=9",
      "scope": "已读官方期刊的低位、单侧站位、肘微弯、肩高终点、慢回及双侧选项。错误条目是据这些要求编写的文字自查例子；未复制原图或创建人体示范。",
      "kind": "professional_exercise_instruction",
      "reviewedAt": "2026-10-14",
      "reviewStatus": "primary_text_reviewed",
      "reviewLabel": "通用文字已核对；自查例子由要求整理"
    }
  },
  "generalTemplateBasis": {
    "scope": "健康成人的一般学习与记录示例；不是个人医疗或公斤数处方",
    "sourceIds": [
      "cdc-adults",
      "cdc-sets",
      "nhs-strength-general",
      "acsm-2026"
    ],
    "majorGroupsAtLeastDaysPerWeek": 2,
    "ordinaryExampleRepetitions": [
      8,
      12
    ],
    "ordinaryExampleSets": [
      1,
      3
    ],
    "defaultExampleSets": 2,
    "requirements": [
      "结合可用器械与实际时间选择结构",
      "从少量学习和记录逐渐开始",
      "没有同动作同器械记录时负荷为未知",
      "不强制1RM测试，也不自动按周加重"
    ],
    "productEstimatesNotGuidelineClaims": [
      "每次时长与过渡耗时",
      "具体动作组合和替代安排",
      "因用户时间裁剪动作或组数的界面流程",
      "休息倒计时默认秒数"
    ],
    "coverageGaps": [
      "当前18模型未覆盖居家拉类、独立髋铰链和核心动作；不能宣称家庭4动作已覆盖全部主要肌群",
      "旧自动计划中的RDL、哑铃肩推、俯身划船并非真实注册模型入口"
    ]
  },
  "resourceGaps": [
    "18动作均没有经核实且获授权的人体模型、完整重复动画、错误对照或可同步阶段视频",
    "SS-PEC官方页已停产，旧型号操作全文尚需核对",
    "Nautilus既有IPPO3模型与当前官方URL的IPPO5版本不一致",
    "HSLLP当前官网与示例滑车参数有版本/量纲差异，不能自动换算",
    "厂家手册正文读取不完整；转载链接只能作为既有待核对来源",
    "普通文本教学可继续显示，缺少视觉资源应明确标示，不能用器械运动替代人体教学"
  ]
};
  if (typeof window !== "undefined") window.BMMD_BEGINNER_CATALOG = catalog;
  if (typeof module !== "undefined" && module.exports) module.exports = catalog;
})();
