/* Plans and session records are independent from the mechanical simulation. */
(() => {
  'use strict';
  const B = window.BM ||= {};
  const C = window.BMMD_BEGINNER_CATALOG;
  const clone = v => JSON.parse(JSON.stringify(v));
  const own = (value,key) => Object.prototype.hasOwnProperty.call(value,key);
  const uid = p => p + '-' + (window.crypto?.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2));
  const all = [...C.actions, ...C.homeActions];
  const byId = Object.fromEntries(all.map(a => [a.id, a]));
  const n = (v, min = 0, max = 100000) => v == null || typeof v==='boolean' || String(v).trim() === '' ? null : Number.isFinite(Number(v)) && Number(v) >= min && Number(v) <= max ? Number(v) : null;
  const now = () => new Date().toISOString();
  const hash = s => { let h = 2166136261; for (const c of s) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return (h >>> 0).toString(36); };
  const basis = a => a?.equipmentKey === 'bodyweight' ? 'bodyweight' : a?.equipmentKey === 'barbell' ? 'total-bar' : a?.loadBasis?.includes('per_arm') ? 'per-side' : a?.equipmentKey === 'plate-loaded' ? 'total-plates' : 'stack-labelled';
  function state() { return B.store.getDraft?.() || B.store.getState(); }
  function tx(fn,options) { return B.store.transact(fn,options); }
  function item(action, c, id) {
    const home = !action.sceneKey;
    const reps = home && action.id !== 'home-wall-press-up' ? 5 : home ? 5 : 8;
    return { id: id || uid('item'), actionId: action.id, equipmentId: action.equipmentId, customName: action.name,
      sets: home ? (action.id === 'home-wall-press-up' ? 3 : 1) : c.experience === 'experienced' ? 3 : 2,
      repsMin: reps, repsMax: home ? (action.id === 'home-wall-press-up' ? 10 : 5) : 12,
      restSeconds: c.goal === 'strength' && c.experience === 'experienced' ? 120 : 60, targetLoad: null,
      unit: home ? 'bodyweight' : c.units==='lb'?'lb':'kg', loadBasis: basis(action),
      loadSource: { type: 'unknown', explanation: '没有同动作、同器械的已确认负荷记录。不提供个人公斤数。' },
      variant:action.defaultVariant||'standard',sides:'both',alternatives: action.alternatives.filter(id => byId[id] && available(byId[id], c)), notes: home ? '依据NHS此动作的文字练习次数；无人体或3D示范。' : '通用学习草案：组次参考CDC。需根据实际完成记录自行确认负荷。' };
  }
  function available(a, c) {
    const selected = c.actions?.length ? c.actions.includes(a.id) : (c.equipment || []).includes(a.equipmentKey);
    return selected && (!a.requiredEquipment || c.resources==null || a.requiredEquipment.every(k=>c.resources.includes(k))) && (c.location !== 'home' || a.equipmentKey === 'bodyweight') &&
      !(c.avoid?.includes('overhead') && a.group === 'shoulder') &&
      !(c.avoid?.includes('squat') && (a.id.includes('squat') || ['incline','home-sit-to-stand'].includes(a.id))) &&
      !(c.avoid?.includes('floor') && ['barbell-bench'].includes(a.id));
  }
  function summarize(p) {
    const days=p.days||[p],groups={},details={};let unknownLoadSets=0,bodyweightSets=0;
    const results=days.map(d=>{let seconds=300;d.items.forEach(i=>{
      seconds+=i.sets*60+(i.sets-1)*i.restSeconds+120;
      if(i.unit==='bodyweight'){bodyweightSets+=i.sets;return;}
      const kg=toKg(i.targetLoad,i.unit||'kg');if(kg==null){unknownLoadSets+=i.sets;return;}
      const factor=(i.sides||'both')==='both'&&['each-dumbbell','per-side'].includes(i.loadBasis)?2:1;
      const k=[i.actionId||i.customName,i.equipmentId,i.loadBasis,i.variant||'standard',i.sides||'both',i.unit||'kg'].join('|');
      groups[k]=(groups[k]||0)+kg*factor*i.sets*i.repsMin;
      details[k]={actionId:i.actionId,name:i.customName,equipmentId:i.equipmentId,basis:i.loadBasis,variant:i.variant||'standard',sides:i.sides||'both',unit:i.unit||'kg',volume:groups[k],volumeKg:groups[k]};
    });return {dayId:d.id,estimatedMinutes:Math.ceil(seconds/60),sets:d.items.reduce((sum,i)=>sum+i.sets,0)};});
    return {days:results,estimatedMinutes:results.reduce((sum,d)=>sum+d.estimatedMinutes,0),knownVolume:Object.values(groups).reduce((sum,v)=>sum+v,0),groups,groupDetails:Object.values(details),unknownLoadSets,bodyweightSets,complete:unknownLoadSets===0,
      method:'时间为5分钟准备、每组1分钟、组间休息与每动作准备2分钟的产品估算。公斤量按动作/器械/变体/侧/原单位/口径分项；lb乘0.45359237换为kg。双侧同重的每侧或每只哑铃乘2，单侧乘1，自重不计公斤量。'};
  }
  function generate(input={}) {
    const c=clone(input);c.days=Math.round(n(c.days,1,6)??3);c.minutes=n(c.minutes,15,120)??30;
    c.equipment=Array.isArray(c.equipment)?c.equipment:[];c.avoid=Array.isArray(c.avoid)?c.avoid:[];
    c.split=['ppl','upper_lower','full'].includes(c.split)?c.split:'full';
    c.timePreference=['time','coverage'].includes(c.timePreference)?c.timePreference:c.moreActions===true||c.timePriority===false?'coverage':'time';delete c.moreActions;delete c.timePriority;
    const eligible=all.filter(a=>available(a,c)),schedule={1:[1],2:[1,4],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,5,6],6:[1,2,3,4,5,6]}[c.days];
    const requested=Array.isArray(c.muscles)&&!c.muscles.includes('full')?c.muscles.filter(g=>['chest','back','shoulder','legs'].includes(g)):null;
    const patterns=c.split==='ppl'?[['chest','shoulder'],['back'],['legs']]:c.split==='upper_lower'?[['chest','back','shoulder'],['legs']]:[['legs','chest','back','shoulder']];
    const labels=c.split==='ppl'?['推','拉','腿']:c.split==='upper_lower'?['上肢','下肢']:['全身类别'];
    const names={chest:'推类',shoulder:'肩部',back:'拉类',legs:'下肢'},coverage={chest:0,shoulder:0,back:0,legs:0};
    const warnings=['当前目录未覆盖所有肌群与完整运动模式；草案不保证满足全部成人指南。'];
    if(!c.actions?.length&&c.location!=='home')warnings.push('型号尚未逐台确认：按器械类型列候选，开始前请核对现场实物。');
    if(c.equipment.includes('bodyweight')&&c.resources==null)warnings.push('墙面与稳固椅子条件尚未确认，请先核对准备条件。');
    const days=schedule.map((weekday,j)=>{
      const intended=requested||patterns[j%patterns.length],order=intended.map((g,k)=>({g,k})).sort((a,b)=>coverage[a.g]-coverage[b.g]||a.k-b.k).map(x=>x.g);
      const d={id:uid('day'),title:'第'+(j+1)+'日 · '+labels[j%labels.length],weekday,items:[]};
      for(const group of order){const choices=eligible.filter(a=>a.group===group);
        if(!choices.length){warnings.push('当前条件缺少'+names[group]+'，没有补入未选择或不存在的器械。');continue;}
        const pref=c.goal==='strength'&&c.experience==='experienced'?choices.find(a=>a.equipmentKey==='barbell'):choices.find(a=>a.equipmentKey==='selectorized');
        d.items.push(item(pref||choices[j%choices.length],c));
        if(c.timePreference==='time'&&summarize(d).estimatedMinutes>c.minutes)d.items.pop();else coverage[group]++;
      }
      d.omittedCategories=intended.filter(g=>!d.items.some(i=>byId[i.actionId]?.group===g));d.overBudgetMinutes=Math.max(0,summarize(d).estimatedMinutes-c.minutes);
      if(d.overBudgetMinutes)warnings.push('保留更多动作：第'+(j+1)+'日预计'+summarize(d).estimatedMinutes+'分钟，超过预算'+d.overBudgetMinutes+'分钟。');
      else if(d.omittedCategories.length&&d.items.length)warnings.push('第'+(j+1)+'日按时间优先减少动作，未安排'+d.omittedCategories.map(g=>names[g]).join('、')+'；其他日优先安排少练的类别。');
      return d;
    });
    const uncoveredCategories=[...new Set(requested||patterns.flat())].filter(g=>coverage[g]===0);
    if(uncoveredCategories.length)warnings.push('本周未覆盖'+uncoveredCategories.map(g=>names[g]).join('、')+'。可增加天数、时间或确认所需器械，也可选择保留更多动作并接受超时；不能称为完整全身安排。');
    if(!days.some(d=>d.items.length))warnings.push('还没有可执行动作，请先认识或确认器械与家庭准备条件。');
    if(c.days<2)warnings.push('你选择每周1天；草案不声称满足成人至少每周2天强化主要肌群的通用建议。');
    return {id:uid('plan'),version:1,title:({full:'全身类别学习',ppl:'推 / 拉 / 腿',upper_lower:'上 / 下肢'})[c.split]+' · '+c.days+'天',kind:'guided',createdAt:now(),updatedAt:now(),conditions:c,days,categoryCoverage:coverage,uncoveredCategories,warnings:[...new Set(warnings)],sourceLinks:['https://www.cdc.gov/physical-activity-basics/adding-adults/what-counts.html','https://www.nhs.uk/live-well/exercise/strength-exercises/'],templateNote:'通用学习草案，非个人最优处方。轮换与时间取舍是产品安排；家庭动作按NHS文字次数，不套用健身房負荷。'};
  }
  function revise(plan, mutate) { const p=clone(plan);p.parentId=p.id;p.familyId=plan.familyId||plan.id;p.id=uid('plan');p.version++;p.updatedAt=now();mutate(p);return p; }
  function fromLegacy(payload) {
    if(typeof payload==='string') { try{payload=JSON.parse(payload);}catch{return [];} }
    if(!payload || typeof payload!=='object')return [];
    const plans = Array.isArray(payload.plans) ? payload.plans : payload.plans != null ? [] : [payload], id='legacy-'+hash(JSON.stringify(payload));
    const days=plans.filter(d=>d&&typeof d==='object'&&!Array.isArray(d)).slice(0,Math.max(1,Math.min(6,Number(payload.split)||6))).map((d,j)=>({id:id+'-day-'+j,title:d.title || '原计划 '+(j+1),legacyContent:d.content || '',items:(Array.isArray(d.exercises)?d.exercises:[]).filter(e=>e&&typeof e==='object'&&String(e.action||'').trim()).map((e,k)=>{
      const a=all.find(a=>[a.name,...a.aliases].some(alias=>alias===e.action));
      const reps=String(e.reps||'').match(/\d+/g)?.map(Number)||[8];
      const i=a?item(a,{},id+'-item-'+j+'-'+k):{id:id+'-item-'+j+'-'+k,actionId:null,equipmentId:null,customName:String(e.action),sets:1,repsMin:8,repsMax:12,restSeconds:60,targetLoad:null,unit:'kg',loadBasis:'stack-labelled',loadSource:{type:'unknown',explanation:'旧课表没有重量或器械来源，未自动推算。'},alternatives:[],notes:''};
      i.sets=Math.max(1,Math.min(12,Math.floor(Number(e.sets)||1)));i.repsMin=Math.max(1,Math.min(50,reps[0]));i.repsMax=Math.max(i.repsMin,Math.min(50,reps[1]||reps[0]));i.notes=String(e.notes||'');i.legacyRow=clone(e);return i;
    })}));
    return [{id,title:'原手动课表（保留原文）',version:1,kind:'legacy',createdAt:now(),updatedAt:now(),conditions:{legacy:true},days,warnings:['原文字、动作与备注保留；未确认型号，不根据旧文本生成个人公斤数。']}];
  }
  const blankDraft = i => {const e=equipmentContext(i,null);return {load:'',reps:'',feel:'unsure',notes:'',unit:i?.recordUnit||i?.unit||'kg',equipmentConfirmed:e.confirmed,equipmentLabel:e.equipmentLabel};};
  const emptyRest = (enabled=true) => ({endAt:null,remainingMs:0,paused:false,enabled});
  const active = s => s.sessions.find(x=>x.id===s.activeSessionId);
  const recorded = (s,i) => s.sets.filter(r=>r.itemId===i.id && !r.deletedAt).length+s.events.filter(e=>e.type==='skip'&&e.data?.scope==='set'&&e.data.itemId===i.id).length;
  function advance(s) {
    const next=s.items.find(i=>!i.skippedAt&&recorded(s,i)<i.sets);
    s.cursor={itemId:next?.id||null,setIndex:next?recorded(s,next):0};s.draft=blankDraft(next);
  }
  function start(planId,dayId,overrides=null) {
    const old=state();if(old.activeSessionId)return {ok:false,error:'已有未结束训练，请先继续或提前结束。'};
    const p=old.plans.find(p=>p.id===planId),d=p?.days.find(d=>d.id===dayId);if(!d?.items.length)return {ok:false,error:'本日还没有可执行动作。'};
    const items=clone(overrides?.items||d.items);if(!items.length||items.length>100)return {ok:false,error:'本次安排需要1至100个动作'};items.forEach(i=>{delete i.equipmentContext;delete i.recordUnit;});
    const snapshot=clone(p);snapshot.days.find(x=>x.id===d.id).items=clone(items);
    const s={id:uid('session'),planId:p.id,planVersion:p.version,planSnapshot:snapshot,dayId:d.id,startedAt:now(),endedAt:null,status:'active',cursor:{itemId:items[0].id,setIndex:0},items,sets:[],events:[],draft:blankDraft(items[0]),rest:emptyRest(),sessionOnlyAdjustments:!!overrides};
    return {...atomic(st=>{st.sessions.push(s);st.activeSessionId=s.id;}),sessionId:s.id};
  }
  function draft(values) {return tx(st=>{const s=active(st);if(!s)throw Error('没有进行中训练');Object.assign(s.draft,values);});}
  function complete(expectedCursor) {
    return atomic(st=>{
      const s=active(st),i=currentEntry(s);if(!i)throw Error('没有当前动作');if(s.status!=='active')throw Error('训练已暂停，请先继续');
      if(expectedCursor&&(expectedCursor.itemId!==s.cursor.itemId||expectedCursor.setIndex!==s.cursor.setIndex))throw Error('当前组已变化，请重新确认');
      const raw=String(s.draft.load??''),reps=n(s.draft.reps,0,1000),load=n(raw);if(reps==null||!Number.isInteger(reps))throw Error('填写实际次数，未执行可填0。');
      if(raw.trim()!==''&&load==null)throw Error('实际重量须为非负数');
      const unit=i.unit==='bodyweight'?'bodyweight':s.draft.unit||i.unit||'kg';if(!['kg','lb','bodyweight'].includes(unit))throw Error('请选择kg或lb单位');
      const oldContext=equipmentContext(i,s),e=resolvedEquipment(i,s.draft);if(oldContext.confirmed&&oldContext.equipmentId!==e.equipmentId){i.targetLoad=null;i.loadSource={type:'unknown',explanation:'实际器械条件已变化，不沿用旧负荷参考。'};}i.equipmentContext=e;i.recordUnit=unit;
      s.sets.push({id:uid('set'),sessionId:s.id,itemId:i.id,actionId:i.actionId,equipmentId:e.confirmed?e.equipmentId:null,equipmentLabel:e.equipmentLabel,setIndex:s.cursor.setIndex,setType:s.draft.setType||'working',load:unit==='bodyweight'?null:load,reps,feel:s.draft.feel||'unsure',notes:s.draft.notes||'',completedAt:now(),unit,inputLoadRaw:unit==='bodyweight'?'':raw,inputUnit:unit,loadKg:toKg(load,unit),loadBasis:i.loadBasis,actionName:i.customName,variant:i.variant||'standard',sides:i.sides||'both',targetSnapshot:{repsMin:i.repsMin,repsMax:i.repsMax,targetLoad:i.targetLoad,unit:i.unit,loadBasis:i.loadBasis}});
      const settings=s.rest,seconds=settings.nextSeconds||i.restSeconds;advance(s);
      s.rest={...emptyRest(settings.enabled),durationSeconds:seconds,...(settings.nextSeconds?{nextSeconds:settings.nextSeconds}:{}),endAt:settings.enabled&&s.cursor.itemId?Date.now()+seconds*1000:null,remainingMs:settings.enabled&&s.cursor.itemId?seconds*1000:0};
    });
  }
  function event(s,type,data) {s.events.push({id:uid('event'),type,at:now(),data:clone(data||{})});}
  function remaining(s) { const r=s?.rest || B.store.getRest?.() || active(state())?.rest;return !r||!r.enabled?0:r.paused?r.remainingMs:Math.max(0,(r.endAt||0)-Date.now()); }
  function rest(action) {
    return atomic(st=>{const s=active(st);if(!s)throw Error('没有进行中的训练');const r=s.rest,left=remaining(s);
      if(action==='on'){r.enabled=true;r.paused=false;const seconds=r.nextSeconds||r.durationSeconds||currentEntry(s)?.restSeconds||60;r.durationSeconds=seconds;r.remainingMs=s.cursor.itemId&&s.sets.length?seconds*1000:0;r.endAt=r.remainingMs?Date.now()+r.remainingMs:null;}
      else if(action==='off'){r.enabled=false;r.paused=false;r.endAt=null;r.remainingMs=0;}
      else if(action==='skip'){r.endAt=null;r.remainingMs=0;r.paused=false;}
      else if(action==='restart'&&r.enabled){const seconds=r.durationSeconds||currentEntry(s)?.restSeconds||60;r.remainingMs=seconds*1000;r.endAt=Date.now()+r.remainingMs;r.paused=false;}
      else if(r.enabled&&action==='pause'){r.remainingMs=left;r.endAt=null;r.paused=true;}
      else if(r.enabled&&action==='resume'&&r.paused){r.endAt=r.remainingMs?Date.now()+r.remainingMs:null;r.paused=false;}
      else if(r.enabled&&action==='extend'&&s.cursor.itemId){r.remainingMs=left+30000;if(!r.paused)r.endAt=Date.now()+r.remainingMs;}
    });
  }
  function interrupt(type,replacement) {
    return atomic(st=>{const s=active(st),i=currentEntry(s);if(!i)throw Error('没有当前动作');
      if(type==='skip'){i.skippedAt=now();event(s,'skip',{itemId:i.id,reason:replacement||'用户跳过'});}
      else{const a=byId[replacement];if(!a)throw Error('替代动作不存在');const before=clone(i),sets=i.sets,min=i.repsMin,max=i.repsMax;delete i.equipmentContext;delete i.recordUnit;Object.assign(i,item(a,s.planSnapshot.conditions,i.id),{sets,repsMin:min,repsMax:max});const remainingSets=Math.max(0,i.sets-recorded(s,i));event(s,'replace',{before,after:clone(i),remainingSets,reason:'已保留原动作的已完成组，接下来还有'+remainingSets+'组使用新动作。'});}
      s.rest={...emptyRest(s.rest.enabled),...(s.rest.nextSeconds?{nextSeconds:s.rest.nextSeconds}:{})};advance(s);
    });
  }
  function pause() {return atomic(st=>{const s=active(st);if(!s)throw Error('没有进行中训练');s.status=s.status==='paused'?'active':'paused';if(s.status==='paused'){s.rest.remainingMs=remaining(s);s.rest.endAt=null;s.rest.paused=true;}else if(s.rest.paused&&s.rest.enabled){s.rest.endAt=s.rest.remainingMs?Date.now()+s.rest.remainingMs:null;s.rest.paused=false;}event(s,s.status==='paused'?'pause':'resume');});}
  function end(sessionId) {return atomic(st=>{const s=sessionId?st.sessions.find(s=>s.id===sessionId):active(st);if(!s)throw Error('没有进行中训练');if(s.endedAt)return;s.endedAt=now();s.status=sessionSummary(s).completionEligible?'completed':'partial';event(s,'end',{status:s.status,summary:sessionSummary(s)});s.rest=emptyRest(s.rest.enabled);st.activeSessionId=null;B.TrainingData?.numberSessions(st);});}
  function skipSet(){return atomic(st=>{const s=active(st),i=currentEntry(s);if(!i)throw Error('没有当前组');event(s,'skip',{scope:'set',itemId:i.id,setIndex:s.cursor.setIndex});advance(s);s.rest=emptyRest(s.rest.enabled);});}
  function addSet(){return atomic(st=>{const s=active(st),i=currentEntry(s)||s?.items.at(-1);if(!i||i.sets>=12)throw Error('每个动作最多12组');i.sets++;if(!s.cursor.itemId)advance(s);});}
  function correct(setId,values) {
    return atomic(st=>{const s=st.sessions.find(s=>s.sets.some(r=>r.id===setId)),r=s?.sets.find(r=>r.id===setId);if(!r)throw Error('该组不存在');
      const before=clone(r),reps=n(values.reps,0,1000),raw=values.inputLoadRaw??(values.load==null?'':String(values.load)),load=n(raw);if(reps==null||!Number.isInteger(reps))throw Error('次数须为非负整数');if(String(raw).trim()!==''&&load==null)throw Error('重量格式无效');
      const unit=r.unit==='bodyweight'?'bodyweight':values.inputUnit||values.unit||r.inputUnit||r.unit||'kg';if(!['kg','lb','bodyweight'].includes(unit))throw Error('单位无效');
      Object.assign(r,{reps,load:unit==='bodyweight'?null:load,unit,inputLoadRaw:unit==='bodyweight'?'':String(raw),inputUnit:unit,loadKg:toKg(load,unit),notes:values.notes!=null?String(values.notes):String(r.notes||''),feel:values.feel||r.feel});event(s,'correction',{before,after:clone(r)});if(s.endedAt){s.status=sessionSummary(s).completionEligible?'completed':'partial';B.TrainingData?.numberSessions(st);}
    });
  }
  function last(actionId,equipmentId,b,variant='standard',sides='both',unit='kg') {
    const q={actionId,equipmentId,loadBasis:b,variant,sides,unit};return state().sessions.flatMap(s=>s.sets).filter(r=>!r.deletedAt&&sameIdentity(r,q)).sort((a,b)=>b.completedAt.localeCompare(a.completedAt))[0]||null;
  }

  // Unit conversion changes display units only; it never transfers ability across machines.
  const LB_TO_KG=0.45359237;
  const atomic=fn=>tx(fn,{onFailure:'base'});
  const activeSession=()=>B.store.getActiveSession?.()||active(state());
  const currentEntry=s=>s?.items.find(i=>i.id===s.cursor.itemId);
  const normalizeLabel=v=>String(v||'').normalize('NFKC').trim().replace(/\s+/g,' ').toLowerCase();
  const customEquipmentId=label=>'custom-'+hash(normalizeLabel(label));
  const unknownEquipment=label=>({confirmed:false,equipmentId:null,equipmentLabel:String(label||'').trim(),kind:'unknown'});
  function toKg(value,unit='kg'){const valueN=n(value);return valueN==null||!['kg','lb'].includes(unit)?null:unit==='lb'?valueN*LB_TO_KG:valueN;}
  function convertLoad(value,from='kg',to='kg'){const kg=toKg(value,from);return kg==null||!['kg','lb'].includes(to)?null:to==='lb'?kg/LB_TO_KG:kg;}
  function recordLoadKg(r){if(!r||r.unit==='bodyweight'||r.inputUnit==='bodyweight')return null;return own(r,'loadKg')?r.loadKg:toKg(r.load,r.unit||'kg');}
  function formatLoad(r,digits=1){if(r?.unit==='bodyweight'||r?.inputUnit==='bodyweight')return '自重';const unit=r?.inputUnit||r?.unit||'kg',raw=r?.inputLoadRaw??(r?.load==null?'':String(r.load));return String(raw).trim()===''||recordLoadKg(r)==null?'重量未知':String(raw)+' '+unit+(unit==='lb'?' ≈ '+recordLoadKg(r).toFixed(digits)+' kg':'');}
  function equipmentContext(i=currentEntry(activeSession()),s=activeSession()){
    if(typeof i==='string'){const id=i;i=s?.items.find(entry=>entry.id===id);}
    const e=i?.equipmentContext;if(!e?.confirmed||!e.equipmentId)return unknownEquipment(e?.equipmentLabel);
    if(e.kind==='catalog'&&e.equipmentId!==i.equipmentId)return unknownEquipment(e.equipmentLabel);return clone(e);
  }
  function confirmEquipment(selection={}){
    return atomic(st=>{const s=active(st),i=currentEntry(s);if(!i)throw Error('没有当前动作');let e;
      if(selection.kind==='custom'){const label=String(selection.equipmentLabel??selection.label??'').trim();if(!label||label.length>200)throw Error('填写不超过200字的现场器械名称');e={confirmed:true,equipmentId:customEquipmentId(label),equipmentLabel:label,kind:'custom'};}
      else if(selection.kind==='catalog'){const id=selection.equipmentId||i.equipmentId;if(!id||id!==i.equipmentId)throw Error('请确认当前型号，或填写自定义器械名称');e={confirmed:true,equipmentId:id,equipmentLabel:String(selection.equipmentLabel??selection.label??'').trim()||byId[i.actionId]?.model||id,kind:'catalog'};}
      else e=unknownEquipment(selection.equipmentLabel??selection.label);
      const old=equipmentContext(i,s);if(old.confirmed?old.equipmentId!==e.equipmentId:e.confirmed&&e.equipmentId!==i.equipmentId){i.targetLoad=null;i.loadSource={type:'unknown',explanation:'实际器械已改变，不沿用另一器械的负荷参考。'};}
      i.equipmentContext=e;Object.assign(s.draft,{equipmentConfirmed:e.confirmed,equipmentLabel:e.equipmentLabel});
    });
  }
  function resolvedEquipment(i,d){let e=equipmentContext(i,null);const label=String(d.equipmentLabel||'').trim();if(e.confirmed&&label&&normalizeLabel(label)!==normalizeLabel(e.equipmentLabel))return unknownEquipment(label);
    if(!e.confirmed&&d.equipmentConfirmed===true){if(d.equipmentKind==='custom'||(!i.equipmentId&&label))e={confirmed:true,equipmentId:customEquipmentId(label),equipmentLabel:label,kind:'custom'};else if(i.equipmentId)e={confirmed:true,equipmentId:i.equipmentId,equipmentLabel:label||byId[i.actionId]?.model||i.equipmentId,kind:'catalog'};}return e;
  }
  function setRestSeconds(seconds){const value=n(seconds,30,600);if(value==null||!Number.isInteger(value))return {ok:false,error:'后续组休息须为30–600秒整数'};return atomic(st=>{const s=active(st);if(!s)throw Error('没有进行中训练');s.rest.nextSeconds=value;});}
  function sessionSummary(s=activeSession()){
    if(!s)return {recordedSets:0,executedSets:0,targetSets:0,targetMetSets:0,skippedSets:0,unfinishedSets:0,unexecutedSets:0,zeroRepSets:0,pendingSets:0,unmetTargetSets:0,items:[],skippedItems:[],completionEligible:false,endedEarly:false,status:null};
    const items=s.items.map(i=>{const rows=s.sets.filter(r=>r.itemId===i.id&&!r.deletedAt),executedSets=rows.filter(r=>r.reps>0).length;
      const targetMetSets=rows.filter(r=>{const target=r.targetSnapshot||s.planSnapshot.days.find(d=>d.id===s.dayId)?.items.find(x=>x.id===i.id)||i;if(!(r.reps>0)||r.reps<target.repsMin)return false;if(target.targetLoad==null||target.unit==='bodyweight')return true;const kg=recordLoadKg(r),required=toKg(target.targetLoad,target.unit||'kg');return kg!=null&&required!=null&&kg>=required&&r.loadBasis===target.loadBasis;}).length;
      const singleSkips=s.events.filter(e=>e.type==='skip'&&e.data?.scope==='set'&&e.data.itemId===i.id).length;const skippedSets=i.skippedAt?Math.max(0,i.sets-rows.length):Math.min(singleSkips,Math.max(0,i.sets-rows.length));
      return {itemId:i.id,actionId:i.actionId,name:i.customName,targetSets:i.sets,recordedSets:rows.length,executedSets,targetMetSets,skippedSets,zeroRepSets:rows.filter(r=>r.reps===0).length,pendingSets:Math.max(0,i.sets-rows.length-skippedSets),unexecutedSets:Math.max(0,i.sets-executedSets),unfinishedSets:Math.max(0,i.sets-executedSets-skippedSets),unmetTargetSets:Math.max(0,i.sets-targetMetSets),skipped:!!i.skippedAt};
    });const total=k=>items.reduce((sum,i)=>sum+i[k],0);return {recordedSets:total('recordedSets'),executedSets:total('executedSets'),targetSets:total('targetSets'),targetMetSets:total('targetMetSets'),skippedSets:total('skippedSets'),unfinishedSets:total('unfinishedSets'),remainingSets:total('pendingSets'),unexecutedSets:total('unexecutedSets'),zeroRepSets:total('zeroRepSets'),pendingSets:total('pendingSets'),unmetTargetSets:total('unmetTargetSets'),items,skippedItems:items.filter(i=>i.skipped),completionEligible:total('targetSets')>0&&items.every(i=>i.executedSets>=i.targetSets&&i.skippedSets===0),endedEarly:!!s.endedAt&&items.some(i=>i.recordedSets<i.targetSets),status:s.status};
  }
  function identity(i,s){const record=own(i||{},'completedAt'),e=record?null:equipmentContext(i,s);return {actionId:i?.actionId||'custom-action-'+hash(normalizeLabel(i?.actionName||i?.customName)),equipmentId:record?i.equipmentId:e?.confirmed?e.equipmentId:null,variant:i?.variant||'standard',sides:i?.sides||'both',unit:i?.inputUnit||i?.recordUnit||i?.unit||'kg',loadBasis:i?.loadBasis};}
  function sameIdentity(r,q,conversion=false){const a=identity(r);return !!q.equipmentId&&!!a.equipmentId&&['actionId','equipmentId','variant','sides','loadBasis'].every(k=>q[k]==null&&k==='loadBasis'||a[k]===q[k])&&(a.unit===q.unit||conversion&&['kg','lb'].includes(a.unit)&&['kg','lb'].includes(q.unit));}
  function queryIdentity(i,s){return i&&own(i,'loadBasis')&&own(i,'equipmentId')&&!own(i,'id')?i:identity(i,s);}
  function lastCurrent(i=currentEntry(activeSession()),s=activeSession(),options={}){if(!i||!s)return null;const q=queryIdentity(i,s),r=s.sets.filter(r=>{if(r.deletedAt)return false;if(sameIdentity(r,q,options.allowUnitConversion))return true;if(q.equipmentId||r.equipmentId||!i.id||r.itemId!==i.id)return false;const a=identity(r);return ['actionId','variant','sides','unit','loadBasis'].every(k=>a[k]===q[k])&&normalizeLabel(r.equipmentLabel)===normalizeLabel(i.equipmentContext?.equipmentLabel);}).reverse().sort((a,b)=>b.completedAt.localeCompare(a.completedAt))[0];return r?{...clone(r),sessionId:s.id,sessionDate:s.startedAt,sessionPlanTitle:s.planSnapshot.title}:null;}
  function lastPrevious(i=currentEntry(activeSession()),s=activeSession(),options={}){if(!i)return null;const q=queryIdentity(i,s),sessions=state().sessions.filter(x=>x.id!==s?.id).reverse().sort((a,b)=>b.startedAt.localeCompare(a.startedAt));for(const previous of sessions){const r=lastCurrent(q,previous,options);if(r)return r;}return null;}
  function availability(a,c={}){
    const blockedReasons=[],needsConfirmation=[],equipment=Array.isArray(c.equipment)?c.equipment:[],actions=Array.isArray(c.actions)?c.actions:[],avoid=Array.isArray(c.avoid)?c.avoid:[],resources=Array.isArray(c.resources)?c.resources:null;
    if(c.location==='home'&&a.equipmentKey!=='bodyweight')blockedReasons.push('当前选择家庭场所，需要改变条件。');
    if(avoid.includes('overhead')&&a.group==='shoulder')blockedReasons.push('你选择回避肩部举起类。');
    if(avoid.includes('squat')&&(a.id.includes('squat')||['incline','home-sit-to-stand'].includes(a.id)))blockedReasons.push('你选择回避深蹲/倒蹬/起坐类。');
    if(avoid.includes('floor')&&a.id==='barbell-bench')blockedReasons.push('你选择回避卧姿杠铃动作。');
    const required=a.requiredEquipment||[];if(resources&&required.some(k=>!resources.includes(k)))blockedReasons.push('未选择所需准备条件：'+required.filter(k=>!resources.includes(k)).join('、'));else if(!resources&&required.length)needsConfirmation.push('准备条件待确认：'+required.join('、'));
    if(!actions.includes(a.id)){if(!equipment.includes(a.equipmentKey))needsConfirmation.push('所需器械尚未确认。');else if(a.sceneKey)needsConfirmation.push('仅选择器械类型，具体型号尚未确认。');}
    return {status:blockedReasons.length?'blocked':needsConfirmation.length?'pending':'available',blockedReasons,needsConfirmation};
  }
  function replacementCandidates(i=currentEntry(activeSession()),c=activeSession()?.planSnapshot.conditions||{}){
    const candidates=all.filter(a=>a.id!==i?.actionId).map(a=>({id:a.id,action:clone(a),name:a.name,equipmentId:a.equipmentId,equipmentKey:a.equipmentKey,equipmentName:a.equipmentName||a.model||(a.requiredEquipment||[]).join('、'),relationship:i?.alternatives?.includes(a.id)?'目录中的替代选项，不代表等价，不换算重量。':byId[i?.actionId]?.group===a.group?'同一浏览类别的另一动作。':'不同浏览类别，请确认本次安排。',...availability(a,c)}));return {available:candidates.filter(a=>a.status==='available'),pending:candidates.filter(a=>a.status==='pending'),all:candidates};
  }

  B.flow={all,byId,uid,n,clone,state,tx,basis,item,generate,summarize,revise,fromLegacy,start,draft,active:()=>B.store.getActiveSession?.() || active(state()),complete,rest,remaining,interrupt,pause,end,skipSet,addSet,correct,last,sessionSummary,replacementCandidates,availability,confirmEquipment,equipmentContext,customEquipmentId,identity,lastCurrent,lastPrevious,setRestSeconds,toKg,convertLoad,recordLoadKg,formatLoad,LB_TO_KG};
  B.plan={generate,summarize,fromLegacy,mutatePlanVersion:revise,renderLegacy:()=>{}};
})();
