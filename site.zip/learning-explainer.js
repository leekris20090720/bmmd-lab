/* Presentation-only lessons. All physical values come from mechanics-core.
 * No training storage, replacement physics engine, or calibrated dimensions. */
(function (global) {
  'use strict';
  const node = typeof module === 'object' && module.exports;
  const B = global.BM || {}, M = node ? require('./mechanics-core.js') : B.Mechanics;
  const clone = v => JSON.parse(JSON.stringify(v));
  const clamp = v => Math.max(0, Math.min(1, v));
  function sameLift(params, ratio) {
    const height = params.handleTravelM / params.ratio;
    const next = { ...clone(params), ratio, handleTravelM: height * ratio };
    const result = M.evaluate('pulley', next, 1);
    if (!result.valid) throw Error(result.reasons.join(' '));
    if(next.sources && next.handleTravelM!==params.handleTravelM)next.sources.handleTravelM='unknown';
    return next;
  }
  function study(model, params, baseline, progress) {
    const current = M.evaluate(model, params, progress);
    const before = current.valid && model!=='pulley' ? M.atCoordinate(model,baseline,model==='cam'?current.angleRad:current.displacementM) : M.evaluate(model,baseline,progress);
    const result = { current, before, alternatives: [] };
    if (!current.valid) return result;
    if (model === 'pulley') {
      result.heightM = params.handleTravelM / params.ratio;
      result.alternatives = [1, 2, 4].map(ratio => {
        try { const p = sameLift(params, ratio); return { ratio, params: p, result: M.evaluate(model, p, progress) }; }
        catch (error) { return { ratio, error: error.message }; }
      });
    }
    if (model === 'incline') result.alternatives = ['up', 'down'].map(direction => ({ direction,
      result: M.evaluate(model, { ...params, direction }, progress) }));
    return result;
  }
  const nextProgress = progress => Math.min(1, Math.round((progress + .05) * 1e8) / 1e8);
  if (node) { module.exports = { sameLift, study, nextProgress }; return; }
  if (!M || !global.document) return;
  const P=B.LessonProfiles;
  const $ = s => document.querySelector(s), esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  const en = () => B.i18n?.getLanguage() === 'en';
  const D = {
    identify:['找到关键位置','Find the key parts'], prepare:['完成准备','Get ready'], move:['观察运动','Watch the moving arm'], moveHome:['分阶段练习','Follow each phase'], errors:['查看常见错误','Review one common error'],
    homePartHelp:['点名称，查看示意图中的对应位置。','Choose a label to locate it in the diagram.'],
    selfCheckTask:['核对当前动作的一处情况；这是文字自查，不是自动检测。','Check one situation for this exercise. This is self-review, not automatic detection.'],
    identifyTask:['先找到坐垫、靠背、转轴和小腿垫。','First locate the seat, backrest, pivot and shin pads.'],
    prepareTask:['把膝关节对准器械转轴，再确认滚垫的位置。','Align the knee with the machine pivot, then check the pads.'],
    moveTask:['只观察工作臂：它带着小腿垫绕转轴运动。','Watch the working arm carry the shin pads around the pivot.'],
    errorTask:['一次核对一处；这些是教学例子，不是动作检测。','Check one example at a time. This is instruction, not motion detection.'],
    seat:['坐垫','Seat'], back:['靠背','Backrest'], axis:['器械转轴','Machine pivot'], roller:['小腿垫','Shin pads'],
    seatNote:['坐稳坐垫，双手握住两侧把手。','Sit securely and hold the side handles.'],
    backNote:['背部贴住靠背；实物调节以现场说明为准。','Keep the back supported; follow the instructions on the actual machine.'],
    axisNote:['观察器械侧面的转轴。膝关节应与它对齐。','Find the pivot on the side of the machine and align the knee with it.'],
    rollerNote:['滚垫放在脚踝上方的小腿前侧，不压在脚背上。','Place the pads against the front of the lower leg above the ankle, not on the foot.'],
    partHelp:['点名称，对应部件会提亮；镜头移动时可直接拖动打断。','Select a name to highlight that part. Drag to interrupt the camera.'],
    next:['下一步','Next'], previous:['上一步','Previous'], restart:['重新看一遍','Start again'], nextError:['看下一个例子','Next example'],
    observe:['观察位置','Where to look'], situation:['容易出现的情况','What can happen'], correction:['调整提示','What to adjust'],
    reference:['实物参照 · 型号与调节请核对现场器械','Reference photo · check the actual model and adjustment instructions'],
    idealOnly:['这里比较理想传动配置；不表示当前实物可以改变倍率或绕索。','These are ideal transmission comparisons, not changes available on this machine.'],
    noHumanHome:['位置图只帮助辨认支撑点；没有人体模型或动作检测。','The position diagram identifies supports. There is no human model or motion detection.'],
    nextPhase:['下一运动阶段','Next movement phase'], homeMoveTask:['按提示分阶段练习；图中只标示支撑位置。','Follow the phase cues; the diagram only marks support positions.'],
    readyTask:['先让器械静止，核对下面的支撑、握法和固定条件。','With the equipment still, check the support, grip and securing conditions below.'],
    readyHome:['先确认支撑稳固，再按当前动作摆好起始位置。','Check the support is stable, then take the starting position for this exercise.'],
    motionTask:['对照当前阶段的提示，观察本动作的运动部件。','Read the current phase cues and follow this exercise’s moving part.'],
    positionOnly:['支撑位置示意 · 不是人体动作演示','Support-position diagram · not a human demonstration'],
    noHuman:['器械动画不是人体动作示范；本模型没有人体或动作检测。','The machine animation is not a human demonstration. There is no body tracking.'],
    stopIfPain:['出现不适时停止当前组；文字与模型不能判断原因。','Stop the set if discomfort occurs; text and models cannot determine its cause.'],
    details:['完整说明、来源与模型边界','Full instructions, sources and model limits'],
    watch:['看一遍讲解','Watch the walkthrough'], pause:['暂停','Pause'], resume:['继续讲解','Resume'], exit:['退出讲解','Exit walkthrough'],
    forceTitle:['看一个力','Study one force'], changeTitle:['改变作用线','Move the force line'], compareTitle:['比较前后','Compare before and after'], conclusionTitle:['得到结论','Conclusion'],
    demo0:['先认出整台器械。','Start with the whole machine.'], demo1:['观察转轴和滚垫的连接位置。','Locate the pivot and the pad connection.'], demo2:['工作臂缓慢伸出，再回到原处。','The working arm moves out slowly, then returns.'],
    demo3:['现在只研究一个力对器械轴的转动作用。','Now examine one force acting about the machine shaft.'], demo4:['保持力不变，只把作用线移远一点。','Keep the force fixed and move its line of action farther away.'], demo5:['虚线保留原状态，实线是改变后的状态。','The dashed line retains the baseline; the solid line is the new state.'], demo6:['垂直力臂增大，同一力的力矩随之增大。','A longer perpendicular arm gives the same force a larger torque.'],
    automaticPaused:['你已接管操作，讲解已暂停。','You took control. The walkthrough is paused.'],
    question:['为什么同样的力，作用位置不同，转动效果会变化？','Why does moving the same force change its turning effect?'],
    object:['先选分析对象：理想传动轴。','Choose the ideal transmission shaft as the analysis object.'],
    force:['只看这一个力：钢索张力，方向向下。','Study one force: downward cable tension.'],
    line:['沿力的方向延长，就得到力的作用线。','Extend the force direction to obtain its line of action.'],
    distance:['从转轴向作用线作垂线，这段才是有效力臂。','The perpendicular from the pivot to the line of action is the effective arm.'],
    vary:['力的大小固定，只移动这条作用线。','Keep the force fixed and move only its line of action.'],
    compare:['对照虚线基准，看力臂和力矩一起变化。','Compare against the dashed baseline: the arm and torque change together.'],
    meaning:['力矩描述一个力使物体绕指定轴转动的作用。在力相同的情况下，垂直力臂越长，力矩越大。','Torque describes the turning effect of one force about a specified axis. For the same force, a longer perpendicular arm gives a larger torque.'],
    shaftOnly:['这里研究器械轴，不是膝关节力矩、肌肉力量或你实际感到的难度。','This concerns the machine shaft, not knee-joint torque, muscle force or perceived effort.'],
    shaftGeneric:['这里解释理想传动轴，不代表人体关节力矩、肌肉力量或你实际感到的难度。','This explains an ideal transmission shaft, not human joint torque, muscle force or perceived effort.'],
    modelExample:['理想传动图解 · 模型示例，尺寸不是器械实测值','Ideal transmission diagram · example values, not measured equipment dimensions'],
    baseArm:['基准有效力臂 d₀（m）','Base effective arm d₀ (m)'], motionTorqueTask:['沿角度 θ 定位，观察假设的 d(θ) 如何改变阻力矩。','Position the ideal angle θ and observe how the assumed d(θ) changes torque.'],
    variableArm:['移动作用线 · 垂直力臂 d（m）','Move the line of action · perpendicular arm d (m)'],
    changeOne:['自己改变一个条件','Change one condition'], formula:['查看公式解释','Explain the formula'], fullLab:['进入完整实验室','Open the full lab'],
    F:['F · 指定力的大小','F · magnitude of the selected force'], d:['d · 转轴到作用线的垂距','d · perpendicular pivot-to-line distance'], tau:['τ · 该力对指定轴的力矩大小','τ · magnitude of this force’s torque about the axis'],
    pivot:['O · 转轴','O · pivot'], forceLine:['力的作用线','Line of action'], baseline:['虚线：比较基准','Dashed: comparison baseline'],
    step:['步骤','Step'], ready:['准备','Ready'], push:['发力','Extend'], return:['返回','Return'],
    phenomenon:['1 · 看懂现象','1 · Observe'], experiment:['2 · 动手比较','2 · Compare'], math:['3 · 理解公式','3 · Explain'], research:['4 · 进一步研究','4 · Research'],
    camQuestion:['同样的钢索张力，力臂变长后，轴上的力矩怎样变化？','With cable tension fixed, how does a longer arm change shaft torque?'],
    pulleyQuestion:['抬高同一配重同样高度，能用更长行程换取更小拉力吗？','Can a longer pull lift the same load to the same height with less force?'],
    inclineQuestion:['同一滑车推起与下放，摩擦怎样改变外力和机械功？','How does friction change force and work when the same sled moves up or down?'],
    camTask:['先看轴 O、钢索作用线与垂距 d。然后只改变基准力臂，其余条件保留。','Locate O, the cable line and d. Then change only the base arm; keep the other conditions fixed.'],
    pulleyTask:['先看手柄与配重反向运动。比较时固定抬升高度；倍率改变，手柄总行程也要相应改变。','Watch handle and load move in opposite directions. Keep lift height fixed for comparison; total handle travel must change with the ratio.'],
    inclineTask:['先选滑车为分析对象。只改变摩擦系数，再分别检查上推与下放。','Choose the sled as the object. Change only friction, then examine upward and downward travel.'],
    more:['更多参数与输入来源','More parameters and input sources'], further:['进阶工具：曲线设计、微积分、范围与档案','Advanced tools: design, calculus, ranges and archives'],
    singleStep:['单步 +5% 行程','Step +5% travel'], resetPose:['重置姿态','Reset pose'], restoreBaseline:['恢复比较基准','Restore comparison baseline'],
    transport:['比较同一抬升高度','Compare the same lift height'], liftNote:['各配置的配重抬升高度相同；超出输入范围的配置会说明原因。','All configurations lift the load by the same height. Out-of-range cases show a reason.'],
    ratio:['理想倍率','Ideal ratio'], handleForce:['手柄拉力 N','Handle force N'], handleTravel:['总手柄行程 m','Total handle travel m'], inputWork:['输入功 J','Input work J'], potential:['势能变化 J','Potential change J'], dissipated:['摩擦耗散 J','Friction loss J'],
    up:['上推','Upward'], down:['受控下放','Controlled lowering'], direction:['运动方向','Travel direction'], forceN:['沿上坡外力 N','Force uphill N'],
    energyNote:['机械功不等于人体热量。下放时保留功的正负号；播放只规定姿态，不计算惯性附加力。','Mechanical work is not metabolic energy. Lowering retains work signs; playback prescribes poses and adds no inertial forces.'],
    camConclusion:['在同一角度，对照垂直力臂、钢索张力与轴上负载力矩。','At the same angle, compare the perpendicular arm, cable tension and shaft load torque.'],
    pulleyConclusion:['理想传动用更长手柄行程换取更小拉力；输入功与势能增加相等。','An ideal transmission trades longer handle travel for less force; input work equals the potential increase.'],
    inclineConclusion:['摩擦总与运动相反。比较同一行程，上推和下放的耗散均不为负。','Friction opposes motion. For the same travel, dissipation is nonnegative in both directions.'],
    current:['当前','Current'], original:['基准','Baseline'], samePose:['当前条件与基准对照','Current conditions vs. baseline'],
    formulaNote:['公式解释的是刚才的图：选中一个变量，可突出它对应的对象。','The formula describes the diagram you just saw. Select a variable to highlight its object.'],
    glossary:['概念就地解释','Terms explained here'], torqueDef:['力矩：一个力对指定轴的转动作用，单位 N·m。','Torque: the turning effect of a force about an axis, in N·m.'],
    armDef:['力臂：转轴到力作用线的垂直距离，不是摆臂长度。','Moment arm: the perpendicular pivot-to-force-line distance, not the lever length.'],
    derivativeDef:['导数：阻力曲线在当前位置随角度或位移变化得多快，不是角速度。','Derivative: how quickly resistance changes with angle or displacement, not angular velocity.'],
    integralDef:['积分：沿路径累计许多小段的贡献；这里累计机械功，单位 J。','Integral: accumulate small contributions along a path; here the result is mechanical work in J.'],
    dampingDef:['阻尼：模型中让振动逐渐衰减的作用；现有弹簧使用归一化单位。','Damping: the effect that reduces oscillation in the model; the spring uses normalized units.'],
    secant:['两个点靠近：从割线看局部变化','Bring two points closer: from secant to local slope'],
    frictionLabel:['动摩擦系数','Friction coefficient'], fixedLiftTitle:['固定配重总抬升高度','Fixed total load lift'],
    gap:['两点进度间距','Gap between the two positions'], accumulated:['从起点累计的机械功','Mechanical work accumulated from the start'],
    invalid:['输入无效：先修正参数，图解与比较暂不显示。','Invalid input: correct the parameters before viewing diagrams or comparisons.'],
    genericModel:['下面用通用理想传动轴解释原理；这台器械的实际传动关系尚未核实，图解不是它的实测结构。','The diagram uses a generic ideal shaft. This machine’s actual transmission has not been verified; this is not a measured representation of it.'],
    fullReadouts:['完整读数','All readings'],
    noExtra:['先理解当前关系，再打开高级工具。原来的搜索、范围、来源和档案都保留。','Understand this relation first, then open advanced tools. Search, ranges, sources and archives remain available.'],
    playHint:['播放是规定运动示意，不是自由动力学模拟。单步将进度前移5%。','Playback is prescribed motion, not free dynamics. Each step advances progress by 5%.'],
    unavailable:['三维未就绪：可用实物照片和图解继续学习。','3D is unavailable: continue with the reference photo and diagrams.'],
  };
  const txt = key => D[key]?.[en() ? 1 : 0] ?? key;
  const h = key => `<span data-i18n-skip data-did-key="${key}">${esc(txt(key))}</span>`;
  const btn = (key, action, extra='', primary=false) => `<button type="button" data-did="${action}" ${extra} class="${primary?'bm-primary eng-primary':''}">${h(key)}</button>`;
  const f = (v,n=2) => Number.isFinite(v) ? v.toFixed(n) : '—';
  let lesson = { id:'', step:0, error:0, intro:0, arm:.12 }, current=null, demo=null, demoFrame=0, binding=null;
  const media = matchMedia('(prefers-reduced-motion: reduce)');
  function catalogText(value) { return `<span data-i18n-skip data-did-source="${esc(value)}">${esc(B.i18n?.t(value)||value)}</span>`; }
  const pair=value=>Array.isArray(value)?`<span data-i18n-skip data-did-zh="${esc(value[0])}" data-did-en="${esc(value[1])}">${esc(value[en()?1:0])}</span>`:catalogText(value);
  function localize(root=document) {
    root.querySelectorAll('[data-did-zh]').forEach(el=>{el.textContent=en()?el.dataset.didEn:el.dataset.didZh;});
    root.querySelectorAll('[data-did-key]').forEach(el => { el.textContent=txt(el.dataset.didKey); });
    root.querySelectorAll('[data-did-label]').forEach(el=>el.setAttribute('aria-label',txt(el.dataset.didLabel)));
    root.querySelectorAll('[data-did-source]').forEach(el=>{el.textContent=B.i18n?.t(el.dataset.didSource)||el.dataset.didSource;});
    root.querySelectorAll('[data-did-alt]').forEach(el=>{el.alt=B.i18n?.t(el.dataset.didAlt)||el.dataset.didAlt;});
  }
  function image(a) { return a.image ? `<figure class="did-reference"><img src="${esc(a.image)}" data-did-alt="${esc(a.name)}" alt="${esc(B.i18n?.t(a.name)||a.name)}"><figcaption>${h('reference')}</figcaption></figure>` : ''; }
  const demoLast=()=>current?.a.sceneKey&&P.forAction(current.a).model!=='qualitative'?6:3;
  function demoCopy(i){
    const a=current?.a;if(!a)return '';const p=P.lesson(a),part=p.parts.find(x=>x.id===p.preparePart);
    if(i===0)return pair([`先认出${a.name}的支撑与操作位置。`,'Locate the supports and operating points for this exercise.']);
    if(i===1)return pair([`先核对${part.label[0]}，再读本动作的准备提示。`,`Check ${part.label[1].toLowerCase()}, then read this exercise’s setup cues.`]);
    if(i===2)return h(a.sceneKey?'motionTask':'positionOnly');
    if(i===3)return a.sceneKey?pair(p.question):h('selfCheckTask');
    if(i>=4&&p.model==='pulley')return pair(i===4?['固定配重抬升高度，改变理想倍率。','Keep the lift height fixed and change the ideal ratio.']:['比较手柄行程、拉力与机械功。','Compare handle travel, force and mechanical work.']);
    if(i>=4&&p.model==='incline')return pair(i===4?['改变摩擦系数，观察外力与耗散。','Change friction and observe external force and dissipation.']:['分别比较上推和受控下放，保留功的符号。','Compare ascent and controlled descent, retaining the signs of work.']);
    if(p.model==='qualitative')return h('positionOnly');
    return h('demo'+i);
  }
  function demoMarkup() {
    if(!demo)return '';
    return `<section class="did-narration" data-i18n-skip><small>${demo.index+1} / ${demoLast()+1}</small><strong>${h((current?.a.sceneKey?['identify','prepare','move','forceTitle','changeOne','compareTitle','conclusionTitle']:['identify','prepare','moveHome','errors'])[demo.index])}</strong><p>${demoCopy(demo.index)}</p><div class="did-actions">${btn(demo.index===demoLast()?'restart':demo.running?'pause':'resume','demo-toggle')}${btn('previous','demo-prev',demo.index===0?'disabled':'')}${btn('next','demo-next',demo.index===demoLast()?'disabled':'')}${btn('exit','demo-exit')}</div></section>`;
  }
  function introParams(){return {...M.defaults.cam,massKg:current?.a.id==='lat'?(B.modelLoads?.lat??M.defaults.cam.massKg):M.defaults.cam.massKg,leverM:current?.a.id==='lat'?.65:M.defaults.cam.leverM,eccentricity:lesson.curve==='motion'?.5:0,startAngleRad:-.1,sweepRad:1.46,baseArmM:lesson.arm};}
  function introData() { return M.evaluate('cam',introParams(),lesson.progress??.35); }
  let studyFrame=0,studyRunning=false,studyClock=0,studyStart=0,studyLast=0;
  function stopStudy(){studyRunning=false;cancelAnimationFrame(studyFrame);studyFrame=0;const b=$('[data-did="study-play"]');if(b){b.textContent=en()?'Play':'播放';b.setAttribute('aria-pressed','false');}}
  function studyPosition(){return principleModel(current.a)==='cam'&&lesson.curve!=='motion'?lesson.arm/.4:lesson.progress??.5;}
  function seekStudy(progress){
    lesson.progress=clamp(progress);
    if(principleModel(current.a)==='cam'){
      if(lesson.curve==='motion'){if(current.a.id==='cam')B.learningTeaching?.pose(lesson.progress);}
      else{lesson.arm=.4*lesson.progress;const arm=$('[data-did-arm]');if(arm)arm.value=String(lesson.arm);}
      updateInline();
    }else updateOtherInline();
    const range=$('[data-did-progress]');if(range)range.value=String(studyPosition()*100);
  }
  function transport(){const arm=principleModel(current.a)==='cam'&&lesson.curve!=='motion',label=arm?(en()?'Perpendicular-arm scan':'垂直力臂扫描进度'):(en()?'Prescribed motion progress':'规定运动进度');return `<label class="did-one-variable">${label} <input type="range" min="0" max="100" step=".1" value="${studyPosition()*100}" data-did-progress aria-label="${label}"></label><div class="did-actions">${[['study-play',studyRunning?(en()?'Pause':'暂停'):(en()?'Play':'播放')],['study-step',en()?'Step +5% range':'单步 +5% 范围'],['study-reset',en()?'Reset pose':'重置姿态'],['study-baseline',en()?'Fix comparison baseline':'固定比较基准']].map(([action,text])=>`<button type="button" data-did="${action}" ${action==='study-play'?`aria-pressed="${studyRunning}" ${media.matches?'disabled':''}`:''}>${text}</button>`).join('')}</div><p class="did-note">${arm?(en()?'Only the ideal force line moves; actual machine settings stay unchanged. Each step advances 5% of the arm range.':'只移动理想力的作用线，不改变实物调节。单步推进力臂范围的 5%。'):h('playHint')}${media.matches?(en()?' Reduced motion: use steps or the slider.':' 减少动态：请用单步或滑块观察。'):''}</p>`;}
  function curveControls(a){if(lesson.intro<4)return '';return (a.id==='cam'?`<label class="did-one-variable">${en()?'Observe':'观察方式'}<select data-did-curve aria-label="${en()?'Curve observation':'曲线观察方式'}"><option value="arm" ${lesson.curve!=='motion'?'selected':''}>${en()?'Hold force: arm and torque':'固定力，观察力臂与力矩'}</option><option value="motion" ${lesson.curve==='motion'?'selected':''}>${en()?'Follow ideal angle: resistance torque':'沿理想动作角度观察阻力变化'}</option></select></label>`:'')+transport();}
  function camMotionSvg(){const r=introData(),g=r.geometry,O={x:110,y:132},xy=p=>({x:O.x+p.x*175,y:O.y-p.y*175}),H=xy(g.handle),C=xy(g.cableContact),endY=C.y+45;return `<svg class="did-force-figure" viewBox="0 0 340 205" role="img" aria-label="${en()?'Ideal shaft at the current angle':'当前角度的理想轴'}"><path d="M${O.x} ${O.y}L${H.x} ${H.y}" stroke="#718293" stroke-width="8"/><circle cx="${O.x}" cy="${O.y}" r="6" fill="#8771d5"/><path d="M${C.x} 20V184" stroke="#d97440" stroke-dasharray="5 4"/><path d="M${O.x} ${O.y}H${C.x}" stroke="#22a79b" stroke-width="3"/><path d="M${C.x-7} ${O.y}v7h7" fill="none" stroke="#22a79b"/><path d="M${C.x} ${C.y}V${endY}l-5-8m5 8 5-8" stroke="#d97440" stroke-width="2.5" fill="none"/><text x="12" y="25">θ ${(r.angleRad*180/Math.PI).toFixed(1)}°</text><text x="180" y="64">T ${r.forces.find(f=>f.id==='cable').magnitudeN.toFixed(1)} N</text><text x="180" y="90">d ${r.effectiveArmM.toFixed(3)} m</text><text x="12" y="198" font-size="12">${en()?'Ideal effective arm, not a cam outline':'理想有效力臂函数，不是实物凸轮轮廓'}</text></svg>`;}
  function armIntro(a){const native=B.physics?.readScene?.('arm');if(!native)return `<section class="did-intro"><h2>${pair(P.forAction(a).question)}</h2><p>${en()?'Geometry is unavailable. Use the reference photo and instructions; no quantitative result is shown.':'几何未就绪：可先查看实物参照和文字说明，暂不显示定量结果。'}</p></section>`;lesson.spatialBaseline||=clone(native.params);return `<section class="did-intro" data-i18n-skip><h2>${pair(P.forAction(a).question)}</h2><p class="did-task">${en()?'Move the pulley. Watch φ and the perpendicular arm, while ideal tension stays fixed.':'移动滑轮，观察夹角 φ 和垂直力臂变化；理想拉力大小保持不变。'}</p><label class="did-one-variable">${en()?'Arm angle θ, from downward vertical':'抬臂角 θ，从竖直向下量起'}<input type="range" min="0" max="90" step=".5" value="${native.params.angleDeg}" data-did-native-angle aria-label="${en()?'Arm angle theta':'抬臂角 θ'}"></label><label class="did-one-variable">${en()?'Left pulley position, illustration':'左滑轮位置，模型示意'}<input type="range" min="0" max="100" step=".5" value="${native.settings.pulleyLeftPercent}" data-did-native-pulley aria-label="${en()?'Left pulley position':'左滑轮位置'}"></label><p>τ = |r × F| = TL|sinφ|</p><p class="did-note">${en()?'θ is arm elevation; φ is the angle between r and cable tension. Only a vertical point weight uses mgL|sinθ|. The pivot is idealized; no body tracking or muscle-force calculation.':'θ 是抬臂角；φ 是 r 与钢索拉力的夹角。只有竖直重力点负载才使用 mgL|sinθ|。转轴为理想化示意，没有人体检测或肌肉力计算。'}</p><p class="did-note">${en()?'Fixed load and ratio: T = mg/n. Pulling farther does not make an ideal fixed-ratio cable lighter.':'固定配重与倍率：T = mg/n。理想固定倍率钢索不会因为拉得更远就变轻。'}</p><div class="did-actions"><button type="button" data-did="arm-step">${en()?'Step +5% angle range':'单步 +5% 角度范围'}</button><button type="button" data-did="arm-reset">${en()?'Reset pose':'重置姿态'}</button></div><a href="#engineering/pulley/observe">${en()?'Compare ideal pulley force and travel':'进一步比较理想滑轮的力与行程'} →</a></section>`;}

  function introSvg() {
    if(lesson.curve==='motion')return camMotionSvg();
    const r=introData(),before=M.evaluate('cam',lesson.baseline||{...introParams(),baseArmM:.12,eccentricity:0},lesson.progress??.35),s=lesson.intro;
    const x=48+r.effectiveArmM*620,bx=48+before.effectiveArmM*620,force=r.forces.find(q=>q.id==='cable');
    return `<svg class="did-force-figure" viewBox="0 0 340 205" role="img" data-did-label="question" aria-label="${esc(txt('question'))}" data-i18n-skip><defs><pattern id="did-grid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M20 0H0V20" fill="none" stroke="currentColor" opacity=".08"/></pattern><marker id="did-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#d97440"/></marker></defs><rect width="340" height="205" fill="url(#did-grid)"/><path d="M48 95L320 95" stroke="#718293" stroke-width="9" stroke-linecap="round"/><circle cx="48" cy="95" r="8" fill="var(--ui-surface)" stroke="#8771d5" stroke-width="3"/><text x="18" y="76">${esc(txt('pivot'))}</text>${s>=1?`<path d="M${x} 95V167" stroke="#d97440" stroke-width="3" marker-end="url(#did-arrow)"/><text x="${Math.min(245,x+10)}" y="155">F ${f(force.magnitudeN,1)} N</text>`:''}${s>=2?`<path d="M${x} 22V184" stroke="#d97440" stroke-dasharray="5 4"/><text x="155" y="20">${esc(txt('forceLine'))}</text>`:''}${s>=3?`<path d="M48 95H${x}" stroke="#22a79b" stroke-width="3"/><path d="M${x-8} 95V103H${x}" stroke="#22a79b" fill="none"/><text x="55" y="119" fill="#178c82">d ${f(r.effectiveArmM,3)} m</text>`:''}${s>=5?`<path d="M${bx} 30V181M48 133H${bx}" stroke="currentColor" opacity=".45" stroke-dasharray="5 4"/>`:''}<text x="14" y="185" font-size="12"><tspan x="14">${en()?'Ideal transmission · example values':'理想传动图解 · 模型示例'}</tspan><tspan x="14" dy="15">${en()?'Dimensions are not measured on the machine':'尺寸不是器械实测值'}</tspan></text></svg>`;
  }
  function principleModel(a){return P.forAction(a).model;}
  // Read-only projection of the exact teaching calculation, for the adjacent
  // observation board. Consumers never own a second parameter or playback state.
  function presentation(){
    if(!current)return null;
    const profile=P.lesson(current.a),model=profile.model,progress=lesson.progress??(model==='cam'?.35:.5);
    const params=model==='cam'?introParams():model==='qualitative'?null:clone(lesson.other||M.defaults[model]);
    return {curve:lesson.curve||'arm',spatial:current.a.id==='arm'?B.physics?.readScene?.('arm')||null:null,spatialBaseline:lesson.spatialBaseline,id:current.a.id,name:B.i18n?.t(current.a.name)||current.a.name,mode:current.mode,step:lesson.step,intro:lesson.intro,phase:current.phase,model,progress,params,baseline:lesson.baseline||(model==='cam'?{...introParams(),baseArmM:.12,eccentricity:0}:params?clone(M.defaults[model]):null),result:params?M.evaluate(model,params,progress):null,question:profile.question[en()?1:0],part:current.mode==='setup'||lesson.step===1?profile.preparePart:lesson.step===2?profile.movingPart:'',partLabel:profile.parts.find(p=>p.id===(current.mode==='setup'||lesson.step===1?profile.preparePart:lesson.step===2?profile.movingPart:''))?.label[en()?1:0]||'',narrating:!!demo,running:!!demo?.running};
  }
  function publish(){if(typeof global.CustomEvent==='function'&&document.dispatchEvent)document.dispatchEvent(new CustomEvent('bm:didactics-view',{detail:presentation()}));}
  function publishSoon(){if(typeof global.queueMicrotask==='function')global.queueMicrotask(publish);}
  function shaftBalance(){const r=introData(),T=r.forces.find(q=>q.id==='cable').magnitudeN,dh=introParams().leverM;return `<strong>F<sub>h</sub> × d<sub>h</sub> = T × d<sub>c</sub></strong><br>F<sub>h</sub> ${f(r.forceN,1)} N · d<sub>h</sub> ${f(dh,3)} m · T ${f(T,1)} N · d<sub>c</sub> ${f(r.effectiveArmM,3)} m<br><small>${en()?'Ideal static balance about the machine shaft. Both distances are perpendicular arms. The assumed handle arm is not a measured dimension; the cable-contact geometry is uncalibrated.':'关于器械轴的理想静力平衡；两处 d 均为垂直力臂。手柄力臂是假设尺寸，钢索接触几何未标定。'}</small>`;}
  function introMarkup(a) {
    const steps=['object','force','line','distance','vary','compare','meaning'];
    const r=introData();
    return `<section class="did-intro" data-i18n-skip><p class="did-eyebrow">${h('step')} ${lesson.intro+1} / 7</p><h2>${pair(P.forAction(a).question)}</h2><p class="did-task">${h(lesson.curve==='motion'?'motionTorqueTask':steps[lesson.intro])}</p>${a.id==='lat'?`<p data-shaft-balance>${shaftBalance()}</p><p class="did-note">${en()?'The manual routes the cable through frame pulleys and a work-arm pulley. This diagram studies one ideal equivalent force; real multi-segment moments remain uncalibrated.':'装配图显示钢索经过机架与工作臂上的滑轮。下图只研究一个理想等效作用力，实物多绳段的合力矩尚未标定。'}</p><details><summary>${en()?'Manufacturer connection reference':'厂家连接依据'}</summary><p><a href="https://kb.cybexintl.com/Assembly_Manuals/Strength/Life_Fitness_Axiom_OP-PD_Pulldown_Assembly_Instructions_1013943-0001.pdf" target="_blank" rel="noopener">OP-PD · 1013943-0001 REV AB</a> · ${en()?'PDF p.15: shaft and work arm; p.25: cable path. Exact contact and lever-arm functions are not supplied.':'PDF 第15页：轴与工作臂；第25页：钢索路线。未给出准确接触几何和力臂函数。'}</p></details>`:''}${curveControls(a)}<div id="did-inline-diagram">${introSvg()}</div><div class="did-live-reading" id="did-inline-reading">${lesson.intro>=1?'F '+f(r.forces.find(q=>q.id==='cable').magnitudeN,1)+' N　':''}${lesson.intro>=3?`d ${f(r.effectiveArmM,3)} m　`:''}${lesson.intro>=4?`τ ${f(r.torqueNm,2)} N·m`:''}</div>${lesson.intro>=4?`<label class="did-one-variable">${h(lesson.curve==='motion'?'baseArm':'variableArm')}<input type="range" min="0" max=".4" step=".005" value="${lesson.arm}" data-did-arm data-did-label="${lesson.curve==='motion'?'baseArm':'variableArm'}" aria-label="${esc(txt(lesson.curve==='motion'?'baseArm':'variableArm'))}"></label>`:''}${lesson.intro===6?`<div class="did-equation">τ = F × d<br><small>${f(r.torqueNm)} N·m = ${f(r.forces.find(q=>q.id==='cable').magnitudeN,1)} N × ${f(r.effectiveArmM,3)} m</small></div><ul class="did-variables"><li>${h('F')}</li><li>${h('d')}</li><li>${h('tau')}</li></ul>`:''}<div class="did-actions">${btn('previous','intro-prev',lesson.intro===0?'disabled':'')}${btn(lesson.intro===6?'restart':'next',lesson.intro===6?'intro-reset':'intro-next','',true)}</div><div class="did-paths">${btn('changeOne','intro-vary')}${btn('formula','intro-formula')}<a href="#engineering/${principleModel(a)}/observe">${h('fullLab')} →</a></div><p class="did-note">${h(a.id==='cam'?'shaftOnly':'shaftGeneric')}</p></section>`;
  }
  function conceptSvg(model,params,progress) {
    const r=M.evaluate(model,params,progress);if(!r.valid)return '';
    const ends=[0,1].flatMap(p=>Object.values(M.evaluate(model,params,p).position));
    if(model==='incline')ends.push(r.geometry.trackEnd);
    if(model==='pulley')ends.push(...r.geometry.pulleyCenters);
    const xs=ends.map(p=>p.x),ys=ends.map(p=>p.y),cx=(Math.min(...xs)+Math.max(...xs))/2,cy=(Math.min(...ys)+Math.max(...ys))/2;
    const scale=220/Math.max(1.5,Math.max(...xs)-Math.min(...xs)+.5,Math.max(...ys)-Math.min(...ys)+.5);
    const xy=p=>({x:200+(p.x-cx)*scale,y:145-(p.y-cy)*scale});
    const line=(a,b,c='#718293',dash='')=>{a=xy(a);b=xy(b);return `<path d="M${a.x} ${a.y}L${b.x} ${b.y}" fill="none" stroke="${c}" stroke-width="3" ${dash?'stroke-dasharray="'+dash+'"':''}/>`;};
    const point=(p,color)=>{p=xy(p);return `<circle cx="${p.x}" cy="${p.y}" r="9" fill="${color}"/>`;};
    let shapes='';
    if(model==='pulley'){
      const g=r.geometry,top=g.fixedPulley.y;
      shapes=line(g.handle,{x:g.handle.x,y:top},'#d97440')+line({x:g.handle.x,y:top},{x:g.load.x,y:top},'#d97440')+line({x:g.load.x,y:top},g.load,'#d97440')+point(g.handle,'#257bd6')+point(g.load,'#718293');
      const H=xy(g.handle),L=xy(g.load);
      shapes+=`<text x="${H.x-40}" y="${H.y+30}">${en()?'Handle':'手柄'}</text><text x="${L.x+12}" y="${L.y+20}">${en()?'Load':'配重'}</text><text x="130" y="28">${params.ratio}:1 ${en()?'ideal module':'理想传动模块'}</text>`;
    }else shapes=line(r.geometry.trackStart,r.geometry.trackEnd)+point(r.geometry.sled,'#718293');
    const peak=Math.max(1,...r.forces.map(q=>q.magnitudeN));
    const colors={external:'#257bd6',cable:'#d97440',gravity:'#d97440',normal:'#8771d5',friction:'#c19324'};
    r.forces.forEach(force=>{
      const A=xy(force.origin),B={x:A.x+force.vector.x/peak*62,y:A.y-force.vector.y/peak*62},angle=Math.atan2(B.y-A.y,B.x-A.x),c=colors[force.id]||'#718293';
      if(force.magnitudeN<1e-9)return;
      shapes+=`<path d="M${A.x} ${A.y}L${B.x} ${B.y}M${B.x-7*Math.cos(angle-.45)} ${B.y-7*Math.sin(angle-.45)}L${B.x} ${B.y}L${B.x-7*Math.cos(angle+.45)} ${B.y-7*Math.sin(angle+.45)}" fill="none" stroke="${c}" stroke-width="2.5"/><text x="${B.x+8}" y="${B.y-8}">${force.symbol} ${f(force.magnitudeN,1)} N</text>`;
    });
    return `<svg class="did-force-figure" viewBox="0 0 400 300" role="img" aria-label="${esc(txt(model+'Question'))}"><rect x="10" y="10" width="380" height="280" rx="10" fill="none" stroke="currentColor" opacity=".1"/>${shapes}<text x="12" y="280" font-size="10">${model==='pulley'?(en()?'Equivalent module, not a reeving drawing':'等效传动图，不表示真实绕索'):(en()?'Object: sled; uphill force is positive':'分析对象：滑车；沿上坡为外力正向')}</text></svg>`;
  }
  function inlineComparison(model,params){
    const s=study(model,params,lesson.baseline||M.defaults[model],lesson.progress??.5),rows=[['handleForce',s.before.forceN,s.current.forceN,'N'],['inputWork',s.before.energy?.inputWorkJ,s.current.energy?.inputWorkJ,'J'],['potential',s.before.energy?.potentialJ,s.current.energy?.potentialJ,'J'],['dissipated',s.before.energy?.dissipatedJ,s.current.energy?.dissipatedJ,'J']];
    return `<div class="did-inline-table"><table><thead><tr><th></th><th>${h('original')}</th><th>${h('current')}</th></tr></thead><tbody>${model==='incline'?`<tr><th>${h('direction')}</th><td>${h(M.defaults.incline.direction)}</td><td>${h(params.direction)}</td></tr>`:''}${rows.map(([label,before,after,unit])=>`<tr><th>${h(label)}</th><td>${f(before)} ${unit}</td><td>${f(after)} ${unit}</td></tr>`).join('')}</tbody></table></div>`;
  }
  function otherIntro(a) {
    if(a.id==='arm')return armIntro(a);
    const model=principleModel(a);
    lesson.other ||= clone(M.defaults[model]);
    const params=lesson.other,r=M.evaluate(model,params,lesson.progress??.5),s=study(model,params,M.defaults[model],lesson.progress??.5);
    const controls=model==='pulley'?`<label class="did-one-variable">${h('ratio')}<select data-did-other="ratio" data-did-label="ratio" aria-label="${esc(txt('ratio'))}">${[1,2,4].map(n=>`<option value="${n}" ${params.ratio===n?'selected':''}>${n}:1</option>`).join('')}</select></label>`:`<label class="did-one-variable">μ<input type="range" min="0" max="1" step=".01" value="${params.friction}" data-did-other="friction" data-did-label="frictionLabel" aria-label="${esc(txt('frictionLabel'))}"></label><div class="did-actions">${['up','down'].map(d=>btn(d,'inline-direction',`data-direction="${d}" aria-pressed="${params.direction===d}"`)).join('')}</div>`;
    return `<section class="did-intro" data-i18n-skip><h2>${pair(P.forAction(a).question)}</h2><p class="did-task">${h(model+'Task')}</p>${model==='pulley'?`<p class="did-note">${h('idealOnly')}</p>`:''}<div id="did-other-diagram">${conceptSvg(model,params,lesson.progress??.5)}</div>${controls}${transport()}${model==='incline'?frictionStudy(params):''}<div class="did-live-reading" id="did-other-reading">F ${f(r.forceN,1)} N · W ${f(r.energy.inputWorkJ)} J · ΔU ${f(r.energy.potentialJ)} J · D ${f(r.energy.dissipatedJ)} J</div>${model==='pulley'?`<p data-pulley-summary>${pulleySummary(params)}</p><details><summary>${en()?'Compare 1:1 / 2:1 / 4:1 at the same lift':'同一抬升高度，比较 1:1 / 2:1 / 4:1'}</summary><div class="did-inline-table" data-pulley-comparison>${pulleyComparison(params)}</div><p>${en()?'Input work is accumulated to the current progress; total handle travel covers the complete lift.':'输入功累计到当前进度；总手柄行程对应完整抬升。'}</p></details>`:''}<p>${h(model+'Conclusion')}</p>${lesson.intro>=5?`<div id="did-inline-comparison">${inlineComparison(model,params)}</div>`:''}<details ${lesson.intro===6?'open':''}><summary>${h('formula')}</summary><p class="did-equation">${model==='pulley'?'F = mg/n ; xₕ = n × h':'F↑/↓ = mg sinβ ± μmg cosβ'}</p><p>${h('energyNote')}</p></details><p><a href="#engineering/${model}/observe">${h('fullLab')} →</a></p></section>`;
  }
  function pulleySummary(params){return `${en()?'Total load lift':'配重总抬升高度'} ${(params.handleTravelM/params.ratio).toFixed(3)} m · ${en()?'Total handle travel':'总手柄行程'} ${params.handleTravelM.toFixed(3)} m`;}
  function pulleyComparison(params){const s=study('pulley',params,lesson.baseline||M.defaults.pulley,lesson.progress??.5);return `<table><thead><tr><th>${h('ratio')}</th><th>${h('handleForce')}</th><th>${h('handleTravel')}</th><th>${h('inputWork')}</th></tr></thead><tbody>${s.alternatives.map(row=>row.result?`<tr><td>${row.ratio}:1</td><td>${f(row.result.forceN,1)}</td><td>${f(row.params.handleTravelM,3)}</td><td>${f(row.result.energy.inputWorkJ)}</td></tr>`:`<tr><td>${row.ratio}:1</td><td colspan="3">${esc(row.error)}</td></tr>`).join('')}</tbody></table>`;}
  function frictionStudy(params){const up=M.evaluate('incline',{...params,direction:'up'},1),down=M.evaluate('incline',{...params,direction:'down'},1);return `<p>${en()?'kg is mass; N is force. On Earth, 1 kg weighs about 9.81 N. Total moving mass includes the sled and its load; plate mass alone is not total mass. An unknown real sled mass remains unknown.':'kg 是质量，N 是力；地球表面 1 kg 的重力约 9.81 N。总移动质量包含滑车和负载，装片质量不等于总质量；真实滑车质量未知时保持未知。'}</p><div class="did-actions"><button type="button" data-did="friction-zero">${en()?'No friction example':'无摩擦示例'}</button><button type="button" data-did="friction-example">${en()?'Assumed friction μ = 0.12':'示例摩擦 μ = 0.12'}</button></div><p class="did-note" data-friction-assumption>${en()?'Current model total mass':'当前模型总质量'} ${f(params.massKg,1)} kg · ${(params.inclineRad*180/Math.PI).toFixed(1)}° · μ ${f(params.friction,2)} ${en()?'is assumed, not measured':'为假设，不是器械实测值'}</p><p data-friction-pair>${en()?'Up / controlled lowering, uphill external force':'上推 / 受控下放的沿上坡外力'}：${f(up.forceN,1)} / ${f(down.forceN,1)} N</p>`;}
  function supportFigure(a){
    const wall=a.id==='home-wall-press-up';
    return `<figure class="did-home-reference"><svg viewBox="0 0 340 155" role="img" aria-label="${esc(txt('positionOnly'))}" data-did-label="positionOnly"><path d="M10 137H330" stroke="currentColor" opacity=".2"/><g data-did-zone="support" stroke="#718293" stroke-width="7" fill="none">${wall?'<path d="M76 15V135"/>':'<path d="M65 44V135M65 94H144V135M65 44H133V94"/>'}</g><g data-did-zone="body" fill="#8771d5"><circle cx="218" cy="52" r="12"/><path d="M218 67V99" stroke="#8771d5" stroke-width="6"/></g><g data-did-zone="hands" fill="#257bd6"><circle cx="${wall?85:135}" cy="63" r="6"/></g><g data-did-zone="feet" stroke="#22a79b" stroke-width="6"><path d="M201 129H225M239 129H263"/></g></svg><figcaption>${h('positionOnly')}</figcaption></figure>`;
  }
  function partButtons(p){return `<div class="did-parts">${p.parts.map(part=>`<button type="button" data-did="part" data-part="${part.id}" aria-pressed="false">${pair(part.label)}</button>`).join('')}</div>`;}
  function teaching(a,mode,phase,legacy) {
    if(lesson.id!==a.id){if(demo){pauseDemo();demo=null;}lesson={id:a.id,step:0,error:0,intro:0,arm:.12};}
    current={a,mode,phase};publishSoon();const p=P.lesson(a),step=lesson.step,labels=['identify','prepare',a.sceneKey?'move':'moveHome','errors'];
    const tail=`<details class="did-full"><summary>${h('details')}</summary>${legacy}</details>`;
    if(mode==='physics')return demoMarkup()+(p.model==='qualitative'?homePrinciple(a):p.model==='cam'?(a.id==='cam'?'':`<p class="did-note" data-i18n-skip>${a.id==='lat'?pair(['已核对固定转臂与钢索路径；以下理想等效力臂仍未标定。','Attached arms and the cable path were checked; the ideal equivalent arms below remain uncalibrated.']):h('genericModel')}</p>`)+introMarkup(a):otherIntro(a))+tail;
    if(mode==='setup')return `<section class="did-teaching" data-i18n-skip><h2>${h('prepare')}</h2><p class="did-task">${h(a.sceneKey?'readyTask':'readyHome')}</p>${a.sceneKey?`<div class="did-part-locator">${image(a)}${partButtons(p)}</div>`:supportFigure(a)+partButtons(p)}<p id="did-part-note" class="did-part-note">${h(a.sceneKey?'partHelp':'homePartHelp')}</p><ul class="did-cues">${p.setup.slice(0,3).map(c=>`<li>${catalogText(c)}</li>`).join('')}</ul></section>${tail}`;
    const motion=a.steps[phase]||a.steps[0];let content='';
    if(step<=1){
      content=`${a.sceneKey?`<div class="did-part-locator">${image(a)}${partButtons(p)}</div>`:supportFigure(a)+partButtons(p)}<p id="did-part-note" class="did-part-note">${step===0?h(a.sceneKey?'partHelp':'homePartHelp'):pair(p.parts.find(x=>x.id===p.preparePart).label)}</p>`;
      const cues=step===0?(a.identification?.points||[]):[...p.prepare,...p.setup.filter(c=>!p.prepare.includes(c))];
      content+=`<ul class="did-cues">${cues.slice(0,step===0?1:3).map(c=>`<li>${catalogText(c)}</li>`).join('')}</ul>`;
      if(step===1&&['nautilus-pullover','machine-fly','incline'].includes(a.id))content+=`<p class="did-note did-essential">${catalogText(a.setup.model[0])}</p>`;
    }
    if(step===2)content=`${!a.sceneKey?supportFigure(a):''}<div class="bm-stage-nav" role="group" data-did-label="${a.sceneKey?'move':'moveHome'}" aria-label="${esc(txt(a.sceneKey?'move':'moveHome'))}">${a.steps.map((s,i)=>`<button type="button" data-bm="stage" data-stage="${i}" aria-pressed="${phase===i}">${catalogText(s.label)}</button>`).join('')}</div><p class="did-phase-label">${catalogText(motion.label)}</p><ul class="did-cues">${motion.cues.slice(0,3).map(c=>`<li>${catalogText(c)}</li>`).join('')}</ul><div class="did-actions"><button type="button" class="bm-primary" data-bm="stage" data-stage="${(phase+1)%a.steps.length}">${h('nextPhase')}</button></div>`;
    if(step===3){const error=p.errors[lesson.error%p.errors.length],part=p.parts.find(x=>x.id===error.lookPart);content=`<dl class="did-error"><dt>${h('situation')}</dt><dd>${pair(error.example||error.title)}</dd><dt>${h('observe')}</dt><dd><button type="button" data-did="part" data-part="${part.id}">${pair(part.label)}</button></dd><dt>${h('correction')}</dt><dd>${pair(error.correction)}</dd></dl>${p.errors.length>1?btn('nextError','error-next'):''}`;}
    const task=step===0?pair([`先找到${p.parts.map(x=>x.label[0]).join('、')}。`,`First locate: ${p.parts.map(x=>x.label[1].toLowerCase()).join(', ')}.`]):h(step===1?(a.sceneKey?'readyTask':'readyHome'):step===2?(a.sceneKey?'motionTask':'homeMoveTask'):'selfCheckTask');
    return `${demoMarkup()}<section class="did-teaching" data-i18n-skip><nav class="did-steps" data-did-label="step" aria-label="${esc(txt('step'))}">${labels.map((key,i)=>`<button data-did="lesson-step" type="button" data-step="${i}" aria-current="${step===i?'step':'false'}"><small>0${i+1}</small>${h(key)}</button>`).join('')}</nav><h2>${h(labels[step])}</h2><p class="did-task">${task}</p>${content}<div class="did-actions">${step>0?btn('previous','lesson-prev'):''}${btn(step===3?'restart':step===2?'errors':'next',step===3?'lesson-reset':'lesson-next','',true)}${!demo?btn('watch','demo-start'):''}</div><p class="did-note">${h(a.sceneKey?'noHuman':'noHumanHome')}</p><p class="did-note did-essential">${h('stopIfPain')}</p></section>${tail}`;
  }
  function homePrinciple(a){const p=P.forAction(a);if(a.sceneKey)return `<section class="did-intro" data-i18n-skip><h2>${pair(p.question)}</h2>${image(a)}${partButtons(p)}<p>${pair(['观察杠铃重力的竖直作用线与支撑位置。缺少人体关节与接触力数据，不计算人体力矩、肌肉力或消耗。','Observe the vertical gravity line and supports. Without human joint/contact-force data, no human torque, muscle force or metabolic cost is calculated.'])}</p><ul class="did-cues">${a.steps.map(s=>`<li>${catalogText(s.cues[0])}</li>`).join('')}</ul></section>`;return `<section class="did-intro" data-i18n-skip><h2>${pair(p.question)}</h2>${supportFigure(a)}<p>${pair(['先辨认支撑点，再对照准备、动作和返回三个阶段。这里只解释位置关系，没有求解人体受力。','Locate the supports, then compare the ready, movement and return phases. This explains positions; it does not solve human forces.'])}</p><ul class="did-cues">${a.steps.map(s=>`<li>${catalogText(s.cues[0])}</li>`).join('')}</ul><p class="did-note">${pair(['没有身体质量分布、关节坐标和地面反力数据，不显示人体力矩或能量数值。','Without body mass distribution, joint coordinates and support forces, no human torque or energy values are shown.'])}</p></section>`;}
  function refresh() { B.learningTeaching?.refresh(); }
  function phase(index,motion) { B.learningTeaching?.phase(index,motion); }
  function pauseDemo() { if(!demo?.running)return;demo.running=false;cancelAnimationFrame(demoFrame);demoFrame=0;const button=$('[data-did=demo-toggle]');if(button)button.innerHTML=h(demo.index===demoLast()?'restart':'resume'); }
  const durations=[2600,3000,6000,2600,2800,2800,0];
  function applyDemo() {
    if(!demo)return;
    const i=demo.index;
    const a=current.a,p=P.forAction(a);
    if(!a.sceneKey){lesson.step=i;B.learningTeaching?.mode('how');if(i===2)phase(0);refresh();return;}
    if(i<3){lesson.step=i;B.learningTeaching?.mode('how');if(i===0)B.equipmentInspection?.whole();if(i===1)B.equipmentInspection?.select(p.preparePart);if(i===2){B.equipmentInspection?.reset();phase(0,0);}}
    else{lesson.intro=[0,0,0,3,4,5,6][i];if(i>=4){if(p.model==='cam')lesson.arm=.2;else if(p.model==='pulley')lesson.other=sameLift({...M.defaults.pulley},4);else if(p.model==='incline')lesson.other={...M.defaults.incline,friction:.3};}B.learningTeaching?.mode('physics');}
    refresh();
  }
  function runDemo() {
    B.learningTeaching?.stop();
    if(!demo||media.matches)return;
    demo.running=true;demo.started=performance.now()-demo.elapsed;refresh();
    const tick=now=>{
      if(!demo?.running||document.hidden)return;
      demo.elapsed=now-demo.started;
      if(demo.index===2){const p=clamp(demo.elapsed/durations[2]),fraction=p<.5?p*2:2-p*2;phase(p<.5?1:2,current?.a.sceneKey?fraction:undefined);}
      if(demo.elapsed>=durations[demo.index]){
        if(demo.index===demoLast()){pauseDemo();return;}
        demo.index++;demo.elapsed=0;demo.started=now;applyDemo();if(demo.index===demoLast()){pauseDemo();return;}
      }
      demoFrame=requestAnimationFrame(tick);
    };demoFrame=requestAnimationFrame(tick);
  }
  function updateInline() {
    const figure=$('#did-inline-diagram');if(figure)figure.innerHTML=introSvg();
    const r=introData(),reading=$('#did-inline-reading');if(reading)reading.textContent=`F ${f(r.forces.find(q=>q.id==='cable').magnitudeN,1)} N　d ${f(r.effectiveArmM,3)} m　τ ${f(r.torqueNm)} N·m`;
    const equation=$('.did-intro .did-equation');if(equation)equation.innerHTML=`τ = F × d<br><small>${f(r.torqueNm)} N·m = ${f(r.forces.find(q=>q.id==='cable').magnitudeN,1)} N × ${f(r.effectiveArmM,3)} m</small>`;
    const balance=$('[data-shaft-balance]');if(balance)balance.innerHTML=shaftBalance();
    publish();
  }
  document.addEventListener('click',event=>{const link=event.target.closest('.did-intro a[href^="#engineering/"]');if(!link||!current)return;stopStudy();pauseDemo();const view=presentation();if(view.params&&!view.spatial)B.engineering?.fromTeaching?.({action:view.id,model:view.model,params:view.params,baseline:view.baseline,progress:view.progress,question:P.forAction(current.a).question});});
  document.addEventListener('click',event=>{
    const b=event.target.closest('[data-did]');if(!b)return;const action=b.dataset.did;
    if(action.startsWith('lab-'))return;
    if(!action.startsWith('demo-'))pauseDemo();
    if(action.startsWith('study-')){
      if(action==='study-play'){if(studyRunning)stopStudy();else if(!media.matches){studyRunning=true;studyStart=performance.now();studyClock=Math.acos(1-2*studyPosition());studyLast=0;const tick=now=>{if(!studyRunning||document.hidden){stopStudy();return;}if(now-studyLast>50){studyLast=now;seekStudy((1-Math.cos(studyClock+(now-studyStart)*Math.PI/3000))/2);}studyFrame=requestAnimationFrame(tick);};studyFrame=requestAnimationFrame(tick);b.textContent=en()?'Pause':'暂停';b.setAttribute('aria-pressed','true');}}
      else {stopStudy();if(action==='study-step')seekStudy(nextProgress(studyPosition()));if(action==='study-reset')seekStudy(0);if(action==='study-baseline'){lesson.baseline=clone(principleModel(current.a)==='cam'?introParams():lesson.other);publish();}}return;
    }
    if(action==='arm-step'||action==='arm-reset'){B.learningTeaching?.pose(action==='arm-reset'?0:Math.min(1,B.physics.readScene('arm').step/100+.05));refresh();return;}
    if(action==='friction-zero'||action==='friction-example'){stopStudy();lesson.other={...M.defaults.incline,massKg:100,friction:action==='friction-zero'?0:.12,direction:lesson.other?.direction||'up'};refresh();return;}
    stopStudy();
    if(action==='part'){
      B.learningTeaching?.stop();
      document.querySelectorAll('.did-parts [data-part]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));
      const note=$('#did-part-note');if(note)note.innerHTML=h(b.dataset.part+'Note');
      const p=P.forAction(current.a),part=p.parts.find(x=>x.id===b.dataset.part);if(note&&part)note.innerHTML=pair(part.label);
      if(current.a.sceneKey)B.equipmentInspection?.select(b.dataset.part);else document.querySelectorAll('[data-did-zone]').forEach(z=>z.classList.toggle('did-zone-active',z.dataset.didZone===b.dataset.part));return;
    }
    if(action==='lesson-step')lesson.step=Number(b.dataset.step);
    if(action==='lesson-next')lesson.step=Math.min(3,lesson.step+1);
    if(action==='lesson-prev')lesson.step=Math.max(0,lesson.step-1);
    if(action==='lesson-reset')lesson.step=0;
    if(action==='error-next')lesson.error++;
    if(action.startsWith('lesson-')){B.learningTeaching?.stop();phase(0,0);B.equipmentInspection?.reset();}
    if(action==='inline-direction'&&lesson.other)lesson.other.direction=b.dataset.direction;
    if(action==='intro-next')lesson.intro=Math.min(6,lesson.intro+1);
    if(action==='intro-prev')lesson.intro=Math.max(0,lesson.intro-1);
    if(action==='intro-vary')lesson.intro=4;
    if(action==='intro-formula')lesson.intro=6;
    if(action==='intro-reset'){lesson.intro=0;lesson.arm=.12;}
    if(action==='demo-start'){B.learningTeaching?.stop();demo={index:0,elapsed:0,running:false,started:0};applyDemo();runDemo();}
    if(action==='demo-toggle'){if(demo?.running)pauseDemo();else{if(demo?.index===demoLast()){demo.index=0;demo.elapsed=0;applyDemo();}runDemo();}}
    if(action==='demo-prev'||action==='demo-next'){pauseDemo();demo.index=Math.max(0,Math.min(demoLast(),demo.index+(action==='demo-next'?1:-1)));demo.elapsed=0;applyDemo();}
    if(action==='demo-exit'){pauseDemo();demo=null;}
    refresh();
    const replacement=document.querySelector(`[data-did="${action}"]`);replacement?.focus({preventScroll:true});
  });
  function updateOtherInline(){
    if(!current||!lesson.other)return;const model=current.a.sceneKey==='incline'?'incline':'pulley';
    const r=M.evaluate(model,lesson.other,lesson.progress??.5),figure=$('#did-other-diagram'),read=$('#did-other-reading');
    if(figure)figure.innerHTML=conceptSvg(model,lesson.other,lesson.progress??.5);
    const cmp=$('#did-inline-comparison');if(cmp)cmp.innerHTML=inlineComparison(model,lesson.other);
    if(read)read.textContent=`F ${f(r.forceN,1)} N · W ${f(r.energy.inputWorkJ)} J · ΔU ${f(r.energy.potentialJ)} J · D ${f(r.energy.dissipatedJ)} J`;
    const summary=$('[data-pulley-summary]');if(summary)summary.textContent=pulleySummary(lesson.other);const table=$('[data-pulley-comparison]');if(table)table.innerHTML=pulleyComparison(lesson.other);
    const pair=$('[data-friction-pair]');if(pair&&model==='incline'){const up=M.evaluate('incline',{...lesson.other,direction:'up'},1),down=M.evaluate('incline',{...lesson.other,direction:'down'},1);pair.textContent=(en()?'Up / controlled lowering: ':'上推 / 受控下放：')+f(up.forceN,1)+' / '+f(down.forceN,1)+' N';}
    const assumptions=$('[data-friction-assumption]');if(assumptions){const p=lesson.other;assumptions.textContent=(en()?'Current model total mass ':'当前模型总质量 ')+f(p.massKg,1)+' kg · '+(p.inclineRad*180/Math.PI).toFixed(1)+'° · μ '+f(p.friction,2)+(en()?' is assumed, not measured':' 为假设，不是器械实测值');}
    publish();
  }
  document.addEventListener('input',event=>{
    if(event.target.matches('[data-did-progress]')){pauseDemo();stopStudy();seekStudy(Number(event.target.value)/100);return;}
    if(event.target.matches('[data-did-native-angle],[data-did-native-pulley]')){pauseDemo();stopStudy();B.learningTeaching?.stop();const target=event.target.matches('[data-did-native-angle]')?$('#arm-angle'):document.querySelector('[data-machine-key="pulleyLeftPercent"]');if(target){target.value=event.target.value;target.dispatchEvent(new Event('input',{bubbles:true}));publish();}return;}
    if(event.target.matches('#arm-angle,[data-machine-key="pulleyLeftPercent"]')&&current?.a.id==='arm')publish();
    if(event.target.matches('[data-did-arm]')){pauseDemo();stopStudy();lesson.arm=Number(event.target.value);const range=$('[data-did-progress]');if(range&&lesson.curve!=='motion')range.value=String(lesson.arm/.4*100);updateInline();}
    if(event.target.matches('[data-did-other]')){
      pauseDemo();stopStudy();const key=event.target.dataset.didOther,value=Number(event.target.value);
      if(key==='ratio'){try{lesson.other=sameLift(lesson.other,value);}catch{return;}}else lesson.other[key]=value;
      updateOtherInline();
    }
  });
  document.addEventListener('change',event=>{if(event.target.matches('[data-did-curve]')){stopStudy();lesson.curve=event.target.value;if(lesson.curve==='motion'&&current?.a.id==='cam')B.learningTeaching?.pose(lesson.progress??.35);refresh();return;}if(event.target.matches('select[data-did-other]')){try{lesson.other=sameLift(lesson.other,Number(event.target.value));updateOtherInline();}catch{/* Valid options and bounds are retained. */}}});
  document.addEventListener('click',event=>{if(event.target.closest('[data-bm=play]')&&current?.a.sceneKey&&current.mode==='how'){lesson.step=2;refresh();}},true);
  document.addEventListener('pointerdown',event=>{if(event.target.closest('#digital-twin-canvas,[data-param],.bm-modes,.bm-stage-nav,.bm-play-tools,.bm-structure-tools')){pauseDemo();stopStudy();}if(event.target.closest('#digital-twin-canvas'))B.learningTeaching?.stop();},{capture:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){pauseDemo();stopStudy();}});
  window.addEventListener('hashchange',()=>{if(!location.hash.startsWith('#action/')){pauseDemo();stopStudy();demo=null;}});
  document.addEventListener('bm:language-change',()=>{if(current){const active=document.activeElement,selector=active?.hasAttribute('data-did')?'[data-did="'+active.dataset.did+'"]':active?.hasAttribute('data-did-arm')?'[data-did-arm]':active?.hasAttribute('data-did-progress')?'[data-did-progress]':active?.hasAttribute('data-did-other')?'[data-did-other="'+active.dataset.didOther+'"]':null;refresh();if(selector)$(selector)?.focus({preventScroll:true});}localize();if(binding)updateLab();});
  media.addEventListener('change',()=>{if(media.matches){pauseDemo();stopStudy();}const play=$('[data-did=study-play]');if(play){play.disabled=media.matches;play.title=media.matches?(en()?'Use steps or the slider in reduced motion':'减少动态模式下请用单步或滑块'):'';}});
  function labHeader(model) {
    return `<section class="did-lab-intro" data-i18n-skip><nav class="did-layers" data-did-label="step" aria-label="${esc(txt('step'))}">${['phenomenon','experiment','math','research'].map((k,i)=>btn(k,'lab-layer',`data-layer="${i}" aria-pressed="${i===0}"`)).join('')}</nav><h2>${h(model+'Question')}</h2><p class="did-task">${h(model+'Task')}</p><p class="did-next" id="did-lab-next">${h('playHint')}</p></section>`;
  }
  function labResults() { return `<section class="did-results" data-i18n-skip><h2>${h('samePose')}</h2><div id="did-study-values"></div><p id="did-study-conclusion"></p><div id="did-study-comparison"></div><details><summary>${h('glossary')}</summary>${['torqueDef','armDef','derivativeDef','integralDef','dampingDef'].map(k=>`<p>${h(k)}</p>`).join('')}</details></section>`; }
  function bindLab(adapter) { binding=adapter;updateLab(); }
  function updateLab() {
    if(!binding||binding.root.hidden)return;
    const {model,params,baseline,progress,result}=binding.read();
    const host=$('#did-study-values');if(!host)return;if(!result?.valid){host.innerHTML=h('invalid');$('#did-study-conclusion').textContent='';$('#did-study-comparison').textContent='';return;}
    const s=study(model,params,baseline,progress),v=model==='cam'?'torqueNm':'forceN',unit=model==='cam'?'N·m':'N';
    host.innerHTML=`<div><small>${h('original')}</small><strong>${f(s.before[v])} ${unit}</strong></div><div><small>${h('current')}</small><button type="button" data-eng="focus" data-focus="${model==='cam'?'d':'F'}"><strong>${f(result[v])} ${unit}</strong></button></div><div><small>Δ</small><strong>${f(s.before.valid?result[v]-s.before[v]:NaN)} ${unit}</strong></div>`;
    $('#did-study-conclusion').innerHTML=h(model+'Conclusion');
    const delta=s.before.valid?result[v]-s.before[v]:NaN;
    $('#did-study-conclusion').append(document.createTextNode(!s.before.valid?(en()?' The baseline does not cover this position; no direct difference is available.':' 基准不覆盖当前位置，不能直接相减。'):Math.abs(delta)<1e-10?(en()?' The current value matches the baseline.':' 当前读数与基准相同。'):en()?` At this position: ${delta>=0?'+':''}${f(delta)} ${unit} versus baseline.`:` 当前位置比基准${delta>=0?'增加':'减少'} ${f(Math.abs(delta))} ${unit}。`));
    const cmp=$('#did-study-comparison');
    const energy=result.energy,barMax=Math.max(1,Math.abs(energy.inputWorkJ),Math.abs(energy.potentialJ),energy.dissipatedJ);
    const bars=`<div class="did-energy">${[['inputWork','inputWorkJ','#257bd6'],['potential','potentialJ','#8771d5'],['dissipated','dissipatedJ','#c19324']].map(([label,key,color])=>{const value=energy[key],length=Math.abs(value)/barMax*48;return `<div class="did-energy-row"><span>${h(label)}</span><div class="did-energy-track"><i style="left:${value<0?50-length:50}%;width:${length}%;background:${color}"></i></div><b>${f(value)} J</b></div>`;}).join('')}</div>`;

    if(model==='cam')cmp.innerHTML=`<p>d: ${f(s.before.effectiveArmM,3)} → ${f(result.effectiveArmM,3)} m　·　T: ${f(s.before.forces?.find(q=>q.id==='cable')?.magnitudeN,1)} → ${f(result.forces.find(q=>q.id==='cable').magnitudeN,1)} N</p><small>${h('shaftOnly')}</small>`;
    if(model==='pulley')cmp.innerHTML=`<p>${en()?'Fixed total lift':'固定总抬升高度'} ${f(s.heightM,3)} m · ${en()?'Current lift':'当前抬升'} ${f(result.energy.loadDisplacementM,3)} m (${f(progress*100,1)}%)</p><div class="eng-table-wrap"><table><thead><tr>${['ratio','handleForce','handleTravel','inputWork','potential'].map(k=>`<th>${h(k)}</th>`).join('')}</tr></thead><tbody>${s.alternatives.map(row=>row.result?`<tr><td>${row.ratio}:1</td><td>${f(row.result.forceN,1)}</td><td>${f(row.params.handleTravelM,3)}</td><td>${f(row.result.energy.inputWorkJ)}</td><td>${f(row.result.energy.potentialJ)}</td></tr>`:`<tr><td>${row.ratio}:1</td><td colspan="4">${esc(B.i18n?.t(row.error)||row.error)}</td></tr>`).join('')}</tbody></table></div><p>${h('liftNote')}</p>`;
    if(model==='incline')cmp.innerHTML=`<div class="eng-table-wrap"><table><thead><tr>${['direction','forceN','inputWork','potential','dissipated'].map(k=>`<th>${h(k)}</th>`).join('')}</tr></thead><tbody>${s.alternatives.map(row=>`<tr><td>${h(row.direction)}</td><td>${f(row.result.forceN,1)}</td><td>${f(row.result.energy.inputWorkJ)}</td><td>${f(row.result.energy.potentialJ)}</td><td>${f(row.result.energy.dissipatedJ)}</td></tr>`).join('')}</tbody></table></div><p>${h('energyNote')}</p>`;
    cmp.insertAdjacentHTML('beforeend',bars);
  }
  document.addEventListener('click',event=>{
    const b=event.target.closest('[data-did^="lab-"]');if(!b||!binding)return;
    if(b.dataset.did==='lab-layer'){
      const level=Number(b.dataset.layer),root=binding.root;
      root.dataset.studyLevel=String(level);
      root.querySelectorAll('[data-did="lab-layer"]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));
      if(level===1)root.querySelector('.eng-parameters')?.scrollIntoView({block:'nearest'});
      if(level===2){root.querySelector('#did-formula-details').open=true;root.querySelector('#did-formula-details')?.scrollIntoView({block:'nearest'});}
      if(level===3){root.querySelector('#did-research-details').open=true;root.querySelector('#did-research-details')?.scrollIntoView({block:'nearest'});}
      $('#did-lab-next').innerHTML=h(['playHint',binding.read().model+'Task','formulaNote','noExtra'][level]);
    }
  });
  B.Didactics={teaching,localize,labHeader,labResults,bindLab,updateLab,sameLift,study,nextProgress,h,txt,pause(){pauseDemo();stopStudy();},presentation,seek(progress){if(current){stopStudy();seekStudy(progress);}}};
})(typeof window==='object'?window:globalThis);
