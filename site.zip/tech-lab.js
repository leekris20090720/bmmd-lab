/* BM//MD visual layer. Each effect is independent of the equipment simulation. */
(() => {
  'use strict';
  const EFFECTS = [
    ['aurora', '极光背景'], ['particles', '粒子连线'], ['grid', '全息网格'],
    ['corners', '面板角标'], ['glow', '发光描边'], ['shimmer', '按钮流光'],
    ['scan', '扫描光线'], ['orbit', '轨道光环'], ['radar', '雷达扫描'],
    ['ruler', '视窗刻度'], ['telemetry', '状态仪表'], ['texture', '屏幕纹理'],
    ['reveal', '面板入场'], ['ripple', '点击波纹'], ['spotlight', '悬停光斑'],
    ['badges', '技术标签']
  ];
  const STORAGE_KEY = 'bmmd_visual_effects_v1';
  const THEME_KEY = 'bmmd_visual_theme';
  const body = document.body;
  const media = matchMedia('(prefers-reduced-motion: reduce)');
  const state = Object.fromEntries(EFFECTS.map(([key]) => [key, true]));
  const read = (key) => { try { return localStorage.getItem(key); } catch { return null; } };
  const write = (key, value) => { try { localStorage.setItem(key, value); } catch {} };
  try {
    const saved = JSON.parse(read(STORAGE_KEY));
    if (saved && typeof saved === 'object') EFFECTS.forEach(([key]) => {
      if (typeof saved[key] === 'boolean') state[key] = saved[key];
    });
  } catch {}
  if (read(THEME_KEY) === 'light') body.classList.remove('dark-mode');
  body.classList.add('tech-lab');

  const created = [];
  const removers = [];
  const create = (tag, className, parent, text) => {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text) el.textContent = text;
    if (parent) parent.appendChild(el);
    return el;
  };
  const own = (el) => { created.push(el); return el; };
  const listen = (el, type, callback, options) => {
    el.addEventListener(type, callback, options);
    removers.push(() => el.removeEventListener(type, callback, options));
  };
  const decorative = (el) => { el.setAttribute('aria-hidden', 'true'); return el; };
  const atmosphere = own(decorative(create('div', 'tech-atmosphere', body)));
  atmosphere.id = 'tech-atmosphere';
  create('div', 'tech-aurora tech-aurora-cyan', atmosphere);
  create('div', 'tech-aurora tech-aurora-violet', atmosphere);
  const particles = create('canvas', 'tech-particle-layer', atmosphere);
  create('div', 'tech-texture', atmosphere);

  /* Decorative instrument frame: it never captures equipment pointer input. */
  const viewport = document.querySelector('.twin-pane');
  if (viewport) { viewport.appendChild(particles); own(particles); }
  let sceneCode, sceneName, progressReadout, actionReadout;
  if (viewport) {
    const decor = own(decorative(create('div', 'tech-viewport-decor', viewport)));
    create('div', 'tech-floor-grid', decor);
    create('div', 'tech-scan-beam', decor);
    create('div', 'tech-scanlines', decor);
    const orbits = create('div', 'tech-holo-orbits', decor);
    for (let i = 0; i < 3; i++) create('i', `tech-orbit tech-orbit-${i + 1}`, orbits);
    create('div', 'tech-radar', decor);
    create('div', 'tech-ruler-x', decor);
    create('div', 'tech-ruler-y', decor);
    const brackets = create('div', 'tech-reticle-corners', decor);
    for (const corner of ['tl', 'tr', 'bl', 'br']) create('i', `tech-corner-${corner}`, brackets);
    const strip = own(decorative(create('div', 'tech-instrument-strip', viewport)));
    const active = create('span', 'tech-active-label', strip);
    create('i', 'tech-status-dot', active);
    create('span', '', active, 'MODEL / ');
    sceneCode = create('b', 'tech-scene-code', active, 'ALL');
    sceneName = create('span', 'tech-scene-type', strip, '3D 力学实验室');
    const live = own(decorative(create('div', 'tech-live-status', viewport)));
    actionReadout = create('span', '', live, '18 个器械模型');
    progressReadout = create('span', '', live, '动作指导已就绪');
  }

  /* Portal background is a real raster asset; no UI or instructions are baked in. */
  const portal = document.getElementById('portal-hub-overlay');
  if (portal) {
    const portalDecor = own(decorative(create('div', 'tech-portal-decor', portal)));
    const image = create('img', 'tech-portal-image', portalDecor);
    image.src = 'assets/tech/aurora-lab.webp';
    image.alt = '';
    image.decoding = 'async';
    create('div', 'tech-portal-vignette', portalDecor);
    const hero = document.getElementById('portal-welcome-stage');
    if (hero) {
      const badges = own(create('div', 'tech-portal-badges', hero));
      const modelCount = document.querySelectorAll('.analysis-module[data-scene]').length;
      for (const text of [`${modelCount} 个器械模型`, '3D 交互实验', '逐项动作指导']) create('span', '', badges, text);
      const footnote = own(create('p', 'tech-portal-footnote', hero, 'BIOMECHANICS / DIGITAL TRAINING LAB'));
      footnote.setAttribute('aria-hidden', 'true');
    }
  }

  /* A reversible effects board makes this maximal version easy to edit down. */
  const panel = own(create('section', 'tech-effects-panel', body));
  panel.id = 'tech-effects-panel';
  panel.hidden = true;
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-label', '视觉特效');
  const panelHead = create('div', 'tech-effects-head', panel);
  const headText = create('div', '', panelHead);
  create('small', '', headText, 'VISUAL CONTROL');
  create('h2', '', headText, '视觉特效');
  const closeButton = create('button', 'tech-effects-close', panelHead, '关闭');
  closeButton.type = 'button';
  create('p', 'tech-effects-caption', panel, '先加满，再挑选。每一种效果都可以单独关闭。');
  const effectGrid = create('div', 'tech-effects-grid', panel);
  const inputs = new Map();
  EFFECTS.forEach(([key, name]) => {
    const label = create('label', '', effectGrid);
    const input = create('input', '', label);
    input.type = 'checkbox';
    input.checked = state[key];
    input.dataset.effect = key;
    create('span', '', label, name);
    inputs.set(key, input);
    listen(input, 'change', () => { state[key] = input.checked; applyEffects(); });
  });
  const actions = create('div', 'tech-effects-actions', panel);
  const allButton = create('button', '', actions, '全部开启');
  const staticButton = create('button', '', actions, '静态模式');
  const noneButton = create('button', '', actions, '关闭特效');
  [allButton, staticButton, noneButton].forEach((button) => { button.type = 'button'; });
  create('p', 'tech-effects-note', panel, '只改变视觉效果，器械参数和训练数据保持原设置。');
  const triggers = [];
  let lastTrigger;
  const openPanel = (button) => {
    lastTrigger = button;
    panel.hidden = !panel.hidden;
    triggers.forEach((trigger) => trigger.setAttribute('aria-expanded', String(!panel.hidden)));
    if (!panel.hidden) closeButton.focus();
  };
  const closePanel = (restore = false) => {
    panel.hidden = true;
    triggers.forEach((trigger) => trigger.setAttribute('aria-expanded', 'false'));
    if (restore && lastTrigger?.isConnected) lastTrigger.focus();
  };
  const addTrigger = (parent, className) => {
    const button = own(create('button', `tech-effects-toggle ${className}`, parent, '视觉特效'));
    button.type = 'button';
    button.setAttribute('aria-controls', panel.id);
    button.setAttribute('aria-expanded', 'false');
    triggers.push(button);
    listen(button, 'click', () => openPanel(button));
    return button;
  };
  const brand = document.querySelector('.system-header .brand');
  let brandShell;
  if (brand) {
    brandShell = create('div', 'tech-brand-shell');
    brand.before(brandShell);
    addTrigger(brandShell, 'tech-header-trigger');
    brandShell.appendChild(brand);
  }
  if (portal) {
    const controls = own(create('div', 'tech-portal-controls', portal));
    addTrigger(controls, 'tech-portal-trigger');
  }
  listen(closeButton, 'click', () => closePanel(true));
  listen(document, 'keydown', (event) => { if (event.key === 'Escape' && !panel.hidden) closePanel(true); });
  listen(document, 'click', (event) => {
    if (!panel.hidden && !panel.contains(event.target) && !triggers.some((trigger) => trigger.contains(event.target))) closePanel();
  });
  const setAll = (value) => { EFFECTS.forEach(([key]) => { state[key] = value; }); applyEffects(); };
  listen(allButton, 'click', () => setAll(true));
  listen(noneButton, 'click', () => setAll(false));
  listen(staticButton, 'click', () => {
    setAll(true);
    ['particles', 'shimmer', 'scan', 'orbit', 'radar', 'reveal', 'ripple', 'spotlight'].forEach((key) => { state[key] = false; });
    applyEffects();
  });
  function applyEffects() {
    body.dataset.techFx = EFFECTS.filter(([key]) => state[key]).map(([key]) => key).join(' ');
    inputs.forEach((input, key) => { input.checked = state[key]; });
    write(STORAGE_KEY, JSON.stringify(state));
    if (!state.particles) context?.clearRect(0, 0, width, height);
    else { drawParticles(false); scheduleParticles(); }
  }

  /* Low-cost particle network: 24 fps cap, hidden-tab pause, smaller mobile budget. */
  const context = particles.getContext('2d');
  let width = 0, height = 0, nodes = [], frame = 0, lastDraw = 0, alive = true;
  let pointer = { x: -1000, y: -1000 };
  const randomNode = () => ({ x: Math.random() * width, y: Math.random() * height, dx: (Math.random() - .5) * .2, dy: (Math.random() - .5) * .2, size: Math.random() * 1.25 + .45 });
  const resizeParticles = () => {
    width = viewport?.clientWidth || innerWidth;
    height = viewport?.clientHeight || innerHeight;
    const scale = Math.min(devicePixelRatio || 1, 1.5);
    particles.width = Math.round(width * scale);
    particles.height = Math.round(height * scale);
    particles.style.width = `${width}px`; particles.style.height = `${height}px`;
    context?.setTransform(scale, 0, 0, scale, 0, 0);
    nodes = Array.from({ length: width < 700 ? 24 : Math.min(65, Math.floor(width / 23)) }, randomNode);
    drawParticles(false);
  };
  const drawParticles = (move) => {
    if (!context) return;
    context.clearRect(0, 0, width, height);
    if (!state.particles) return;
    const dark = body.classList.contains('dark-mode');
    const tint = dark ? '76,210,244' : '27,108,175';
    const alpha = dark ? .5 : .22;
    nodes.forEach((node, i) => {
      if (move) {
        node.x += node.dx; node.y += node.dy;
        if (node.x < 0 || node.x > width) node.dx *= -1;
        if (node.y < 0 || node.y > height) node.dy *= -1;
      }
      context.fillStyle = `rgba(${tint},${alpha})`;
      context.beginPath(); context.arc(node.x, node.y, node.size, 0, Math.PI * 2); context.fill();
      for (let j = i + 1; j < nodes.length; j++) {
        const other = nodes[j], distance = Math.hypot(node.x - other.x, node.y - other.y);
        if (distance < 130) {
          context.strokeStyle = `rgba(${tint},${(1 - distance / 130) * alpha * .26})`;
          context.beginPath(); context.moveTo(node.x, node.y); context.lineTo(other.x, other.y); context.stroke();
        }
      }
      const proximity = Math.hypot(node.x - pointer.x, node.y - pointer.y);
      if (state.spotlight && proximity < 175) {
        context.strokeStyle = `rgba(${tint},${(1 - proximity / 175) * alpha * .32})`;
        context.beginPath(); context.moveTo(node.x, node.y); context.lineTo(pointer.x, pointer.y); context.stroke();
      }
    });
  };
  const animateParticles = (time) => {
    frame = 0;
    if (!alive || document.hidden || !state.particles || media.matches) return;
    if (time - lastDraw >= 42) { drawParticles(true); lastDraw = time; }
    scheduleParticles();
  };
  function scheduleParticles() {
    if (alive && !frame && context && state.particles && !document.hidden && !media.matches) frame = requestAnimationFrame(animateParticles);
  }
  resizeParticles();
  listen(window, 'resize', resizeParticles, { passive: true });
  listen(document, 'visibilitychange', () => { if (!document.hidden) scheduleParticles(); });
  listen(media, 'change', () => { drawParticles(false); scheduleParticles(); });

  /* Hover and ripple feedback only touch decorative CSS variables and elements. */
  const panelSelector = '.gateway-card,.workspace-card,.config-card,.analysis-module,.coach-hud';
  let hoverPanel = null, pendingPointer = 0;
  const onPointerMove = (event) => {
    if (event.pointerType === 'touch' || media.matches) return;
    const viewportRect = viewport?.getBoundingClientRect();
    pointer = { x: event.clientX - (viewportRect?.left || 0), y: event.clientY - (viewportRect?.top || 0) };
    if (!state.spotlight || pendingPointer) return;
    hoverPanel = event.target.closest(panelSelector);
    pendingPointer = requestAnimationFrame(() => {
      pendingPointer = 0;
      if (!hoverPanel) return;
      const rect = hoverPanel.getBoundingClientRect();
      hoverPanel.style.setProperty('--spot-x', `${event.clientX - rect.left}px`);
      hoverPanel.style.setProperty('--spot-y', `${event.clientY - rect.top}px`);
    });
  };
  listen(document, 'pointermove', onPointerMove, { passive: true });
  listen(document, 'pointerleave', () => { pointer = { x: -1000, y: -1000 }; }, { passive: true });
  listen(document, 'click', (event) => {
    if (!state.ripple || media.matches) return;
    const button = event.target.closest('button');
    if (!button || button.closest('.tech-effects-panel')) return;
    const rect = button.getBoundingClientRect();
    const ripple = create('span', 'tech-ripple', button);
    ripple.setAttribute('aria-hidden', 'true');
    const size = Math.max(rect.width, rect.height) * 2;
    ripple.style.width = ripple.style.height = `${size}px`;
    ripple.style.left = `${event.detail ? event.clientX - rect.left : rect.width / 2}px`;
    ripple.style.top = `${event.detail ? event.clientY - rect.top : rect.height / 2}px`;
    ripple.addEventListener('animationend', () => ripple.remove(), { once: true });
    setTimeout(() => ripple.remove(), 900);
  });

  /* All instrument values describe the live scene, never fabricated health data. */
  let lastScene = '';
  const syncInstruments = () => {
    const tab = document.querySelector('.action-tab.active');
    const scene = tab?.dataset.scene || 'overview';
    const module = document.querySelector('.analysis-module.active');
    const count = document.querySelectorAll('.analysis-module[data-scene]').length;
    if (sceneCode) sceneCode.textContent = module?.id.replace('module-', '').padStart(2, '0') || 'ALL';
    if (sceneName) sceneName.textContent = tab?.textContent.trim() || '3D 力学实验室';
    if (actionReadout) actionReadout.textContent = scene === 'overview' ? `${count} 个器械模型` : `动作 ${sceneCode.textContent} · ${count} 台器械`;
    if (progressReadout) {
      const range = module?.querySelector('input[type="range"]:not(:disabled)');
      const label = range?.closest('label');
      const rangeName = label?.childNodes[0]?.textContent.trim() || '动作行程';
      const valueText = label?.querySelector('span[id$="-value"]')?.textContent.trim();
      progressReadout.textContent = range ? `${rangeName} ${valueText || range.value}` : '动作指导已就绪';
    }
    if (scene !== lastScene) {
      lastScene = scene;
      if (module && state.reveal && !media.matches) {
        module.classList.remove('tech-reveal-in');
        requestAnimationFrame(() => module.classList.add('tech-reveal-in'));
      }
    }
    if (portal) body.classList.toggle('tech-portal-open', getComputedStyle(portal).display !== 'none');
  };
  const interval = setInterval(syncInstruments, 750);
  const tabObserver = new MutationObserver(syncInstruments);
  const tabBar = document.querySelector('.action-tab-bar');
  if (tabBar) tabObserver.observe(tabBar, { attributes: true, attributeFilter: ['class'], subtree: true });
  const themeObserver = new MutationObserver(() => {
    write(THEME_KEY, body.classList.contains('dark-mode') ? 'dark' : 'light');
    drawParticles(false);
  });
  themeObserver.observe(body, { attributes: true, attributeFilter: ['class'] });
  applyEffects();
  syncInstruments();

  window.BMMDVisuals = {
    effectNames: EFFECTS.map(([key, name]) => ({ key, name })),
    getState: () => ({ ...state }),
    setEffect: (key, value) => { if (key in state) { state[key] = Boolean(value); applyEffects(); } },
    setAll,
    destroy: () => {
      alive = false;
      cancelAnimationFrame(frame); cancelAnimationFrame(pendingPointer);
      clearInterval(interval); tabObserver.disconnect(); themeObserver.disconnect();
      removers.forEach((remove) => remove());
      created.forEach((el) => el.remove());
      document.querySelectorAll('.tech-reveal-in,.tech-ripple').forEach((el) => {
        if (el.classList.contains('tech-ripple')) el.remove(); else el.classList.remove('tech-reveal-in');
      });
      if (brandShell?.isConnected && brand?.isConnected) { brandShell.before(brand); brandShell.remove(); }
      delete body.dataset.techFx;
      body.classList.remove('tech-lab', 'tech-portal-open');
      delete window.BMMDVisuals;
    }
  };
})();
