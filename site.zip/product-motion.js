/* Motion for the current product pages. All text stays semantic; no cloned paragraphs. */
(() => {
  'use strict';
  const B = window.BM;
  const media = matchMedia('(prefers-reduced-motion: reduce)');
  const pointer = matchMedia('(hover: hover) and (pointer: fine)');
  let observer = null, schedule = 0, lastRoute = '', prepared = new WeakSet();
  const running = new Set();
  const reduced = () => media.matches || document.documentElement.classList.contains('pd-reduced');
  function animate(element, frames, options) {
    if (!element?.animate || reduced() || document.hidden) return;
    const animation = element.animate(frames, options);
    running.add(animation);
    animation.finished.catch(() => {}).finally(() => running.delete(animation));
    return animation;
  }
  function reveal(element, order = 0, minimal = false) {
    if (B.ScrollMotion?.owns(element)) return;
    if (prepared.has(element)) return;
    prepared.add(element);
    element.classList.add('pd-motion-seen');
    animate(element, [{ opacity: 0.18, transform: `translateY(${minimal ? 5 : 18}px)` }, { opacity: 1, transform: 'translateY(0)' }],
      { duration: minimal ? 260 : 620, delay: Math.min(order, 5) * (minimal ? 25 : 65), easing: 'cubic-bezier(.18,.75,.2,1)' });
  }
  function title(element, train) {
    if (!element || prepared.has(element)) return;
    element.setAttribute('data-heading-renderer', 'product-motion');
    if (element.closest('.apple-hero-copy')) {
      // Break only at authored line breaks. Screen-reader and selectable text remain intact.
      const lines = element.innerHTML.split(/<br\s*\/?\s*>/i);
      if (lines.length > 1) element.innerHTML = lines.map((line, i) => `<span class="pd-title-line"><span class="pd-title-ink ${i ? 'pd-title-accent' : ''}">${line}</span></span>`).join('');
      element.querySelectorAll('.pd-title-ink').forEach((line, i) => reveal(line, i));
      prepared.add(element);
    } else {
      element.classList.add('pd-motion-title');
      reveal(element, 0, train);
    }
  }
  function refresh() {
    schedule = 0;
    observer?.disconnect();
    const route = document.body.dataset.bmRoute || '';
    const train = route.startsWith('train/');
    const surface = route === 'home' ? document.getElementById('portal-hub-overlay') : document.getElementById('product-root');
    if (!surface) return;
    document.documentElement.classList.toggle('pd-motion-reduced', reduced());
    surface.classList.add('pd-motion-surface');
    updateReadingProgress();
    const directory = surface.querySelector('.pd-course-directory');
    if (directory) rootObserver.observe(directory, { childList: true });
    title(surface.querySelector('.apple-hero-copy>h1, .pd-page-heading h1'), train);
    const active = document.querySelector('#pd-header [aria-current]');
    if (active && route !== lastRoute) animate(active, [{ opacity: .35, transform: 'translateY(3px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: 300, easing: 'ease-out' });
    lastRoute = route;
    const elements = surface.querySelectorAll(route === 'home' ? '.apple-hero-copy>p,.apple-hero-copy>span,.pd-home-directions>section,#equipment-hero-root' :
      train ? '.pd-page-intro,.pd-plan,.pd-empty,.pd-current,.pd-summary,.pd-history-row,.pd-session-strip' :
        '.pd-lead,.pd-doors>a,.pd-course-directory>a,.pd-course-demo:not(.pd-course-persistent),.pd-course-prose:not(.pd-course-reading)>section,.pd-ex-theme,.pd-ex-observe,.pd-ex-controls,.pd-plot,.pd-local-panel');
    if (reduced()) { elements.forEach(el => { prepared.add(el); el.classList.add('pd-motion-seen'); }); return; }
    const root = surface;
    observer = new IntersectionObserver(entries => {
      let order = 0;
      for (const entry of entries) if (entry.isIntersecting) { reveal(entry.target, order++, train); observer?.unobserve(entry.target); }
    }, { root, threshold: .06, rootMargin: '0px 0px -24px 0px' });
    elements.forEach(el => { if (!prepared.has(el)) observer.observe(el); });
  }
  function requestRefresh() { if (!schedule) schedule = requestAnimationFrame(refresh); }
  function updateReadingProgress() {
    const root = document.getElementById('product-root');
    if (!root) return;
    const length = root.scrollHeight - root.clientHeight;
    root.style.setProperty('--pd-reading-progress', length > 0 ? Math.min(1, Math.max(0, root.scrollTop / length)) : 0);
  }
  document.addEventListener('click', event => {
    const button = event.target.closest('#product-root button:not(:disabled),#product-root a.pd-button,.pd-home-directions .pd-button,#pd-header button');
    if (!button || reduced() || !button.animate || B.ReferenceEffects?.ownsClick(button)) return;
    // Transform only; DOM labels and live form values are never rewritten.
    animate(button, [{ scale: '1' }, { scale: '.975', offset: .3 }, { scale: '1' }], { duration: 250, easing: 'cubic-bezier(.2,.8,.2,1)' });
    if (!button.querySelector('.pd-click-wave')) {
      const wave = document.createElement('span'), rect = button.getBoundingClientRect();
      wave.className = 'pd-click-wave'; wave.setAttribute('aria-hidden', 'true');
      wave.style.left = (event.detail ? event.clientX - rect.left : rect.width / 2) + 'px';
      wave.style.top = (event.detail ? event.clientY - rect.top : rect.height / 2) + 'px';
      button.append(wave);
      const effect = animate(wave, [{ opacity: .35, transform: 'translate(-50%,-50%) scale(0)' }, { opacity: 0, transform: 'translate(-50%,-50%) scale(8)' }], { duration: 550, easing: 'ease-out' });
      if (effect) effect.finished.catch(() => {}).finally(() => wave.remove()); else wave.remove();
    }
  });
  document.addEventListener('pointermove', event => {
    if (!pointer.matches || reduced()) return;
    const card = event.target.closest('.pd-home-directions>section,.pd-doors>a,.pd-course-directory>a');
    if (!card || B.ReferenceEffects?.ownsCard(card)) return;
    const box = card.getBoundingClientRect();
    card.style.setProperty('--pd-light-x', Math.round((event.clientX - box.left) / box.width * 100) + '%');
    card.style.setProperty('--pd-light-y', Math.round((event.clientY - box.top) / box.height * 100) + '%');
  }, { passive: true });
  function sync() {
    if (reduced() || document.hidden) {
      running.forEach(a => a.cancel()); running.clear();
      document.documentElement.classList.add('pd-motion-paused');
    } else document.documentElement.classList.remove('pd-motion-paused');
    document.documentElement.classList.toggle('pd-motion-reduced', reduced());
    requestRefresh();
  }
  const rootObserver = new MutationObserver(requestRefresh);
  function start() {
    const product = document.getElementById('product-root'), copy = document.querySelector('.apple-hero-copy');
    if (product) rootObserver.observe(product, { childList: true });
    product?.addEventListener('scroll', updateReadingProgress, { passive: true });
    if (copy) rootObserver.observe(copy, { childList: true });
    refresh();
  }
  media.addEventListener('change', sync);
  document.addEventListener('visibilitychange', sync);
  window.addEventListener('bm:store', () => queueMicrotask(() => { if (reduced() !== document.documentElement.classList.contains('pd-motion-reduced')) sync(); }));
  window.addEventListener('bm:page-ready', requestRefresh);
  window.addEventListener('pagehide', () => { observer?.disconnect(); running.forEach(a => a.cancel()); });
  window.addEventListener('pageshow', sync);
  B.ProductMotion = { refresh: requestRefresh, get reduced() { return reduced(); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true }); else start();
})();
