/* Scroll choreography for the existing product. This layer does not replace
   pages, route content, inputs, simulation values or browser-local records. */
(() => {
  'use strict';
  const B=window.BM=window.BM||{};
  const media=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
  const revealSelector='.pd-home-directions>section,#equipment-hero-root,.pd-learn-discover,.pd-live-lab,.pd-learn-feature,.pd-learn-shelf>a,.pd-learn-questions li,.pd-course-directory>a,.pd-ex-theme,.pd-ex-observe,.pd-plot,.pd-local-panel,.pd-plan,.pd-history-row,.pd-doors>a,.pd-section-head';
  const sectionSelector='.pd-ex-theme,.pd-learn-discover,.pd-live-lab,.pd-learn-movements,.pd-learn-questions,.pd-course-prose';
  const magneticSelector='.pd-home-directions .pd-button,.pd-main .pd-primary,#pd-header button,.pd-course-directory>a,.pd-learn-tools>a,.pd-learn-tools>button';
  const prepared=new WeakSet(),animations=new Set(),magnetCache=new WeakMap();
  let root=null,scroller=null,entry=null,tree=null,progress=null,frame=0,prepareFrame=0,parallax=[],sections=[];
  let activeMagnet=null,pointerFrame=0,pointerEvent=null,revealed=0,scrollFrameCount=0,lastReduced=false;
  const reduced=()=>media.matches||document.documentElement.classList.contains('pd-reduced');
  const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
  const owns=el=>!!el?.matches?.(revealSelector);
  function play(el,keyframes,options){
    if(reduced()||document.hidden||!el.animate)return null;
    const animation=el.animate(keyframes,options);animations.add(animation);
    animation.finished.catch(()=>{}).finally(()=>animations.delete(animation));return animation;
  }
  function enter(el){
    if(el.dataset.smState==='entered'||el.dataset.smState==='entering')return;
    el.dataset.smState='entering';
    const heading=el.matches('.pd-section-head'),order=Number(el.dataset.smOrder||0);
    const frames=heading?
      [{opacity:.12,translate:'0 26px',clipPath:'inset(0 0 100% 0)'},{opacity:1,translate:'0 0',clipPath:'inset(0 0 0% 0)'}]:
      [{opacity:.12,translate:'0 48px',filter:'blur(7px)'},{opacity:1,translate:'0 0',filter:'blur(0px)'}];
    const animation=play(el,frames,{duration:heading?900:850,delay:order*75,easing:'cubic-bezier(.16,1,.3,1)',fill:'backwards'});
    const done=()=>{if(el.isConnected)el.dataset.smState='entered';};
    if(animation)animation.finished.then(done,done);else done();
    document.documentElement.dataset.smRevealed=String(++revealed);
  }
  function clearMagnet(el){
    if(!el)return;
    el.style.removeProperty('--sm-magnet-x');el.style.removeProperty('--sm-magnet-y');el.style.removeProperty('--sm-hover-r');
    el.classList.remove('sm-pointer');magnetCache.delete(el);
  }
  function prepare(){
    prepareFrame=0;
    const route=document.body.dataset.bmRoute||'home';
    const next=document.querySelector(route==='home'?'#portal-hub-overlay':'#product-root');
    if(!next)return;
    if(root!==next){tree?.disconnect();root=next;tree=new MutationObserver(records=>{
      const changed=records.some(record=>{
        if(record.target.closest?.('svg,output,.cm-title,.cm-range-shell,#pd-ex-diagram,#pd-ex-metrics,#pd-ex-plots,#pd-course-physics-readout'))return false;
        return [...record.addedNodes].some(node=>node.nodeType===1&& !node.matches('.cm-button-light,.pd-click-wave,.cm-constellation,.cm-word,.cm-char') &&
          (node.matches(revealSelector+',.cm-image-frame,.pd-content,.pd-main')||node.querySelector?.(revealSelector)));
      });
      if(changed)schedule();
    });tree.observe(root,{childList:true,subtree:true});}
    scroller=root;
    if(!document.documentElement.classList.contains('sm-ready'))document.documentElement.classList.add('sm-ready');
    if(document.documentElement.classList.contains('sm-reduced')!==reduced())document.documentElement.classList.toggle('sm-reduced',reduced());
    lastReduced=reduced();
    entry?.disconnect();
    entry=new IntersectionObserver(entries=>{
      for(const item of entries)if(item.isIntersecting){enter(item.target);entry.unobserve(item.target);}
    },{root,threshold:.04,rootMargin:'0px 0px 36px 0px'});
    let order=0;
    root.querySelectorAll(revealSelector).forEach(el=>{
      if(el.matches('.pd-section-head')&&el.closest('.pd-learn-discover,.pd-live-lab'))return;
      el.classList.add('sm-reveal-target');
      el.dataset.smOrder=String(el.matches('.pd-course-directory>a,.pd-learn-shelf>a,.pd-doors>a')?(order++%3):0);
      if(prepared.has(el)){if(el.dataset.smState==='waiting')entry.observe(el);return;}
      prepared.add(el);
      if(reduced()||route==='train/session'){el.dataset.smState='entered';return;}
      el.dataset.smState='waiting';entry.observe(el);
    });
    parallax=[];
    root.querySelectorAll('.cm-image-frame,.pd-learn-equipment img,.pd-model-fallback img').forEach(el=>{
      el.classList.add('sm-parallax');
      const anchor=el.closest('.pd-course-directory>a,.pd-learn-feature,.pd-learn-shelf>a,.pd-model-fallback')||el.parentElement;
      parallax.push({el,anchor,range:el.matches('.cm-image-frame')?12:22});
    });
    const hero=root.querySelector('#equipment-hero-root');
    if(hero){hero.classList.add('sm-hero-depth');parallax.push({el:hero,anchor:hero.parentElement,range:18,hero:true});}
    sections=[...root.querySelectorAll(sectionSelector)].filter(el=>!el.closest('.pd-course-workspace'));
    sections.forEach(el=>el.classList.add('sm-scroll-section'));
    const header=document.getElementById('pd-header');
    progress=header?.querySelector('.sm-reading-progress');
    if(header&&!progress){progress=document.createElement('span');progress.className='sm-reading-progress';progress.setAttribute('aria-hidden','true');header.append(progress);}
    document.documentElement.dataset.smTargets=String(root.querySelectorAll('.sm-reveal-target').length);
    requestTick();
  }
  function schedule(){if(!prepareFrame)prepareFrame=requestAnimationFrame(prepare);}
  function tick(){
    frame=0;if(!root||document.hidden)return;
    const bounds=root.getBoundingClientRect(),height=root.clientHeight||innerHeight;
    const length=scroller.scrollHeight-scroller.clientHeight;
    const fraction=length>1?clamp(scroller.scrollTop/length):0;
    if(progress){progress.style.setProperty('--sm-progress',fraction.toFixed(4));progress.hidden=length<20;}
    for(const item of parallax){
      if(!item.el.isConnected)continue;
      const rect=item.anchor.getBoundingClientRect();
      if(rect.bottom<bounds.top-160||rect.top>bounds.bottom+160)continue;
      const p=clamp((rect.top+rect.height/2-bounds.top-height/2)/height,-.8,.8);
      const y=reduced()?0:-p*item.range;
      item.el.style.setProperty('--sm-drift',y.toFixed(2)+'px');
      if(item.hero)item.el.style.setProperty('--sm-hero-scale',reduced()?'1':(1+clamp(root.scrollTop/Math.max(1,height),0,1)*.035).toFixed(4));
    }
    for(const el of sections){
      const r=el.getBoundingClientRect();if(r.bottom<bounds.top||r.top>bounds.bottom)continue;
      el.style.setProperty('--sm-line-progress',clamp((bounds.bottom-r.top)/Math.min(height*.8,Math.max(180,r.height))).toFixed(4));
    }
    document.documentElement.dataset.smScrollFrames=String(++scrollFrameCount);
    document.documentElement.dataset.smProgress=fraction.toFixed(4);
  }
  function requestTick(){if(!frame)frame=requestAnimationFrame(tick);}
  document.addEventListener('scroll',event=>{
    const el=event.target;
    if(!root)return;
    if(el===root)scroller=root;
    else if(el instanceof Element&&el.matches('.pd-course-reading')&&root.contains(el))scroller=el;
    else return;
    requestTick();
  },{capture:true,passive:true});
  function pointer(){
    pointerFrame=0;const e=pointerEvent;pointerEvent=null;
    if(!e||!fine.matches||reduced())return;
    const el=e.target.closest(magneticSelector);
    if(activeMagnet!==el){clearMagnet(activeMagnet);activeMagnet=el;}
    if(!el||el.disabled||B.ReferenceEffects?.ownsMagnet(el))return;
    let rect=magnetCache.get(el);if(!rect){rect=el.getBoundingClientRect();magnetCache.set(el,rect);}
    const x=clamp((e.clientX-rect.left)/rect.width-.5,-.5,.5),y=clamp((e.clientY-rect.top)/rect.height-.5,-.5,.5);
    el.classList.add('sm-pointer');
    if(el.matches('button,.pd-button')){
      el.classList.add('sm-magnetic');el.style.setProperty('--sm-magnet-x',(x*10).toFixed(2)+'px');el.style.setProperty('--sm-magnet-y',(y*8).toFixed(2)+'px');
    }else{el.style.setProperty('--sm-hover-r',(x*3).toFixed(2)+'deg');}
  }
  document.addEventListener('pointermove',event=>{if(!fine.matches||reduced())return;pointerEvent=event;if(!pointerFrame)pointerFrame=requestAnimationFrame(pointer);},{passive:true});
  document.addEventListener('pointerout',event=>{if(activeMagnet&&!activeMagnet.contains(event.relatedTarget)){clearMagnet(activeMagnet);activeMagnet=null;}},{passive:true});
  document.addEventListener('focusin',event=>{const el=event.target.closest('.sm-reveal-target');if(el&&el.dataset.smState==='waiting')enter(el);});
  function sync(){
    const isReduced=reduced();if(document.documentElement.classList.contains('sm-reduced')!==isReduced)document.documentElement.classList.toggle('sm-reduced',isReduced);
    if(isReduced||document.hidden){animations.forEach(a=>a.cancel());animations.clear();clearMagnet(activeMagnet);activeMagnet=null;root?.querySelectorAll('[data-sm-state="waiting"]').forEach(el=>el.dataset.smState='entered');}
    if(isReduced!==lastReduced){lastReduced=isReduced;schedule();}else requestTick();
  }
  const preferences=new MutationObserver(sync);preferences.observe(document.documentElement,{attributes:true,attributeFilter:['class']});
  const routes=new MutationObserver(()=>{clearMagnet(activeMagnet);activeMagnet=null;schedule();});routes.observe(document.body,{attributes:true,attributeFilter:['data-bm-route']});
  window.addEventListener('bm:page-ready',schedule);window.addEventListener('resize',()=>{magnetCache.delete(activeMagnet);requestTick();},{passive:true});
  document.addEventListener('visibilitychange',sync);media.addEventListener('change',sync);
  window.addEventListener('pageshow',schedule);
  window.addEventListener('pagehide',()=>{cancelAnimationFrame(frame);cancelAnimationFrame(prepareFrame);cancelAnimationFrame(pointerFrame);frame=prepareFrame=pointerFrame=0;entry?.disconnect();animations.forEach(a=>a.cancel());animations.clear();});
  B.ScrollMotion={owns,refresh:schedule};
  // Run before the existing entry-effect engines decide their ownership.
  prepare();
})();
