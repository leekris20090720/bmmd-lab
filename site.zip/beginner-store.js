/* Local, versioned personal data. Model examples never become confirmed user measurements. */
(() => {
  'use strict';
  const VERSION = 3;
  const FORMAT = 'bmmd-beginner-export';
  const STORE_KEY = 'bmmd_beginner_store_v3';
  const BACKUP_PREFIX = 'bmmd_beginner_backup_v3_';
  const LEGACY_KEYS = ['user_bio_profile', 'bmmd_custom_training_plan_v1', 'bmmd_custom_plan'];
  const SOURCES = new Set(['user', 'record-estimate', 'height-estimate', 'model-example', 'unknown']);
  const FIELDS = ['height', 'weight', 'armSpan', 'upperArmLength', 'forearmLength',
    'shoulderWidthCm', 'femurLength', 'tibiaLength', 'ankleDorsiflexionCm',
    'plankSeconds', 'hingeGapCm', 'legRaiseAngle', 'armRatio', 'femurRatio',
    'shoulderWidth', 'ankleMobility', 'shoulderRisk', 'spineRisk'];
  const ABILITY_DEFAULTS = { squat1RM: 120, lat1RM: 70, lateral1RM: 12.5 };
  const MAX_BYTES = 4 * 1024 * 1024;
  const MAX_IMPORT_BYTES = 32 * 1024 * 1024;
  const utf8Bytes = value => {let n=0;for(const c of String(value)){const code=c.codePointAt(0);n+=code<128?1:code<2048?2:code<65536?3:4;}return n;};
  const ID = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}$/;
  const FIELD_KEY = /^[A-Za-z][A-Za-z0-9_]{0,79}$/;
  const UNSAFE_KEYS = new Set(['__proto__', 'prototype', 'constructor']);
  const clone = value => JSON.parse(JSON.stringify(value));
  const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
  const plain = value => Boolean(value) && typeof value === 'object' && !Array.isArray(value) &&
    (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
  const errorText = error => error instanceof Error ? error.message : String(error);
  const nowISO = () => new Date().toISOString();
  let storage = null, state, volatileDraft = null, lastCanonicalRaw = null;
  let lastError = null, loadError = null, backupError = null, lastSavedAt = null, hasStoredData = false;
  const legacyRaw = {};
  const subscribers = new Set();

  function validDate(value, timestamp = false) {
    if (typeof value !== 'string') return false;
    const pattern = timestamp ? /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/ :
      /^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2}))?$/;
    if (!pattern.test(value) || !Number.isFinite(Date.parse(value))) return false;
    const year = Number(value.slice(0, 4)), month = Number(value.slice(5, 7)), day = Number(value.slice(8, 10));
    if (year < 1900 || year > 2200 || new Date(Date.UTC(year, month - 1, day)).toISOString().slice(0, 10) !== value.slice(0, 10)) return false;
    return value.length === 10 || (Number(value.slice(11, 13)) <= 23 && Number(value.slice(14, 16)) <= 59 && Number(value.slice(17, 19)) <= 59);
  }
  function validate(value) {
    const errors = [];
    const add = (path, message) => { if (errors.length < 40) errors.push(path + ': ' + message); };
    let visited = 0;
    const seen = new Set();
    function tree(item, path, depth) {
      if (++visited > 100000 || depth > 25) { add(path, '数据层级或数量超出限制'); return; }
      if (item === null || typeof item === 'boolean') return;
      if (typeof item === 'number') { if (!Number.isFinite(item)) add(path, '数字必须有限'); return; }
      if (typeof item === 'string') { if (item.length > 200000) add(path, '文本过长'); return; }
      if (typeof item !== 'object' || (!Array.isArray(item) && !plain(item))) { add(path, '只允许普通 JSON 数据'); return; }
      if (seen.has(item)) { add(path, '不允许循环或复用对象引用'); return; }
      seen.add(item);
      if (Array.isArray(item)) {
        if (item.length > 3000) add(path, '数组过长');
        const ids = new Set();
        for (let index = 0; index < Math.min(item.length, 3001); index++) {
          const child = item[index];
          if (plain(child) && own(child, 'id')) {
            if (typeof child.id !== 'string' || !ID.test(child.id)) add(path + '[' + index + '].id', 'ID 格式无效');
            else if (ids.has(child.id)) add(path, '重复 ID: ' + child.id);
            else ids.add(child.id);
          }
          tree(child, path + '[' + index + ']', depth + 1);
        }
      } else {
        if (Reflect.ownKeys(item).length > 200) add(path, '对象字段过多');
        for (const key of Reflect.ownKeys(item)) {
          if (typeof key !== 'string' || UNSAFE_KEYS.has(key)) { add(path, '不安全的对象字段'); continue; }
          const descriptor = Object.getOwnPropertyDescriptor(item, key);
          if (!descriptor || descriptor.get || descriptor.set) { add(path + '.' + key, '不允许访问器'); continue; }
          tree(descriptor.value, path + '.' + key, depth + 1);
        }
      }
      seen.delete(item);
    }
    tree(value, 'state', 0);
    if (errors.length) return errors;
    let serialized;
    try { serialized = JSON.stringify(value); } catch (error) { add('state', errorText(error)); return errors; }
    if (utf8Bytes(serialized) > MAX_BYTES) add('state', '训练库超过 4 MiB 产品安全上限，请导出并归档整理；原数据保持。');
    if (!plain(value)) { add('state', '必须是对象'); return errors; }
    if (value.version !== VERSION) add('state.version', '只支持版本 3');
    for (const key of ['profile', 'conditions', 'plans', 'sessions', 'activeSessionId', 'wizard', 'preferences'])
      if (!own(value, key)) add('state.' + key, '缺少完整快照字段');
    for (const key of Object.keys(value))
      if (!['version', 'profile', 'conditions', 'plans', 'sessions', 'activeSessionId', 'wizard', 'preferences', 'legacyCustomPlan'].includes(key)) add('state.' + key, '未知顶层字段');
    for (const key of ['conditions', 'wizard', 'preferences']) if (!plain(value[key])) add('state.' + key, '必须是对象');
    function conditions(c,path){
      if(!plain(c)){add(path,'条件必须是对象');return;}
      const enums={experience:['new','some','experienced','unsure'],goal:['learn','strength','general','hypertrophy','unsure'],location:['home','gym','unsure'],split:['full','ppl','upper_lower','unsure','hypertrophy'],units:['kg','lb'],timePreference:['time','coverage']};
      for(const [k,allowed] of Object.entries(enums))if(own(c,k)&&!allowed.includes(c[k]))add(path+'.'+k,'条件选项无效');
      for(const [k,min,max] of [['days',1,6],['minutes',15,120]])if(own(c,k)){const n=Number(c[k]);if(c[k]===null||c[k]===''||!Number.isFinite(n)||n<min||n>max||(k==='days'&&!Number.isInteger(n)))add(path+'.'+k,'时间/天数无效');}
      for(const key of ['equipment','actions','resources','avoid','muscles'])if(own(c,key)){if(!Array.isArray(c[key])||c[key].length>100)add(path+'.'+key,'必须为有限选项数组');else c[key].forEach((v,i)=>{if(typeof v!=='string'||!ID.test(v))add(path+'.'+key+'['+i+']','选项无效');});}
    }
    conditions(value.conditions,'state.conditions');

    if (plain(value.wizard) && (!Number.isInteger(value.wizard.step) || value.wizard.step < 0 || value.wizard.step > 50)) add('state.wizard.step', '步骤无效');
    const text = (item, path, max = 4000, required = false) => {
      if (item == null && !required) return;
      if (typeof item !== 'string' || item.length > max) add(path, '文本类型或长度无效');
    };
    const number = (item, path, min = 0, max = 100000, integer = false, nullable = true) => {
      if (item === null && nullable) return;
      if (typeof item !== 'number' || !Number.isFinite(item) || item < min || item > max || (integer && !Number.isInteger(item))) add(path, '数字范围无效');
    };
    const date = (item, path, nullable = false, timestamp = true) => {
      if (item === null && nullable) return;
      if (!validDate(item, timestamp)) add(path, '日期格式无效');
    };
    const id = (item, path, nullable = false) => {
      if (item === null && nullable) return;
      if (typeof item !== 'string' || !ID.test(item)) add(path, 'ID 格式无效');
    };
    const enumValue = (item, allowed, path, nullable = false) => {
      if (item === null && nullable) return;
      if (!allowed.includes(item)) add(path, '枚举值无效');
    };
    if (!plain(value.profile) || !plain(value.profile.fields) || !Array.isArray(value.profile.abilities)) add('state.profile', '档案结构无效');
    else {
      for (const key of FIELDS) if (!own(value.profile.fields, key)) add('state.profile.fields.' + key, '缺少可空档案字段');
      for (const [key, field] of Object.entries(value.profile.fields)) {
        const path = 'state.profile.fields.' + key;
        if (!FIELD_KEY.test(key) || UNSAFE_KEYS.has(key) || !plain(field) || !own(field, 'value') || !own(field, 'source') || !own(field, 'updatedAt')) { add(path, '字段结构无效'); continue; }
        if (!SOURCES.has(field.source)) add(path + '.source', '来源无效');
        if (field.updatedAt !== null) date(field.updatedAt, path + '.updatedAt');
        if (field.value !== null && !['number', 'string', 'boolean'].includes(typeof field.value)) add(path + '.value', '个人字段必须是可空标量');
        if (FIELDS.includes(key) && !['femurRatio', 'shoulderWidth'].includes(key) && field.value !== null && typeof field.value !== 'number') add(path + '.value', '身体测量必须是数字或 null');
        if (['femurRatio', 'shoulderWidth'].includes(key) && field.value !== null && typeof field.value !== 'string') add(path + '.value', '分类字段必须是文本或 null');
        if (typeof field.value === 'number') number(field.value, path + '.value', 0, 100000);
        if (typeof field.value === 'string') text(field.value, path + '.value', 500);
        if (own(field, 'pendingValue') && field.pendingValue !== null && !['number', 'string', 'boolean'].includes(typeof field.pendingValue)) add(path + '.pendingValue', '待确认字段必须是标量');
      }
      if (value.profile.pendingLegacy != null && !plain(value.profile.pendingLegacy)) add('state.profile.pendingLegacy', '待确认旧值必须是对象');
      value.profile.abilities.forEach((ability, index) => {
        const path = 'state.profile.abilities[' + index + ']';
        if (!plain(ability)) { add(path, '能力记录必须是对象'); return; }
        id(ability.id, path + '.id');
        if (!SOURCES.has(ability.source)) add(path + '.source', '来源无效');
        if (own(ability, 'value')) number(ability.value, path + '.value');
        if (own(ability, 'load')) number(ability.load, path + '.load');
        if (ability.updatedAt != null) date(ability.updatedAt, path + '.updatedAt');
        if (ability.confirmed === true && (ability.source === 'unknown' || ability.source === 'model-example')) add(path, '来源不明或模型示例不可确认为个人能力');
      });
    }
    function item(itemValue, path) {
      if (!plain(itemValue)) { add(path, '动作必须是对象'); return; }
      id(itemValue.id, path + '.id');
      id(itemValue.actionId, path + '.actionId', true);
      id(itemValue.equipmentId, path + '.equipmentId', true);
      text(itemValue.customName, path + '.customName', 200);
      number(itemValue.sets, path + '.sets', 1, 12, true, false);
      number(itemValue.repsMin, path + '.repsMin', 1, 50, true, false);
      number(itemValue.repsMax, path + '.repsMax', 1, 50, true, false);
      if (itemValue.repsMax < itemValue.repsMin) add(path, '次数范围顺序无效');
      number(itemValue.restSeconds, path + '.restSeconds', 30, 600, true, false);
      number(itemValue.targetLoad, path + '.targetLoad');
      enumValue(itemValue.unit, ['kg', 'lb', 'bodyweight'], path + '.unit');
      enumValue(itemValue.loadBasis, ['stack-labelled', 'total-bar', 'total-plates', 'per-side', 'each-dumbbell', 'bodyweight'], path + '.loadBasis');
      if (!plain(itemValue.loadSource)) add(path + '.loadSource', '负荷来源无效');
      else {
        enumValue(itemValue.loadSource.type, ['unknown', 'user', 'record'], path + '.loadSource.type');
        if (itemValue.loadSource.recordId != null) id(itemValue.loadSource.recordId, path + '.loadSource.recordId');
        if (itemValue.loadSource.date != null) date(itemValue.loadSource.date, path + '.loadSource.date', false, false);
        text(itemValue.loadSource.explanation, path + '.loadSource.explanation', 2000);
      }
      if (!Array.isArray(itemValue.alternatives) || itemValue.alternatives.length > 30) add(path + '.alternatives', '替代动作列表无效');
      else itemValue.alternatives.forEach((alternative, index) => id(alternative, path + '.alternatives[' + index + ']'));
      text(itemValue.notes, path + '.notes', 4000);
      if(own(itemValue,'variant'))id(itemValue.variant,path+'.variant');
      if(own(itemValue,'sides'))enumValue(itemValue.sides,['both','left','right','single'],path+'.sides');
      if(own(itemValue,'recordUnit'))enumValue(itemValue.recordUnit,['kg','lb','bodyweight'],path+'.recordUnit');
      if(own(itemValue,'equipmentContext')){
        const e=itemValue.equipmentContext,ep=path+'.equipmentContext';
        if(!plain(e))add(ep,'器械上下文必须是对象');
        else {if(typeof e.confirmed!=='boolean')add(ep+'.confirmed','确认状态须为布尔值');id(e.equipmentId,ep+'.equipmentId',true);text(e.equipmentLabel,ep+'.equipmentLabel',200,true);enumValue(e.kind,['catalog','custom','unknown'],ep+'.kind');if(e.confirmed&&(!e.equipmentId||e.kind==='unknown'))add(ep,'已确认器械须有身份');if(e.kind==='custom'&&e.confirmed&&!String(e.equipmentLabel||'').trim())add(ep,'自定义器械名称不可空白');if(e.kind==='catalog'&&e.confirmed&&e.equipmentId!==itemValue.equipmentId)add(ep,'目录型号与确认对象不一致');if(e.kind==='unknown'&&(e.confirmed||e.equipmentId!==null))add(ep,'未知器械不能带已确认身份');if(e.kind==='custom'&&typeof e.equipmentId==='string'&&!e.equipmentId.startsWith('custom-'))add(ep,'自定义器械身份须使用custom前缀');}
      }
    }
    function plan(planValue, path) {
      if (!plain(planValue)) { add(path, '计划必须是对象'); return; }
      id(planValue.id, path + '.id'); text(planValue.title, path + '.title', 200, true);
      if(own(planValue,'familyId'))id(planValue.familyId,path+'.familyId');
      if(own(planValue,'parentId'))id(planValue.parentId,path+'.parentId');
      if(own(planValue,'archived')&&typeof planValue.archived!=='boolean')add(path+'.archived','归档状态须为布尔值');
      for (const key of ['warnings','sourceLinks']) if (own(planValue,key)) { const a=planValue[key];if(!Array.isArray(a)||a.length>100)add(path+'.'+key,'必须为有限字符串数组');else a.forEach((v,j)=>{text(v,path+'.'+key+'['+j+']',2000,true);if(key==='sourceLinks'&&typeof v==='string'){try{const u=new URL(v);if(!['https:','http:'].includes(u.protocol))throw Error();}catch{add(path+'.'+key,'来源URL无效');}}if(key==='sourceLinks' && (typeof v!=='string'||!/^https?:\/\//i.test(v)))add(path+'.'+key,'来源只接受http或https链接');}); }
      if(own(planValue,'templateNote'))text(planValue.templateNote,path+'.templateNote',4000);
      number(planValue.version, path + '.version', 1, 100000, true, false);
      enumValue(planValue.kind, ['guided', 'manual', 'legacy'], path + '.kind');
      date(planValue.createdAt, path + '.createdAt'); date(planValue.updatedAt, path + '.updatedAt');
      conditions(planValue.conditions,path+'.conditions');
      if (!Array.isArray(planValue.days) || planValue.days.length > 31) { add(path + '.days', '训练日列表无效'); return; }
      planValue.days.forEach((day, index) => {
        const dayPath = path + '.days[' + index + ']';
        if (!plain(day)) { add(dayPath, '训练日必须是对象'); return; }
        id(day.id, dayPath + '.id'); text(day.title, dayPath + '.title', 200, true);
        if (day.weekday != null) number(day.weekday, dayPath + '.weekday', 1, 7, true, false);
        if (!Array.isArray(day.items) || day.items.length > 100) add(dayPath + '.items', '动作列表无效');
        else day.items.forEach((entry, itemIndex) => item(entry, dayPath + '.items[' + itemIndex + ']'));
      });
    }
    if(plain(value.wizard)&&own(value.wizard,'draftPlan'))plan(value.wizard.draftPlan,'state.wizard.draftPlan');
    if(plain(value.preferences)&&value.preferences.planDraft!=null){const draft=value.preferences.planDraft;if(!plain(draft))add('state.preferences.planDraft','编辑草稿须为对象');else{id(draft.baseId,'state.preferences.planDraft.baseId',true);plan(draft.plan,'state.preferences.planDraft.plan');if(own(draft,'changed')&&typeof draft.changed!=='boolean')add('state.preferences.planDraft.changed','变化标记须为布尔值');if(draft.baseId!==null&&Array.isArray(value.plans)&&!value.plans.some(p=>p.id===draft.baseId))add('state.preferences.planDraft.baseId','草稿原版本不存在');}}
    if(plain(value.preferences)&&own(value.preferences,'loadStep'))number(value.preferences.loadStep,'state.preferences.loadStep',.1,100,false,false);
    if (!Array.isArray(value.plans) || value.plans.length > 1000) add('state.plans', '计划列表无效');
    else value.plans.forEach((entry, index) => plan(entry, 'state.plans[' + index + ']'));
    if (!Array.isArray(value.sessions) || value.sessions.length > 1000) add('state.sessions', '训练记录列表无效');
    else value.sessions.forEach((session, index) => {
      const path = 'state.sessions[' + index + ']';
      if (!plain(session)) { add(path, '训练记录必须是对象'); return; }
      if(own(session,'notes'))text(session.notes,path+'.notes',4000);id(session.id, path + '.id'); id(session.planId, path + '.planId'); id(session.dayId, path + '.dayId');
      number(session.planVersion, path + '.planVersion', 1, 100000, true, false);
      plan(session.planSnapshot, path + '.planSnapshot');
      if (plain(session.planSnapshot)) {
        if (session.planSnapshot.id !== session.planId || session.planSnapshot.version !== session.planVersion) add(path, '计划快照与引用不一致');
        if (Array.isArray(session.planSnapshot.days) && !session.planSnapshot.days.some(day => day.id === session.dayId)) add(path + '.dayId', '训练日不在计划快照中');
      }
      date(session.startedAt, path + '.startedAt'); date(session.endedAt, path + '.endedAt', true);
      enumValue(session.status, ['active', 'paused', 'completed', 'partial'], path + '.status');
      if(own(session,'trainingNumber'))number(session.trainingNumber,path+'.trainingNumber',1,100000000,true,false);
      if (!plain(session.cursor)) add(path + '.cursor', '训练位置无效');
      else { id(session.cursor.itemId, path + '.cursor.itemId', true); number(session.cursor.setIndex, path + '.cursor.setIndex', 0, 1500, true, false); }
      if (!Array.isArray(session.items) || session.items.length > 100) add(path + '.items', '动作快照列表无效');
      else session.items.forEach((entry, itemIndex) => item(entry, path + '.items[' + itemIndex + ']'));
      if (!Array.isArray(session.sets) || session.sets.length > 1500) add(path + '.sets', '训练组列表无效');
      else session.sets.forEach((set, setIndex) => {
        const setPath = path + '.sets[' + setIndex + ']';
        if (!plain(set)) { add(setPath, '训练组必须是对象'); return; }
        if(own(set,'sessionId')&&set.sessionId!==session.id)add(setPath+'.sessionId','组所属训练ID不一致');id(set.id, setPath + '.id'); id(set.itemId, setPath + '.itemId');
        id(set.actionId, setPath + '.actionId', true); id(set.equipmentId, setPath + '.equipmentId', true);
        if(own(set,'variant'))id(set.variant,setPath+'.variant');
        if(own(set,'sides'))enumValue(set.sides,['both','left','right','single'],setPath+'.sides');
        if(own(set,'unit'))enumValue(set.unit,['kg','lb','bodyweight'],setPath+'.unit');
        if(own(set,'loadBasis'))enumValue(set.loadBasis,['stack-labelled','total-bar','total-plates','per-side','each-dumbbell','bodyweight'],setPath+'.loadBasis');
        if(own(set,'equipmentLabel'))text(set.equipmentLabel,setPath+'.equipmentLabel',200);
        if(own(set,'actionName'))text(set.actionName,setPath+'.actionName',200);
        const rawKeys=['inputUnit','inputLoadRaw','loadKg'],rawCount=rawKeys.filter(k=>own(set,k)).length;if(rawCount!==0&&rawCount!==3)add(setPath,'原始重量、单位与公斤换算须完整保留');if(set.unit==='lb'&&rawCount!==3)add(setPath,'lb记录须完整保留原始数值与换算');if(set.unit==='bodyweight'&&set.load!==null)add(setPath,'自重记录不应包含外部重量');
        if(own(set,'inputUnit')){enumValue(set.inputUnit,['kg','lb','bodyweight'],setPath+'.inputUnit');if(set.unit!==set.inputUnit)add(setPath,'原始单位与记录单位不一致');}
        if(own(set,'inputLoadRaw')){text(set.inputLoadRaw,setPath+'.inputLoadRaw',100,true);if(typeof set.inputLoadRaw==='string'&&(set.inputLoadRaw.trim()===''?set.load!==null:!Number.isFinite(Number(set.inputLoadRaw))||Number(set.inputLoadRaw)<0||Number(set.inputLoadRaw)!==set.load))add(setPath+'.inputLoadRaw','原始重量与数值不一致');}
        if(own(set,'loadKg')){number(set.loadKg,setPath+'.loadKg',0,100000);const expected=set.unit==='bodyweight'||set.load===null?null:set.load*(set.unit==='lb'?0.45359237:1);if(expected===null?set.loadKg!==null:typeof set.loadKg!=='number'||Math.abs(set.loadKg-expected)>1e-7*Math.max(1,expected))add(setPath+'.loadKg','公斤换算与原始单位不一致');}
        if(own(set,'targetSnapshot')){const t=set.targetSnapshot,tp=setPath+'.targetSnapshot';if(!plain(t))add(tp,'目标快照须为对象');else{number(t.repsMin,tp+'.repsMin',1,50,true,false);number(t.repsMax,tp+'.repsMax',1,50,true,false);number(t.targetLoad,tp+'.targetLoad');enumValue(t.unit,['kg','lb','bodyweight'],tp+'.unit');enumValue(t.loadBasis,['stack-labelled','total-bar','total-plates','per-side','each-dumbbell','bodyweight'],tp+'.loadBasis');if(t.repsMax<t.repsMin)add(tp,'目标次数范围顺序无效');}}
        number(set.setIndex, setPath + '.setIndex', 0, 1500, true, false);
        if(own(set,'setType'))enumValue(set.setType,['warmup','working'],setPath+'.setType');
        number(set.load, setPath + '.load'); number(set.reps, setPath + '.reps', 0, 1000, true);
        enumValue(set.feel, ['easy', 'steady', 'hard', 'discomfort', 'unsure'], setPath + '.feel', true);
        text(set.notes, setPath + '.notes', 4000); date(set.completedAt, setPath + '.completedAt');
      });
      if (!Array.isArray(session.events) || session.events.length > 3000) add(path + '.events', '事件记录无效');
      else session.events.forEach((event, eventIndex) => {
        const eventPath = path + '.events[' + eventIndex + ']';
        if (!plain(event)) { add(eventPath, '事件必须是对象'); return; }
        id(event.id, eventPath + '.id'); enumValue(event.type, ['replace', 'skip', 'pause', 'resume', 'end', 'correction'], eventPath + '.type');
        date(event.at, eventPath + '.at');
      });
      if (!plain(session.draft)) add(path + '.draft', '未提交草稿无效');
      else { if(own(session.draft,'setType'))enumValue(session.draft.setType,['warmup','working'],path+'.draft.setType');if(own(session.draft,'unit'))enumValue(session.draft.unit,['kg','lb','bodyweight'],path+'.draft.unit');if(own(session.draft,'equipmentConfirmed')&&typeof session.draft.equipmentConfirmed!=='boolean')add(path+'.draft.equipmentConfirmed','须为布尔值');if(own(session.draft,'equipmentLabel'))text(session.draft.equipmentLabel,path+'.draft.equipmentLabel',200); text(session.draft.load, path + '.draft.load', 100, true); text(session.draft.reps, path + '.draft.reps', 100, true); text(session.draft.notes, path + '.draft.notes', 4000); enumValue(session.draft.feel, ['easy', 'steady', 'hard', 'discomfort', 'unsure'], path + '.draft.feel', true); }
      if (!plain(session.rest)) add(path + '.rest', '休息状态无效');
      else {
        number(session.rest.endAt, path + '.rest.endAt', 0, 100000000000000);
        number(session.rest.remainingMs, path + '.rest.remainingMs', 0, 86400000, false, false);
        for(const key of ['nextSeconds','durationSeconds'])if(own(session.rest,key))number(session.rest[key],path+'.rest.'+key,30,600,true,false);
        if (typeof session.rest.paused !== 'boolean' || typeof session.rest.enabled !== 'boolean') add(path + '.rest', '休息开关必须是布尔值');
      }
    });
    if (value.activeSessionId !== null) {
      id(value.activeSessionId, 'state.activeSessionId');
      const active = Array.isArray(value.sessions) && value.sessions.find(session => session.id === value.activeSessionId);
      if (!active || !['active', 'paused'].includes(active.status)) add('state.activeSessionId', '进行中的训练不存在或已结束');
    }
    return errors;
  }

  function parseLegacy(key) {
    const raw = legacyRaw[key];
    if (raw == null) return null;
    try { return JSON.parse(raw); } catch (_) { return raw; }
  }
  function freshState() {
    const fields = {};
    const pendingLegacy = {};
    const legacy = parseLegacy('user_bio_profile');
    for (const key of FIELDS) {
      fields[key] = { value: null, source: 'unknown', updatedAt: null };
      if (plain(legacy) && own(legacy, key) && legacy[key] != null && ['number', 'string', 'boolean'].includes(typeof legacy[key])) {
        fields[key].pendingValue = legacy[key];
        pendingLegacy[key] = legacy[key];
      }
    }
    const abilities = Object.entries(ABILITY_DEFAULTS).map(([key, example]) => {
      const fromLegacy = plain(legacy) && own(legacy, key) && legacy[key] != null;
      return { id: key, kind: key, value: null, pendingValue: fromLegacy ? legacy[key] : example,
        source: fromLegacy ? 'unknown' : 'model-example', confirmed: false, updatedAt: null };
    });
    return { version: VERSION, profile: { fields, abilities, pendingLegacy }, conditions: {},
      plans: [], sessions: [], activeSessionId: null, wizard: { step: 0 }, preferences: {},
      legacyCustomPlan: parseLegacy('bmmd_custom_training_plan_v1') ?? parseLegacy('bmmd_custom_plan') };
  }
  function writeBackup(reason, rawCanonical = null, stable = false) {
    if (!storage) return { ok: false, error: '浏览器本地存储不可用' };
    const payload = { version: VERSION, reason, createdAt: nowISO(), canonicalRaw: rawCanonical, legacyRaw: clone(legacyRaw) };
    const identity = JSON.stringify({ canonicalRaw: rawCanonical, legacyRaw });
    let hash = 2166136261;
    for (let index = 0; index < identity.length; index++) hash = Math.imul(hash ^ identity.charCodeAt(index), 16777619);
    const suffix = stable ? 'load_' + (hash >>> 0).toString(16) : Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
    const key = BACKUP_PREFIX + suffix;
    try {
      if (stable) {
        const previous = storage.getItem(key);
        if (previous !== null) {
          let parsed;
          try { parsed = JSON.parse(previous); } catch (_) { return writeBackup(reason, rawCanonical, false); }
          if (parsed.canonicalRaw === rawCanonical && JSON.stringify(parsed.legacyRaw) === JSON.stringify(legacyRaw)) return { ok: true, error: null, key };
          return writeBackup(reason, rawCanonical, false);
        }
      }
      storage.setItem(key, JSON.stringify(payload));
      if (storage.getItem(key) !== JSON.stringify(payload)) throw new Error('备份写入后未能读回');
      return { ok: true, error: null, key };
    } catch (error) { return { ok: false, error: '无法备份原有数据：' + errorText(error) }; }
  }
  function emit(reason) {
    const detail = { reason, state: clone(state) };
    for (const callback of subscribers) {
      try { callback(clone(state), reason); } catch (error) { console.error(error); }
    }
    if (typeof window.dispatchEvent === 'function' && typeof CustomEvent === 'function') window.dispatchEvent(new CustomEvent('bm:store', { detail }));
  }
  function getSaveStatus() {
    return { savedAt: lastSavedAt, hasData: hasStoredData, unsaved: !!volatileDraft,
      error: lastError, loadError, backupError };
  }
  function notifySave() {
    if (typeof window.dispatchEvent === 'function' && typeof CustomEvent === 'function')
      window.dispatchEvent(new CustomEvent('bm:storage-status', { detail: getSaveStatus() }));
  }
  function commit(next, reason) {
    const errors = validate(next);
    if (errors.length) { lastError = errors.join('\n'); notifySave(); return { ok: false, error: lastError, errors }; }
    const draft = clone(next);
    try {
      if (!storage) throw new Error('浏览器本地存储不可用');
      if (backupError) {
        const backup = writeBackup('retry-before-save', storage.getItem(STORE_KEY), true);
        if (!backup.ok) throw new Error(backup.error);
        backupError = null;
      }
      const serialized = JSON.stringify(draft);
      if (storage.getItem(STORE_KEY) !== lastCanonicalRaw) throw new Error('另一标签页已更新训练记录。请先下载当前备份，再刷新本页，避免覆盖。');
      storage.setItem(STORE_KEY, serialized);
      if (storage.getItem(STORE_KEY) !== serialized) throw new Error('写入后未能读回，数据尚未确认保存');
      lastCanonicalRaw = serialized;
      state = draft;
      volatileDraft = null;
      lastError = null;
      if (reason.startsWith('import-')) loadError = null;
      lastSavedAt = nowISO();
      hasStoredData = true;
      emit(reason);
      notifySave();
      return { ok: true, error: null };
    } catch (error) {
      volatileDraft = draft;
      lastError = '保存失败：' + errorText(error);
      notifySave();
      return { ok: false, error: lastError };
    }
  }
  function transact(callback, options = {}) {
    if (typeof callback !== 'function') return { ok: false, error: '修改必须是同步函数' };
    const base = clone(volatileDraft || state);
    const draft = clone(base);
    try {
      const returned = callback(draft);
      if (returned && typeof returned.then === 'function') return { ok: false, error: '修改不支持异步函数' };
      const result = commit(draft, 'transaction');
      if(!result.ok&&options.onFailure==='base')volatileDraft=base;
      return result;
    } catch (error) { return { ok: false, error: '修改失败：' + errorText(error) }; }
  }
  function getProfile() {
    const result = { sources: {}, pendingLegacy: clone(state.profile.pendingLegacy || {}) };
    for (const [key, field] of Object.entries(state.profile.fields)) { result[key] = field.value; result.sources[key] = field.source; }
    for (const key of Object.keys(ABILITY_DEFAULTS)) { result[key] = null; result.sources[key] = 'unknown'; }
    return result;
  }
  function saveProfile(values) {
    if (!plain(values)) return { ok: false, error: '档案必须是对象' };
    return transact(draft => {
      draft.profile.pendingLegacy ||= {};
      for (const [key, supplied] of Object.entries(values)) {
        if (['sources', 'pendingLegacy', 'abilities'].includes(key)) continue;
        if (!FIELD_KEY.test(key) || UNSAFE_KEYS.has(key)) throw new Error('档案字段无效：' + key);
        if (own(ABILITY_DEFAULTS, key)) {
          if (supplied !== null) throw new Error('个人能力必须单独确认，不能写入身体测量');
          continue;
        }
        const suppliedField = plain(supplied) && own(supplied, 'value') ? supplied : null;
        const fieldValue = suppliedField ? suppliedField.value : supplied;
        if (fieldValue !== null && !['number', 'string', 'boolean'].includes(typeof fieldValue)) throw new Error('档案值必须是可空标量：' + key);
        const source = fieldValue === null ? 'unknown' : (suppliedField?.source || values.sources?.[key] || 'user');
        if (!SOURCES.has(source)) throw new Error('档案来源无效：' + key);
        draft.profile.fields[key] = { value: fieldValue, source, updatedAt: nowISO() };
        delete draft.profile.pendingLegacy[key];
      }
    });
  }
  function exportData() {
    return { format: FORMAT, version: VERSION, exportedAt: nowISO(), state: clone(state),
      legacyRaw: clone(legacyRaw), volatileDraft: volatileDraft ? clone(volatileDraft) : null,
      storage: { loadError, backupError, lastError } };
  }
  function previewImport(input) {
    const errors = [];
    let object = input;
    if (typeof input === 'string') {
      if (utf8Bytes(input) > MAX_IMPORT_BYTES) return { ok: false, errors: ['导入文件超过 32 MiB 解析限制'], summary: null, data: null };
      try { object = JSON.parse(input); } catch (_) { return { ok: false, errors: ['JSON 格式无效'], summary: null, data: null }; }
    }
    let candidate = object, usesDraft = false;
    if (!plain(object)) errors.push('导入内容必须是对象');
    else if (own(object, 'format')) {
      if (object.format !== FORMAT || object.version !== VERSION) errors.push('备份格式或版本不受支持');
      for (const key of Object.keys(object))
        if (!['format', 'version', 'exportedAt', 'state', 'legacyRaw', 'volatileDraft', 'storage'].includes(key) || UNSAFE_KEYS.has(key)) errors.push('备份含未知或不安全字段：' + key);
      if (!validDate(object.exportedAt, true)) errors.push('备份导出日期无效');
      for (const key of ['state', 'legacyRaw', 'volatileDraft']) if (!own(object, key)) errors.push('备份缺少字段：' + key);
      if (!plain(object.legacyRaw) || Object.values(object.legacyRaw).some(value => value !== null && typeof value !== 'string')) errors.push('旧存储快照格式无效');
      else for (const key of Object.keys(object.legacyRaw)) if (!LEGACY_KEYS.includes(key)) errors.push('未知旧存储键：' + key);
      if (object.volatileDraft != null) {
        const draftErrors = validate(object.volatileDraft);
        if (draftErrors.length) errors.push(...draftErrors.map(error => '草稿 ' + error));
        else usesDraft = true;
      }
      candidate = usesDraft ? object.volatileDraft : object.state;
      const stateErrors = validate(object.state);
      errors.push(...stateErrors);
      try { if (utf8Bytes(JSON.stringify(object)) > MAX_IMPORT_BYTES) errors.push('备份超过 32 MiB 解析限制'); } catch (_) { errors.push('备份不可序列化'); }
    }
    if (!errors.length) errors.push(...validate(candidate));
    if (errors.length) return { ok: false, errors: errors.slice(0, 40), summary: null, data: null };
    const data = clone(candidate);
    const confirmedFields = Object.values(data.profile.fields).filter(field => field.value !== null && field.source !== 'unknown' && field.source !== 'model-example').length;
    return { ok: true, errors: [], data, summary: { plans: data.plans.length, sessions: data.sessions.length,
      confirmedFields, pendingFields: Object.keys(data.profile.pendingLegacy || {}).length,
      includesLegacyCustomPlan: data.legacyCustomPlan != null, usesUnsavedDraft: usesDraft } };
  }
  function mergeStates(current, incoming) {
    const merged = clone(current);
    for (const [key, field] of Object.entries(incoming.profile.fields)) {
      const existing = merged.profile.fields[key];
      if (!existing || (existing.value === null && field.value !== null)) merged.profile.fields[key] = clone(field);
    }
    merged.profile.pendingLegacy = { ...(incoming.profile.pendingLegacy || {}), ...(merged.profile.pendingLegacy || {}) };
    for (const [key, field] of Object.entries(merged.profile.fields))
      if (field.value !== null && field.source !== 'unknown' && field.source !== 'model-example') delete merged.profile.pendingLegacy[key];
    for (const key of ['abilities']) {
      const ids = new Set(merged.profile[key].map(entry => entry.id));
      for (const entry of incoming.profile[key]) if (!ids.has(entry.id)) { merged.profile[key].push(clone(entry)); ids.add(entry.id); }
    }
    for (const key of ['plans', 'sessions']) {
      const ids = new Set(merged[key].map(entry => entry.id));
      for (const entry of incoming[key]) if (!ids.has(entry.id)) { merged[key].push(clone(entry)); ids.add(entry.id); }
    }
    merged.conditions = { ...incoming.conditions, ...merged.conditions };
    merged.preferences = { ...incoming.preferences, ...merged.preferences };
    // A fresh destination must also restore a pending recommendation. Existing editing wins on conflict.
    if (!merged.wizard.draftPlan && incoming.wizard.draftPlan) merged.wizard = clone(incoming.wizard);
    if (Array.isArray(incoming.preferences.customActions) && Array.isArray(current.preferences.customActions)) {
      const actions = clone(current.preferences.customActions), ids = new Set(actions.map(a => a.id));
      for (const action of incoming.preferences.customActions) if (!ids.has(action.id)) { actions.push(clone(action)); ids.add(action.id); }
      merged.preferences.customActions = actions;
    }
    if (merged.legacyCustomPlan == null && incoming.legacyCustomPlan != null) merged.legacyCustomPlan = clone(incoming.legacyCustomPlan);
    if (!merged.activeSessionId && incoming.activeSessionId && merged.sessions.some(session => session.id === incoming.activeSessionId && ['active', 'paused'].includes(session.status))) merged.activeSessionId = incoming.activeSessionId;
    return window.BM?.TrainingData?.mergeNumbers(current,incoming,merged)||merged;
  }
  function applyImport(preview, mode) {
    if (!['merge', 'replace'].includes(mode)) return { ok: false, error: '导入方式无效' };
    if (!preview || preview.ok !== true || !preview.data) return { ok: false, error: '请先预览有效的备份' };
    const checked = previewImport(preview.data);
    if (!checked.ok) return { ok: false, error: checked.errors.join('\n') };
    const next = mode === 'replace' ? (window.BM?.TrainingData?.numberSessions(checked.data)||checked.data) : mergeStates(volatileDraft || state, checked.data);
    const errors = validate(next);
    if (errors.length) return { ok: false, error: errors.join('\n'), errors };
    let raw = null;
    try { if (!storage) throw new Error('浏览器本地存储不可用'); raw = storage.getItem(STORE_KEY); }
    catch (error) { return { ok: false, error: '无法读取导入前数据：' + errorText(error) }; }
    const backup = writeBackup('before-import-' + mode, raw);
    if (!backup.ok) { backupError = backup.error; return { ok: false, error: backup.error }; }
    backupError = null;
    const result = commit(next, 'import-' + mode);
    return { ...result, backupKey: backup.key };
  }
  function clearOwnedData(includeLegacy = false) {
    if (!storage) return { ok: false, error: '浏览器本地存储不可用' };
    try {
      if (storage.getItem(STORE_KEY) !== lastCanonicalRaw) throw new Error('另一标签页已更新训练记录，请先刷新核对。');
      const keys = [];
      for (let index = 0; index < storage.length; index++) {
        const key = storage.key(index);
        if (key === STORE_KEY || (typeof key === 'string' && key.startsWith(BACKUP_PREFIX)) || (includeLegacy && LEGACY_KEYS.includes(key))) keys.push(key);
      }
      for (const key of keys) storage.removeItem(key);
      for (const key of keys) if (storage.getItem(key) !== null) throw new Error('部分数据未能清除');
      if (includeLegacy) for (const key of LEGACY_KEYS) legacyRaw[key] = null;
      state = freshState(); volatileDraft = null; lastError = null; backupError = null; lastSavedAt = null; hasStoredData = false; lastCanonicalRaw = null;
      emit('clear');
      notifySave();
      return { ok: true, error: null, removedKeys: keys.length };
    } catch (error) { lastError = '清除失败：' + errorText(error); return { ok: false, error: lastError }; }
  }

  let savedRaw = null;
  try {
    storage = window.BM?.LocalVault ? window.BM.LocalVault.storage : window.localStorage;
    for (const key of LEGACY_KEYS) legacyRaw[key] = storage.getItem(key);
    savedRaw = storage.getItem(STORE_KEY);
    lastCanonicalRaw = savedRaw;
    hasStoredData = savedRaw !== null;
  } catch (error) { loadError = '读取本地数据失败：' + errorText(error); backupError = loadError; }
  if (storage && (savedRaw !== null || Object.values(legacyRaw).some(value => value !== null))) {
    const backup = writeBackup('before-load', savedRaw, true);
    if (!backup.ok) backupError = backup.error;
  }
  state = freshState();
  if (savedRaw !== null) {
    try {
      const parsed = JSON.parse(savedRaw);
      const errors = validate(parsed);
      if (errors.length) throw new Error(errors.join('; '));
      state = clone(parsed);
    } catch (error) { loadError = '已保留原始数据，档案读取失败：' + errorText(error); }
  }
/* Candidate to paste inside beginner-store.js before window.BM.store is frozen.
 * Uses its storage, STORE_KEY, BACKUP_PREFIX, LEGACY_KEYS, MAX_BYTES,
 * utf8Bytes, nowISO and errorText bindings. No operation runs automatically.
 * Expose getStorageUsage/listBackups/exportBackups/pruneBackups on the store API.
 * UTF-16 bytes estimate string storage; they are not the browser's quota.
 * MAX_BYTES is the canonical UTF-8 product limit, not a localStorage quota.
 */
function storageSnapshot() {
  if (!storage) throw new Error('浏览器本地存储不可用');
  const keys = [], seen = new Set();
  for (let i = 0, length = storage.length; i < length; i++) {
    const key = storage.key(i);
    if (typeof key === 'string' && !seen.has(key)) { keys.push(key); seen.add(key); }
  }
  const entries = [];
  for (const key of keys) {
    const raw = storage.getItem(key);
    if (raw !== null) entries.push({ key, raw });
  }
  return entries;
}
function getStorageUsage() {
  try {
    const entries = storageSnapshot();
    const groups = { canonical: [], backups: [], legacy: [], other: [] };
    for (const e of entries) groups[e.key === STORE_KEY ? 'canonical' : e.key.startsWith(BACKUP_PREFIX) ? 'backups' : LEGACY_KEYS.includes(e.key) ? 'legacy' : 'other'].push(e);
    const measure = rows => ({ keyCount: rows.length,
      utf16EstimatedBytes: rows.reduce((sum, e) => sum + 2 * (e.key.length + e.raw.length), 0),
      serializedUtf8Bytes: rows.reduce((sum, e) => sum + utf8Bytes(e.raw), 0) });
    const canonical = measure(groups.canonical);
    return { ok: true, error: null, ...measure(entries),
      owned: measure([...groups.canonical, ...groups.backups, ...groups.legacy]),
      groups: Object.fromEntries(Object.entries(groups).map(([key, rows]) => [key, measure(rows)])),
      safetyLimitBytes: MAX_BYTES, canonicalUtf8Bytes: canonical.serializedUtf8Bytes,
      canonicalAtSafetyLimit: canonical.serializedUtf8Bytes >= MAX_BYTES,
      browserQuotaBytes: null, browserRemainingBytes: null,
      estimateNote: 'UTF-16 字符串占用估计；4 MiB 为训练库产品安全上限，浏览器实际配额与剩余空间未知。' };
  } catch (error) { return { ok: false, error: '无法读取存储占用：' + errorText(error) }; }
}
function backupRows() {
  const rows = storageSnapshot().filter(e => e.key.startsWith(BACKUP_PREFIX)).map((entry, index) => {
    const result = { ...entry, storageIndex: index, version: null, reason: null, createdAt: null,
      valid: false, parseError: null, protected: false, protectionReasons: [],
      utf16EstimatedBytes: 2 * (entry.key.length + entry.raw.length), serializedUtf8Bytes: utf8Bytes(entry.raw) };
    try {
      const p = JSON.parse(entry.raw);
      if (!p || typeof p !== 'object' || Array.isArray(p) || p.version !== 3 || typeof p.reason !== 'string' ||
          typeof p.createdAt !== 'string' || !Number.isFinite(Date.parse(p.createdAt)) ||
          !(p.canonicalRaw === null || typeof p.canonicalRaw === 'string') ||
          !p.legacyRaw || typeof p.legacyRaw !== 'object' || Array.isArray(p.legacyRaw) ||
          Object.keys(p.legacyRaw).some(key => !LEGACY_KEYS.includes(key)) ||
          Object.values(p.legacyRaw).some(raw => raw !== null && typeof raw !== 'string')) throw new Error('备份元数据格式无效');
      result.version = p.version; result.reason = p.reason; result.createdAt = p.createdAt; result.valid = true;
    } catch (error) { result.parseError = errorText(error); }
    return result;
  });
  const protect = (row, reason) => { if (row) { row.protected = true; row.protectionReasons.push(reason); } };
  const chronological = rows.filter(r => r.valid).slice().sort((a, b) => Date.parse(a.createdAt) - Date.parse(b.createdAt) || a.storageIndex - b.storageIndex);
  protect(chronological.find(r => ['before-load', 'retry-before-save'].includes(r.reason)), 'first-migration');
  protect(chronological.filter(r => r.reason.startsWith('before-import-')).at(-1), 'latest-pre-import');
  // Unreadable snapshots are still exact recoverable raw data. Do not discard them.
  for (const row of rows) if (!row.valid) protect(row, 'unreadable-backup');
  if (rows.length && !rows.some(r => r.protected)) protect(chronological.at(-1) || rows[0], 'last-retained-backup');
  return rows;
}
function listBackups() {
  try {
    const rows = backupRows();
    return { ok: true, error: null, backups: rows.map(({ raw, storageIndex, ...metadata }) => metadata) };
  } catch (error) { return { ok: false, error: '无法读取本机备份：' + errorText(error), backups: [] }; }
}
function checkedBackupSelection(ids, rows, allowAll) {
  if (allowAll && ids == null) return rows;
  if (!Array.isArray(ids) || ids.length > 10000 || ids.some(key => typeof key !== 'string' || !key.startsWith(BACKUP_PREFIX)) || new Set(ids).size !== ids.length) throw new Error('请选择不重复的本工具备份键');
  const byKey = new Map(rows.map(row => [row.key, row]));
  return ids.map(key => { const row = byKey.get(key); if (!row) throw new Error('备份不存在或已经变化：' + key); return row; });
}
function exportBackups(ids = null) {
  try {
    const selected = checkedBackupSelection(ids, backupRows(), true);
    return { ok: true, error: null, data: { format: 'bmmd-beginner-backups', version: 3,
      exportedAt: nowISO(), backups: selected.map(({ key, raw }) => ({ key, raw })) },
      exportedKeys: selected.map(row => row.key) };
  } catch (error) { return { ok: false, error: '无法导出本机备份：' + errorText(error), data: null, exportedKeys: [] }; }
}
function pruneBackups(ids, options = {}) {
  const removedKeys = [];
  try {
    if (options.confirmed !== true || options.exported !== true) throw new Error('请先导出选中备份，再明确确认删除');
    const rows = backupRows(), selected = checkedBackupSelection(ids, rows, false);
    if (!selected.length) return { ok: true, error: null, removedKeys };
    if (selected.some(row => row.protected)) throw new Error('首份迁移、最新导入前或无法读取的备份受保护，请保留');
    if (rows.length - selected.length < 1) throw new Error('至少须保留一份本机备份');
    if(!Array.isArray(options.exportedBackups)||options.exportedBackups.length>10000||options.exportedBackups.some(e=>!e||typeof e.key!=='string'||typeof e.raw!=='string'))throw new Error('请先导出选中备份，并保留本次原文导出回执');
    if(selected.some(row=>!options.exportedBackups.some(e=>e.key===row.key&&e.raw===row.raw)))throw new Error('选中备份在导出后新增或已变化，请重新导出');
    if (options.exportedKeys && (!Array.isArray(options.exportedKeys) || selected.some(row => !options.exportedKeys.includes(row.key)))) throw new Error('部分选中备份尚未导出');
    // Check the full selection before touching storage; changed snapshots require a new export.
    for (const row of selected) if (storage.getItem(row.key) !== row.raw) throw new Error('备份已经变化，请重新导出后再删除');
    for (const row of selected) {
      storage.removeItem(row.key);
      if (storage.getItem(row.key) !== null) throw new Error('备份未能确认删除：' + row.key);
      removedKeys.push(row.key);
    }
    return { ok: true, error: null, removedKeys };
  } catch (error) { return { ok: false, error: '删除备份失败：' + errorText(error), removedKeys }; }
}

  window.BM ||= {};
  window.BM.store = Object.freeze({
    version: VERSION, key: STORE_KEY, getSaveStatus,
    getState: () => clone(state),
    getDraft: () => volatileDraft ? clone(volatileDraft) : null,
    hasUnsavedDraft: () => !!volatileDraft,
    getActiveSession: () => { const st=volatileDraft||state;return clone(st.sessions.find(x=>x.id===st.activeSessionId)||null); },
    getRest: () => { const st=volatileDraft||state;return clone(st.sessions.find(x=>x.id===st.activeSessionId)?.rest||null); }, transact, getProfile, saveProfile,
    getLegacy: key => LEGACY_KEYS.includes(key) ? clone(parseLegacy(key)) : null,
    exportData, previewImport, applyImport, clearOwnedData, getStorageUsage, listBackups, exportBackups, pruneBackups,
    subscribe: callback => {
      if (typeof callback !== 'function') throw new TypeError('订阅者必须是函数');
      subscribers.add(callback); return () => subscribers.delete(callback);
    }
  });
})();
