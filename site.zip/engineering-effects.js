/* Decorative integration for the independent engineering workspace.
 * Original model state, inputs, canvas gestures and experiment data stay owned
 * by mechanics-lab.js. No records, readouts or simulation values are rewritten. */
(() => {
  'use strict';
  const B = window.BM = window.BM || {};
  const media = matchMedia('(prefers-reduced-motion: reduce)');
  const fine = matchMedia('(hover:hover) and (pointer:fine)');
  const reduced = () => media.matches || document.documentElement.classList.contains('pd-reduced');
  const clamp = value => Math.max(0, Math.min(1, value));
  let root = null, shellObserver = null, panelObserver = null, groupObserver = null;
  let visibility = null, resize = null, queued = 0, pointerFrame = 0, scrollFrame = 0;
  let groups = [], decorations = [], panels = [], progress = null, pointer = null, pointerPanel = null;
  const seen = new WeakSet(), animations = new Set(), feedback = new WeakMap();
  const active = () => root && !root.hidden && !document.hidden && !reduced();
  function decorate(parent, name) {
    const node = document.createElement('span'); node.className = name; node.setAttribute('aria-hidden', 'true'); parent.append(node); decorations.push(node); return node;
  }
  function animate(element, frames, options) {
    if (!active() || !element?.animate) return;
    const animation = element.animate(frames, options); animations.add(animation);
    animation.finished.catch(() => {}).finally(() => animations.delete(animation)); return animation;
  }
  function clear() {
    panelObserver?.disconnect(); groupObserver?.disconnect(); visibility?.disconnect(); resize?.disconnect();
    cancelAnimationFrame(pointerFrame); cancelAnimationFrame(scrollFrame); pointerFrame = scrollFrame = 0;
    animations.forEach(animation => animation.cancel()); animations.clear();
    decorations.forEach(node => node.remove()); decorations = [];
    groups.forEach(({ host }) => host.classList.remove('eng-fx-group')); groups = [];
    panels.forEach(panel => { panel.style.removeProperty('--eng-fx-presence'); panel.classList.remove('eng-fx-offscreen'); }); panels = [];
    pointer = pointerPanel = null; progress = null;
  }
  function sync() {
    if (!root) return;
    root.dataset.engFxReduced = String(reduced());
    root.dataset.engFxPaused = String(!active());
    if (!active()) {
      animations.forEach(animation => animation.cancel()); animations.clear();
      panels.forEach(panel => panel.style.removeProperty('--eng-fx-presence'));
    }
    updateGroups(reduced()); updateProgress();
  }
  function updateGroups(instant = false) {
    for (const { host, marker } of groups) {
      const selected = host.querySelector('button[aria-pressed="true"],button[aria-selected="true"]');
      if (!selected || !selected.getClientRects().length) { marker.style.setProperty('--eng-fx-show', '0'); continue; }
      if (instant) marker.style.transition = 'none';
      marker.style.setProperty('--eng-fx-x', selected.offsetLeft + 'px');
      marker.style.setProperty('--eng-fx-y', selected.offsetTop + 'px');
      marker.style.setProperty('--eng-fx-w', selected.offsetWidth + 'px');
      marker.style.setProperty('--eng-fx-h', selected.offsetHeight + 'px');
      marker.style.setProperty('--eng-fx-show', '1');
      if (instant) { marker.getBoundingClientRect(); marker.style.removeProperty('transition'); }
    }
  }
  function range(input) {
    const min = Number(input.min || 0), max = Number(input.max || 100), value = Number(input.value);
    input.style.setProperty('--eng-fx-fill', (100 * clamp((value - min) / (max - min || 1))).toFixed(2) + '%');
  }
  function updateProgress() {
    scrollFrame = 0;
    if (!root || root.hidden || !progress) return;
    const distance = root.scrollHeight - root.clientHeight;
    progress.style.setProperty('--eng-fx-progress', String(distance > 1 ? clamp(root.scrollTop / distance) : 0));
  }
  function scroll() {
    if (!scrollFrame) scrollFrame = requestAnimationFrame(updateProgress);
    if (pointerPanel) pointerPanel.style.removeProperty('--eng-fx-presence');
    pointerPanel = null;
  }
  function paintPointer() {
    pointerFrame = 0;
    if (!active() || !pointer || !fine.matches) return;
    const panel = pointer.target.closest('.eng-models>button,.eng-parameters,.did-lab-intro,.eng-panel');
    if (pointerPanel !== panel) { pointerPanel?.style.removeProperty('--eng-fx-presence'); pointerPanel = panel; }
    if (!panel) return;
    const rect = panel.getBoundingClientRect();
    panel.style.setProperty('--eng-fx-px', (pointer.clientX - rect.left).toFixed(1) + 'px');
    panel.style.setProperty('--eng-fx-py', (pointer.clientY - rect.top).toFixed(1) + 'px');
    panel.style.setProperty('--eng-fx-presence', '1');
  }
  function enter(panel) {
    if (seen.has(panel)) return;
    seen.add(panel);
    // Fade the panel only: never move/scale a canvas, parameter or plotted target.
    animate(panel, [{ opacity: .35 }, { opacity: 1 }], { duration: 600, easing: 'cubic-bezier(.16,1,.3,1)' });
  }
  function prepare() {
    queued = 0; clear();
    if (!root || root.hidden) { sync(); return; }
    groups = [...root.querySelectorAll('.eng-models,.did-layers,.eng-segment,.eng-tabs')].map(host => {
      host.classList.add('eng-fx-group'); return { host, marker: decorate(host, 'eng-fx-indicator') };
    });
    panels = [...root.querySelectorAll('.eng-models>button,.did-lab-intro,.eng-stage,.eng-parameters,.eng-position,.did-results,.eng-panel')];
    panels.filter(panel => panel.matches('.eng-models>button,.did-lab-intro,.eng-parameters,.eng-panel')).forEach(panel => decorate(panel, 'eng-fx-spot'));
    panels.filter(panel => panel.matches('.eng-stage,.eng-parameters,.eng-panel')).forEach(panel => { const border = decorate(panel, 'eng-fx-border'); border.append(document.createElement('i'), document.createElement('i')); });
    progress = decorate(root, 'eng-fx-progress');
    root.querySelectorAll('input[type=range]').forEach(range);
    visibility = new IntersectionObserver(entries => {
      entries.forEach(item => { item.target.classList.toggle('eng-fx-offscreen', !item.isIntersecting); if (item.isIntersecting) enter(item.target); });
    }, { root, threshold: .03, rootMargin: '0px 0px 40px 0px' });
    panels.forEach(panel => visibility.observe(panel));
    updateGroups(true);
    resize = new ResizeObserver(() => { updateGroups(true); updateProgress(); });
    groups.forEach(({ host }) => resize.observe(host));
    const selected = new MutationObserver(() => updateGroups()); groupObserver = selected;
    groups.forEach(({ host }) => selected.observe(host, { attributes: true, subtree: true, attributeFilter: ['aria-pressed', 'aria-selected'] }));
    const panel = root.querySelector('.eng-panel');
    if (panel) {
      panelObserver = new MutationObserver(records => {
        if (records.some(record => [...record.addedNodes, ...record.removedNodes].some(node => node.nodeType === 1 && !node.classList.contains('eng-fx-border') && !node.classList.contains('eng-fx-spot')))) {
          seen.delete(panel); schedule();
        }
      });
      panelObserver.observe(panel, { childList: true });
    }
    root.dataset.engFx = 'cosmic-panels ambient-glow border-beam spotlight selection-glide input-feedback';
    sync();
  }
  function schedule() { if (!queued) queued = requestAnimationFrame(prepare); }
  function connect() {
    const next = document.getElementById('engineering-root'); if (!next || next === root) return;
    shellObserver?.disconnect(); clear(); root = next;
    shellObserver = new MutationObserver(records => {
      if (records.some(record => record.type === 'childList' && [...record.addedNodes].some(node => node.nodeType === 1 && node.classList.contains('eng-shell')))) schedule();
      else if (records.some(record => record.type === 'attributes' && record.attributeName === 'hidden')) schedule();
      else if (records.some(record => record.attributeName === 'data-medium')) {
        animate(root.querySelector('.eng-stage-content'), [{ opacity: .35 }, { opacity: 1 }], { duration: 350, easing: 'ease-out' });
      }
    });
    shellObserver.observe(root, { childList: true, attributes: true, attributeFilter: ['hidden', 'data-medium'] });
    root.addEventListener('scroll', scroll, { passive: true });
    root.addEventListener('pointermove', event => {
      if (!active() || !fine.matches || event.pointerType === 'touch' || event.buttons) return;
      pointer = event; if (!pointerFrame) pointerFrame = requestAnimationFrame(paintPointer);
    }, { passive: true });
    root.addEventListener('pointerleave', () => { pointerPanel?.style.removeProperty('--eng-fx-presence'); pointerPanel = null; pointer = null; });
    root.addEventListener('input', event => {
      const input = event.target;
      if (!input.matches('input[type=range],input[type=number],select')) return;
      const field = input.closest('.eng-field,.eng-position,.eng-controls');
      (field || root).querySelectorAll('input[type=range]').forEach(range);
      if (!field || !active()) return;
      feedback.get(field)?.cancel();
      const effect = animate(field, [{ boxShadow: '0 0 0 1px #9fc4ff80,0 0 26px #7b9cff28' }, { boxShadow: '0 0 0 1px #9fc4ff00,0 0 26px #7b9cff00' }], { duration: 600, easing: 'ease-out' });
      if (effect) feedback.set(field, effect);
    }, { passive: true });
    root.addEventListener('click', () => requestAnimationFrame(() => { if (!root.hidden) root.querySelectorAll('input[type=range]').forEach(range); }));
    schedule();
  }
  new MutationObserver(connect).observe(document.body, { childList: true });
  new MutationObserver(sync).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
  media.addEventListener('change', sync); document.addEventListener('visibilitychange', sync);
  document.addEventListener('bm:language-change', () => requestAnimationFrame(updateGroups));
  window.addEventListener('pagehide', () => { cancelAnimationFrame(queued); queued = 0; clear(); });
  window.addEventListener('pageshow', schedule);
  B.EngineeringAppearance = { refresh: schedule };
  connect();
})();
