/* Original course prose layered on the retained, sourced action catalog. All copy is bilingual. */
(function(){'use strict';const B=window.BM;const specifications={
arm:{type:'lateral',intro:['站在低位滑轮旁，把上臂向侧面抬起。握把、钢索与滑轮的位置一起决定外力方向；本课演示双侧，单侧站位须按正文另行确认。','Stand beside a low pulley and raise the upper arm sideways. Handle, rope and pulley positions determine external force direction. The model demonstrates both sides; consult the text for single-side setup.'],muscles:['三角肌中束参与抬臂，肩胛周围肌群协同，躯干与下肢维持站姿；画面不估算各肌肉的分力。','The middle deltoid contributes to arm elevation, scapular muscles coordinate and the trunk and legs stabilize. Individual muscle forces are not estimated.'],chain:['手握低位附件 → 钢索经过可调滑轮 → 配重塔被抬升。机架不动；握把、钢索和配重运动。厂家标示2:1指这一器械的传动关系，不是用户能力换算。','Hand on low attachment → rope through an adjustable pulley → rising weight stack. The frame stays still while handle, rope and stack move. The manufacturer’s 2:1 ratio describes transmission, not personal strength.'],look:['观察肘部保留起始的微弯，肩部不随每次抬臂耸起，双脚不左右移位。看钢索拉向滑轮，而不是默认永远竖直。','Watch for a consistent slight elbow bend, no repeated shoulder shrug and stable feet. The rope pulls toward its pulley, not necessarily vertically.'],change:['身体侧摆、屈肘角度明显变化','Side sway or changing elbow bend'],effect:['肩到握把的几何关系随之改变，不能再把同一配重当作同一路径的重复。先减轻负荷并核对站位、肘角与滑轮锁销。','The shoulder-to-handle geometry changes, so the same stack is no longer a repeat of the same path. Reduce load and recheck stance, elbow bend and the pulley pin.'],question:['为什么抬到肩高之前，拉力方向已经变了？','Why does cable direction change before shoulder height?'],physics:['张力沿当前钢索。外力矩是τ=r×F，取决于作用点位置与钢索方向的夹角；张力可以近似不变，力矩仍变化。','Tension follows the current cable line. External torque τ=r×F depends on both application point and cable angle; torque may change while tension stays approximately constant.'],study:'shoulder',experiments:['direction','lever','pulley'],quiz:['只看配重塔数字，能确定肩部外力矩吗？','Does a stack number alone determine external shoulder torque?'],answer:['不能，还需要作用点、钢索方向和肩部相对位置。','No. The application point, cable direction and shoulder position also matter.']},
cam:{type:'extension',intro:['坐在靠背上，通过伸膝让小腿向前抬起。小腿垫把器械阻力传到小腿；它不是对人体动作的实时检测。','Sit against the backrest and extend the knees to move the lower legs forward. Shin pads transmit machine resistance to the lower legs. This is a teaching model, not live posture detection.'],muscles:['股四头肌负责伸膝，其中股直肌还跨过髋关节；躯干靠垫、双手和骨盆帮助保持坐姿。不能把器械轴力矩直接视为某一条肌肉的力量。','The quadriceps extend the knee; rectus femoris also crosses the hip. Backrest, hands and pelvis help maintain sitting. Machine shaft torque is not an individual muscle force.'],chain:['小腿压住滚垫 → 工作臂绕固定轴转动 → 凸轮与钢索传递负荷 → 配重上升。靠背和机架提供支撑，滚垫跟随工作臂运动。','Shin against roller → work arm rotates around its fixed axis → cam and rope transmit load → stack rises. Backrest and frame support the body while pads travel with the arm.'],look:['从侧面先找膝盖和器械转轴，再看滚垫是否在脚踝上方。发力时骨盆留在坐垫上，回程让小腿回到起始位置而不让配重砸落。','From the side, locate knee and machine axis, then check that pads contact above the ankle. Keep the pelvis seated and control the return without dropping the stack.'],change:['膝的位置离开器械轴线','Knee moves away from the machine axis'],effect:['人体和机器绕不同的中心转动，滚垫相对小腿的接触路径会改变。对照模式只后移骨盆，展示几何差异；不计算受伤概率。停下后按OP-LE资料调靠背并重新核对。','Body and machine rotate about different centers, changing pad contact along the shin. The comparison shifts the pelvis to show geometry, without injury prediction. Stop and recheck the backrest according to OP-LE instructions.'],question:['为什么同一配重，在不同伸膝位置的阻力矩会变？','Why can the same stack produce different torque through extension?'],physics:['配重对钢索给出近似张力，轴到钢索作用线的垂距决定器械轴力矩。实验的d(θ)是有效力臂，尚不是OP-LE实测凸轮轮廓；人体膝力矩还需要接触点与人体模型。','Approximate cable tension acts at a perpendicular distance from the shaft. That distance sets machine torque. Experimental d(θ) is an effective arm, not a measured OP-LE cam contour; knee torque additionally needs contact and human geometry.'],study:'extension',experiments:['lever','cam','work','calculus','uncertainty','design'],quiz:['d(θ)变大，是否等于凸轮外轮廓半径必然变大？','Does a larger d(θ) necessarily mean a larger contour radius?'],answer:['不是。d是到钢索作用线的垂距，外形还受接触与切线几何约束。','No. d is distance to the cable line; the outline also depends on contact and tangent geometry.']},
incline:{type:'press-leg',intro:['背臀靠住垫面，用脚推着滑车沿斜轨移动。开始和结束都要认识承重挂钩与保险把手；本课不模拟自动解锁。','Support back and pelvis and push the carriage along inclined rails. Know the loading hooks and safety handles before entry and exit. The model does not simulate automatic unlocking.'],muscles:['膝伸展与髋伸展由股四头肌、臀部等共同参与；背垫和骨盆接触关系约束动作范围，不能只根据滑车位移判断人体深度。','Quadriceps and hip extensors share knee and hip extension. Backrest and pelvic contact constrain range; carriage position alone does not determine human depth.'],chain:['脚掌 → 脚踏和滑车 → 沿45°导轨抬升挂片与滑车。导轨和机架不动，滑车和挂片一起移动；两边装片质量和空车质量共同影响负载。','Feet → plate and carriage → loaded carriage rises along 45° rails. Rails stay fixed; carriage and working plates move. Both plate mass and carriage tare contribute.'],look:['侧面观察臀部和背垫接触，正面观察膝盖随脚尖方向移动。回程深度以能维持接触和控制为前提，不用页面角度替代现场调节。','From the side, watch pelvis/back contact; from the front, watch knees follow the toes. Return only as far as contact and control allow. Screen angles do not replace on-site setup.'],change:['下放时骨盆离垫或借身体摆动','Pelvis lifting off support or body sway during descent'],effect:['支撑点改变后，躯干与髋的相对运动不再与原示范一致。先缩小行程并重查靠背、保险和脚位；本模型未求解腰椎载荷。','Changing support alters trunk–hip motion. Reduce range and recheck backrest, safety and foot placement. Lumbar loading is not solved.'],question:['挂片相同，斜面和摩擦为什么还会改变推力？','Why do slope and friction matter with the same plates?'],physics:['重力沿轨道只有mg sinβ，支持力近似mg cosβ；运动摩擦沿轨道反向。上行与下行的所需外力不同。静止需要单独的静摩擦平衡，不能套用滑动公式。','Along-track gravity is mg sinβ and normal force is approximately mg cosβ. Kinetic friction opposes motion, making upward and downward force different. Rest requires a separate static-friction model.'],study:'general',experiments:['incline','work','power','uncertainty'],quiz:['45°轨道上的沿坡重力等于全部mg吗？','Is along-track gravity equal to all of mg at 45°?'],answer:['不等于，是mg sin45°；滑车质量和摩擦仍需另计。','No. It is mg sin45°. Carriage mass and friction also matter.']},
pec:{type:'fly',intro:['本课选择OP-FLY的胸飞鸟变式：背靠垫，双手从两侧向前合拢。后束变式是面朝垫向外打开，不能沿用胸飞鸟的人体朝向。','This lesson uses the OP-FLY chest-fly variation: back against the pad, hands moving inward from the sides. The rear-deltoid variation faces the pad and opens outward; it needs a different body orientation.'],muscles:['胸大肌参与上臂向身体前方合拢，三角肌前束协同；肘部微弯和躯干稳定帮助保持接触路径。','Pectoralis major contributes to bringing upper arms together, with anterior-deltoid assistance. A consistent elbow bend and stable trunk maintain the path.'],chain:['握把 → 左右转臂 → 各自凸轮与钢索 → 配重塔。机架固定，握把随转臂走圆弧；铰接式握把允许局部转向，不代表可任意改变转轴。','Grips → paired arms → their cams and ropes → stack. The frame stays fixed and arms follow arcs. Pivoting grips allow local hand orientation, not arbitrary machine-axis changes.'],look:['看手肘是否保持相近弯曲，肩背是否仍贴靠垫。双手接近时停在可控制的位置，不用撞击握把证明完成。','Watch elbow bend and shoulder/back contact. Stop at a controlled near-closed position rather than striking the grips together.'],change:['躯干前倾追逐握把','Leaning forward after the grips'],effect:['肩相对机器的位置改变，手和转臂的路径不再围绕同一稳定支撑。重查座椅和起始张开程度，减小无法控制的范围。','Shoulders shift relative to the machine. Recheck seat and starting opening and reduce uncontrolled range.'],question:['为什么机器轴的阻力不能直接等于肩部肌肉力？','Why is machine-axis resistance not shoulder muscle force?'],physics:['机器通过转臂、凸轮和接触点传力；肩与机器轴并不重合。需要分别对机器和人体画研究对象，才能讨论各自的力矩。','Arms, cams and contact points transmit load. Shoulder and machine axes differ. Analyze machine and body as separate objects before discussing their torques.'],study:'press',experiments:['lever','cam','work'],quiz:['胸飞鸟和后束能只切换名字而保留同一人体朝向吗？','Can fly and rear-deltoid lessons share the same body orientation?'],answer:['不能。接触靠垫的一面和工作方向不同。','No. Support contact and working direction differ.']},
lat:{type:'pulldown',intro:['OP-PD通过固定转臂下拉长握把。它与自由钢索横杆不同；本型号压腿垫固定，不能把通用下拉调节项直接套上来。','OP-PD pulls long grips on fixed rotating arms, unlike a freely moving cable bar. Its thigh pad is fixed; generic adjustable-pad instructions do not apply.'],muscles:['背阔肌与肩周肌群参与上臂下收，屈肘肌群辅助拉动；大腿、座椅和双脚稳定身体。','Latissimus and shoulder muscles contribute to arm lowering, assisted by elbow flexors. Thigh contact, seat and feet stabilize the body.'],chain:['双手 → 固定转臂 → 轴侧凸轮 → 钢索和配重。长握把绕机器轴走弧线，压腿垫与机架保持固定。','Hands → rotating arm → shaft cam → rope and stack. Long grips follow the machine arc; thigh pad and frame remain fixed.'],look:['按本型号说明，握稳后坐入，让大腿处于固定垫下；躯干略从髋部前倾。看握把到约肩高后停止，不套用自由横杆必须拉到胸口的终点。','Grip before sitting, with thighs under the fixed pad and a slight forward hinge as instructed for this model. Stop around shoulder-height grips rather than imposing a free-bar chest-touch endpoint.'],change:['用躯干后摆带动固定转臂','Swinging the trunk backward to drive the arm'],effect:['肩和握把的相对关系改变，机器运动混入躯干移动。先降低负荷，重查坐入位置和固定垫接触。','Shoulder–grip geometry changes and trunk motion contributes. Reduce load and recheck seat and thigh-pad contact.'],question:['钢索张力与长握把受到的力为什么不同？','Why do cable tension and long-handle force differ?'],physics:['在同一根机器轴上平衡T·d与Fhandle·L，得到Fhandle=T·d/L。这里T接近mg只是理想条件；人体肩力矩还需要另一套作用点几何。','On the machine shaft, T·d balances Fhandle·L, giving Fhandle=T·d/L. T≈mg is idealized; shoulder torque needs separate body geometry.'],study:'pull',experiments:['lever','cam','work'],quiz:['看到配重质量就能直接得到握把力吗？','Does mass alone give handle force?'],answer:['不能，还要知道机器轴上的有效力臂与握把臂长。','No. Shaft moment arm and handle lever length are also needed.']},
'barbell-squat':{type:'squat',intro:['自由杠铃随人体一起上下，力量架用于起落杠和保护，不替人体规定轨迹。它不是所有初学者都必须采用的起步动作。','A free bar moves with the body. The rack supports entry, reracking and protection, not a fixed lifting path. It is not a mandatory starting exercise for every novice.'],muscles:['膝和髋伸肌共同起身，躯干肌群维持杠与身体的相对关系；脚掌支撑把反作用力传回身体。','Knee and hip extensors raise the body while trunk muscles stabilize the bar–body relation. Feet transmit ground reaction.'],chain:['脚掌与地面 → 膝髋和躯干 → 上背接触杠铃。出架后杠铃不再由J杯承重，机架不作为运动导轨。','Ground and feet → knees, hips and trunk → bar on the upper back. After unracking, J-cups no longer carry the bar and the rack is not a rail.'],look:['侧面看脚掌是否持续接地、杠与上背是否保持接触。下降范围按控制能力和保护装置确认；不把不同人的膝前移或躯干角度都判成错误。','From the side, check foot contact and bar contact on the upper back. Choose depth with control and safety setup; knee travel and trunk angle vary across bodies.'],change:['起身时骨盆偏向一侧','Pelvis shifting sideways during ascent'],effect:['左右支撑和负荷路径发生改变。对照只展示位置变化，没有由此推出伤害概率；重新检查站位、负荷与保护配置。','Left–right support and load path change. The comparison shows position, not injury probability. Recheck stance, load and safety setup.'],question:['同一杠铃高度能唯一决定膝关节力矩吗？','Does one bar height uniquely determine knee torque?'],physics:['还需要身体质量分布、膝髋位置、地面反作用与加速度。课程只呈现规定姿态，不用一个手柄或杠铃力替代全身逆动力学。','Body mass distribution, joint positions, ground reaction and acceleration are also needed. The lesson shows prescribed poses, not whole-body inverse dynamics.'],study:'general',experiments:['lever','work','kinematics','uncertainty'],quiz:['机架保护杆是否决定人体的唯一深蹲轨迹？','Do rack safeties define one mandatory squat path?'],answer:['不决定。保护装置限制意外下落，不能替代动作与站位控制。','No. Safeties limit an unintended fall; they do not control stance or technique.']},
'cable-row':{type:'row',intro:['OP-RW的自调节握把随低位转臂后拉；脚踏提供稳定接触。这是坐姿器械划船，不是把一条自由钢索路径任意移到身边。','OP-RW self-aligning grips travel with a low-pivot row arm. Footplates stabilize the body. This is a guided seated row, not an arbitrary free-cable path.'],muscles:['背阔肌、菱形肌与斜方肌等参与上臂后移和肩胛控制，肘屈肌辅助；双腿与躯干维持坐姿。','Latissimus, rhomboids and trapezius contribute to arm pull and scapular control; elbow flexors assist, while legs and trunk stabilize.'],chain:['手 → 自调节握把 → 低位转臂与拉索连接点 → 导轮 → 配重。脚踏和机架固定，握把与转臂运动。','Hand → self-aligning grips → low-pivot arm/cable attachment → pulleys → stack. Footplates and frame are fixed.'],look:['双脚压住斜面脚踏，膝微弯；观察手肘向后时胸部不大幅后仰。返回时手臂伸出去，身体不被配重拉离坐垫。','Press into the angled footplates with slight knee bend. Elbows move back without large trunk lean. Reach forward on return without being pulled from the seat.'],change:['后拉时胸部跟着后仰','Leaning the chest backward during the pull'],effect:['握把的位移混入躯干后移，目标路径的控制发生变化。降低负荷，先核对脚踏接触和起始伸臂位置。','Handle travel now includes trunk displacement. Reduce load and recheck foot contact and starting reach.'],question:['为什么配重上升距离不等于握把走过的圆弧长度？','Why may stack rise differ from the grip’s arc length?'],physics:['拉索连接在转臂的特定位置，绳长变化由该点到导轮的距离变化决定。握把圆弧和钢索行程是两个不同坐标。','The cable attaches at a particular arm point. Rope-length change depends on that point’s distance to the pulley; grip arc and cable travel are different coordinates.'],study:'pull',experiments:['direction','pulley','work'],quiz:['自调节握把意味着机架转轴可以随意改变吗？','Do self-aligning grips imply an adjustable machine pivot?'],answer:['不意味着。握把局部转向与固定转轴是不同部件。','No. Local grip orientation and machine pivot location are distinct.']},
'barbell-bench':{type:'bench',intro:['平躺在O-FB固定卧推凳上，让自由杠铃从受控低点推起。机架只承担起落杠；需要根据现场保护方式安排协助。','Lie on the fixed O-FB bench and press a free bar from a controlled low point. The rack supports unracking/reracking; use the appropriate on-site protection or assistance.'],muscles:['胸大肌、三角肌前束与肱三头肌共同推起杠铃，背部、骨盆与双脚提供支撑。','Pectoralis major, anterior deltoid and triceps share the press; upper back, pelvis and feet provide support.'],chain:['双手接触杠铃 → 肘肩协同推起 → 杠铃重力持续向下。躺板与机架固定；杠铃脱离支架后不受器械导轨约束。','Hands on bar → elbow/shoulder press → gravity remains downward. Bench and rack stay fixed; the unracked bar is not rail-guided.'],look:['看双手握距、手腕与前臂的关系，以及背部、臀部、双脚是否维持原接触。返回到可控制位置，结束后确认两端落入挂点才放手。','Watch grip width, wrist–forearm relation and stable back/pelvis/foot contact. Lower under control; confirm both ends are racked before letting go.'],change:['推举时躯干失去原来的支撑','Losing the original body supports during pressing'],effect:['身体对杠铃的相对位置改变；不能把移动幅度减小等同于能力提高。先核对保护与握持，再调整负荷。','Body position relative to the bar changes. A shorter displacement is not automatically improved capacity. Recheck protection and grip before changing load.'],question:['杠铃重力方向不变，肩部外力矩为何仍会变？','Why can shoulder torque change while bar gravity remains vertical?'],physics:['肩到杠铃重力作用线的垂直距离随路径改变。本站不从一条杠铃轨迹计算肌肉力、胸肌增长或损伤风险。','Perpendicular distance from shoulder to the bar’s gravity line changes through the path. Bar trajectory alone does not give muscle forces, hypertrophy or injury risk.'],study:'press',experiments:['lever','work','power','kinematics'],quiz:['躺板是水平的，肩部力臂也固定吗？','Does a horizontal bench imply a constant shoulder moment arm?'],answer:['不是，杠铃与关节的相对位置仍在变化。','No. Bar and joint positions still change relative to each other.']},
'flat-press':{type:'chest-press',intro:['坐姿OP-CP推胸由固定转臂引导握把。先用座椅让身体与握把起点相配，再沿机器路径推出。','The seated OP-CP guides grips on fixed arms. Use the seat to match body and starting grips, then follow the machine path.'],muscles:['胸大肌、三角肌前束和肱三头肌共同参与，靠背和双脚减少身体整体移动。','Pectoralis major, anterior deltoid and triceps contribute; backrest and feet reduce whole-body movement.'],chain:['手 → 双位置握把 → 低位转臂 → 凸轮钢索 → 配重。靠背与主转轴固定，座椅高度是独立调节。','Hands → dual-position grips → low-pivot arms → cam/cable → stack. Backrest and main axis are fixed; seat height is separately adjustable.'],look:['肩背留在靠垫上，手腕不在推出时突然折弯。比较座椅高低时，看握把相对胸部的位置，而不是追求一个通用百分比。','Keep shoulders and back supported and avoid abrupt wrist bend. When changing seat height, watch grip position relative to the chest rather than targeting a generic percentage.'],change:['为了够到握把而前伸躯干','Reaching the trunk forward after the grips'],effect:['靠背支撑减弱，肩与转臂的相对几何改变。停下后重新设置座椅和起始握持。','Backrest support decreases and shoulder-to-arm geometry changes. Stop and reset seat and starting grip.'],question:['座椅升高改变了什么，没有改变什么？','What does a higher seat change, and what stays fixed?'],physics:['身体接触点相对握把改变，机器轴与凸轮传动没有因此变成另一套结构。实物调节和实验中的有效力臂参数分开。','Body contact changes relative to grips while machine axis and cam transmission remain. Physical setup and experimental effective-arm parameters are separate.'],study:'press',experiments:['lever','cam','work'],quiz:['座椅更高是否必然更轻松？','Is a higher seat necessarily easier?'],answer:['不能这样判断；还要看身体比例、接触和路径，示例不处方个人档位。','No. Proportions, contact and path matter; examples do not prescribe a personal setting.']},
'incline-press':{type:'incline-press',intro:['IL-IP的左右工作臂独立上推，靠背提供上斜支撑；每侧挂片的记录口径要与双侧合计分开。','The IL-IP has independent upward-press arms and an inclined backrest. Per-side plate records must be distinguished from bilateral totals.'],muscles:['胸大肌、三角肌前束和肱三头肌参与上斜推举；躯干和双脚保持身体支撑。','Pectoralis major, anterior deltoid and triceps contribute to the inclined press, while trunk and feet maintain support.'],chain:['手 → 左右独立握把与转臂 → 各侧装片轴。阻力来源是挂片重力及机器结构，左右可以分别运动。','Hands → independent grips/arms → each arm’s plate horn. Plate gravity and machine geometry supply resistance; each side can move independently.'],look:['看双侧握把各自的路径、背臀接触和手肘伸展。完成一侧不代表另一侧已经完成，训练记录应保留侧别口径。','Watch each grip path, back/pelvis contact and elbow extension. One side finishing does not complete the other; preserve side-specific recording.'],change:['一侧推到终点，另一侧突然落回','One side finishing while the other drops'],effect:['两侧独立负荷没有被同时控制。先降低负荷，分别确认能平稳返回；独立结构不意味着两侧能力相同。','The independent loads are not both controlled. Reduce load and verify each return; independent arms do not imply equal capacity.'],question:['挂片质量相同，转臂的阻力矩会恒定吗？','Do equal plates give constant arm torque?'],physics:['重力始终向下，装片轴相对转轴的位置随运动改变，重力作用线的垂距也改变。不是所有挂片机都能按mg直接当握把力。','Gravity stays downward while plate-horn position changes, altering its perpendicular moment arm. Plate mass times g is not generally grip force.'],study:'press',experiments:['lever','work','uncertainty'],quiz:['每侧20 kg和双侧合计20 kg可以合成同一记录吗？','Can 20 kg per side and 20 kg total be one record?'],answer:['不能；侧别和重量口径不同。','No. Side and load basis differ.']},
'cable-fly':{type:'standing-fly',intro:['站在双塔滑轮前，双手沿可控制的弧线合拢。左右钢索各有配重来源，站位和滑轮高度决定每侧拉力方向。','Stand in front of dual pulleys and bring the hands together along controlled arcs. Each side has its own stack; stance and pulley height set cable direction.'],muscles:['胸大肌参与上臂合拢，肩前侧协同，躯干和下肢维持站姿。肘微弯不等于肘角绝对不能有任何自然变化。','Pectoralis major contributes to arm adduction with anterior-shoulder assistance; trunk and legs stabilize. A slight elbow bend is not a demand for perfectly rigid joints.'],chain:['双手握附件 → 左右钢索分别经过可调滑轮 → 各自配重。机架固定；手可以走自由路径，但钢索始终指向对应出绳轮。','Hands on attachments → separate ropes through adjustable pulleys → separate stacks. The frame is fixed and hand paths are free, while each rope points to its pulley.'],look:['先看两侧滑轮锁住，再看合拢与返回时躯干不前后追逐握把。手腕、肘与钢索关系比界面里一个归一化角度更有解释力。','Check both pulley locks, then watch the trunk stay stable through closing and return. Wrist/elbow/cable relations explain more than an unexplained normalized angle.'],change:['合拢时身体前冲','Lunging the body forward while closing'],effect:['握把位移混入全身移动，胸肩相对钢索的几何改变。重查站位和配重，不把更长位移当成更有效。','Handle displacement now includes whole-body motion and shoulder-to-cable geometry changes. Recheck stance and load; farther travel is not automatically better.'],question:['滑轮升高，钢索方向和有效分量怎样改变？','How does a higher pulley change cable direction and components?'],physics:['各侧钢索张力沿当前出绳方向，分量随方向改变。不能用同一个纯竖直箭头表示所有站位与高度。','Each cable pulls along its current line and components change with direction. One vertical arrow cannot represent every stance and pulley height.'],study:'press',experiments:['direction','lever','pulley'],quiz:['双塔的左右配重能不区分地自动合并吗？','Can left and right stacks automatically be merged?'],answer:['不能，必须知道使用侧和记录口径。','No. Used side and recording basis must be known.']},
'machine-fly':{type:'fly',intro:['SS-PEC坐姿夹胸用两侧转臂引导双手向前合拢，座椅和起始打开位置分别影响身体关系与可用行程。','The SS-PEC guides a seated fly through paired arms. Seat position and starting opening affect body fit and available range separately.'],muscles:['胸大肌参与上臂合拢，三角肌前束协同，靠背和脚部接触稳定身体。','Pectoralis major brings the arms together, assisted by the anterior deltoid, with backrest and foot support.'],chain:['手 → 铰接握把 → 独立转臂与凸轮 → 钢索配重。握把局部自转帮助对齐，转臂轨迹仍由机器约束。','Hands → pivoting grips → paired arms and cams → cable stack. Grip articulation helps alignment while machine arms constrain the path.'],look:['比较座椅调节后，双手合拢时相对胸部的位置；起始张开要在可控制、无不适的范围，不追求越大越好。','Compare grip position relative to the chest after seat changes. Use a controlled, comfortable starting opening rather than maximizing it.'],change:['返回时突然放松，让转臂把肩向后带','Relaxing abruptly and letting the arms pull the shoulders backward'],effect:['回程速度失去控制，身体与支撑关系改变。减小张开范围并重新建立慢回程。','Return speed becomes uncontrolled and support relations change. Reduce opening and restore a controlled return.'],question:['起始打开位置与阻力曲线参数是一回事吗？','Is starting opening the same as a resistance-curve parameter?'],physics:['起始打开改变可走的动作区间；实验中的d(θ)描述理想传动。前者不等于改变实物凸轮，后者不是现场调节菜单。','Starting opening selects an available movement interval. Experimental d(θ) describes ideal transmission; it does not mean changing the real cam.'],study:'press',experiments:['cam','work','calculus'],quiz:['打开越大，是否能从模型判断增肌一定越多？','Can the model prove a wider opening gives more hypertrophy?'],answer:['不能，模型没有计算长期人体适应。','No. Long-term human adaptation is not computed.']},
'scissor-pulldown':{type:'pulldown',intro:['IL-WPD让左右工作臂沿宽握圆弧下拉。它不是一根可任意改变握距的自由横杆。','IL-WPD independent arms pull through wide-grip arcs. It is not a free bar with arbitrary grip width.'],muscles:['背阔肌与肩周肌群使上臂下收，肘屈肌辅助；大腿垫与脚部接触限制身体被向上带起。','Latissimus and shoulder muscles lower the arms, assisted by elbow flexors. Thigh-pad and foot contact resist body lift.'],chain:['手 → 宽握独立转臂 → 每侧挂片轴绕固定机器轴转动。左右负荷分开，机架与座椅支撑保持不动。','Hands → independent wide-grip arms → plate horns rotate about fixed axes. Left/right loads are separate; frame and seat remain fixed.'],look:['看肘随弧线向下，坐姿和大腿接触不随每次下拉改变。宽握是该结构的路径，不自动代表更高背阔刺激。','Watch elbows follow the downward arcs while seated/thigh contact stays steady. A wide machine path does not automatically mean more lat stimulus.'],change:['一边下拉时躯干扭转','Trunk rotation while one arm pulls'],effect:['肩、骨盆与独立握把的相对关系改变。先对照双侧小负荷路径，再决定是否做明确的单侧变式。','Shoulders, pelvis and independent grips change their relation. Compare controlled light bilateral motion before choosing a deliberate unilateral variation.'],question:['为什么更宽的手位不能直接写成更好的增肌？','Why is a wider hand position not proof of better hypertrophy?'],physics:['力臂只是外部几何。肌电、肌肉力与长期增长是不同测量；当前机器的轴和手位不能直接用自由钢索研究替代验证。','Moment arms describe external geometry. EMG, muscle force and long-term growth are different outcomes; a free-cable study does not validate this machine directly.'],study:'pull',experiments:['lever','work','uncertainty'],quiz:['自由横杆的宽握研究可以直接认证IL-WPD吗？','Can a free-bar grip study directly validate IL-WPD?'],answer:['不能，两种器械约束不同，只能谨慎讨论相关问题。','No. Their constraints differ; only limited related questions can be discussed.']},
'nautilus-pullover':{type:'pullover',intro:['坐姿上拉用肘垫和握把带动转臂向前下方运动；辅助脚踏用于进入和退出，不是正式工作时用腿代替上肢发力。','The seated pullover uses elbow pads and grips to move an arm forward/down. The assist pedal helps entry and exit, not replacing upper-body work during the stroke.'],muscles:['上臂相对躯干下移涉及背阔肌等肩部伸展肌群，胸部与其他肌群的参与随角度改变；不是“孤立一条肌肉”的检测。','Arm lowering involves shoulder extensors including latissimus; pectoral and other contributions vary with angle. This is not a single-muscle isolation measurement.'],chain:['上臂和肘垫接触 → 弧形工作臂 → 凸轮与钢索 → 配重。辅助踏板与进入机构联动，正式动作与辅助进入要分开理解。','Upper-arm/elbow-pad contact → arc arm → cam and cable → stack. The assist pedal links to entry; entry assistance and the working stroke are distinct.'],look:['看肘是否持续贴垫、躯干是否留在靠垫和安全带范围。不要把手用力弯肘拉握把当作同一上臂下压路径。','Watch elbow-pad contact and the supported/belted trunk. Strong elbow bending to pull the grip is not the same upper-arm lowering path.'],change:['用躯干前倾追随肘垫','Following the elbow pads with trunk lean'],effect:['肩相对机器轴的位置改变，接触几何不再与原姿态一致。先核对型号牌示、座椅、安全带和进入脚踏；具体IPPO3版本资料仍有限。','Shoulders shift relative to the machine axis and contact geometry changes. Recheck model instructions, seat, belt and assist pedal; IPPO3-specific documentation remains limited.'],question:['肘垫与握把为什么必须一起观察？','Why watch both elbow pads and grips?'],physics:['二者是同一转臂上的不同接触点，手和上臂受力不能随意互换。本站未测真实凸轮和人体受力分配。','They are distinct contacts on one arm. Hand and upper-arm forces cannot be exchanged arbitrarily; the real cam and human load sharing are unmeasured.'],study:'general',experiments:['lever','cam','work'],quiz:['能否把辅助脚踏运动当成正式训练重复？','Can assist-pedal motion be counted as a training repetition?'],answer:['不能。它用于进入退出，训练记录仍需人工确认实际动作。','No. It assists entry/exit; actual training repetitions require deliberate recording.']},
'hammer-row':{type:'chest-row',intro:['IL-ROW用胸托支撑躯干，双手分别拉动独立工作臂。胸托划船与没有胸托的自由划船具有不同支撑条件。','IL-ROW supports the trunk on a chest pad while hands pull independent arms. It has different support conditions from an unsupported free row.'],muscles:['背阔肌、肩胛周围肌群与肘屈肌参与，胸托和脚踏提供支撑。胸托减少一种身体移动自由度，但不替代握持与回程控制。','Latissimus, scapular muscles and elbow flexors contribute. Chest pad and footplates support the body, but do not replace grip and return control.'],chain:['手 → 独立握把与转臂 → 各侧挂片重力。胸托、座椅与脚踏固定；工作臂绕机器轴移动。','Hands → independent grips/arms → plate gravity on each side. Chest support, seat and footplates stay fixed while arms rotate.'],look:['看胸部保持贴垫，手肘向后而骨盆不后移；返回时逐渐伸臂，保持工作臂受控。','Keep chest contact as elbows travel back, without shifting the pelvis. Reach forward gradually on return and control each arm.'],change:['拉回时胸部离开胸垫','Chest leaving its support during the pull'],effect:['原本稳定的支撑条件丢失，躯干后移混入握把路径。先把负荷降到能维持胸托接触的位置。','The support condition changes and trunk movement contributes to handle travel. Lower load until chest support can be maintained.'],question:['同一挂片在转臂不同位置为何不同？','Why do the same plates act differently at different arm positions?'],physics:['装片点绕轴移动，重力作用线到机器轴的垂距改变。机架上储存的片不随工作臂动，不属于本次工作负荷。','The plate point moves about an axis, changing gravity’s perpendicular arm. Storage plates on the frame do not move with the work arm and are not its working load.'],study:'pull',experiments:['lever','work','power'],quiz:['机架储存轴上的片需要计入工作负荷吗？','Should storage-horn plates count as working load?'],answer:['不需要，它们未随工作臂运动。','No. They do not move with the working arm.']},
'cable-pulldown':{type:'pulldown',intro:['OP-LR共用一座配重塔，提供上方横杆下拉与下方中性握把划船。本课程当前人体演示上方横杆下拉，切换附件须在配重落稳后完成。','OP-LR shares one stack between overhead pulldown and low neutral-grip row. The current body demonstration is the overhead pulldown; change attachments only with the stack settled.'],muscles:['下拉涉及背阔肌、肩周肌群与肘屈肌；低位划船又改变上臂和肩胛路径，应当分开记录。','Pulldown involves latissimus, shoulder muscles and elbow flexors. Low row changes arm and scapular paths and should be recorded separately.'],chain:['横杆 → 上方导轮和钢索 → 共用配重塔；低位附件经过下方出绳轮。手柄行程取决于具体布绳，不按外观随意猜倍率。','Bar → overhead pulleys/rope → shared stack; the low attachment uses the lower exit. Travel depends on actual reeving, not a guessed visual ratio.'],look:['下拉时大腿留在垫下，横杆受控向前胸方向走；这与OP-PD固定转臂的肩高终点不同。结束时把配重放稳再放附件。','Keep thighs under the pad and control the bar toward the front chest. This differs from OP-PD’s fixed-arm shoulder-height endpoint. Settle the stack before releasing the attachment.'],change:['借后仰把下拉做成划船','Turning a pulldown into a row with large backward lean'],effect:['上臂相对躯干与钢索的方向改变，这可是一种明确变式，但不能混作同一条件比较。先区分当前学习哪种附件和动作。','Arm–trunk and cable directions change. It may be a deliberate variation, but not the same comparison condition. First identify attachment and movement.'],question:['同一塔的下拉和划船能按同一动作比较吗？','Can pulldown and row on one stack be treated as one exercise?'],physics:['阻力来源可相同，但作用点、方向、运动路径和人体接触不同。比较重量前须同时确认动作、附件、侧别和口径。','Resistance source may match, but contact, direction and path differ. Confirm exercise, attachment, side and load basis before comparison.'],study:'pull',experiments:['direction','pulley','work'],quiz:['看到同一配重塔就能合并两种动作的进步吗？','Does one stack justify merging progress across both actions?'],answer:['不能。动作与附件条件不同。','No. Action and attachment conditions differ.']},
'machine-military-press':{type:'shoulder',intro:['IL-SP两侧独立肩推，靠背与座椅为身体提供倾斜支撑。型号的固定倾角不是可任意更改的实验参数。','IL-SP has independent press arms and an inclined seat/back support. Its fixed model inclination is not an arbitrary experimental setting.'],muscles:['三角肌和肱三头肌参与上推，肩胛周围肌群协同；靠背与脚部稳定躯干。','Deltoid and triceps contribute to pressing with scapular coordination; backrest and feet stabilize the trunk.'],chain:['手 → 左右独立转臂 → 工作装片轴与挂片重力。机架固定，各臂可分别移动。','Hands → independent arms → working plate horns and gravity. The frame is fixed and each arm can move separately.'],look:['握把起点接近肩部或略高，手腕与前臂自然对齐。看背部留在垫上，而不是用躯干向后摆来增加握把行程。','Begin with grips around shoulder level or slightly higher and wrists naturally aligned with forearms. Keep back support instead of leaning back to add travel.'],change:['推起时腰背整体向后追随','Large backward trunk movement during the press'],effect:['肩相对握把的路径和支撑条件改变。先减轻负荷并检查座椅、背垫和起点；不能从外观预测腰椎受力。','Shoulder path and support conditions change. Reduce load and check seat/backrest/start. Lumbar forces cannot be predicted from appearance.'],question:['独立工作臂是否意味着两侧握把力相同？','Do independent arms guarantee equal forces?'],physics:['左右有各自装片与几何位置。相同片重只满足一个输入条件，并不证明人体两侧能力相同。','Each side has its own load and geometry. Equal plates establish one input condition, not equal human capacity.'],study:'shoulder',experiments:['lever','work','uncertainty'],quiz:['示例里两侧同步，能说明你的两侧力量相同吗？','Does symmetric animation imply your sides are equally strong?'],answer:['不能。人体模型不是个人测量。','No. The mannequin is not a personal measurement.']},
'seated-machine-shoulder':{type:'shoulder',intro:['OP-SP坐姿肩推沿固定转臂轨迹上推，可选择厂家提供的中立或正握把位。座椅改变身体相对握把的高度，不改变固定靠背与轴。','OP-SP presses along fixed arms with manufacturer-provided neutral or pronated grips. Seat height changes body fit, not the fixed backrest or axis.'],muscles:['三角肌、肱三头肌与肩胛周围肌群协同，躯干和双脚维持支撑。','Deltoid, triceps and scapular muscles coordinate while trunk and feet maintain support.'],chain:['手 → 对应握把 → 转臂和凸轮 → 钢索配重。转臂上推，配重上升；靠背与机器轴固定。','Hands → chosen grips → arms/cam → cable stack. Arms press upward and the stack rises; backrest and shaft stay fixed.'],look:['调节座椅时观察握把起点相对肩部的位置，确认双脚能稳定支撑。发力时肘逐渐伸展，不用耸肩或全身后移来追逐终点。','During seat adjustment, watch starting grip height relative to shoulders and stable foot support. Extend elbows gradually without chasing the end through whole-body movement.'],change:['座椅位置不合适，身体离垫够握把','Leaving the pad to reach grips from a poor seat position'],effect:['支撑与接触关系改变。重新调座椅并检查握把选项；页面示意没有实物档位编号。','Support/contact changes. Recheck seat and grip selection; the display does not invent real detent numbers.'],question:['调高座椅为什么会改变姿势但不改变配重？','Why does a higher seat change posture but not the stack mass?'],physics:['座椅改变人的接触几何，配重质量仍是独立输入。不要把一个示意高度自动转成个人推荐重量。','Seat height changes contact geometry; mass is a separate input. A display height does not determine a personal load recommendation.'],study:'shoulder',experiments:['lever','cam','work'],quiz:['模型座椅滑块的数字是实物档位吗？','Are display seat-slider values real machine detents?'],answer:['不是。没有已核实档位，按实物说明确认。','No. Detents are unverified; use the actual machine instructions.']},
'home-wall-press-up':{type:'wall',intro:['站在坚固墙面前，用手掌支撑，屈肘靠近墙面再推回。支撑从地面换成墙面，改变身体相对重力的几何关系。','Stand at a solid wall with palm support, bend elbows toward it and press back. Wall support changes body geometry relative to gravity.'],muscles:['胸部、肩前侧和肱三头肌参与推回，躯干与腿部维持身体整体排列。','Chest, anterior shoulder and triceps contribute to the press, while trunk and legs maintain alignment.'],chain:['双脚与地面、双手与墙面共同提供外部支撑；没有配重塔。身体质量的重力由多个接触点共同平衡。','Feet on ground and hands on wall share support. There is no stack; multiple contacts balance body weight.'],look:['手掌位于胸部高度，身体作为整体靠近墙面；脚掌留地，墙面不滑动。','Keep palms at chest height, move the body as a unit, maintain foot contact and use a stable wall.'],change:['腰腹先靠近墙而肩部不跟随','Waist moving toward the wall ahead of the shoulders'],effect:['身体排列和支撑几何改变。缩小幅度，重建从肩到脚的整体移动；不同站距可以是有意的难度变式。','Body alignment and support geometry change. Reduce range and restore coordinated movement. Different distances may be deliberate difficulty variations.'],question:['为何离墙远近会改变练习感受？','Why does wall distance change the exercise?'],physics:['站距改变重心与接触点的相对位置，手部支撑反力可变化。没有全身质量分布和实测反力时，不显示“手承受体重百分比”。','Distance changes center-of-mass/contact geometry and can alter hand reaction. Without mass distribution and measured forces, no percent-bodyweight claim is shown.'],study:'general',experiments:['lever','work','kinematics'],quiz:['墙壁俯卧撑记录的自重等于双手实际承受全部体重吗？','Does bodyweight recording mean the hands support all body mass?'],answer:['不等于。双脚也提供支撑。','No. The feet also support the body.']},
'home-sit-to-stand':{type:'chair-stand',intro:['从稳固无轮椅子的前缘坐姿站起，再受控坐回。椅子是起点和终点支撑，站起后主要由脚掌承重。','Rise from the front of a stable non-wheeled chair, then sit back under control. The chair supports the endpoints; feet support standing.'],muscles:['股四头肌与髋伸肌参与站起，躯干和踝周围肌群帮助控制重心移动。','Knee and hip extensors raise the body; trunk and ankle muscles help control the center of mass.'],chain:['坐垫承重 → 躯干稍前倾、脚掌接地 → 骨盆离椅 → 站立。支撑从椅子与双脚转为双脚，再在回程恢复。','Seat support → slight forward trunk lean with feet grounded → pelvis leaves chair → standing. Support shifts from chair/feet to feet and returns on descent.'],look:['从侧面看骨盆离开椅子前，身体稍向前移；双脚位置保持，站稳后慢慢坐回。','From the side, see the body shift slightly forward before the pelvis leaves. Keep feet placed and sit down gradually after stabilizing.'],change:['还未对准椅子就快速向后落座','Dropping backward before aligning with the chair'],effect:['回程失去受控的支撑转换。先确认椅子固定和位置，再减小速度；模型不测试个人平衡能力。','Controlled support transfer is lost. Check chair position/stability and slow the return. The model does not test personal balance.'],question:['为什么站起前常先稍向前倾？','Why does rising often start with a slight forward lean?'],physics:['它改变身体重心相对脚部支撑的位置，帮助建立离椅后的平衡条件。具体角度因人体与椅高不同，示例不给统一角度处方。','It changes center-of-mass position relative to the feet for post-seat balance. Body proportions and chair height vary; no universal angle is prescribed.'],study:'general',experiments:['lever','work','power','kinematics'],quiz:['骨盆离椅后，椅子还在承担同样的支撑力吗？','After the pelvis leaves, does the chair provide the same support force?'],answer:['没有。支撑已主要转到脚部。','No. Support has transferred primarily to the feet.']},
'home-mini-squat':{type:'mini-squat',intro:['轻扶稳固椅背做小幅屈膝与起身。椅子帮助稳定，不意味着把体重全部挂在手臂上。','Lightly hold a stable chair back during a small squat and return. The chair assists balance rather than suspending all bodyweight from the arms.'],muscles:['膝与髋伸肌参与起身，躯干与脚部控制平衡，手轻扶支撑。','Knee and hip extensors contribute while trunk and feet control balance with light hand support.'],chain:['脚掌承重与椅背辅助接触 → 屈膝降低骨盆 → 受控站起。椅子固定，人体在多个关节协同运动。','Weight through feet with light chair contact → knees bend and pelvis lowers → controlled rise. The chair stays fixed while multiple joints coordinate.'],look:['双脚约髋宽，椅子不移动；观察脚跟不抬起、膝盖与脚尖方向相配，深度保持舒适的小幅。','Keep feet about hip-width and the chair stationary. Watch heel contact, knees following toes and a comfortable small range.'],change:['身体前倾追逐椅背','Leaning the body forward after the chair support'],effect:['身体相对手和双脚的位置改变，小幅屈膝混入了额外躯干移动。保持支撑稳固，缩小幅度并重新观察背部与膝的配合；不以模型判断个人跌倒风险。','The body shifts relative to hands and feet, adding trunk movement to the small knee bend. Keep support fixed, reduce range and recheck trunk–knee coordination. The model does not predict personal fall risk.'],question:['小幅与深幅为什么是不同的几何条件？','Why do small and deep squats have different geometry?'],physics:['膝髋角度、重心和接触反力的关系随深度改变。仅用“深度百分比”不能代替关节、支撑和身体比例信息。','Joint angles, center of mass and contact reactions change with depth. A normalized depth alone does not describe joints, support or proportions.'],study:'general',experiments:['lever','work','uncertainty'],quiz:['扶椅练习和杠铃深蹲能直接比较负重数字吗？','Can supported squats and barbell squats be compared by load numbers alone?'],answer:['不能。支撑和阻力来源不同。','No. Support and resistance sources differ.']},
'home-calf-raise':{type:'calf',intro:['轻扶稳固椅背，抬起脚跟再缓慢放下。观察脚前掌与地面的接触，以及脚跟的升降。','Lightly hold a stable chair, raise the heels and lower them slowly. Watch forefoot contact and heel travel.'],muscles:['小腿后侧肌群参与踝跖屈，脚部与躯干维持平衡；手提供轻支撑。','Calf muscles contribute to plantarflexion; feet and trunk maintain balance with light hand support.'],chain:['脚前掌与地面接触 → 脚跟抬升 → 身体重心上移 → 受控下放。椅背不随身体升降。','Forefoot contact → heel rise → center of mass rises → controlled lowering. Chair support remains stationary.'],look:['看脚跟慢慢离地，脚前掌仍接地，身体不前后摆。返回时别靠突然落跟来结束。','Watch a gradual heel rise with forefoot contact and no body sway. Avoid finishing by dropping the heels abruptly.'],change:['抬跟时身体向前后摇摆','Rocking the body during heel rise'],effect:['踝部运动混入整体位移与支撑变化。减小幅度，确认椅子稳固并把注意力放在脚跟升降。','Ankle movement mixes with whole-body displacement. Reduce range, secure the support and focus on heel rise.'],question:['脚跟升高能直接告诉我们小腿肌肉力吗？','Does heel height directly give calf muscle force?'],physics:['还需要踝轴、肌腱力臂、身体重心和地面反力。课程只有规定运动，不能把位移导数当成真实肌腱负荷。','Ankle axis, tendon arm, center of mass and ground reaction are also needed. Prescribed motion derivatives are not measured tendon load.'],study:'general',experiments:['lever','work','kinematics'],quiz:['弹簧实验的刚度可以当作你的跟腱刚度吗？','Is the spring experiment’s stiffness your Achilles-tendon stiffness?'],answer:['不能，它是独立的物理示例，没有个人测量。','No. It is an independent physical example without personal measurements.']}
};
const studies={
general:{authors:'Currier et al. (2026)',title:'Resistance Training Prescription for Muscle Function, Hypertrophy, and Physical Performance in Healthy Adults: An Overview of Reviews',url:'https://pubmed.ncbi.nlm.nih.gov/41843416/',doi:'10.1249/MSS.0000000000003897',body:['ACSM立场文件整合健康成人阻力训练的系统综述，比较不同安排与不练或其他安排的适应结果。总体支持渐进训练；它不验证本页面器械几何，也不为个人给出公斤数。本文核对PubMed摘要，未核对全文。','The ACSM position stand synthesized reviews of healthy-adult resistance training, comparing programs with no training or other prescriptions. It supports progressive training, not this page’s geometry or personal kilogram targets. PubMed abstract checked; full text not checked.'],limits:['一般人群研究不能替代当前动作的直接证据，更不能推断用户关节负荷、疾病处理或个人能力。本站时间预算、动作轮换是可检查的产品规则，并非论文验证过的个体最优方案。','General population evidence is not direct validation of this action and cannot determine your joint loads, clinical management or capacity. Site time budgets and exercise rotation are inspectable product rules, not a study-validated personal optimum.']},
extension:{authors:'Larsen et al. (2025; online 2024)',title:'The effects of hip flexion angle on quadriceps femoris muscle hypertrophy in the leg extension exercise',url:'https://pubmed.ncbi.nlm.nih.gov/39699974/',doi:'10.1080/02640414.2024.2444713',body:['研究比较22名未训练男性在40°与90°髋屈曲下进行10周腿伸展，按同一受试者的两侧分配条件，用超声观察股直肌与股外侧肌厚度。摘要报告股直肌更偏向40°条件，股外侧肌差异不明显。这里核对的是摘要。','In 22 untrained men, a 10-week within-person study compared leg extensions at 40° and 90° hip flexion. Ultrasound assessed rectus-femoris and vastus-lateralis thickness. The abstract favored 40° for rectus femoris but found little difference for vastus lateralis. Abstract checked.'],limits:['研究角度不等于OP-LE的可调靠背档位，不支持把商业器械改到说明书外的姿态；样本和测量也不能给每个人保证增肌或安全。实践上先核对稳定接触，再把髋角当成需要额外证据的变量。','Study angles are not OP-LE backrest detents and do not justify positions outside instructions. The sample and outcomes cannot guarantee individual growth or safety. Establish support first; hip angle remains an evidence-dependent variable.']},
press:{authors:'Trebs, Brandenburg & Pitney (2010)',title:'An electromyography analysis of 3 muscles surrounding the shoulder joint during the performance of a chest press exercise at several angles',url:'https://pubmed.ncbi.nlm.nih.gov/20512064/',doi:'10.1519/JSC.0b013e3181ddfae7',body:['研究比较不同卧推倾角下胸肌不同部位与三角肌前束的肌电，即短时电活动，不是长期生长。所读摘要以各角度相对负荷比较；说明姿态会影响测得的活动分布，不等于本站每台推胸或夹胸机都得到验证。','This acute study compared chest-region and anterior-deltoid EMG at different bench inclinations using relative loads. EMG is short-term electrical activity, not long-term growth. The abstract supports posture-dependent activity, not validation of every press or fly here.'],limits:['自由杠铃与固定转臂的支撑、路径不同。夹胸更不是卧推动作。本文只用来提出“角度与测量口径为何重要”的相关问题，不给出某台机器更增肌的排序。摘要已核对，未核对全文。','Free-bar and guided-arm supports and paths differ, and fly is not bench press. This only informs the related question of angle and measurement, without ranking machines for hypertrophy. Abstract checked; full text not checked.']},
pull:{authors:'Andersen et al. (2014)',title:'Effects of grip width on muscle strength and activation in the lat pull-down',url:'https://pubmed.ncbi.nlm.nih.gov/24662157/',doi:'10.1097/JSC.0000000000000232',body:['15名男性以三种正握宽度做6RM下拉，比较最大可完成负荷与肌电。摘要报告全程背阔肌等活动总体相近，较窄和中等握距可完成的负荷高于宽握。肌电不等于长期增肌；这里没有把作者的长期推测当成测量结果。','Fifteen men performed 6RM pulldowns with three pronated widths. The abstract reports broadly similar whole-movement lat EMG and higher achievable loads with narrow/medium grips than wide. EMG is not long-term growth; long-term speculation is not treated as a measured result.'],limits:['这不是OP-PD、IL-WPD、划船或上拉机的直接试验。支撑、固定轴、附件与人体比例都可能改变适用性。实践中先选择器械允许且可控制的握持，再保持条件一致做记录。仅核对摘要。','This is not a direct trial of OP-PD, IL-WPD, row or pullover machines. Support, axes, attachments and body proportions limit transfer. Use permitted controlled grips and consistent records. Abstract only checked.']},
shoulder:{authors:'Saeterbakken & Fimland (2013)',title:'Effects of body position and loading modality on muscle activity and strength in shoulder presses',url:'https://pubmed.ncbi.nlm.nih.gov/23096062/',doi:'10.1519/JSC.0b013e318276b873',body:['15名健康男性比较坐姿、站姿以及哑铃、杠铃肩推，测量1RM与肌电。摘要显示支撑和负荷方式影响可用重量与神经肌肉活动；更不稳定的条件不等于更大可用重量，也不能据此排序增肌效果。','Fifteen healthy men compared seated/standing and barbell/dumbbell presses using 1RM and EMG. Support and loading changed strength and activity. Less stability did not mean greater load capacity and does not rank hypertrophy outcomes.'],limits:['研究未测试本站固定肩推机或滑轮侧平举，不能把相关结果当型号证据。它提醒我们区分支撑、轨迹与测量指标；个体舒服的姿态差异也不能自动判为错误。摘要已核对，未核对全文。','The study did not test these guided presses or cable lateral raises. It motivates distinguishing support, path and outcome, not device-specific claims. Comfortable individual variation is not automatically an error. Abstract checked; full text not checked.']}
};
const motionReferences={
 "cam": {
  "title": [
   "Life Fitness 官方操作手册 · OP-LE · PDF 第 50 页",
   "Life Fitness instructions · OP-LE · PDF page 50"
  ],
  "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=50",
  "scope": [
   "已核对该动作的文字和示意图：身体支撑、握持、运动方向与返回。模型尺寸仍为近似值。",
   "Movement text and diagrams checked for support, grip, direction and return. Dimensions remain approximate."
  ],
  "kind": "manual"
 },
 "pec": {
  "title": [
   "Life Fitness 官方操作手册 · OP-FLY · PDF 第 61 页",
   "Life Fitness instructions · OP-FLY · PDF page 61"
  ],
  "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=61",
  "scope": [
   "已核对该动作的文字和示意图：身体支撑、握持、运动方向与返回。模型尺寸仍为近似值。",
   "Movement text and diagrams checked for support, grip, direction and return. Dimensions remain approximate."
  ],
  "kind": "manual"
 },
 "lat": {
  "title": [
   "Life Fitness 官方操作手册 · OP-PD · PDF 第 52 页",
   "Life Fitness instructions · OP-PD · PDF page 52"
  ],
  "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=52",
  "scope": [
   "已核对该动作的文字和示意图：身体支撑、握持、运动方向与返回。模型尺寸仍为近似值。",
   "Movement text and diagrams checked for support, grip, direction and return. Dimensions remain approximate."
  ],
  "kind": "manual"
 },
 "cable-row": {
  "title": [
   "Life Fitness 官方操作手册 · OP-RW · PDF 第 53 页",
   "Life Fitness instructions · OP-RW · PDF page 53"
  ],
  "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=53",
  "scope": [
   "已核对该动作的文字和示意图：身体支撑、握持、运动方向与返回。模型尺寸仍为近似值。",
   "Movement text and diagrams checked for support, grip, direction and return. Dimensions remain approximate."
  ],
  "kind": "manual"
 },
 "flat-press": {
  "title": [
   "Life Fitness 官方操作手册 · OP-CP · PDF 第 48 页",
   "Life Fitness instructions · OP-CP · PDF page 48"
  ],
  "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=48",
  "scope": [
   "已核对该动作的文字和示意图：身体支撑、握持、运动方向与返回。模型尺寸仍为近似值。",
   "Movement text and diagrams checked for support, grip, direction and return. Dimensions remain approximate."
  ],
  "kind": "manual"
 },
 "cable-pulldown": {
  "title": [
   "Life Fitness 官方操作手册 · OP-LR · PDF 第 62 页",
   "Life Fitness instructions · OP-LR · PDF page 62"
  ],
  "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=62",
  "scope": [
   "已核对该动作的文字和示意图：身体支撑、握持、运动方向与返回。模型尺寸仍为近似值。",
   "Movement text and diagrams checked for support, grip, direction and return. Dimensions remain approximate."
  ],
  "kind": "manual"
 },
 "seated-machine-shoulder": {
  "title": [
   "Life Fitness 官方操作手册 · OP-SP · PDF 第 54 页",
   "Life Fitness instructions · OP-SP · PDF page 54"
  ],
  "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/OM-OP_Life_Fitness_Axiom_Single_Station_Series_1014208-0001.pdf#page=54",
  "scope": [
   "已核对该动作的文字和示意图：身体支撑、握持、运动方向与返回。模型尺寸仍为近似值。",
   "Movement text and diagrams checked for support, grip, direction and return. Dimensions remain approximate."
  ],
  "kind": "manual"
 },
 "machine-fly": {
  "title": [
   "Life Fitness 官方手册 · SS-PEC · PDF 第 20 页",
   "Life Fitness official manual · SS-PEC · PDF page 20"
  ],
  "url": "https://kb.cybexintl.com/Owners_Manuals/Strength/Life_Fitness_Insignia_Series_Owners_Manual_9481201_Rev_BE.pdf#page=20",
  "scope": [
   "核对 SS-PEC 飞鸟的坐姿、肩部支撑和向前合拢；没有用 SS-FLY 后束动作替代。",
   "SS-PEC seating, shoulder support and forward closure checked; not substituted with SS-FLY rear-delt instructions."
  ],
  "kind": "manual"
 },
 "incline-press": {
  "title": [
   "Life Fitness / Hammer Strength 官方动作演示",
   "Life Fitness / Hammer Strength official demonstration"
  ],
  "url": "https://www.youtube.com/watch?v=UKPBc1BWRzw",
  "scope": [
   "已查看厂家视频中的人体姿态和运动路径；本站提供同步双臂示意，未声称实机尺寸标定。",
   "Manufacturer video posture and path viewed. This lesson illustrates synchronized arms, not a dimensionally calibrated replica."
  ],
  "kind": "video"
 },
 "scissor-pulldown": {
  "title": [
   "Life Fitness / Hammer Strength 官方动作演示",
   "Life Fitness / Hammer Strength official demonstration"
  ],
  "url": "https://www.youtube.com/watch?v=QkyAbP1r8Nc",
  "scope": [
   "已查看厂家视频中的人体姿态和运动路径；本站提供同步双臂示意，未声称实机尺寸标定。",
   "Manufacturer video posture and path viewed. This lesson illustrates synchronized arms, not a dimensionally calibrated replica."
  ],
  "kind": "video"
 },
 "hammer-row": {
  "title": [
   "Life Fitness / Hammer Strength 官方动作演示",
   "Life Fitness / Hammer Strength official demonstration"
  ],
  "url": "https://www.youtube.com/watch?v=VZmJ8z6zh3g",
  "scope": [
   "已查看厂家视频中的人体姿态和运动路径；本站提供同步双臂示意，未声称实机尺寸标定。",
   "Manufacturer video posture and path viewed. This lesson illustrates synchronized arms, not a dimensionally calibrated replica."
  ],
  "kind": "video"
 },
 "machine-military-press": {
  "title": [
   "Life Fitness / Hammer Strength 官方动作演示",
   "Life Fitness / Hammer Strength official demonstration"
  ],
  "url": "https://www.youtube.com/watch?v=TBZ3m1cd2Vw",
  "scope": [
   "已查看厂家视频中的人体姿态和运动路径；本站提供同步双臂示意，未声称实机尺寸标定。",
   "Manufacturer video posture and path viewed. This lesson illustrates synchronized arms, not a dimensionally calibrated replica."
  ],
  "kind": "video"
 },
 "incline": {
  "title": [
   "Hammer Strength HSLLP 官方产品与演示",
   "Hammer Strength HSLLP manufacturer reference"
  ],
  "url": "https://www.lifefitness.com/en-us/catalog/strength-training/plate-loaded/plate-loaded-linear-leg-press",
  "scope": [
   "核对 45° 导轨、背部支撑和脚踏方向；教学行程按固定腿长限制。",
   "45-degree rails, back support and footplate direction checked; lesson travel is bounded by fixed leg lengths."
  ],
  "kind": "manufacturer"
 },
 "arm": {
  "title": [
   "Life Fitness 双滑轮官方动作挂图 · Lateral Raise",
   "Life Fitness DAP exercise poster · Lateral Raise"
  ],
  "url": "https://www.lifefitness.com.au/wp-content/uploads/2015/02/CMDAP-Poster-vf.pdf",
  "scope": [
   "核对侧平举动作图。挂图对应 Cable Motion 系列，作为动作参考；不是 OP-DAP 尺寸或传动标定。",
   "Lateral-raise illustration checked. This Cable Motion poster informs movement, not OP-DAP dimensions or transmission calibration."
  ],
  "kind": "manufacturer-poster"
 },
 "cable-fly": {
  "title": [
   "ACE 官方动作库 · Standing Chest Fly",
   "ACE exercise library · Standing Chest Fly"
  ],
  "url": "https://www.acefitness.org/resources/everyone/exercise-library/160/standing-chest-fly/",
  "scope": [
   "核对站姿、肘部保留屈曲和双手在身前合拢；器械布置另按 OP-DAP 厂家资料。",
   "Standing support, retained elbow flexion and closure in front checked; OP-DAP documentation informs equipment arrangement."
  ],
  "kind": "exercise-guidance"
 },
 "barbell-squat": {
  "title": [
   "ACE 官方动作库 · 杠铃动作说明",
   "ACE exercise library · Barbell movement"
  ],
  "url": "https://www.acefitness.org/resources/everyone/exercise-library/11/back-squat/",
  "scope": [
   "核对杠铃、人体和支撑点的关系。架与凳的厂家结构资料没有当作人体教学视频。",
   "Bar, body and support relationships checked. Rack and bench structural documentation is not presented as a human demonstration."
  ],
  "kind": "exercise-guidance"
 },
 "barbell-bench": {
  "title": [
   "ACE 官方动作库 · 杠铃动作说明",
   "ACE exercise library · Barbell movement"
  ],
  "url": "https://www.acefitness.org/resources/everyone/exercise-library/5/chest-press/",
  "scope": [
   "核对杠铃、人体和支撑点的关系。架与凳的厂家结构资料没有当作人体教学视频。",
   "Bar, body and support relationships checked. Rack and bench structural documentation is not presented as a human demonstration."
  ],
  "kind": "exercise-guidance"
 },
 "home-wall-press-up": {
  "title": [
   "NHS 官方动作图与步骤",
   "NHS official movement illustrations and steps"
  ],
  "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
  "scope": [
   "核对稳固支撑、身体方向和动作步骤。扶椅动作站在椅背外侧；提踵保留脚部与地面的接触。",
   "Stable support, orientation and sequence checked. Chair exercises stand behind the chair; heel raising retains floor contact."
  ],
  "kind": "exercise-guidance"
 },
 "home-sit-to-stand": {
  "title": [
   "NHS 官方动作图与步骤",
   "NHS official movement illustrations and steps"
  ],
  "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
  "scope": [
   "核对稳固支撑、身体方向和动作步骤。扶椅动作站在椅背外侧；提踵保留脚部与地面的接触。",
   "Stable support, orientation and sequence checked. Chair exercises stand behind the chair; heel raising retains floor contact."
  ],
  "kind": "exercise-guidance"
 },
 "home-mini-squat": {
  "title": [
   "NHS 官方动作图与步骤",
   "NHS official movement illustrations and steps"
  ],
  "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
  "scope": [
   "核对稳固支撑、身体方向和动作步骤。扶椅动作站在椅背外侧；提踵保留脚部与地面的接触。",
   "Stable support, orientation and sequence checked. Chair exercises stand behind the chair; heel raising retains floor contact."
  ],
  "kind": "exercise-guidance"
 },
 "home-calf-raise": {
  "title": [
   "NHS 官方动作图与步骤",
   "NHS official movement illustrations and steps"
  ],
  "url": "https://www.nhs.uk/live-well/exercise/strength-exercises/",
  "scope": [
   "核对稳固支撑、身体方向和动作步骤。扶椅动作站在椅背外侧；提踵保留脚部与地面的接触。",
   "Stable support, orientation and sequence checked. Chair exercises stand behind the chair; heel raising retains floor contact."
  ],
  "kind": "exercise-guidance"
 },
 "nautilus-pullover": {
  "title": [
   "Core Health & Fitness 官方产品资料",
   "Core Health & Fitness manufacturer information"
  ],
  "url": "https://www.corehandf.com/products/nautilus-inspiration-pull-over",
  "scope": [
   "已修正固定肩轴、肘垫接触和屈肘转动；尚未取得 IPPO3 对应的厂家人体演示。官网当前为 IPPO5，不能据此宣称 IPPO3 动作已获厂家验证。",
   "Fixed shoulder axis, elbow-pad contact and bent-elbow rotation corrected. No IPPO3-specific manufacturer human demonstration was obtained. The current IPPO5 page cannot validate an IPPO3 replica."
  ],
  "kind": "geometry-only"
 }
};
B.CourseContent={specifications,studies,motionReferences,version:2};
})();
