/* Experiment-only snapshots. This module never reads or writes the training store. */
(function (root, factory) {
  'use strict';
  var mechanics = typeof module === 'object' && module.exports ? require('./mechanics-core.js') : root && root.BM && root.BM.Mechanics;
  var api = factory(mechanics, root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) { root.BM = root.BM || {}; root.BM.MechanicsSnapshots = api; }
})(typeof window !== 'undefined' ? window : null, function (M, root) {
  'use strict';
  if (!M) throw new Error('实验计算内核尚未加载。');
  var KEY = 'bmmd_mechanics_snapshots_v1';
  var FORMAT = 'bmmd-mechanics-snapshots';
  var VERSION = 1;
  var SOURCES = ['model-example', 'user-measured', 'manufacturer', 'assumed-range', 'unknown'];
  var MODELS = ['pulley', 'cam', 'incline'];
  var QUANTITIES = ['forceN', 'torqueNm'];
  var COLUMNS = ['progress', 'angleRad', 'displacementM', 'forceN', 'torqueNm', 'effectiveArmM', 'inputWorkJ', 'potentialJ', 'dissipatedJ', 'balanceResidualJ'];
  var UNITS = Object.assign({},M.units,{progress:'1',balanceResidualJ:'J'});
  var TOP = ['id','createdAt','modelVersion','schemaVersion','model','params','parameterSources','units','assumptions','progress','quantity','target','range','note','curve','search'];
  var MAX_BYTES = 10 * 1024 * 1024;
  var own = function (object, key) { return Object.prototype.hasOwnProperty.call(object, key); };
  var finite = function (value) { return typeof value === 'number' && Number.isFinite(value); };
  var clone = function (value) { return JSON.parse(JSON.stringify(value)); };
  function plain(value) { return Boolean(value) && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null); }
  function demand(condition, message) { if (!condition) throw new Error(message); }
  function stable(value) {
    if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
    if (plain(value)) return '{' + Object.keys(value).sort().map(function (key) { return JSON.stringify(key) + ':' + stable(value[key]); }).join(',') + '}';
    return JSON.stringify(value);
  }
  function safeTree(value) {
    var count = 0, seen = new Set();
    function visit(item, depth) {
      demand(++count <= 100000 && depth <= 16, '实验档案层级或内容过多。');
      if (item === null || typeof item === 'boolean') return;
      if (typeof item === 'number') { demand(finite(item), '实验档案包含非有限数值。'); return; }
      if (typeof item === 'string') { demand(item.length <= 10000, '实验档案文字过长。'); return; }
      demand(plain(item) || Array.isArray(item), '实验档案只允许普通 JSON 数据。');
      demand(!seen.has(item), '实验档案不能包含循环引用。'); seen.add(item);
      if (Array.isArray(item)) {
        demand(item.length <= 3000, '实验档案数组过长。');
        demand(Reflect.ownKeys(item).every(function(key){return key==='length' || typeof key==='string' && /^(0|[1-9]\d*)$/.test(key) && Number(key)<item.length;}), '实验档案数组含未知字段。');
        for (var index=0;index<item.length;index++) {
          var child = Object.getOwnPropertyDescriptor(item,String(index));
          demand(child && !child.get && !child.set,'实验档案不允许稀疏数组或访问器。');
          visit(child.value,depth+1);
        }
      } else {
        demand(Reflect.ownKeys(item).length <= 100, '实验档案字段过多。');
        Reflect.ownKeys(item).forEach(function (key) {
          demand(typeof key === 'string' && ['__proto__','prototype','constructor'].indexOf(key) < 0, '实验档案包含不安全字段。');
          var descriptor = Object.getOwnPropertyDescriptor(item, key);
          demand(descriptor && !descriptor.get && !descriptor.set, '实验档案不允许访问器字段。');
          visit(descriptor.value, depth + 1);
        });
      }
      seen.delete(item);
    }
    visit(value, 0);
  }
  function exactKeys(value, keys, label) {
    demand(plain(value), label + '必须为对象。');
    demand(stable(Object.keys(value).sort()) === stable(keys.slice().sort()), label + '字段不完整或含未知字段。');
  }
  function validSources(model, params, parameterSources) {
    var keys = Object.keys(M.defaults[model]);
    exactKeys(params.sources, keys, '参数来源'); exactKeys(parameterSources, keys, '参数来源副本');
    keys.forEach(function (key) { demand(SOURCES.indexOf(params.sources[key]) >= 0, key + ' 的输入来源无效。'); });
    demand(stable(params.sources) === stable(parameterSources), '两份参数来源不一致。');
  }
  function scalar(row) {
    return { progress: row.progress, angleRad: row.angleRad, displacementM: row.displacementM,
      forceN: row.forceN, torqueNm: row.torqueNm, effectiveArmM: row.effectiveArmM,
      inputWorkJ: row.energy.inputWorkJ, potentialJ: row.energy.potentialJ,
      dissipatedJ: row.energy.dissipatedJ, balanceResidualJ: row.energy.balanceResidualJ };
  }
  function validSearch(value, model) {
    if (value === null) return;
    demand(plain(value), '搜索记录必须为对象或空值。');
    if (own(value,'model')) demand(value.model === model, '搜索记录与快照模型不同。');
    if (own(value,'version')) demand(value.version === M.version, '搜索记录模型版本不支持。');
    if (own(value,'quantity')) demand(QUANTITIES.indexOf(value.quantity) >= 0, '搜索记录物理量无效。');
    if (own(value,'bestParams')) demand(M.normalize(model,value.bestParams).valid, '搜索记录最优参数超出模型范围。');
    ['beforeError','afterError'].forEach(function (key) { if (own(value,key)) demand(value[key] === null || finite(value[key]) && value[key] >= 0, '搜索记录误差无效。'); });
    ['evaluated','candidates'].forEach(function (key) { if (own(value,key)) demand(Number.isInteger(value[key]) && value[key] >= 0 && value[key] <= 1000000, '搜索候选数量无效。'); });
    if (own(value,'evaluated') && own(value,'candidates')) demand(value.evaluated <= value.candidates, '已搜索数量不能超过候选数。');
    demand(value.globallyOptimal !== true, '当前网格搜索不能标为全局最优。');
  }
  function validate(input) {
    try {
      safeTree(input); exactKeys(input, TOP, '实验快照');
      demand(input.schemaVersion === VERSION, '实验快照格式版本不支持。');
      demand(input.modelVersion === M.version, '实验快照模型版本不支持；未自动改写旧模型结果。');
      demand(MODELS.indexOf(input.model) >= 0, '实验快照只支持滑轮、理想有效力臂和斜面模型。');
      demand(typeof input.id === 'string' && /^exp_[A-Za-z0-9_-]{8,100}$/.test(input.id), '实验快照 ID 无效。');
      demand(typeof input.createdAt === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(input.createdAt) && new Date(input.createdAt).toISOString() === input.createdAt, '实验快照日期无效。');
      exactKeys(input.params,Object.keys(M.defaults[input.model]).concat('sources'),'实验参数');
      var normal = M.normalize(input.model,input.params);
      demand(normal.valid, normal.reasons.join(' ')); validSources(input.model,input.params,input.parameterSources);
      demand(stable(input.units) === stable(UNITS), '实验单位表与当前模型不一致。');
      demand(stable(input.assumptions) === stable(M.assumptions[input.model]), '实验假设与当前模型版本不一致。');
      demand(finite(input.progress) && input.progress >= 0 && input.progress <= 1, '实验姿态必须在 0 到 1 内。');
      demand(QUANTITIES.indexOf(input.quantity) >= 0, '实验曲线物理量无效。');
      demand(Array.isArray(input.range) && input.range.length === 2 && input.range.every(function(v){ return finite(v) && v >= 0 && v <= 1; }), '积分范围无效。');
      demand(typeof input.note === 'string' && input.note.length <= 4000, '实验备注须为不超过 4000 字符的文字。');
      demand(Array.isArray(input.target) && (input.target.length === 0 || input.target.length >= 2 && input.target.length <= 21), '目标控制点数量无效。');
      input.target.forEach(function (point, i) {
        exactKeys(point,['progress','value'],'目标控制点');
        demand(finite(point.progress) && point.progress >= 0 && point.progress <= 1 && finite(point.value) && Math.abs(point.value) <= 10000000, '目标控制点包含非法位置或数值。');
        demand(i === 0 || input.target[i-1].progress < point.progress, '目标控制点应按位置严格递增。');
      });
      demand(Array.isArray(input.curve) && input.curve.length === 121, '实验曲线必须包含 121 个完整样本。');
      input.curve.forEach(function (row, i) {
        exactKeys(row,COLUMNS,'曲线样本');
        var expected = scalar(M.evaluate(input.model,input.params,i/120));
        COLUMNS.forEach(function(key){ demand(finite(row[key]) && Math.abs(row[key]-expected[key]) <= 1e-9*Math.max(1,Math.abs(expected[key])), '曲线样本 ' + i + ' 的 ' + key + ' 与参数/单位不一致。'); });
      });
      validSearch(input.search,input.model);
      return {ok:true,error:null,snapshot:clone(input)};
    } catch (error) { return {ok:false,error:error instanceof Error ? error.message : String(error),snapshot:null}; }
  }
  function create(input) {
    input = input || {}; safeTree(input);
    demand(MODELS.indexOf(input.model) >= 0,'请选择有效实验模型。');
    var normalized = M.normalize(input.model,input.params || {});
    demand(normalized.valid,normalized.reasons.join(' '));
    if (input.params) {
      demand(plain(input.params),'实验参数必须为对象。');
      Object.keys(input.params).forEach(function(key){demand(own(M.defaults[input.model],key)||key==='sources','实验参数含未知字段：'+key);});
      if (input.params.sources) Object.keys(input.params.sources).forEach(function(key){demand(own(M.defaults[input.model],key),'参数来源含未知字段。');});
    }
    var idPart = root && root.crypto && typeof root.crypto.randomUUID === 'function' ? root.crypto.randomUUID() : Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,12);
    var params = Object.assign({},normalized.params,{sources:clone(normalized.sources)});
    var snap = {id:'exp_'+idPart,createdAt:new Date().toISOString(),modelVersion:M.version,schemaVersion:VERSION,
      model:input.model,params:params,parameterSources:clone(normalized.sources),units:clone(UNITS),assumptions:M.assumptions[input.model].slice(),
      progress:input.progress === undefined ? 0 : input.progress,quantity:input.quantity || (input.model === 'cam' ? 'torqueNm' : 'forceN'),
      target:clone(input.target || []),range:clone(input.range || [0,1]),note:input.note === undefined ? '' : input.note,
      curve:M.sample(input.model,params,121).map(scalar),search:input.search == null ? null : clone(input.search)};
    var checked = validate(snap); demand(checked.ok,checked.error); return checked.snapshot;
  }
  function storage() {
    var store = root && root.localStorage;
    demand(store && typeof store.getItem === 'function' && typeof store.setItem === 'function','浏览器本机存储不可用，实验快照未保存。');
    return store;
  }
  function load() {
    try {
      var raw = storage().getItem(KEY);
      if (raw === null) return {ok:true,error:null,snapshots:[]};
      demand(typeof raw === 'string' && raw.length <= MAX_BYTES,'实验快照库过大；未改写现有内容。');
      var parsed = JSON.parse(raw), rows;
      if (Array.isArray(parsed)) rows = parsed;
      else { exactKeys(parsed,['format','schemaVersion','snapshots'],'实验快照库'); demand(parsed.format === FORMAT && parsed.schemaVersion === VERSION,'实验快照库格式不支持。'); rows=parsed.snapshots; }
      demand(Array.isArray(rows) && rows.length <= 1000,'实验快照列表无效或超过 1000 项；原内容保持。');
      var ids = new Set(), snapshots = rows.map(function(row){ var result=validate(row); demand(result.ok,result.error); demand(!ids.has(row.id),'实验快照库含重复 ID。'); ids.add(row.id); return result.snapshot; });
      return {ok:true,error:null,snapshots:snapshots};
    } catch(error) { return {ok:false,error:'无法读取实验快照：'+(error instanceof Error ? error.message : String(error)),snapshots:[]}; }
  }
  function save(snapshot) {
    var checked = validate(snapshot);
    if (!checked.ok) return {ok:false,error:checked.error,snapshot:null};
    var previous = load(); if (!previous.ok) return {ok:false,error:previous.error,snapshot:null};
    try {
      var existing = previous.snapshots.find(function(row){return row.id === checked.snapshot.id;});
      if (existing) { demand(stable(existing) === stable(checked.snapshot),'相同 ID 的快照内容不同；旧快照保持，请创建新快照。'); return {ok:true,error:null,snapshot:clone(existing),snapshots:previous.snapshots,count:previous.snapshots.length,alreadySaved:true}; }
      demand(previous.snapshots.length < 1000,'本机实验快照已达 1000 项；请导出，现有快照没有被删除。');
      var rows = previous.snapshots.concat([checked.snapshot]);
      var payload = JSON.stringify({format:FORMAT,schemaVersion:VERSION,snapshots:rows});
      demand(payload.length <= MAX_BYTES,'本机实验快照超过容量上限；请导出，旧快照保持。');
      var store = storage(); store.setItem(KEY,payload);
      demand(store.getItem(KEY)===payload,'存储写入未获确认，请保留并导出当前快照。');
      return {ok:true,error:null,snapshot:checked.snapshot,snapshots:rows,count:rows.length,alreadySaved:false};
    } catch(error) { return {ok:false,error:'无法保存实验快照：'+(error instanceof Error ? error.message : String(error)),snapshot:null}; }
  }
  function json(snapshot) { var result=validate(snapshot); demand(result.ok,result.error); return JSON.stringify(result.snapshot,null,2); }
  function csv(snapshot) {
    var result=validate(snapshot); demand(result.ok,result.error); var s=result.snapshot;
    // Text beginning with spreadsheet formula markers is forced to text. Numeric
    // physical columns stay numeric, including legitimate signed forces/work.
    function cell(value) { var text=String(value == null ? '' : value); if (typeof value !== 'number' && /^[\s]*[=+\-@]/.test(text)) text="'"+text; return '"'+text.replace(/"/g,'""')+'"'; }
    var header=['record_type','key','value','unit','source'].concat(COLUMNS.map(function(key){return key+' ['+UNITS[key]+']';}));
    var rows=[header];
    function metadata(key,value,unit,source){rows.push(['metadata',key,value,unit||'',source||''].concat(COLUMNS.map(function(){return '';})));}
    ['id','createdAt','modelVersion','schemaVersion','model','quantity','progress','note'].forEach(function(key){metadata(key,s[key],UNITS[key]||'');});
    metadata('range',JSON.stringify(s.range),'normalized progress'); metadata('target',JSON.stringify(s.target),UNITS[s.quantity]);
    metadata('search',JSON.stringify(s.search));
    s.assumptions.forEach(function(value,i){metadata('assumption.'+i,value);});
    Object.keys(M.defaults[s.model]).forEach(function(key){metadata('params.'+key,s.params[key],M.units[key],s.parameterSources[key]);});
    s.curve.forEach(function(row,i){rows.push(['sample',i,'','',''].concat(COLUMNS.map(function(key){return row[key];})));});
    return '\uFEFF'+rows.map(function(row){return row.map(cell).join(',');}).join('\r\n');
  }
  return {key:KEY,format:FORMAT,schemaVersion:VERSION,sources:SOURCES.slice(),columns:COLUMNS.slice(),create:create,validate:validate,load:load,save:save,csv:csv,json:json};
});
