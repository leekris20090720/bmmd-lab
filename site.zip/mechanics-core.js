/* Shared, SI-only, quasi-static model kernel. No DOM, storage, rendering or training data. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) { root.BM = root.BM || {}; root.BM.Mechanics = api; }
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  var VERSION = 'mechanics-1.0.0';
  var G = 9.81;
  var PI = Math.PI;
  var defaults = {
    pulley: { massKg: 40, ratio: 2, handleTravelM: 0.8 },
    cam: { massKg: 30, baseArmM: 0.12, eccentricity: 0.5, phaseRad: 0, leverM: 0.5, startAngleRad: 0, sweepRad: PI },
    incline: { massKg: 80, inclineRad: PI / 4, friction: 0.12, travelM: 0.8, direction: 'up' }
  };
  var bounds = {
    pulley: { massKg: [0, 300], ratio: [1, 4], handleTravelM: [0.05, 2] },
    cam: { massKg: [0, 300], baseArmM: [0, 0.4], eccentricity: [0, 0.85], phaseRad: [-PI, PI], leverM: [0.1, 1.4], startAngleRad: [-PI, PI], sweepRad: [PI / 12, 2 * PI] },
    incline: { massKg: [0, 500], inclineRad: [0, PI / 2], friction: [0, 1], travelM: [0.05, 3] }
  };
  function field(model, key, label, unit, step, extra) {
    var b = bounds[model][key];
    return Object.assign({ key: key, label: label, unit: unit, min: b ? b[0] : null, max: b ? b[1] : null, step: step, kind: 'number' }, extra || {});
  }
  var schema = {
    pulley: [field('pulley', 'massKg', '模型配重', 'kg', 1), field('pulley', 'ratio', '理想传动比', '', 1, { kind: 'select', options: [1, 2, 4] }), field('pulley', 'handleTravelM', '手柄实际行程', 'm', 0.01)],
    cam: [field('cam', 'massKg', '模型配重', 'kg', 1), field('cam', 'baseArmM', '基准有效力臂 r₀', 'm', 0.005), field('cam', 'eccentricity', '有效力臂变化系数 k', '', 0.01), field('cam', 'phaseRad', '相位 φ', 'rad', 0.01), field('cam', 'leverM', '手柄臂长 L', 'm', 0.01), field('cam', 'startAngleRad', '起始角 θ₀', 'rad', 0.01), field('cam', 'sweepRad', '转角范围 Δθ', 'rad', 0.01)],
    incline: [field('incline', 'massKg', '滑车与负载总质量', 'kg', 1), field('incline', 'inclineRad', '轨道倾角 β', 'rad', 0.01), field('incline', 'friction', '动摩擦系数 μ', '', 0.01), field('incline', 'travelM', '轨道实际行程', 'm', 0.01), { key: 'direction', label: '准静态运动方向', unit: '', kind: 'select', options: ['up', 'down'] }]
  };
  var units = { massKg: 'kg', ratio: '1', handleTravelM: 'm', baseArmM: 'm', eccentricity: '1', phaseRad: 'rad', leverM: 'm', startAngleRad: 'rad', sweepRad: 'rad', inclineRad: 'rad', friction: '1', travelM: 'm', direction: '1', angleRad: 'rad', displacementM: 'm', forceN: 'N', torqueNm: 'N·m', effectiveArmM: 'm', inputWorkJ: 'J', potentialJ: 'J', dissipatedJ: 'J' };
  var assumptions = {
    pulley: ['理想、无质量、不可伸长钢索；无摩擦滑轮。', '定传动比线性传动；手柄向下位移 x，配重向上位移 x/n。', '准静态，忽略加速度、转动惯量与人体关节力矩。'],
    cam: ['理想有效力臂传动族：d(θ)=r₀[1+k sin(θ+φ)]。', 'd 是转轴到钢索力作用线的垂距，不是轮廓极径。未求解接触、切线或制造轮廓。', '钢索张力为 mg；忽略摩擦、惯性与钢索伸长，手柄力沿半径的垂直方向。'],
    incline: ['直轨道、恒定动摩擦系数；准静态，忽略加速度与惯性附加力。', '外力沿轨道作用，支持力 N=mg cosβ。', '摩擦始终反向于规定运动；静止时的静摩擦平衡不在本模型内。']
  };
  function finite(n) { return typeof n === 'number' && Number.isFinite(n); }
  function clamp(n, lo, hi) { return Math.min(hi, Math.max(lo, n)); }
  function vec(x, y, z) { return { x: x || 0, y: y || 0, z: z || 0 }; }
  function scale(v, f) { return vec(v.x * f, v.y * f, v.z * f); }
  function add(a, b) { return vec(a.x + b.x, a.y + b.y, a.z + b.z); }
  function force(id, label, origin, vector, body) {
    var symbols = { external: 'F', cable: 'T', reaction: 'R', gravity: 'mg', normal: 'N', friction: 'f' };
    return { id: id, name: label, label: label, symbol: symbols[id] || id, origin: origin, vector: vector, magnitudeN: Math.hypot(vector.x, vector.y, vector.z), body: body };
  }
  function normalize(model, input) {
    var reasons = [], out = {}, sources = {};
    if (!Object.prototype.hasOwnProperty.call(defaults, model)) return { model: model, params: out, sources: sources, valid: false, reasons: ['未知模型。'] };
    input = input || {};
    Object.keys(defaults[model]).forEach(function (key) {
      var supplied = Object.prototype.hasOwnProperty.call(input, key);
      var value = supplied ? input[key] : defaults[model][key];
      var b = bounds[model][key];
      if (b && (!finite(value) || value < b[0] || value > b[1])) reasons.push(key + ' 超出有效范围 [' + b[0] + ', ' + b[1] + ']。');
      if (key === 'ratio' && [1, 2, 4].indexOf(value) < 0) reasons.push('理想传动比仅支持 1、2、4。');
      if (key === 'direction' && value !== 'up' && value !== 'down') reasons.push('运动方向必须为 up 或 down。');
      out[key] = b && !finite(value) ? null : key === 'direction' && value !== 'up' && value !== 'down' ? null : value;
      sources[key] = input.sources && typeof input.sources[key] === 'string' ? input.sources[key] : 'model-example';
    });
    return { model: model, params: out, sources: sources, valid: reasons.length === 0, reasons: reasons };
  }
  function empty(model, normalized, progress, reasons) {
    return { version: VERSION, model: model, valid: false, reasons: reasons, params: normalized.params, sources: normalized.sources, progress: finite(progress) ? progress : null, angleRad: null, displacementM: null, position: null, forces: [], effectiveArmM: null, torqueNm: null, forceN: null, energy: null, assumptions: assumptions[model] ? assumptions[model].slice() : [], domain: { progress: [0, 1], parameters: bounds[model] || {} }, geometry: null, units: units };
  }
  function evaluate(model, input, progress) {
    if (progress === undefined) progress = 0;
    var normalized = normalize(model, input), reasons = normalized.reasons.slice();
    if (!finite(progress) || progress < 0 || progress > 1) reasons.push('归一化进度必须在 0 到 1 内。');
    if (reasons.length) return empty(model, normalized, progress, reasons);
    var p = normalized.params, weight = p.massKg * G;
    var result = { version: VERSION, model: model, valid: true, reasons: [], params: p, sources: normalized.sources, progress: progress, angleRad: 0, displacementM: 0, position: {}, forces: [], effectiveArmM: 0, torqueNm: 0, forceN: 0, energy: {}, assumptions: assumptions[model].slice(), domain: { progress: [0, 1], parameters: bounds[model], quantityAxis: model === 'cam' ? 'angleRad' : 'displacementM', axisUnit: model === 'cam' ? 'rad' : 'm' }, geometry: {}, units: units };
    if (model === 'pulley') {
      var x = progress * p.handleTravelM, h = x / p.ratio, tension = weight / p.ratio;
      // Keep the entire permitted load stroke below the fixed block. This is
      // schematic clearance, not an inferred dimension of a commercial machine.
      var topY = Math.max(0.8, 0.6 + p.handleTravelM / p.ratio);
      var handle = vec(-0.35, 0.4 - x), load = vec(0.35, -0.2 + h), fixed = vec(0, topY);
      result.displacementM = x;
      result.forceN = tension;
      result.position = { handle: handle, load: load, pivot: fixed, analysis: handle };
      result.forces = [force('external', '手柄外力 F', handle, vec(0, -tension), 'handle'), force('cable', '钢索张力 T', handle, vec(0, tension), 'handle')];
      result.energy = { inputWorkJ: tension * x, potentialJ: weight * h, dissipatedJ: 0, kineticJ: 0, balanceResidualJ: tension * x - weight * h, roundTripDissipatedJ: 0, loadDisplacementM: h };
      result.geometry = { kind: 'ideal-linear-transmission', analysisBody: 'handle', ratio: p.ratio, fixedPulley: fixed, pulleyCenters: [vec(-0.35, topY), vec(0.35, topY)], handle: handle, load: load, cableDirection: vec(0, 1), handleDirection: vec(0, -1), loadDisplacementM: h, handleTravelM: x, loadWeightN: weight, supportTotalN: weight, cableTensionN: tension, usesRotationalCoordinate: false, schematicClearanceM: topY - (-0.2 + p.handleTravelM / p.ratio) };
    } else if (model === 'cam') {
      var theta0 = p.startAngleRad, theta = theta0 + progress * p.sweepRad;
      var d = p.baseArmM * (1 + p.eccentricity * Math.sin(theta + p.phaseRad));
      var lift = p.baseArmM * ((theta - theta0) - p.eccentricity * (Math.cos(theta + p.phaseRad) - Math.cos(theta0 + p.phaseRad)));
      var torque = weight * d, handleForce = torque / p.leverM;
      var origin = vec(0, 0), camHandle = vec(p.leverM * Math.cos(theta), p.leverM * Math.sin(theta));
      var applied = vec(-handleForce * Math.sin(theta), handleForce * Math.cos(theta));
      var cablePoint = vec(d, 0), cableForce = vec(0, -weight), reaction = scale(add(applied, cableForce), -1);
      result.angleRad = theta;
      result.displacementM = lift;
      result.effectiveArmM = d;
      result.torqueNm = torque;
      result.forceN = handleForce;
      result.position = { handle: camHandle, load: vec(d, -0.4 + lift), pivot: origin, analysis: origin, cableContact: cablePoint };
      result.forces = [force('external', '切向手柄力 F', camHandle, applied, 'ideal-transmission'), force('cable', '钢索张力 mg', cablePoint, cableForce, 'ideal-transmission'), force('reaction', '轴反力 R', origin, reaction, 'ideal-transmission')];
      result.energy = { inputWorkJ: weight * lift, potentialJ: weight * lift, dissipatedJ: 0, kineticJ: 0, balanceResidualJ: 0, roundTripDissipatedJ: 0, loadDisplacementM: lift };
      result.geometry = { kind: 'ideal-effective-arm', analysisBody: 'ideal-transmission', pivot: origin, handle: camHandle, cableContact: cablePoint, cableLine: [vec(d, -0.5), vec(d, 0.5)], armLine: [origin, cablePoint], handleDirection: vec(-Math.sin(theta), Math.cos(theta)), leverM: p.leverM, angleRad: theta, loadDisplacementM: lift, manufactureProfileSolved: false };
      result.domain.angleRad = [theta0, theta0 + p.sweepRad];
    } else {
      var beta = p.inclineRad, s = progress * p.travelM, down = p.direction === 'down';
      var tangent = vec(Math.cos(beta), Math.sin(beta)), normal = vec(-Math.sin(beta), Math.cos(beta));
      var gravityAlong = weight * Math.sin(beta), support = weight * Math.cos(beta), friction = p.friction * support;
      var external = gravityAlong + (down ? -friction : friction);
      var coordinate = down ? p.travelM - s : s, sled = scale(tangent, coordinate);
      var frictionSigned = down ? friction : -friction;
      var potential = (down ? -1 : 1) * gravityAlong * s, dissipated = friction * s, work = (down ? -1 : 1) * external * s;
      result.angleRad = beta;
      result.displacementM = s;
      result.forceN = external;
      result.position = { handle: sled, load: sled, pivot: vec(0, 0), analysis: sled };
      result.forces = [force('external', '沿轨道外力 F（向上为正）', sled, scale(tangent, external), 'sled'), force('gravity', '重力 mg', sled, vec(0, -weight), 'sled'), force('normal', '支持力 N', sled, scale(normal, support), 'sled'), force('friction', '动摩擦 f', sled, scale(tangent, frictionSigned), 'sled')];
      result.energy = { inputWorkJ: work, potentialJ: potential, dissipatedJ: dissipated, kineticJ: 0, balanceResidualJ: work - potential - dissipated, roundTripDissipatedJ: 2 * friction * p.travelM, loadDisplacementM: (down ? -1 : 1) * s };
      result.geometry = { kind: 'inclined-slider', analysisBody: 'sled', trackStart: vec(0, 0), trackEnd: scale(tangent, p.travelM), sled: sled, tangent: tangent, normal: normal, gravityAlongN: gravityAlong, normalN: support, frictionN: friction, upForceN: gravityAlong + friction, downForceN: gravityAlong - friction, signedTrackCoordinateM: coordinate, signedTravelM: (down ? -1 : 1) * s, direction: p.direction, naturallySlidesDown: gravityAlong > friction, requiresDownPull: friction > gravityAlong, motionNotice: friction > gravityAlong ? '摩擦大于沿轨道重力；规定下行时需要向下拉动，不能自然滑下。' : '本模型规定准静态运动，不求解自由滑下的加速度。' };
    }
    result.analysisBody = result.geometry.analysisBody;
    return result;
  }
  function sample(model, params, count) {
    count = count === undefined ? 121 : count;
    if (!Number.isInteger(count) || count < 2 || count > 5001) throw new RangeError('采样数须为 2 到 5001 的整数。');
    var output = [];
    for (var i = 0; i < count; i++) output.push(evaluate(model, params, i / (count - 1)));
    return output;
  }
  function coordinateDomain(model, params) {
    var normalized = normalize(model, params), rotational = model === 'cam';
    if (!normalized.valid) return { valid: false, key: rotational ? 'angleRad' : 'displacementM', unit: rotational ? 'rad' : 'm', min: null, max: null, reasons: normalized.reasons };
    var p = normalized.params, min = rotational ? p.startAngleRad : 0;
    return { valid: true, key: rotational ? 'angleRad' : 'displacementM', unit: rotational ? 'rad' : 'm', min: min, max: rotational ? min + p.sweepRad : model === 'pulley' ? p.handleTravelM : p.travelM, reasons: [] };
  }
  function atCoordinate(model, params, coordinate) {
    var domain = coordinateDomain(model, params);
    if (!domain.valid) return evaluate(model, params, 0);
    var tolerance = 1e-12 * Math.max(1, Math.abs(domain.min), Math.abs(domain.max));
    if (!finite(coordinate) || coordinate < domain.min - tolerance || coordinate > domain.max + tolerance) {
      var invalid = evaluate(model, params, -1);
      invalid.reasons = ['实际物理坐标超出模型有效范围。'];
      invalid.progress = null;
      return invalid;
    }
    return evaluate(model, params, clamp((coordinate - domain.min) / (domain.max - domain.min), 0, 1));
  }
  function sampleCoordinates(model, params, coordinates) {
    if (!Array.isArray(coordinates) || coordinates.length < 1 || coordinates.length > 5001) throw new RangeError('物理坐标采样数组须含 1 到 5001 项。');
    return coordinates.map(function (coordinate) { return atCoordinate(model, params, coordinate); });
  }
  function axis(model, result) { return model === 'cam' ? result.angleRad : result.displacementM; }
  function derivative(model, params, progress, quantity) {
    quantity = quantity || 'torqueNm';
    var center = evaluate(model, params, progress);
    if (!center.valid || !finite(center[quantity])) return null;
    var step = 0.0001, a, b, dx;
    // Second-order one-sided differences avoid the first-order bias at domain ends.
    if (progress < step) {
      a = evaluate(model, params, progress + step); b = evaluate(model, params, progress + 2 * step);
      dx = axis(model, a) - axis(model, center);
      return dx ? (-3 * center[quantity] + 4 * a[quantity] - b[quantity]) / (2 * dx) : null;
    }
    if (progress > 1 - step) {
      a = evaluate(model, params, progress - step); b = evaluate(model, params, progress - 2 * step);
      dx = axis(model, center) - axis(model, a);
      return dx ? (3 * center[quantity] - 4 * a[quantity] + b[quantity]) / (2 * dx) : null;
    }
    a = evaluate(model, params, progress - step); b = evaluate(model, params, progress + step);
    dx = axis(model, b) - axis(model, a);
    return dx ? (b[quantity] - a[quantity]) / dx : null;
  }
  function integrateDetailed(model, params, start, end, segments, method) {
    if (start === undefined) start = 0;
    if (end === undefined) end = 1;
    if (segments === undefined) segments = 256;
    method = method || 'trapezoid';
    if (!Number.isInteger(segments) || segments < 1 || segments > 20000) throw new RangeError('积分分割数须为 1 到 20000。');
    if (['trapezoid', 'left', 'right', 'midpoint'].indexOf(method) < 0) throw new RangeError('未知积分方法。');
    var first = evaluate(model, params, start), last = evaluate(model, params, end);
    if (!first.valid || !last.valid) return { valid: false, valueJ: null, reasons: first.reasons.concat(last.reasons), method: method, segments: segments, variable: model === 'cam' ? 'θ / rad' : 'x / m' };
    var total = 0;
    for (var i = 0; i < segments; i++) {
      var pa = start + (end - start) * i / segments, pb = start + (end - start) * (i + 1) / segments;
      var a = evaluate(model, params, pa), b = evaluate(model, params, pb);
      var qa = model === 'cam' ? a.torqueNm : a.forceN, qb = model === 'cam' ? b.torqueNm : b.forceN;
      var q = method === 'left' ? qa : method === 'right' ? qb : method === 'midpoint' ? (function () { var m = evaluate(model, params, (pa + pb) / 2); return model === 'cam' ? m.torqueNm : m.forceN; })() : (qa + qb) / 2;
      var dx = axis(model, b) - axis(model, a);
      if (model === 'incline' && first.params.direction === 'down') dx *= -1;
      total += q * dx;
    }
    return { valid: true, valueJ: total, method: method, segments: segments, start: start, end: end, variable: model === 'cam' ? 'θ / rad' : 'x / m', integrand: model === 'cam' ? 'τ / N·m' : 'F / N', direction: model === 'incline' ? first.params.direction : 'positive-model-direction', exactEnergyDifferenceJ: last.energy.inputWorkJ - first.energy.inputWorkJ, errorJ: total - (last.energy.inputWorkJ - first.energy.inputWorkJ) };
  }
  function integrate(model, params, start, end, segments, method) { return integrateDetailed(model, params, start, end, segments, method).valueJ; }
  function pointValue(point) { return point && finite(point.value) ? point.value : point && finite(point.y) ? point.y : null; }
  function targetValue(points, progress) {
    if (!Array.isArray(points) || !finite(progress)) return null;
    var clean = points.filter(function (p) { return p && finite(p.progress) && pointValue(p) !== null; }).slice().sort(function (a, b) { return a.progress - b.progress; });
    if (!clean.length) return null;
    if (progress <= clean[0].progress) return pointValue(clean[0]);
    for (var i = 1; i < clean.length; i++) if (progress <= clean[i].progress) {
      var a = clean[i - 1], b = clean[i], dx = b.progress - a.progress;
      return dx ? pointValue(a) + (pointValue(b) - pointValue(a)) * (progress - a.progress) / dx : pointValue(b);
    }
    return pointValue(clean[clean.length - 1]);
  }
  function normalizedRMSE(predicted, target, quantity) {
    quantity = quantity || 'forceN';
    if (!Array.isArray(predicted) || !predicted.length) return Infinity;
    var squared = 0, targetSquared = 0;
    for (var i = 0; i < predicted.length; i++) {
      var row = predicted[i], desired = targetValue(target, row.progress), actual = row[quantity];
      if (row.valid === false || !finite(actual) || !finite(desired)) return Infinity;
      squared += Math.pow(actual - desired, 2); targetSquared += desired * desired;
    }
    return Math.sqrt(squared / predicted.length) / Math.max(1, Math.sqrt(targetSquared / predicted.length));
  }
  function searchGrid(model) {
    var grid = {};
    if (model === 'cam') {
      grid.baseArmM = [0, 0.025, 0.05, 0.075, 0.1, 0.125, 0.15, 0.2, 0.25, 0.3, 0.4];
      grid.eccentricity = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.85];
      grid.phaseRad = [];
      for (var i = 0; i < 17; i++) grid.phaseRad.push(-PI + i * PI / 8);
    } else if (model === 'pulley') grid.ratio = [1, 2, 4];
    else if (model === 'incline') {
      grid.inclineRad = [0, PI / 18, PI / 12, PI / 9, PI / 6, PI / 4, PI / 3, 5 * PI / 12, PI / 2];
      grid.friction = [0, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.6, 0.8, 1];
    }
    return grid;
  }
  function turn() { return new Promise(function (resolve) { setTimeout(resolve, 0); }); }
  async function search(model, params, target, options) {
    options = options || {};
    var normalized = normalize(model, params), quantity = options.quantity || (model === 'cam' ? 'torqueNm' : 'forceN');
    if (!normalized.valid) return { valid: false, reasons: normalized.reasons, cancelled: false, bestParams: normalized.params, beforeError: null, afterError: null, evaluated: 0, candidates: 0 };
    var grid = searchGrid(model), keys = Object.keys(grid), candidates = 1;
    keys.forEach(function (key) { candidates *= grid[key].length; });
    var bestParams = Object.assign({}, normalized.params), before = normalizedRMSE(sample(model, params, 61), target, quantity), best = before, evaluated = 0, cancelled = false;
    if (!finite(before)) return { valid: false, reasons: ['目标控制点或物理量无效。'], cancelled: false, bestParams: bestParams, beforeError: null, afterError: null, evaluated: 0, candidates: candidates };
    for (var index = 0; index < candidates; index++) {
      if (options.signal && options.signal.aborted) { cancelled = true; break; }
      var candidate = Object.assign({}, normalized.params), cursor = index;
      keys.forEach(function (key) { var choices = grid[key]; candidate[key] = choices[cursor % choices.length]; cursor = Math.floor(cursor / choices.length); });
      var error = normalizedRMSE(sample(model, candidate, 61), target, quantity);
      if (error < best) { best = error; bestParams = candidate; }
      evaluated++;
      if (evaluated % 24 === 0 || evaluated === candidates) {
        if (typeof options.onProgress === 'function') options.onProgress({ evaluated: evaluated, candidates: candidates, progress: evaluated / candidates, bestError: best });
        await turn();
      }
    }
    return { valid: true, version: VERSION, model: model, bestParams: bestParams, beforeError: before, afterError: best, evaluated: evaluated, candidates: candidates, cancelled: cancelled, method: 'bounded-grid-search', grid: grid, constraints: bounds[model], quantity: quantity, normalization: 'RMSE / max(1 SI unit, RMS target)', globallyOptimal: false, notice: '有界离散网格搜索，保留原设计作为候选；不是连续参数空间的全局最优。' };
  }
  function sensitivity(model, params, key, fraction, count, quantity, range) {
    fraction = fraction === undefined ? 0.05 : fraction;
    count = count === undefined ? 121 : count;
    quantity = quantity || 'forceN';
    var norm = normalize(model, params), b = bounds[model] && bounds[model][key];
    if (!norm.valid || !b || !finite(fraction) || fraction <= 0 || fraction > 1 || !Number.isInteger(count) || count < 2 || count > 5001 || !finite(evaluate(model, params, 0)[quantity]) || (range && (!finite(range[0]) || !finite(range[1]) || range[0] < 0 || range[0] > 1 || range[1] < 0 || range[1] > 1))) return { valid: false, reasons: ['请选择有效数值参数、物理量、采样数与 (0,1] 的扰动比例；积分范围须在 [0,1]。'] };
    var value = norm.params[key], delta = Math.max(Math.abs(value) * fraction, (b[1] - b[0]) * fraction * 0.1);
    var lowValue = clamp(value - delta, b[0], b[1]), highValue = clamp(value + delta, b[0], b[1]);
    if (key === 'ratio') { lowValue = value === 1 ? 1 : value === 2 ? 1 : 2; highValue = value === 4 ? 4 : value === 2 ? 4 : 2; }
    var lowParams = Object.assign({}, norm.params), highParams = Object.assign({}, norm.params);
    lowParams[key] = lowValue; highParams[key] = highValue;
    var baseline = sample(model, norm.params, count), low = sample(model, lowParams, count), high = sample(model, highParams, count);
    var scaleY = Math.max(1, Math.sqrt(baseline.reduce(function (sum, r) { return sum + r[quantity] * r[quantity]; }, 0) / count));
    var parameterScale = Math.abs(value) || (b[1] - b[0]);
    var baseDomain = coordinateDomain(model, norm.params), lowDomain = coordinateDomain(model, lowParams), highDomain = coordinateDomain(model, highParams);
    var commonMin = Math.max(baseDomain.min, lowDomain.min, highDomain.min), commonMax = Math.min(baseDomain.max, lowDomain.max, highDomain.max);
    var coordinates = [], normalizedCurve = [], comparisonSamples = { baseline: [], low: [], high: [] };
    if (commonMax > commonMin) {
      for (var i = 0; i < count; i++) coordinates.push(commonMin + (commonMax - commonMin) * i / (count - 1));
      comparisonSamples.baseline = sampleCoordinates(model, norm.params, coordinates);
      comparisonSamples.low = sampleCoordinates(model, lowParams, coordinates);
      comparisonSamples.high = sampleCoordinates(model, highParams, coordinates);
      normalizedCurve = coordinates.map(function (coordinate, i) { return { coordinate: coordinate, progress: (coordinate - baseDomain.min) / (baseDomain.max - baseDomain.min), value: highValue === lowValue ? 0 : (comparisonSamples.high[i][quantity] - comparisonSamples.low[i][quantity]) / (highValue - lowValue) * parameterScale / scaleY }; });
    }
    var start = range && finite(range[0]) ? range[0] : 0, end = range && finite(range[1]) ? range[1] : 1;
    var coordinateStart = baseDomain.min + start * (baseDomain.max - baseDomain.min), coordinateEnd = baseDomain.min + end * (baseDomain.max - baseDomain.min);
    var workLo = Math.max(commonMin, Math.min(coordinateStart, coordinateEnd)), workHi = Math.min(commonMax, Math.max(coordinateStart, coordinateEnd));
    var workRange = commonMax > commonMin && workHi >= workLo ? (end >= start ? [workLo, workHi] : [workHi, workLo]) : null;
    function summary(rows, p) {
      var peak = rows.reduce(function (a, row) { return row[quantity] > a[quantity] ? row : a; }, rows[0]);
      var domain = coordinateDomain(model, p);
      return { sampledPeak: peak[quantity], peakProgress: peak.progress, peakCoordinate: axis(model, peak), workJ: workRange ? integrate(model, p, (workRange[0] - domain.min) / (domain.max - domain.min), (workRange[1] - domain.min) / (domain.max - domain.min)) : null, extremaMethod: 'sampled' };
    }
    return { valid: true, parameter: key, baselineValue: value, lowValue: lowValue, highValue: highValue, baseline: baseline, low: low, high: high, normalizedCurve: normalizedCurve, comparisonSamples: comparisonSamples, commonDomain: commonMax > commonMin ? [commonMin, commonMax] : null, workRangeCoordinates: workRange, normalizedReason: commonMax > commonMin ? null : '三组输入没有长度大于零的共同物理坐标域；不计算跨域灵敏度或比较功。', normalization: '(Δquantity / RMS baseline quantity) / (Δparameter / reference parameter), at the same physical coordinate', referenceParameter: parameterScale, referenceQuantity: scaleY, summaries: { baseline: summary(baseline, norm.params), low: summary(low, lowParams), high: summary(high, highParams) } };
  }
  function uncertainty(model, params, key, min, max, count, quantity, steps) {
    count = count === undefined ? 121 : count; quantity = quantity || 'forceN'; steps = steps === undefined ? 17 : steps;
    var norm = normalize(model, params), b = bounds[model] && bounds[model][key];
    if (!norm.valid || !b || !finite(min) || !finite(max) || min > max || min < b[0] || max > b[1] || !Number.isInteger(steps) || steps < 2 || steps > 101 || !Number.isInteger(count) || count < 2 || count > 5001 || !finite(evaluate(model, params, 0)[quantity])) return { valid: false, reasons: ['输入范围超出参数边界、物理量或采样设置无效。'] };
    var envelope = [], values = [];
    for (var j = 0; j < steps; j++) { var v = min + (max - min) * j / (steps - 1); if (key !== 'ratio' || [1, 2, 4].indexOf(v) >= 0) values.push(v); }
    if (key === 'ratio') values = [1, 2, 4].filter(function (v) { return v >= min && v <= max; });
    if (!values.length) return { valid: false, reasons: ['范围内没有允许的离散传动比。'] };
    var inputs = values.map(function (value) { var input = Object.assign({}, norm.params); input[key] = value; return input; });
    var domains = inputs.map(function (input) { return coordinateDomain(model, input); }), baselineDomain = coordinateDomain(model, norm.params);
    var commonMin = Math.max.apply(null, domains.map(function (domain) { return domain.min; })), commonMax = Math.min.apply(null, domains.map(function (domain) { return domain.max; }));
    if (!(commonMax > commonMin)) return { valid: false, reasons: ['输入范围内的模型没有长度大于零的共同物理坐标域；不绘制范围包络。'], parameter: key, inputRange: [min, max], inputValues: values, commonDomain: null, envelope: [], quantity: quantity, isConfidenceInterval: false };
    for (var i = 0; i < count; i++) {
      var coordinate = commonMin + (commonMax - commonMin) * i / (count - 1), low = Infinity, high = -Infinity;
      inputs.forEach(function (input) { var result = atCoordinate(model, input, coordinate); low = Math.min(low, result[quantity]); high = Math.max(high, result[quantity]); });
      envelope.push({ coordinate: coordinate, progress: (coordinate - baselineDomain.min) / (baselineDomain.max - baselineDomain.min), min: low, max: high });
    }
    return { valid: true, parameter: key, inputRange: [min, max], inputValues: values, commonDomain: [commonMin, commonMax], envelope: envelope, quantity: quantity, method: 'bounded-input-grid-envelope', isConfidenceInterval: false, notice: '仅在所有输入共同物理域内绘制离散采样包络，不是统计置信区间；非单调关系的内部极值可能未被有限采样捕获。' };
  }
  return { version: VERSION, gravity: G, defaults: defaults, bounds: bounds, schema: schema, units: units, assumptions: assumptions, normalize: normalize, evaluate: evaluate, sample: sample, coordinateDomain: coordinateDomain, atCoordinate: atCoordinate, sampleCoordinates: sampleCoordinates, derivative: derivative, integrate: integrate, integrateDetailed: integrateDetailed, targetValue: targetValue, normalizedRMSE: normalizedRMSE, error: normalizedRMSE, search: search, sensitivity: sensitivity, uncertainty: uncertainty };
});
